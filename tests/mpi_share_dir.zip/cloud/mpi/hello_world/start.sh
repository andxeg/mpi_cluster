#!/bin/bash

make clean

make

mpirun -np 5 -hosts slave1,master ./mpi_hello_world
