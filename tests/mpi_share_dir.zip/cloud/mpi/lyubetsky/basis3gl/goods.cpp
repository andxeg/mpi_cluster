//	basis3GL:  A program for basis trees construction, v.2.X.X
//	The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/super3gl]
//	(C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
// E-mail: rubanov{at}iitp.ru
//	This program is free software: you can redistribute it and/or modify
//	it under the terms of the GNU General Public License as published by
//	the Free Software Foundation, either version 3 of the License, or
//	(at your option) any later version.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details.
//
//	You should have received a copy of the GNU General Public License
//	along with this program.  If not, see <http://www.gnu.org/licenses/>.

#include <iostream>
#include <iomanip>
#include <complex>
#include <limits>
#include "basis3gl.h"
#include "forest.h"
#include "config.h"

using namespace std;

// Shared variables
PSetMapIter	itv;
PSetMapIter pit, pit1, pit2;
PTree			tree;

// Finds good edges/nodes over all trees for each element of P set
void FindGoodEdges() {
	int v = 0;
	int mingood = numeric_limits<int>::max(), maxgood = 0; 
	double sum = 0.0, sqsum = 0.0, sumR = 0.0;
   int numgood;
	// Loop over elements of P
	for(itv = cfg->PSet.begin(); itv != cfg->PSet.end(); itv++) {
		// Milestones
		if(cfg->Milestones && (v++ & cfg->Milestones) == 0) 
			*Con << "V" << setfill(' ') << setw(5) << cfg->current_n 
            << " V_ " << setfill(' ') << setw(5) << v - 1 << " [" << sum << "]      \r" << flush;
      if( !itv->second.Basis )
         continue;
		// Loop over trees
		for(int t = 0; t < cfg->TreeNum; t++) {
			tree = cfg->GTree[t];
			if( !tree )		// removed tree
				continue;
         if((!cfg->Polytomy || tree->GetMaxDegree() <= 2) && 	   // binary case
            checkGood(tree->GetRoot())) {
               tree->IncrementGoodCount();
               (*itv).second.GoodEdge++;
         }
         else if(tree->GetMaxDegree() > 2) {                      // polytomous case 
            clearNodeFlag(tree->GetRoot());
            if(checkGoodPoly(tree->GetRoot())) {
               tree->IncrementGoodCount();
               (*itv).second.GoodEdge++;
            }
            countRV(tree->GetRoot());
            if(tree->GetRoot()->GetFlag())
			      (*itv).second.GoodNum++;      // for superroot
         }
		}
		sumR += (int)(*itv).second.GoodNum;
      numgood = (*itv).second.GoodEdge;
		if(numgood < mingood)
			mingood = numgood;
		if(numgood > maxgood)
			maxgood = numgood;
		sum += numgood;
		sqsum += (double)numgood * numgood;
	}
   if(cfg->LogIntermediate || cfg->ConIntermediate) {
	   // Compute statistic data of good edges/nodes over elements of PSet
	   int nelem = (int)cfg->PSet.size();
	   double m = sum / nelem;
	   double d = sqsum / nelem;
	   d -= m * m;
	   d = sqrt(d * nelem / (nelem - 1));
      if(cfg->ConIntermediate) {
	      *Con TSTAMP << "Good edges in total: " << fixed << setprecision(0) << sum << ", |R(V)|=" << sumR << endl; 
	      *Con TSTAMP << "Per clade: min=" << mingood << ", max=" << maxgood << ", average=" 
		      << fixed << setprecision(0) << m << ", stdev=" << d << "." << endl;
      }
      if(cfg->LogIntermediate) {
	      *Log TSTAMP << "Good edges in total: " << fixed << setprecision(0) << sum << ", |R(V)|=" << sumR << endl;
	      *Log TSTAMP << "Per clade: min=" << mingood << ", max=" << maxgood << ", average=" 
		      << fixed << setprecision(0) << m << ", stdev=" << d << "." << endl;
      }
	   // Compute statistic data of good edges/nodes over trees
	   mingood = numeric_limits<int>::max(); 
	   maxgood = 0;
	   sum = sqsum = 0.;
	   for(int t = 0; t < cfg->TreeNum; t++) {
		   // Milestones
		   if(cfg->Milestones && (t & cfg->Milestones) == 0)
			   *Con << "V" << setfill(' ') << setw(5) << cfg->current_n 
               << " T " << setfill(' ') << setw(4) << t << "      \r" << flush;
		   tree = cfg->GTree[t];
		   if(tree == NULL)
			   continue;
		   int numgood = tree->GetGoodCount();
		   if(numgood < mingood)
			   mingood = numgood;
		   if(numgood > maxgood)
			   maxgood = numgood;
		   sum += numgood;
		   sqsum += (double)numgood * numgood;
	   }
	   int numtree = cfg->TreeNum - cfg->TreePruned;
	   m = sum / numtree;
	   d = sqsum / numtree;
	   d -= m * m;
	   d = sqrt(d * numtree / (numtree - 1));
      if(cfg->ConIntermediate)
	      *Con TSTAMP << "Per tree: min=" << mingood << ", max=" << maxgood << ", average=" 
		      << fixed << setprecision(0) << m << ", stdev=" << d << "." << endl;
      if(cfg->LogIntermediate)
	      *Log TSTAMP << "Per tree: min=" << mingood << ", max=" << maxgood << ", average=" 
		      << fixed << setprecision(0) << m << ", stdev=" << d << "." << endl;
   }
};

// Checks if given node is the child of a good edge, and increments itv.GoodNum if so
bool checkGood(PNode node) {
	if(node->IsLeaf()) {
		if(IsContained((*itv).first, node->GetSpecies())) {
			(*itv).second.GoodNum++;
			return true;
		}
	}
	else {
		if(IsContained((*itv).first, *node->GetClade())) {
			(*itv).second.GoodNum++;
			return true;
		}
	}
	PNode child = node->GetChild();
	while(child) {
      if(checkGood(child)) {
			tree->IncrementGoodCount();
         (*itv).second.GoodEdge++;
      }
		child = child->GetSibling();
	}
	return false;
};

// Checks if given node of polytomous tree is the child of a good edge, and sets its flag
bool checkGoodPoly(PNode node) {
	if(node->IsLeaf()) {
		if(IsContained((*itv).first, node->GetSpecies())) {
         node->SetFlag();
			return true;
		}
	}
	else {
		if(IsContained((*itv).first, *node->GetClade())) {
         node->SetFlag();
			return true;
		}
	}
	PNode child = node->GetChild();
	while(child) {
      if(checkGoodPoly(child)) {
			tree->IncrementGoodCount();
         (*itv).second.GoodEdge++;
      }
		child = child->GetSibling();
	}
   node->SetFlag(false);
	return false;
}

// Uses node flags to calculate R(V) and increment itv.GoodNum
void countRV(PNode node) {
   if(node->IsLeaf())
      return;
   PNode child = node->GetChild();
	bool any = false;
   while(child) {
      countRV(child);
      if(child->GetFlag())
			any = true;
		child = child->GetSibling();
	}
   if(any)
      (*itv).second.GoodNum++;
};

// Clear flags from this node downwards
void clearNodeFlag(PNode node) {
   node->SetFlag(false);
   PNode child = node->GetChild();
   while(child) {
      clearNodeFlag(child);
		child = child->GetSibling();
   }
};

// Checks if given set contains a particular element
bool IsContained(const myset& Where, int What) {
	return Where.test(What);
};

// Checks if given set contains a particular subset
bool IsContained(const myset& Where, const myset& What) {
	if(What.count() > Where.count())
		return false;
	myset temp(Where);
	temp.intersect(What);
	return (temp == What);
};

// Returns |r(V1,V2)| for given V, V1, V2 and tree. Also computes e=|e(V1,V2)|.
int CountRV1V2(const PSetMapIter & V, const PSetMapIter & V1, const PSetMapIter & V2, PTree t, int *e) {
	pit = V; pit1 = V1; pit2 = V2;
	tree = t;
   *e = 0;
	//return cfg->Polytomy ? checkPolyRnode(tree->GetRoot(), e) : checkRnode(tree->GetRoot(), e);
   return tree->GetMaxDegree() > 2 ? checkPolyRnode(tree->GetRoot(), e) : checkRnode(tree->GetRoot(), e);
};

// Recursively checks if a binary tree node is to be counted in |r(V1,V2)|
// Also computes |e(V1,V2)|
int checkRnode(PNode node, int *e) {
	myset *clade, *lclade, *rclade, *rootclade, *parent;
   myset all;
	if(!node)
		return 0;
	int result = 0;
	bool any1 = false;
	bool any2 = false;
	clade = node->GetClade();
   // Calculate |e(V1,V2)|
   rootclade = tree->GetRoot()->GetClade();
   all.assign(*rootclade);
   all.intersect(pit2->first);
   any1 = false;
   if(all.count() == 0) {        // The tree is empty for V2
      if(node->IsLeaf()) {
			int sp = node->GetSpecies();
			if(IsContained(pit1->first, sp))
				any1 = true;
      }
      else if(IsContained(pit1->first, *clade)) {
         any1 = true;
      }
      if(any1) {
         if(!node->HasParent()) {
            (*e)++;                 // The node is good for V1
         }
         else {
            parent = node->GetParent()->GetClade();
            if(!IsContained(pit1->first, *parent))
               (*e)++;              // The node is good for V1
         }
      }
   }
   else {
      all.assign(*rootclade);
      all.intersect(pit1->first);
      if(all.count() == 0) {     // The tree is empty for V1
         if(node->IsLeaf()) {
			   int sp = node->GetSpecies();
			   if(IsContained(pit2->first, sp))
				   any2 = true;
         }
         else if(IsContained(pit2->first, *clade)) {
            any2 = true;
         }
         if(any2) {
            if(!node->HasParent()) {
               (*e)++;              // The node is good for V2
            }
            else {
               parent = node->GetParent()->GetClade();
               if(!IsContained(pit2->first, *parent))
                  (*e)++;           // The node is good for V2
            }
         }
      }
   }
   // Now compute |r(V1,V2)|
	if(node->IsLeaf())
		return 0;
	PNode left = node->GetChild();
   if(!left)
      throw("checkRnode: Inner childless node encountered.");
	PNode right = left->GetSibling();
	if(IsContained(pit->first, *clade) && 						// detailed check of the node
		!IsContained(pit1->first, *clade) && !IsContained(pit2->first, *clade)) {
		if(!left->IsLeaf()) { 
			lclade = left->GetClade();
			if(IsContained(pit1->first, *lclade)) 
				any1 = true;
			else if(IsContained(pit2->first, *lclade)) 
				any2 = true;
		}
		else {
			int sp = left->GetSpecies();
			if(IsContained(pit1->first, sp))
				any1 = true;
			else if(IsContained(pit2->first, sp))
				any2 = true;
		}
		if(!right->IsLeaf()) {				
			rclade = right->GetClade();
			if(IsContained(pit1->first, *rclade))
				any1 = true;
			else if(IsContained(pit2->first, *rclade))
				any2 = true;
		}
		else {								
			int sp = right->GetSpecies();
			if(IsContained(pit1->first, sp))
				any1 = true;
			else if(IsContained(pit2->first, sp))
				any2 = true;
		}
		if(any1 && any2)
			result++;
	}
	return result + checkRnode(left,e) + checkRnode(right,e);
};

// Recursively checks if a polytomous tree node is to be counted in |r(V1,V2)|
// Also computes |e(V1,V2)|
int checkPolyRnode(PNode node, int *e) {
	myset *clade, *clade1, *rootclade;
   myset all;
	if(!node || node->IsLeaf())
		return 0;
   bool any  = false;
   int isempty = 0;  // 1=empty for V1, 2=empty for V2
   rootclade = tree->GetRoot()->GetClade();
   all.assign(*rootclade);
   all.intersect(pit2->first);
   if(all.count() == 0)
      isempty = 2;
   else {
      all.assign(*rootclade);
      all.intersect(pit1->first);
      if(all.count() == 0)
         isempty = 1;
   }
	int result = 0;
	bool any1 = false;
	bool any2 = false;
   bool maybegood = true;
	clade = node->GetClade();
   if(node->GetParent() && 
      (IsContained(pit1->first, *clade) || IsContained(pit2->first, *clade)))
         maybegood = false;

	PNode child = node->GetChild();
   if(!child)
      throw("checkPolyRnode: Inner childless node encountered.");

	while(child) {
		if(!child->IsLeaf()) {
			clade1 = child->GetClade();
         if(maybegood && IsContained(pit1->first, *clade1)) {
            if(isempty == 2)
               any = true;
				any1 = true;
         }
         else if(maybegood && IsContained(pit2->first, *clade1)) {
            if(isempty == 1)
               any = true;
				any2 = true;
         }
		}
		else {
			int sp = child->GetSpecies();
         if(maybegood && IsContained(pit1->first, sp)) {
            if(isempty == 2)
               any = true;
				any1 = true;
         }
         else if(maybegood && IsContained(pit2->first, sp)) {
            if(isempty == 1)
               any = true;
				any2 = true;
         }
		}
		result += checkPolyRnode(child,e);
		child = child->GetSibling();
	}
   if(any)
      (*e)++;
	if(any1 && any2)
		result++;
	return result;
};
