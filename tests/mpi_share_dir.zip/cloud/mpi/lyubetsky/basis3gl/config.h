//	basis3GL:  A program for basis trees construction, v.2.X.X
//	The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/super3gl]
//	(C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
// E-mail: rubanov{at}iitp.ru
//	This program is free software: you can redistribute it and/or modify
//	it under the terms of the GNU General Public License as published by
//	the Free Software Foundation, either version 3 of the License, or
//	(at your option) any later version.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details.
//
//	You should have received a copy of the GNU General Public License
//	along with this program.  If not, see <http://www.gnu.org/licenses/>.

#ifndef CONFIG_H
#define CONFIG_H

#include <string>
#include <map>
#include <set>
#include <functional>
#include <fstream>
#include <sstream>
#include "basis3gl.h"
#include "forest.h"
#include "myset.h"

using namespace std;
typedef string *Pstr;
typedef map<string, int, less<string> > SpecMap;
typedef pair<SpecMap::iterator, bool> SpecMapInsertResult;

struct PSetFunctor {		// Arranging set of mysets
	bool operator() (myset elem1, myset elem2) const {
		return (elem1 < elem2);
	}
};

typedef pair<myset, myset> V1V2Pair;
struct VData {			// Clade data
   ~VData() {
      if(BasTree) delete BasTree;
      V1V2.clear();
   }
	bool				Basis;
	PTree				BasTree;
	float				Cost;
	#ifdef BTREEWEIGHT
	float				Weight;
	#endif
	set<V1V2Pair>	V1V2;
	int				GoodNum;    // |r(V)| or equivalent in polytomous case
   int            GoodEdge;   // only number of good edges irrespective of polytomy
	int				serial;
};

typedef map<myset, VData, PSetFunctor> PSetMap;
typedef pair<myset, VData> PSetMapPair;
typedef PSetMap::iterator PSetMapIter;
typedef PSetMap::reverse_iterator PSetMapIteR;
typedef pair<PSetMapIter, bool> PSetMapResult;

struct SData {			// Species data
	bool			Enable;
	bool			Included;
   bool        Enable0;    // to store initial set of actual species
	string		Code;
	string		Name;
	int			Meet;
};

struct Config {
	Config() {
		// Default program options
		WorkingDirectory = "";
		ConfigFileName = "basis3GL.ini";
		ConfigFileNameGiven = false;
		SpecLabelParts = 1;
      StopLabel = "";
		StrictLabelControl = false;
		SpeciesTableName = "";
		SpecTableGiven = false;
		SpecTableOverride = false;
		TreeListOverride = false;
		TreeWriteMode = 0;
		BasisName = "";
		BasisNameGiven = false;
		MilestonesGiven = false;
		Milestones = 6;
		LogFileName = "basis3GL.log";
		LogFileNameGiven = false;
		TreeLogMode = 0;
		LogActualTrees = false;
		LogActualSpecies = false;
		LogEntirePset = false;
		LogBasisSets = false;
		LogBasisTrees = false;
		LogIntermediate = false;
      LogOnlyLastBTree = true;
		ConIntermediate = false;
		Polytomy = false;
		// Elements of the configuration
		MaxValues = 3;
		CREM = "#;/*";
		CBLANK = " \t\n\r";
		CDELIM = " \t\n\r=:,";
		CQUOTE = '\"';
		// Elements of the Newick format
		EOT = ';';
		LPAR = '(';
		RPAR = ')';
		COMMA = ',';
		LENPR = ':';
		QUOTE = '\'';
		UND = '_';
		BCOM = '[';
		ECOM = ']';
		// Elementary groups
		DLTOK = ";(),[]";
		BLANK = " \t\n\r";
		MUSTQ = "()[],\':;";
		// CSV species table
		CSVdelimiter = '\t';
		SkipLines = 0;
		SpecNum = 0;
		SpeciesData = NULL;
		MaxSpecies = 32;
		// Table of gene trees
		TreeNum = 0;
		MaxTrees = 16;
		GTree = new PTree [MaxTrees];
		TreePruned = 0;
		// Algorithm parameters
		CLossGiven = false;
		CLoss = 2.;
		CLoss1Given = false;
		CLoss1 = 1.;
		CDuplicationGiven = false;
		CDuplication = 3.;
		ThresholdGiven = false;
		Threshold = 1;
		TreePruningMode = false;
		ExtendPsetGiven = false;
		ExtendPset = false;
		#ifdef BTREEWEIGHT
		BasisTreeWeight = true;
		MinWeight = 0;
		#endif
		// Miscellanea
		STree = NULL;
      ParalogyPenaltyGiven = false;
      ParalogyPenalty = 1.0;
      current_n = -1;
		#ifndef NOMPI
		mpi = true;
		size_mpi = 1;
		rank_mpi = 0;
      ver_mpi = 0;
      sub_mpi = 0;
		#endif
	};
	~Config() {
		delete [] SpeciesData;
	};
	enum TreeWriteOption {				// Enumeration to control tree output
					InnerIndex	= 1,
					InnerName	= 2,			// InnerIndex has precedence
					InnerLength = 4,
					LeafLength	= 8,
					LeafIndex	= 16,			// Print as name_index
					RootNameLen	= 32,
               SpeciesOnly = 64        // Print only species for leaves
	};
									// Configuration format elements
	int			MaxValues;			// Max number of values for a key
	const char	*CREM;				// Comment indicators
	const char	*CBLANK;				// Whitespace characters
	const char	*CDELIM;				// Delimiter characters
	char			CQUOTE;				// Value quotation mark
									// Tree format elements
	char			EOT;					// End of tree
	char			LPAR;					// Begin children list
	char			RPAR;					// End children list
	char			COMMA;				// Children delimiter
	char			LENPR;				// Length prefix
	char			QUOTE;				// Name quotation mark
	char			UND;					// Blank substitute in names
	char			BCOM;					// Begin comment
	char			ECOM;					// End comment
	const char	*DLTOK;				// Tree token delimiters
	const char	*BLANK;				// Whitespace characters
	const char	*MUSTQ;				// Characters that require name to be quoted
									// Program options
	string		WorkingDirectory;	// Path to prepend to all filenames, empty by default
	string		ConfigFileName;	// Configuration file pathname
	bool			ConfigFileNameGiven;		// True if config file is provided
	int			SpecLabelParts;	// Fixed/max depending on StrictLabelControl
   string      StopLabel;        // Any character of the string terminates a label
	bool			StrictLabelControl;		// True if "SpecParts_Gene" label format is required.
	string		SpeciesTableName;	// Species table pathname
	bool			SpecTableGiven;	// True if list of species is somehow provided
	bool			SpecTableOverride;		// True to ignore table of species in the configuration
	bool			TreeListOverride;	// True to ignore tree(s) in the configuration
	int			TreeWriteMode;		// Composed of TreeWriteOption enum
	string		BasisName;			// Basis trees filename
	bool			BasisNameGiven;	// True if BasisName was given in the config or command line
	bool			MilestonesGiven;	// True if Milestones value was given in the command line
	int			Milestones;			// Intermediate output step
   #ifndef NOMPI
   double      StartTime;			// Program start time
   #else
	clock_t		StartTime;			// Program start time
   #endif
	string		LogFileName;		// Filename for a copy of the program console log
	bool			LogFileNameGiven;	// True if log file name was given in the command line
	ofstream		clog;					// File stream to duplicate the console log
	ostringstream	cmem;				// Temporary console output from 2ndary branches
	ostringstream	lmem;				// Temporary log output from 2ndary branches
	bool			Polytomy;			// True if there is at least one polytomous node
									// CSV table of species related data
	char			CSVdelimiter;		// Character used to delimit CSV fields
	int			SkipLines;			// Number of initial lines to skip
	int			SpecNum;				// Number of last species (starts from 1 to avoid zero code)
	int			MaxSpecies;			// Max number of species (to double if necessary)
	SpecMap		Species;				// <Code,number> map of species
	SData			*SpeciesData;		// Array of specied data (by the same number)
									// Gene tree(s) related data
	int			TreeNum;				// Current number of trees (zero based)
	int			MaxTrees;			// Max number of tree (to double if necessary)
	PTree			*GTree;				// Array of gene tree pointers (may include NULLs)
   PTree       *GTree0;          // The same for initial (source) trees.
	int			TreePruned;			// Number of trees removed by pruning
									// Algorithm parameters
	bool			CLossGiven;			// True if CLoss was given in command line
	float			CLoss;				// Cost of gene loss
	bool			CLoss1Given;		// True if CLoss1 was given in command line
	float			CLoss1;				// Cost of disputable gene loss
	bool			CDuplicationGiven;		// True if CDuplication was given in command line
	float			CDuplication;		// Cost of gene duplication
	bool			ThresholdGiven;
	int			Threshold;			// Min allowed number of species meetings to consider
	bool			TreePruningMode;	// If true, eliminate rare species and non-informative trees
	bool			ExtendPsetGiven;	// True, if ExtendPset was given in the command line
	bool			ExtendPset;			// If true, insert additional clade differences in P set
	#ifdef BTREEWEIGHT
	bool			BasisTreeWeight;	// If true, calculate and use the weigth of a basis tree
	float			MinWeight;			// Minimum weight to consider a tree 
	#endif
   bool        ParalogyPenaltyGiven;   // True, if ParalogyPenalty was given in the command line
   float       ParalogyPenalty;        // Paralogy penalty factor (1 by default)
									// Algorithm working data
	PSetMap		PSet;					// Set P of sets of species: map<myset, VData, PFunctor >
   PSetMap     PSet0;            // The same for initial (aggregated) set P
	PSetMapIter *PSetEntry;			// Array of PSet iterators pointing to 1st element of given set size
	PTree			STree;				// Sought-for species tree
   int         current_n;        // Current V number 
									// MPI related data
	#ifndef NOMPI
	bool			mpi;			      // True if the program operates in MPI environment
	int			size_mpi;			// Number of CPUs involved
	int			rank_mpi;			// "This" CPU number
   int         ver_mpi;          // MPI major version number
   int         sub_mpi;          // MPI minor version number
	enum			tag_mpi {		// MPI message tags:
		tagN = 10, 					   // PSet element number to process
      tagCon,                    // Message(s) for the console output
      tagLog,                    // Message(s) for common log
      tagExclude,                // Signal to not include a basis tree
      tagInclude                 // Basis tree to include
	};
	#endif
									// Logging options
	int			TreeLogMode;
	bool			LogActualTrees;
	bool			LogActualSpecies;
	bool			LogEntirePset;
	bool			LogBasisSets;
	bool			LogBasisTrees;
   bool        LogIntermediate;
   bool        LogOnlyLastBTree;
   bool        ConIntermediate;
};

extern Config *cfg;
extern ostream *Con;    // Pointer to either cout (root|single) or cmem (2ndary)
extern ostream *Log;    // Pointer to either clog (root|single) or lmem (2ndary)

string		ToLower(const string& s);
string		ToLower(const char *sz);
bool			ReadSpeciesTable(string filename);
int			AddSpecies(const string& code, const string& name="");
int			SpecCode2Number(const string& code);
string		SpecNumber2Code(int specnum);
bool			ParseCommandLine(int argc, char *argv[]);
bool			ReadConfig(void);
bool			AddGeneTreeFile(string filename);
bool			AddGeneTree(const string& tree);
void			MakeClades(PTree tree);
void			makeClade(PNode node);
void			AnalyzeTrees(void);
void			PruneTrees(void);
void			calcMeeting(PNode node);
void			BuildPSetOfSetOfSpecies(void);
void			FindGoodEdges();
bool			checkGood(PNode node);
bool			checkGoodPoly(PNode node);
void        countRV(PNode node);
void        clearNodeFlag(PNode node);
bool			IsContained(const myset& Where, int What);
bool			IsContained(const myset& Where, const myset& What);
int			ElapsedMin(void);
void			CreatePSetCatalog();
void			IdentifyBasisSets();
void			BuildBasisTrees(void);
void        PostprocessBasis(void);
float			PartitionCost(PSetMapIter pit, const set<V1V2Pair>::iterator partvar);
void			WriteBasisTrees();						// newick.cpp
void			ReadBasisTrees();							// newick.cpp
PTree			AddBasisTree(const string& tree);	// newick.cpp
int			EarlyCommandLine(int argc, char *argv[]);
int			CountRV1V2(const PSetMapIter& pit, const PSetMapIter& pit1, const PSetMapIter& pit2, 
                       PTree tree, int *e);
int			checkRnode(PNode node, int *e);
int			checkPolyRnode(PNode node, int *e);
void			CheckBool(const string& name, bool& param, const string& value);
void			PrintHelp(void);
void			PrintGPL3(void);
void			OpenLogFile(bool flag = true);
#ifdef BTREEWEIGHT
void        DistributeWeights(void);
#endif

#endif
