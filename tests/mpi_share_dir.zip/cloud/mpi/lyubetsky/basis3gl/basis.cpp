//	basis3GL:  A program for basis trees construction, v.2.X.X
//	The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/super3gl]
//	(C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
// E-mail: rubanov{at}iitp.ru
//	This program is free software: you can redistribute it and/or modify
//	it under the terms of the GNU General Public License as published by
//	the Free Software Foundation, either version 3 of the License, or
//	(at your option) any later version.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details.
//
//	You should have received a copy of the GNU General Public License
//	along with this program.  If not, see <http://www.gnu.org/licenses/>.

#include <fstream>
#include <iostream>
#include <iomanip>
#include <strstream>
#include <limits>
#include <complex>
#include <queue>
#include <vector>
#include <assert.h>
#include "basis3gl.h"
#include "forest.h"
#include "config.h"

using namespace std;

class Sp2Add {
public:
   double   criterion;  // comparison criterion
   int      species;    // species number
   int      nodeno;     // best node no. in nodes[]
   double   best;       // best quality value
   PNode    bestnode;   // best quality node to unsert over
   double   good;       // good quality value
   PNode    goodnode;   // good quality node to unsert over
   double   R;          // reliability of insertion
   int      nbest;      // number of 'best' occurrences
};
// This class defines a comparison function for MyQueue
class MyQueueLess {
public:
   bool operator() (Sp2Add* sp1, Sp2Add* sp2) const {
      if(sp1->criterion == sp2->criterion) {
         if(sp1->best == sp2->best)
            return (sp1->R < sp2->R);
         return (sp1->best < sp2->best);
      }
      return (sp1->criterion < sp2->criterion);
   }
};
typedef priority_queue <Sp2Add*, vector<Sp2Add* >, MyQueueLess > MyQueue;

// Creates and fills PSetEntry array of entries into PSet
void CreatePSetCatalog() {
  	cfg->PSetEntry = new PSetMapIter [cfg->SpecNum + 1];
	PSetMapIter PSetIter  = cfg->PSet.begin();
	PSetMapIter NotInPSet = cfg->PSet.end();
	for(int k = 0; k <= cfg->SpecNum; k++)
		cfg->PSetEntry[k] = NotInPSet;
	for( ; PSetIter != NotInPSet; PSetIter++ ) {
		PSetMapPair p = *PSetIter;
		size_t size = p.first.count();
		if(cfg->PSetEntry[size] == NotInPSet) 
			cfg->PSetEntry[size] = PSetIter;
	}
};

// Identifies basis sets in PSet by induction
void IdentifyBasisSets() {
	int numbas = 0;
	int numpart = 0;
	size_t maxpart = 1;
	PSetMapIter none = cfg->PSet.end();
	PSetMapIter pit = cfg->PSetEntry[1];

	// Mark each set of the size=1 as basis set 
	for( ; pit->first.count() == 1; pit++) {
		pit->second.Basis = true;
		pit->second.V1V2.clear();
		numbas++;
		numpart++;
	}

	// Process greater sizes in turn
	myset join;
	for(int size = 2; size <= cfg->SpecNum; size++) {
		if(cfg->PSetEntry[size] == none)
			continue;
		PSetMapIter pit1; 
		PSetMapIter pit2;
		for(int s1 = 1; s1 <= (size >> 1); s1++) {
			int s2 = size - s1;
			if((pit1 = cfg->PSetEntry[s1]) == none || (pit2 = cfg->PSetEntry[s2]) == none)
				continue;
			for( ; pit1 != none && pit1->first.count() == s1; pit1++) {
				if( ! pit1->second.Basis )
					continue;
				if(s1 != s2)
					pit2 = cfg->PSetEntry[s2];
				else {
					pit2 = pit1;
					pit2++;
				}
				for( ; pit2 != none && pit2->first.count() == s2; pit2++) {
					if( ! pit2->second.Basis )
						continue;
					join.assign(pit1->first);
					join.join(pit2->first);
					if(join.count() != size)
						continue;
					// find such set in PSet and make it basis if exists
					pit = cfg->PSet.find(join);
					if(pit == none)
						continue;
					if( ! pit->second.Basis ) {
						pit->second.Basis = true;
						numbas++;
					}
					V1V2Pair v1v2(pit1->first, pit2->first);
					pit->second.V1V2.insert(v1v2);
					numpart++;
					if(cfg->Milestones && (numpart & cfg->Milestones) == 0)
                  *Con << "V" << setfill(' ') << setw(5) << cfg->current_n 
                     << " B " << setfill(' ') << setw(4) << size << " [" 
                     << numpart << "]      \r" << flush;
					if(pit->second.V1V2.size() > maxpart)
						maxpart = pit->second.V1V2.size();
				}
			}
		}
	}
   if(cfg->ConIntermediate)
	   *Con TSTAMP << "Basis sets selected: " << numbas << ", partitions=" 
		   << numpart << " (max=" << maxpart << ")." << endl;
   if(cfg->LogIntermediate)
	   *Log TSTAMP << "Basis sets selected: " << numbas << ", partitions=" 
		   << numpart << " (max=" << maxpart << ")." << endl;
};

// Builds basis trees by induction
void BuildBasisTrees(void) {
	// First building one-element trees
	int serial = 1;
   if(cfg->LogBasisSets && cfg->LogIntermediate) {       // Logging basis sets
		*Log << "\nBasis sets & partitions:" << endl
			<< "    #  |V|{V}  |V1+V2| Partition:|r(V1,V2)|\\|e(V1,V2)|[,penalty]=cost..." << endl; 
	}
	PSetMapIter none = cfg->PSet.end();
	PSetMapIter pit = cfg->PSet.begin();
	for( ; pit != none; pit++) {
		if( ! pit->second.Basis )
			continue;
		if(pit->first.count() > 1)
			break;
		pit->second.serial = serial++;
      if(cfg->LogBasisSets && cfg->LogIntermediate) {
			myset clade = pit->first;
			set<V1V2Pair> &v1v2 = pit->second.V1V2;
			*Log << setfill(' ') << setw(5) << pit->second.serial << "  [" << clade.count() << "] " 
				<< clade.Write() << "  [" << v1v2.size() << "]" << endl;
		}
		int sp = pit->first.first();
		PTree tree = new Tree();
		PNode leaf = tree->AddLeafNode(cfg->SpeciesData[sp].Code);
		leaf->SetSpecies(sp);
      leaf->SetLength(1.0F); 
		tree->SetRoot(leaf);
		tree->SetRooted();
		pit->second.BasTree = tree;
		#ifdef BTREEWEIGHT
		pit->second.Weight = 1.0F;
		#endif
	}
	// Then proceeding from two-element basis sets
	int innerbase = 1;
	int n = 0;
	for( ; pit != none; pit++) {
		if( ! pit->second.Basis )
			continue;
		pit->second.serial = serial++;
		if(cfg->LogBasisSets && cfg->LogIntermediate) {
			myset clade = pit->first;
			set<V1V2Pair> &v1v2 = pit->second.V1V2;
			*Log << setfill(' ') << setw(5) << pit->second.serial << "  [" << clade.count() << "] " 
				<< clade.Write() << "  [" << v1v2.size() << "]";
		}
		int size = pit->first.count();
		// Milestones
		if(cfg->Milestones && (n++ & cfg->Milestones) == 0)
			*Con << "V" << setfill(' ') << setw(5) << cfg->current_n 
            << " BT " << setfill(' ') << setw(4) << size << " [" << n-1 << "]      \r" << flush;
		// Loop over all variants of partitioning
		set<V1V2Pair>::iterator bestvar;
		float bestcost = numeric_limits<float>::max();
		#ifdef BTREEWEIGHT
		float bestcost2 = numeric_limits<float>::max();
		#endif
		set<V1V2Pair>::iterator partvar = pit->second.V1V2.begin();
		for( ; partvar != pit->second.V1V2.end(); partvar++) {
			if(cfg->LogBasisSets && cfg->LogIntermediate) {
				*Log << " " << cfg->PSet.find(partvar->first)->second.serial
					<< "+" << cfg->PSet.find(partvar->second)->second.serial << ":";
			}
			float cost = PartitionCost(pit, partvar);
         if(cfg->LogBasisSets && cfg->LogIntermediate) {
            *Log << "=" << setprecision(1) << cost;
         }
			if(cost < bestcost) {
				#ifdef BTREEWEIGHT
				if(cfg->BasisTreeWeight)
					bestcost2 = bestcost;
				#endif
				bestvar = partvar;
				bestcost = cost;
			}
			#ifdef BTREEWEIGHT
			else if(cfg->BasisTreeWeight && cost < bestcost2)
				bestcost2 = cost;
			#endif
		}
      if(cfg->LogBasisSets && cfg->LogIntermediate)
			*Log << endl;
		// Building best basis tree
		PTree tree = new Tree(innerbase++);
		PNode root = tree->AddInnerNode();
		tree->SetRoot(root);
		tree->SetRooted();
		root->SetDepth(0);
		PSetMapIter pit1 = cfg->PSet.find(bestvar->first);
		PSetMapIter pit2 = cfg->PSet.find(bestvar->second);
		if(pit1 == cfg->PSet.end() || pit2 == cfg->PSet.end())
			throw("Internal error: Partition constituent not found.");
		tree->Clone(pit1->second.BasTree->GetRoot(), root);
		tree->Clone(pit2->second.BasTree->GetRoot(), root);
		tree->UpdateLite(root);
		pit->second.Cost = bestcost;
		pit->second.BasTree = tree;
		#ifdef BTREEWEIGHT
      if(cfg->BasisTreeWeight) { 
         pit->second.Weight = (bestcost2 - bestcost) / bestcost2;
         root->SetLength(pit->second.Weight);
      }
      else {
			pit->second.Weight = 1.0F;
         root->SetLength(1.0F);
      }
		#endif
	}
   PostprocessBasis();
}

// Erase non-basis PSet elements, calc & print BT statistics
void PostprocessBasis(void) {
	PSetMapIter none = cfg->PSet.end();
	PSetMapIter pit = cfg->PSet.begin();
	#ifdef BTREEWEIGHT
	float wmax = 0;
	float wmin = numeric_limits<float>::max();
	double wsum = 0;
	double wsqsum = 0;
	#endif
   #ifdef LOG2TREES
   if(cfg->LogBasisTrees && cfg->LogIntermediate) 		// Log also two-species trees
	   *Log << "\nCost of two-species trees:" << endl;
   #endif
	// Final cut of basis trees
	int btreenum = 0, numleaves = 0, maxleaves = 0;
	for(pit = cfg->PSet.begin(); pit != none; /*pit++*/) {
		if( ! pit->second.Basis ) {
			pit->second.V1V2.clear();
			PSetMapIter toerase = pit++;
			cfg->PSet.erase(toerase);
			continue;
		}
		int leaves = pit->second.BasTree->GetLeafCount();
      #ifdef LOG2TREES
	   if(cfg->LogBasisTrees && cfg->LogIntermediate && 
         !cfg->LogOnlyLastBTree && leaves == 2) {	// Log also two-species trees
		   //set<V1V2Pair>::iterator v1v2 = pit->second.V1V2.begin();
		   //int v1 = v1v2->first.first();
		   //int v2 = v1v2->second.first();
		   //*Log << cfg->SpeciesData[v1].Code << " + " << cfg->SpeciesData[v2].Code
		   // << " = "	<< pit->second.Cost << endl; 
		   ostringstream oss;
		   oss << pit->second.Cost;
		   pit->second.BasTree->GetRoot()->SetName(oss.str());
		   *Log << pit->second.BasTree->Write(Config::InnerName) << endl;
	   }
      #endif
		#ifdef BTREEWEIGHT
      if(leaves < 3 || cfg->BasisTreeWeight && pit->second.Weight < cfg->MinWeight) { 
		#else
		if(leaves < 3) { 
		#endif
			pit->second.Basis = false;
			//pit->second.V1V2.clear();
			//delete pit->second.BasTree;
			PSetMapIter toerase = pit++;
			cfg->PSet.erase(toerase);
		}
		else {
			MakeClades(pit->second.BasTree);
			btreenum ++;
			#ifdef BTREEWEIGHT
			if(cfg->BasisTreeWeight) {
				float w = pit->second.Weight;
				if(w > wmax)
					wmax = w;
				if(w < wmin)
					wmin = w;
				wsum += (double)w;
				wsqsum += (double)w * w;
			}
			#endif
			numleaves += leaves;
			if(leaves > maxleaves)
				maxleaves = leaves;
			pit++;
		}
	}
   if(cfg->LogBasisSets && cfg->LogIntermediate)
		*Log << endl;

   if(cfg->LogIntermediate || cfg->ConIntermediate) {
      if(cfg->ConIntermediate)
	      *Con TSTAMP << "Basis trees constructed: " << btreenum 
            << ", total leaves=" << numleaves << " (max=" << maxleaves 
            << ")." << endl;
      if(cfg->LogIntermediate)
	      *Log TSTAMP << "Basis trees constructed: " << btreenum 
            << ", total leaves=" << numleaves << " (max=" << maxleaves 
            << ")." << endl;
	   #ifdef BTREEWEIGHT
	   if(cfg->BasisTreeWeight) {
		   double m = wsum / btreenum;
         if(cfg->ConIntermediate)
		      *Con TSTAMP << "BT weight: min=" << fixed << setprecision(5) 
               << wmin << ", max=" << setprecision(2) << wmax << ", average=" << m;
         if(cfg->LogIntermediate)
		      *Log TSTAMP << "BT weight: min=" << fixed << setprecision(5) 
               << wmin << ", max=" << setprecision(5) << wmax << ", average=" << m;
         if(btreenum > 1) {
		      double d = wsqsum / btreenum - m * m;
		      d = sqrt(d * btreenum / (btreenum - 1));
            if(cfg->ConIntermediate)
               *Con << ", stdev=" << d;
            if(cfg->LogIntermediate)
               *Log << ", stdev=" << d;
         }
         if(cfg->ConIntermediate)
            *Con << "." << endl;
         if(cfg->LogIntermediate)
            *Log << "." << endl;
	   }
	   #endif
   }
};

// Calculates cost of given partition by the formula c(v1,v2)=c(v1)+c(v2)+a-penalty
float PartitionCost(PSetMapIter pit, const set<V1V2Pair>::iterator partvar) {
	PSetMapIter pit1 = cfg->PSet.find(partvar->first);
	PSetMapIter pit2 = cfg->PSet.find(partvar->second);
	float a = 0.;
	int rv1 = pit1->second.GoodNum;		// |R(V1)|
	int rv2 = pit2->second.GoodNum;		// |R(V2)|
	// Counting |r(V1,V2)| and |e(V1,V2)| in a loop over trees
	int rv1v2 = 0;
   int ev1v2 = 0;
   int penaltysum = 0;
   static int e;      // For side-effect computation of |e(V1,V2)|

	for(int t = 0; t < cfg->TreeNum; t++) {
		PTree tree = cfg->GTree[t];
		if(!tree)
			continue;
		// Check from the root downward whether a node is to be counted in rv1v2
      int r = CountRV1V2(pit, pit1, pit2, tree, &e);
		rv1v2 += r;
      if(r > 1)
         penaltysum += r - 1;
      ev1v2 += e;
	}
   if(cfg->LogBasisSets && cfg->LogIntermediate) {
		*Log << rv1v2 << "\\" << ev1v2;
      if(penaltysum)
         *Log << "," << penaltysum;
   }
	a = cfg->CLoss * (rv1 + rv2 - 2 * rv1v2) +
		cfg->CDuplication * (rv1 + rv2 - pit->second.GoodNum - rv1v2) -
      (cfg->CLoss - cfg->CLoss1) * ev1v2;
   return pit1->second.Cost + pit2->second.Cost + a + 
      (int)(cfg->ParalogyPenalty * penaltysum);
};

#ifdef BTREEWEIGHT
// Recursive comparison of two given subtrees.
bool isSameTree(PNode node1, PNode node2) {
   assert(node1 && node2);
   PNode left1 = node1->GetChild();
   PNode left2 = node2->GetChild();
   if(!left1 && !left2)
      return node1->GetSpecies() == node2->GetSpecies();
   if(!left1 || !left2)
      return false;
   myset *cl1 = left1->GetClade();
   myset *cl2 = left2->GetClade();
   PNode right1 = left1->GetSibling();
   PNode right2 = left2->GetSibling();
   if(!right1 && !right2) {
      if(!cl1 && !cl2)     // both leaves
         return left1->GetSpecies() == left2->GetSpecies();
      if(!cl1 || !cl2)     // one leaf
         return false;
      return *cl1 == *cl2 && isSameTree(left1, left2);
   }
   if(!right1 || !right2)
      return false;
   myset *cr1 = right1->GetClade();
   myset *cr2 = right2->GetClade();
   if(!cl1 && !cl2 && !cr1 && !cr2) {     // four leaves
      int lsp1 = left1->GetSpecies();
      int lsp2 = left2->GetSpecies();
      int rsp1 = right1->GetSpecies();
      int rsp2 = right2->GetSpecies();
      if(lsp1 == lsp2)
         return rsp1 == rsp2;
      if(lsp1 == rsp2)
         return rsp1 == lsp2;
      return false;
   }
   if(!cl1 && !cl2) {                     // two leaves
      int lsp1 = left1->GetSpecies();
      int lsp2 = left2->GetSpecies();
      if(lsp1 == lsp2)
         return isSameTree(right1, right2);
      return false;
   }
   if(!cl1 && !cr2) {
      int lsp1 = left1->GetSpecies();
      int rsp2 = right2->GetSpecies();
      if(lsp1 == rsp2)
         return isSameTree(right1, left2);
      return false;
   }
   if(!cr1 && !cl2) {
      int rsp1 = right1->GetSpecies();
      int lsp2 = left2->GetSpecies();
      if(rsp1 == lsp2)
         return isSameTree(left1, right2);
      return false;
   }
   if(!cr1 && !cr2) {
      int rsp1 = right1->GetSpecies();
      int rsp2 = right2->GetSpecies();
      if(rsp1 == rsp2)
         return isSameTree(left1, left2);
      return false;
   }
   if(!cl1 || !cl2 || !cr1 || !cr2)
      return false;
   if(*cl1 == *cl2 && *cr1 == *cr2)
      return isSameTree(left1, left2) && isSameTree(right1, right2);
   else if(*cl1 == *cr2 && *cr1 == *cl2)
      return isSameTree(left1, right2) && isSameTree(right1, left2);
   return false;
}

// Recursive traversal the tree from given node setting lengths.
void distributeWeights(PNode node) {
   if(!node)
      return;
   myset *clade = node->GetClade();
   if(!clade || clade->count() < 3)
      return;     // lengths already set to 1.0
   PSetMapIter p = cfg->PSet.find(*clade);
   float weight = 0.0;
   if(p != cfg->PSet.end() && p->second.BasTree) {
      // Slow search backward and store as non-basis
      //p = pit;
      //for(--p; p != cfg->PSet.end(); p--) {
      //   if(p->first.count() < clade->count())
      //      break;
      //   myset c(*clade);
      //   c &= p->first;
      //   if(c == *clade)
      //      break;
      //}
      //if(p == cfg->PSet.end())
      //   throw("DWT: Internal error - cannot find basis subtree.");
      //VData v;
      //v.Basis     = false;
      //v.BasTree   = 0;
      //v.Cost      = 0.0F;
      //v.GoodEdge  = 0;
      //v.GoodNum   = 0;
      //v.Weight    = p->second.Weight;
      //cfg->PSet.insert(PSetMapPair(*clade,v));
      PNode root = p->second.BasTree->GetRoot();
      if(root && isSameTree(root, node))
         weight = p->second.Weight;
   }
   node->SetLength(weight);
   PNode left  = node->GetChild();
   PNode right = left->GetSibling();
   distributeWeights(left);
   distributeWeights(right);
}

// Sets lengths of BT inner nodes using weights of PSet elements
void DistributeWeights(void) {
   PSetMapIter pit;
   for(pit = cfg->PSet.begin(); pit != cfg->PSet.end(); pit++) {
      if(!pit->second.Basis || pit->first.count() < 4 || !pit->second.BasTree)
         continue;
      PTree tree  = pit->second.BasTree;
      PNode root  = tree->GetRoot();
      PNode left  = root->GetChild();
      PNode right = left->GetSibling();
      distributeWeights(left);
      distributeWeights(right);
   }
}
#endif
