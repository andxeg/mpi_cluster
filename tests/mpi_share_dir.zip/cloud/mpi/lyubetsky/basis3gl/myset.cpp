//	basis3GL:  A program for basis trees construction, v.2.X.X
//	The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/super3gl]
//	(C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
// E-mail: rubanov{at}iitp.ru
//	This program is free software: you can redistribute it and/or modify
//	it under the terms of the GNU General Public License as published by
//	the Free Software Foundation, either version 3 of the License, or
//	(at your option) any later version.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details.
//
//	You should have received a copy of the GNU General Public License
//	along with this program.  If not, see <http://www.gnu.org/licenses/>.

#include <sstream>
#include <stdlib.h>
#include "basis3gl.h"
#include "myset.h"
#include "config.h"

myset::myset() {
	maxword = (cfg->MaxSpecies + BPW - 1) >> LBPW;
	maxitem = maxword << LBPW;
	mysize = 0;
	trimmer = 0xFFFFFFFF >> (maxitem - cfg->MaxSpecies);
	word = new WORD [maxword];
	for(int k = 0; k < maxword; k++)
		word[k] = 0;
};

myset::myset(const WORD *words) {
	maxword = (cfg->MaxSpecies + BPW - 1) >> LBPW;
	maxitem = maxword << LBPW;
	mysize = 0;
	trimmer = 0xFFFFFFFF >> (maxitem - cfg->MaxSpecies);
	word = new WORD [maxword];
	for(int k = 0; k < maxword; k++) {
		word[k] = words[k];
		if(word[k])
			mysize += count1(word[k]);
	}
};

myset::myset(int item) {
	WORD mask;
//	myset::myset();      // as new releases of gcc complain of it
	maxword = (cfg->MaxSpecies + BPW - 1) >> LBPW;
	maxitem = maxword << LBPW;
	mysize = 0;
	trimmer = 0xFFFFFFFF >> (maxitem - cfg->MaxSpecies);
	word = new WORD [maxword];
	for(int j = 0; j < maxword; j++)
		word[j] = 0;
	mysize = 1;
	int k = I2W(item, &mask);
	word[k] &= mask;
};

myset::myset(const myset &other) {
	maxword = other.maxword;
	maxitem = other.maxitem;
	mysize = other.mysize;
	trimmer = other.trimmer;
	word = new WORD [maxword];
	for(int k = 0; k < maxword; k++)
		word[k] = other.word[k];
};

myset::~myset() {
	delete [] word;
};

// Converts given item number into a word number and the mask given as pointer
// Returns the word number or throws exception on errors
int myset::I2W(int item, WORD *mask) const {
	if(item <= 0 || item > maxitem)
		throw("Myset out of range - increase MaxSpecies.");
	*mask = 1 << ((item - 1) & MBPW);
	return (item - 1) >> LBPW;
};

// Resets unused bits in the last word
void myset::trim() {
	word[maxword - 1] &= trimmer;
};

// Checks whether any item exists in myset: true=yes, false=no(empty myset)
bool myset::any() {
	return (mysize != 0);
};

// Gets mysize (number of bits set)
int myset::count() const {
	return mysize;
};

// Recalculates mysize from scratch
void myset::recount() {
	mysize = 0;			
	for(int k = 0; k < maxword; k++ )
		if(word[k])
			mysize += count1(word[k]);
}

// Returns number of 1s in a word
// Based on the idea by Mikhail Bongard
int myset::count1(const WORD word) const {
	WORD w = word;
	w = ((w >> 1) & 0x55555555) + (w & 0x55555555);
	w = ((w >> 2) & 0x33333333) + (w & 0x33333333);
	w = ((w >> 4) & 0x0F0F0F0F) + (w & 0x0F0F0F0F);
	w = ((w >> 8) & 0x00FF00FF) + (w & 0x00FF00FF);
	w = (w >> 16) + (w & 0x0000FFFF);
	return w;
};

// Flips the state of all items
void myset::flip() {
	for(int k = 0; k < maxword; k++)
		word[k] = ~word[k];
	myset::trim();
	mysize = cfg->MaxSpecies - mysize;
	// reset pruned species
	//for(int i = 1; i <= cfg->MaxSpecies; i++)
	//	if( ! cfg->SpeciesData[i].Enable )
	//		reset(i);
}

// Flips the state of given item
void myset::flip(int item) {
	WORD mask;
	int k = myset::I2W(item, &mask);
	if((word[k] & mask) == 0)
		mysize ++;
	else
		mysize --;
	word[k] ^= mask;
};

// Checks whether no item exist in myset: true=yes(empty myset), false=no
bool myset::none() {
	return (mysize == 0);
};

// Clear entire myset (reset all bits to 0)
void myset::reset() {
	for(int k = 0; k < maxword; k++)
		word[k] = 0;
	mysize = 0;
};

// Deletes given item from myset (reset a bit to 0)
void myset::reset(int item) {
	WORD mask;
	int k = myset::I2W(item, &mask);
	if((word[k] & mask) != 0) {
		word[k] ^= mask;
		mysize --;
	}
};

// Fill entire myset (set all bits to 1)
void myset::set() {
	for(int k = 0; k < maxword; k++)
		word[k] = 0xFFFFFFFF;
	myset::trim();
	mysize = cfg->MaxSpecies;
	// reset pruned species
	for(int i = 1; i <= cfg->MaxSpecies; i++)
		if( ! cfg->SpeciesData[i].Enable ) {
			reset(i);
			mysize--;
		}
};

// Inserts given item into myset (set a bit to 1)
void myset::set(int item) {
	WORD mask;
	int k = myset::I2W(item, &mask);
	if((word[k] & mask) == 0) {
		word[k] |= mask;
		mysize ++;
	}
};

// Gets maximum value of myset item
int myset::size() {
	return maxitem;
};

// Tests a bit to check if given item exists in myset: true=yes, false=no
bool myset::test(int item) const {
	WORD mask;
	int k = myset::I2W(item, &mask);
	return ((word[k] & mask) != 0);
};

// Sets given item a boolean value
void myset::bit(int item, bool state) {
	WORD mask;
	int k = myset::I2W(item, &mask);
	if(state) {
		if((word[k] & mask) == 0)
			mysize ++;
		word[k] |= mask;
	}
	else {
		if((word[k] & mask) != 0)
			mysize --;
		word[k] ^= mask;
	}
}

// Implements operator != relative to other myset
bool myset::operator !=(const myset &other) const {
	#ifdef CHECKSIZE
	if(maxitem != other.maxitem)
		throw("Mysets of different size appear in an operator.");
	#endif
	for(int k = 0; k < maxword; k++)
		if(word[k] != other.word[k])
			return true;
	return false;
}

// Implements operator == relative to other myset
bool myset::operator ==(const myset &other) const {
	#ifdef CHECKSIZE
	if(maxitem != other.maxitem)
		throw("Mysets of different size appear in an operator.");
	#endif
	for(int k = 0; k < maxword; k++)
		if(word[k] != other.word[k])
			return false;
	return true;
}

// Implements &= operator with other myset (intersection)
myset& myset::operator &=(const myset &other) {
	#ifdef CHECKSIZE
	if(maxitem != other.maxitem)
		throw("Mysets of different size appear in an operator.");
	#endif
	for(int k = 0; k < maxword; k++)
		word[k] &= other.word[k];
	recount();
	return *this;
}

// Implements ^= operator with other myset (set positions that differ)
myset& myset::operator ^=(const myset &other) {
	#ifdef CHECKSIZE
	if(maxitem != other.maxitem)
		throw("Mysets of different size appear in an operator.");
	#endif
	for(int k = 0; k < maxword; k++)
		word[k] ^= other.word[k];
	recount();
	return *this;
}

// Implements |= operator with other myset (union)
myset& myset::operator |=(const myset &other) {
	#ifdef CHECKSIZE
	if(maxitem != other.maxitem)
		throw("Mysets of different size appear in an operator.");
	#endif
	for(int k = 0; k < maxword; k++)
		word[k] |= other.word[k];
	recount();
	return *this;
}

// Implements ~ operator (complement)
myset& myset::operator ~() {
	flip();
	return *this;
};

// Implements [] const operator
bool myset::operator [](int item) const {
	return test(item);
}

// Implements [] modifiable operator
reference myset::operator [](int item) {
	return (reference(*this, item));
};

// Implements < operator
bool myset::operator <(const myset &other) const {
	if((*this).count() < other.count())
		return true;
	if((*this).count() > other.count())
		return false;
	for(int k = maxword - 1; k >= 0; k--) {
		if(word[k] < other.word[k])
			return true;
		if(word[k] > other.word[k])
			return false;
	}
	return false;
};

// Assign data from other myset to this myset (assignment)
void myset::assign(const myset &other) {
	#ifdef CHECKSIZE
	if(maxitem != other.maxitem)
		throw("Mysets of different size appear in an operator.");
	#endif
	mysize = other.mysize;
	for(int k = 0; k < maxword; k++)
		word[k] = other.word[k];
};

// Joins other myset to this myset (build a union)
void myset::join(const myset &other) {
	#ifdef CHECKSIZE
	if(maxitem != other.maxitem)
		throw("Mysets of different size appear in an operator.");
	#endif
	for(int k = 0; k < maxword; k++)
		word[k] |= other.word[k];
	recount();
};

// Intersects myset with other myset (builds an intersection)
void myset::intersect(const myset &other) {
	#ifdef CHECKSIZE
	if(maxitem != other.maxitem)
		throw("Mysets of different size appear in an operator.");
	#endif
	for(int k = 0; k < maxword; k++)
		word[k] &= other.word[k];
	recount();
}

// Finds difference of this myset and other myset
void myset::difference(const myset &other) {
	#ifdef CHECKSIZE
	if(maxitem != other.maxitem)
		throw("Mysets of different size appear in an operator.");
	#endif
	for(int k = 0; k < maxword; k++)
		word[k] &= ~other.word[k];
	recount();
}

// Finds first item in myset (=least bit set to 1)
// Returns the species number or 0 if empty
int myset::first() const {
	int base = 0;
	for(int k = 0; k < maxword; k++) {
		if(word[k] != 0) {
			base += count1((word[k] - 1) & ~word[k]);
			return (++ base);
		}
		base += BPW;
	}
	return 0;
};

// Convert myset into a string using given delimiter
string myset::Write(char delimiter) const {
	ostringstream oss;
	string delim = "";
	int base = 0;
	for(int k = 0; k < maxword; k++) {
		if(word[k] != 0) {
			WORD mask = 1;
			for(int i = 1; i <= BPW; i++) {
				if(word[k] & mask) {
					oss << delim << base + i;
					delim = delimiter;
				}
				mask <<= 1;
			}
		}
		base += BPW;
	}
	return oss.str();
};

// Sets myset from a string delimited by given character
void myset::Read(string str, char delimiter) {
	reset();
	size_t pos = 0;
	size_t nextpos;
	while(true) {
		nextpos = str.find(delimiter,pos);
		size_t count = (nextpos != string::npos) ? nextpos - pos : string::npos;
		int k = atoi(str.substr(pos, count).c_str());
		if(k <= 0 || k > maxitem)
			throw("Invalid myset element number encountered in a string.");
		set(k);
		mysize++;
		pos = ++nextpos;
	}
};

// Gets all words into a given buffer (no check!)
void myset::getwords(WORD *w) const {
	for(int i = 0; i < maxword; i++)
		w[i] = word[i];
}

// Sets all words from a given buffer (no check!)
void myset::setwords(const WORD *w) {
	mysize = 0;
	for(int i = 0; i < maxword; i++) {
		word[i] = w[i];
		if(word[i])
			mysize += count1(word[i]);
	}
}

// Assigns boolean to item
reference& reference::operator =(bool value) {
	_pmyset->bit(_mypos, value);
	return (*this);
};

// Assigns reference to item
reference& reference::operator =(const reference& bitref) {
	_pmyset->bit(_mypos, bool(bitref));
	return (*this);
};

// Returns complemented item
bool reference::operator ~() const {
	return ( !_pmyset->test(_mypos));
};

// Returns item
reference::operator bool() const {
	return ( _pmyset->test(_mypos));
};

// Complements stored item
reference& reference::flip() {
	_pmyset->flip(_mypos);
	return (*this);
};
