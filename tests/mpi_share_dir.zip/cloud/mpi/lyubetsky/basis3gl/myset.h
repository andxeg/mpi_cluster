//	basis3GL:  A program for basis trees construction, v.2.X.X
//	The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/super3gl]
//	(C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
// E-mail: rubanov{at}iitp.ru
//	This program is free software: you can redistribute it and/or modify
//	it under the terms of the GNU General Public License as published by
//	the Free Software Foundation, either version 3 of the License, or
//	(at your option) any later version.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details.
//
//	You should have received a copy of the GNU General Public License
//	along with this program.  If not, see <http://www.gnu.org/licenses/>.

#ifndef MYSET_H
#define MYSET_H

#include <string>
#include "basis3gl.h"

using namespace std;

typedef unsigned int WORD;
typedef unsigned char BYTE;
#define	BPB	8		// bits per byte
#define	LBPB	3		// shift to div/mult by BPB
#define	BPW	32		// bits per word
#define	LBPW	5		// shift to div/mult by BPW
#define	MBPW	0x1F	// mask to get modulo BPW

class reference;

// This class is similar to standard bitset<N> class, but it allows N
// to be determined at run time, not at compile time.
// The native bitset functionality is implemented only in part.
// Some member functions were added, though.
class myset {
public:
	myset();
	myset(const WORD *words);
	myset(int item);
	myset(const myset &other);
	~myset();
	bool		any();
	int		count() const;
	void		flip();
	void		flip(int item);
	bool		none();
	void		reset();
	void		reset(int item);
	void		set();
	void		set(int item);
	int		size();
	bool		test(int item) const;
	void		bit(int item, bool state);
	bool		operator!=(const myset &other) const;
	bool		operator==(const myset &other) const;
	myset&	operator&=(const myset &other);
	myset&	operator^=(const myset &other);
	myset&	operator|=(const myset &other);
	myset&	operator~();
	bool		operator[](int item) const;
	reference operator[](int item);
	bool		operator<(const myset &other) const;
	void		assign(const myset &other);
	void		join(const myset &other);
	void		intersect(const myset &other);
	void		difference(const myset &other);
	int		first() const;
	int		count1(const WORD word) const;
	string	Write(char delimiter = ',') const;
	void		Read(std::string str, char delimiter = ',');
	int		wordcount(void) const { return maxword; };
	void		getwords(WORD *w) const;
	void		setwords(const WORD *w);
private:
	int		I2W(int item, WORD *mask) const;
	void		trim();
	void		recount();
protected:
	int		mysize;		// Number of 1-bits in myset
   WORD		*word;		// Pointer to the array of words (with dimension = maxword)
	int		maxitem;		// Max number of elements in myset
	int		maxword;		// Number of words in myset
	WORD		trimmer;		// Mask to reset unused bits in last word
};

class reference {
   friend class myset;
   public:
      reference& operator=(bool value);
      reference& operator=(const reference& bitref);
      bool operator~( ) const;
      operator bool( ) const;
      reference& flip( );
	private:
		reference(myset& _myset, int _pos)
			: _pmyset(&_myset), _mypos(_pos) {}
		myset *_pmyset;	// ptr to the myset
		int	_mypos;		// position of item in myset
};

#endif
