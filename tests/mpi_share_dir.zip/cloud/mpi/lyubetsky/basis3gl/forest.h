//	basis3GL:  A program for basis trees construction, v.2.X.X
//	The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/super3gl]
//	(C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
// E-mail: rubanov{at}iitp.ru
//	This program is free software: you can redistribute it and/or modify
//	it under the terms of the GNU General Public License as published by
//	the Free Software Foundation, either version 3 of the License, or
//	(at your option) any later version.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details.
//
//	You should have received a copy of the GNU General Public License
//	along with this program.  If not, see <http://www.gnu.org/licenses/>.

#ifndef FOREST_H
#define FOREST_H

#include <string>
#include <map>
#include "basis3gl.h"
#include "myset.h"

using namespace std;

// forward declarations & definitions
class Tree;	
class Node;
typedef Tree *PTree;
typedef Node *PNode;
typedef map<string, PNode, less<string> > LeafMap;
typedef map<int, PNode, less<int> > InnerMap;
typedef pair<LeafMap::iterator, bool> LeafInsertResult;
typedef pair<InnerMap::iterator, bool> InnerInsertResult;
class myset;
struct Leaf3 { PNode a, b, c; };		// also used for getting two leaves (b,c) with 'a' as ancestor

// Defines a node of general tree 
class Node {
public:
	Node();
	Node(string name);
	Node(char* name);
	Node(int index);
	Node(string name, int index);
	~Node();
			// getters
	PNode			GetParent() { return Parent; };
	PNode			GetChild() { return Child; };
	PNode			GetSibling() { return Sibling; };
	PTree			GetOwner() { return Owner; };
	string		GetName() { return Name; };
	int			GetIndex() { return Index; };
	int			GetDegree() { return Degree; };
	int			GetDepth() { return Depth; };
	bool			IsLeaf() { return Leaf; };
   bool        GetFlag() { return Flag; }
	int			GetSpecies() { return Species; };
	float			GetLength() { return Length; };
	myset*		GetClade() { return Clade; };
			// setters
	void			SetParent(PNode node) { Parent = node; };
	void			SetChild(PNode node) { Child = node; };
	void			SetSibling(PNode node) { Sibling = node; };
	void			SetOwner(PTree owner) { Owner = owner; };
	void			SetName(const string& name) { Name = name; };
	void			SetName(char* name) { Name = name; };
	void			SetIndex(int index) { Index = index; };
	void			SetDegree(int d) { Degree = d; };
	void			SetDepth(int d) { Depth = d; };
	void			SetLeaf(bool flag=true) { Leaf = flag; };
   void        SetFlag(bool flag=true) { Flag = flag; };
	void			SetSpecies(int specnum) { Species = specnum; };
	void			SetLength(float len) { Length = len; };
	void			SetClade(myset* clade) { Clade = clade; };
			// others
	void			IncrementDegree() { Degree++; };
	void			DecrementDegree() { Degree--; };
	bool			HasParent() { return (Parent != NULL); };
protected:
	PNode			Parent;
	PNode			Child;			// Leftmost child
	PNode			Sibling;			// Next child of same parent
	PTree			Owner;			// Node->Tree pointer
	string		Name;
	int			Index;
	int			Degree;			// Children count
	int			Depth;			// Level number (0 for root) - rooted only
	bool			Leaf;				// true=leaf, false=inner
   bool        Flag;          // general purpose
	int			Species;			// Species number (leaves only)
	float			Length;			// Length of the edge to parent (weight - for basis3)
	myset			*Clade;			// Pointer to set of subordinate species numbers (inner only)
};

// Defines a general tree
class Tree {
public:
	Tree(int baseindex = 0);
	~Tree();
			// getters
	PNode			GetRoot() { return Root; };
	PNode			GetCurrent() { return Current; };
	string		GetName() { return Name; };
	bool			IsRooted() { return Rooted; };
	int			GetInnerCount() { return InnerCount; };
	int			GetLeafCount() { return LeafCount; };
	int			GetNodesCount() { return InnerCount + LeafCount; };
	int			GetMaxDepth() { return MaxDepth; };
	int			GetMaxIndex() { return MaxIndex; };
	int			GetMinDegree() { return MinDegree; };
	int			GetMaxDegree() { return MaxDegree; };
	int			GetGoodCount() { return GoodCount; };
			// setters or modifiers
	void			SetRoot(PNode root) { Root = root; };
	void			SetCurrent(PNode node) { Current = node; };
	void			SetName(const string& name) { Name = name; };
	void			SetName(char* name) { Name = name; };
	void			SetRooted(bool flag = true) { Rooted = flag; };
	void			SetGoodCount(int value) { GoodCount = value; };
	void			IncrementGoodCount(int delta = 1) { GoodCount += delta; };
			// others - see forest.cpp
	void			DeleteNodeTraverse(PNode node);
	void			DeleteNodeTraverse();
	void			RemoveNodeTraverse(PNode node);
	void			RemoveNodeTraverse();
	void			RemoveNode(PNode node);
	void			RemoveNode();
	PNode			GetInner(int index);
	PNode			GetInnerFirst();
	PNode			GetInnerLast();
	PNode			GetInnerNext();
	PNode			GetInnerPrev();
	PNode			SelectInner(int position);
	PNode			GetLeaf(const string& name);
	PNode			GetLeafFirst();
	PNode			GetLeafLast();
	PNode			GetLeafNext();
	PNode			GetLeafPrev();
	PNode			SelectLeaf(int position);
	void			Update();
	void			UpdateLite(PNode node);
	void			UpdateLite();
	PNode			AddInnerNode();
	PNode			AddLeafNode(const string& name);
	PNode			AddInnerChild(PNode parent);
	PNode			AddInnerChild();
	PNode			AddLeafChild(const string& name,PNode parent);
	PNode			AddLeafChild(const string& name);
	PNode			AddInnerSibling(PNode sibling);
	PNode			AddInnerSibling();
	PNode			AddLeafSibling(const string& name,PNode sibling);
	PNode			AddLeafSibling(const string& name);
	bool			Leaf2Inner(PNode node);
	bool			Leaf2Inner();
	bool			Inner2Leaf(PNode node,const string& name);
	bool			Inner2Leaf(const string& name);
	bool			Inner2Leaf(PNode node);
	bool			Inner2Leaf();
	PTree			DefineSubtree(PNode subroot);
	PTree			DefineSubtree();
	PNode			InsertParent(PNode node);
	PNode			InsertParent();
	void			Relink(PNode node,PNode to_parent);
	void			Relink(PNode to_parent);
	void			AttachSubtree(PTree subtree,PNode to_parent);
	void			AttachSubtree(PTree subtree);
	void			Reroot(PNode newroot);
	void			Reroot();
	void			MinMaxDegree(PNode node);
	void			MinMaxDegree();
	bool			Clone(PNode subroot,PNode to_parent);
	bool			Clone(PNode subroot);
	PTree			Clone(void);
   PTree       CloneCut(const myset&);
	bool			GetLeaf3First(Leaf3&);
	bool			GetLeaf3First(Leaf3&,const PNode);
	bool			GetLeaf3First(Leaf3&,const string&);
	bool			GetLeaf3Next(Leaf3&);
	bool			GetLeaf3NextFA(Leaf3&);
	bool			GetLeaf2First(Leaf3&);
	bool			GetLeaf2Next(Leaf3&);
	PNode			GetNCA(PNode, PNode);
	void			InnerPositionSave(void) { InnerIteratorMem = InnerIterator; };
	void			InnerPositionRestore(void) { InnerIterator = InnerIteratorMem; };
	bool			ChangeLeaf(PNode leaf, const string& name, int species);
			// others - see newick.cpp
	virtual string		Write(int mode = -1);	// mode is a sum of cfg->TreeWriteOption values, -1 for default
	virtual bool		Read(const string& s);
private:		// see forest.cpp
	void			deleteNodeTraverse(PNode node);
	void			removeNodeTraverse(PNode node);
	void			updateTree(PNode node);
	void			defineSubtree(PTree subtree,PNode node);
	void			cloneChildren(PNode source, PNode target);
	bool			Check(PNode node);
	bool			TripleTopology(Leaf3&);
			// see newick.cpp
	virtual string		normalName(const string& s);
	virtual string		insertName(PNode node,int mode);
	virtual string		writeTree(PNode node,int mode);
protected:
	PNode			Root;				// For unrooted too
	PNode			Current;			// Current node
	string		Name;
	bool			Rooted;
	int			InnerCount;		// Number of inner nodes (incl. root)
	int			LeafCount;		// Number of leaves
	int			MaxDepth;		// Number of levels - rooted only
	int			MaxIndex;		// Max used value of node index
	int			MinDegree;		// Min degree of inner node
	int			MaxDegree;		// Max degree of inner node
	InnerMap		Inners;			// All nodes but leaves
	LeafMap		Leaves;			// All leaves
	InnerMap::iterator	InnerIterator;		// Used by GetInnerFirst/Next
	InnerMap::iterator	InnerIteratorMem;	// Used to save/restore InnerIterator
	LeafMap::iterator		LeafIterator;		// Used by GetLeafFirst/Next
	LeafMap::iterator		lita, litb, litc;	// Used by GetLeaf3First/Next & GetLeaf2First/Next
	int			GoodCount;		// Total number of good edges over all set P
};

#endif
