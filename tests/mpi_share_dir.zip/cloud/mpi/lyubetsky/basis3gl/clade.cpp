//	basis3GL:  A program for basis trees construction, v.2.X.X
//	The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/super3gl]
//	(C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
// E-mail: rubanov{at}iitp.ru
//	This program is free software: you can redistribute it and/or modify
//	it under the terms of the GNU General Public License as published by
//	the Free Software Foundation, either version 3 of the License, or
//	(at your option) any later version.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details.
//
//	You should have received a copy of the GNU General Public License
//	along with this program.  If not, see <http://www.gnu.org/licenses/>.

#include <iostream>
#include <iomanip>
#include <complex>
#include <limits>
#include "basis3gl.h"
#include "forest.h"
#include "config.h"

using namespace std;

// Fills clade sets at each inner node of a given tree (from scratch)
void MakeClades(PTree tree) {
	if( ! tree )
		return;
	tree->InnerPositionSave();
	// Clear existing sets at every inner node
	for(PNode node = tree->GetInnerFirst(); node; node = tree->GetInnerNext()) {
		myset *clade = node->GetClade();
		if(clade)
			clade->reset();
		else 
			node->SetClade(new myset());
	}
	makeClade(tree->GetRoot());
	tree->InnerPositionRestore();
};

// Recursive function to fill clade at given node
void makeClade(PNode node) {
	if( ! node )
		return;
	myset *clade = node->GetClade();
	PNode child = node->GetChild();
	while(child) {
		if(child->IsLeaf())
			clade->set(child->GetSpecies());
		else {
			makeClade(child);
			myset *cc = child->GetClade();
			clade->join(*cc);
		}
		child = child->GetSibling();
	}
};

// Computes statistics of the input data
void AnalyzeTrees() {
	int perfect = 0, unrooted = 0, polytomous = 0, incomplete = 0;
	int polynum = 0, polymax = 0, polysum = 0;
	int minspec = numeric_limits<int>::max(), maxspec = 0;
	double sum = 0, sqsum = 0;
	int minleaf = numeric_limits<int>::max(), maxleaf = 0;
	double sumleaf = 0, sqsumleaf = 0;
	myset specused;
	for(int i = 0; i < cfg->TreeNum; i++) {
		// Milestones
		if(cfg->Milestones && (i & cfg->Milestones) == 0)
			*Con << "V" << setfill(' ') << setw(5) << cfg->current_n 
            << " T " << setfill(' ') << setw(4) << i << "      \r" << flush;
		PTree t = cfg->GTree[i];
		if(t == NULL)
			continue;
		MakeClades(t);
		myset *clade = t->GetRoot()->GetClade();
		specused.join(*clade);
		int nspec = (int)clade->count();
		/*		Output tree details
		static bool flag = true;
		flag = ! flag;
		if(flag) {
			cout << i+1 << ";" << t->GetLeafCount() << ";" << nspec;
			for(int cit = clade->first(); cit <= cfg->SpecNum; cit++)
				if( (*clade)[cit] )
					cout << ";" << cit;
			cout << endl;
		}
		*/
		if(nspec < minspec)
			minspec = nspec;
		if(nspec > maxspec)
			maxspec = nspec;
		sum += nspec;
		sqsum += (double)nspec * nspec;
		int leafcount = t->GetLeafCount();
		if(leafcount < minleaf)
			minleaf = leafcount;
		if(leafcount > maxleaf)
			maxleaf = leafcount;
		sumleaf += leafcount;
		sqsumleaf += (double)leafcount * leafcount;
		if(t->IsRooted() && t->GetMaxDegree() == 2 && t->GetMinDegree() == 2) {
			perfect ++;
			continue;
		}
		if( ! t->IsRooted())
			unrooted ++;
		if(t->GetMaxDegree() > 2) {
			polytomous ++;
			PNode node = t->GetInnerFirst();
			while(node) {
				int degree = node->GetDegree();
				if(degree > 2) {
					polynum++;
					polysum += degree;
					if(polymax < degree)
						polymax = degree;
				}
				node = t->GetInnerNext();
			}
		}
		if(t->GetMinDegree() < 2)
			incomplete ++;
	}
   // Logging results of the tree analysis
   if(cfg->LogIntermediate || cfg->ConIntermediate) {
	   int numtree = cfg->TreeNum - cfg->TreePruned;
      if(cfg->ConIntermediate)
	      *Con TSTAMP << "Total of " << numtree << " gene trees with " 
            << setprecision(0) << sumleaf << " leaves read." << endl;
      if(cfg->LogIntermediate)
	      *Log TSTAMP << "Total of " << numtree << " gene trees with " 
            << setprecision(0) << sumleaf << " leaves read." << endl;
	   if(numtree && sumleaf > 0) {
		   double m = sumleaf / numtree;
		   double d = sqsumleaf / numtree;
		   d -= m * m;
		   d = sqrt(d * numtree / (numtree - 1));
         if(cfg->ConIntermediate)
		      *Con TSTAMP << "Leaves per tree: min=" << minleaf << ", max=" 
               << maxleaf << ", average=" << fixed << setprecision(0) 
               << m << ", stdev=" << d << "." << endl;
         if(cfg->LogIntermediate)
		      *Log TSTAMP << "Leaves per tree: min=" << minleaf << ", max=" 
               << maxleaf << ", average=" << fixed << setprecision(0) 
               << m << ", stdev=" << d << "." << endl;
		   if(specused.count()) {
			   m = sum / numtree;
			   d = sqsum / numtree;
			   d -= m * m;
			   d = sqrt(d * numtree / (numtree - 1));
            if(cfg->ConIntermediate)
			      *Con TSTAMP << "Species per tree: min=" << minspec << ", max=" 
                  << maxspec << ", average=" << fixed << setprecision(0) 
                  << m << ", stdev=" << d << "." << endl;
            if(cfg->LogIntermediate)
			      *Log TSTAMP << "Species per tree: min=" << minspec << ", max=" 
                  << maxspec << ", average=" << fixed << setprecision(0) 
                  << m << ", stdev=" << d << "." << endl;
		   }
	   }
      if(cfg->ConIntermediate)
	      *Con TSTAMP << "Trees: perfect=" << perfect << ", unrooted=" << unrooted 
            << ", polytomous=" << polytomous << ", incomplete=" << incomplete 
            << "." << endl;
      if(cfg->LogIntermediate)
	      *Log TSTAMP << "Trees: perfect=" << perfect << ", unrooted=" << unrooted 
            << ", polytomous=" << polytomous << ", incomplete=" << incomplete 
            << "." << endl;
	   if(polytomous) {
		   double avgdeg = polysum;
		   avgdeg /= polynum;
         if(cfg->ConIntermediate)
		      *Con TSTAMP << "Polytomous nodes: total=" << polynum << ", max_degree=" 
               << polymax << ", avg_degree=" << fixed << setprecision(0) << avgdeg 
               << "." << endl;
         if(cfg->LogIntermediate)
		      *Log TSTAMP << "Polytomous nodes: total=" << polynum << ", max_degree=" 
            << polymax << ", avg_degree=" << fixed << setprecision(0) << avgdeg 
            << "." << endl;
	   }
      if(cfg->ConIntermediate)
	      *Con TSTAMP << "Overall species found: " << specused.count() << "." << endl;
      if(cfg->LogIntermediate)
	      *Log TSTAMP << "Overall species found: " << specused.count() << "." << endl;
   }
	if(polytomous > 0)
		cfg->Polytomy = true;
};

// Eliminates rarely occurred species and removes non-informative trees
void PruneTrees(void) {
	for(int i = 0; i < cfg->TreeNum; i++) {
		// Milestones
		if(cfg->Milestones && (i & cfg->Milestones) == 0)
			*Con << "V" << setfill(' ') << setw(5) << cfg->current_n 
            << " T " << setfill(' ') << setw(4) << i << "      \r" << flush;
		PTree t = cfg->GTree[i];
      if(!t)
         continue;
		PNode root = t->GetRoot();
		if(root->GetClade()->count() == 1) {		// delete one-species tree
			cfg->GTree[i] = NULL;
			delete t;
			cfg->TreePruned ++;
		}
		else												// count species occurrences
			calcMeeting(root);
	}
   if(cfg->TreePruned && cfg->ConIntermediate)
		*Con TSTAMP << "Removing " << cfg->TreePruned << " single-species tree(s)." << endl;
   if(cfg->TreePruned && cfg->LogIntermediate)
		*Log TSTAMP << "Removing " << cfg->TreePruned << " single-species tree(s)." << endl;
	// Compute species occurrence statistics
	int minocc = numeric_limits<int>::max(), maxocc = 0, sum = 0, sqsum = 0;
	int delspecies = 0;
	for(int sp = 1; sp <= cfg->SpecNum; sp++) {
		// Milestones
		if(cfg->Milestones && (sp & cfg->Milestones) == 0)
			*Con << "V" << setfill(' ') << setw(5) << cfg->current_n 
            << " S " << setfill(' ') << setw(4) << sp << "      \r" << flush;
		SData *spdata = & cfg->SpeciesData[sp];
      if( !spdata->Enable )
         continue;
		if(cfg->TreePruningMode && spdata->Meet < cfg->Threshold) {		// Disable rare species
			delspecies ++;
			spdata->Enable = false;
			cfg->Species.erase(spdata->Code);
		}
		else {
			if(spdata->Meet < minocc)
				minocc = spdata->Meet;
			if(spdata->Meet > maxocc)
				maxocc = spdata->Meet;
			sum += spdata->Meet;
			sqsum += spdata->Meet * spdata->Meet;
		}
	}
	int actspec = cfg->SpecNum - delspecies;
   // Log pruning results
   if(cfg->LogIntermediate || cfg->ConIntermediate) {
	   float m = (float)sum / actspec;
	   float d = (float)sqsum / actspec;
	   d -= m * m;
	   d = sqrt(d * actspec / (actspec - 1));
	   if(actspec > 0) {
         if(cfg->ConIntermediate)
		      *Con TSTAMP << "Species occurrence: min=" << minocc << ", max=" << maxocc << ", average=" 
			      << fixed << setprecision(0) << m << ", stdev=" << d << "." << endl;
         if(cfg->LogIntermediate)
		      *Log TSTAMP << "Species occurrence: min=" << minocc << ", max=" << maxocc << ", average=" 
			      << fixed << setprecision(0) << m << ", stdev=" << d << "." << endl;
	   }
   }
	if(!cfg->TreePruningMode || delspecies == 0) 
		return;
   if(cfg->ConIntermediate)
	   *Con TSTAMP << "Removing " << delspecies << " species due to occurrence threshold of " 
		   << cfg->Threshold << "." << endl;
   if(cfg->LogIntermediate) 
	   *Log TSTAMP << "Removing " << delspecies << " species due to occurrence threshold of " 
		   << cfg->Threshold << "." << endl;

      // Remove deleted species from each tree and possibly delete a tree itself
	int deltreemore = 0;
	for(int i = 0; i < cfg->TreeNum; i++) {
		// Milestones
		if(cfg->Milestones && (i & cfg->Milestones) == 0)
			*Con << "V" << setfill(' ') << setw(5) << cfg->current_n 
            << " T " << setfill(' ') << setw(4) << i << "      \r" << flush;
		PTree t = cfg->GTree[i];
		if(t == NULL)		// already removed
			continue;
		PNode leaf = t->GetLeafFirst();
		while(leaf) {
			int sp = leaf->GetSpecies();
			SData *spdata = & cfg->SpeciesData[sp];
			PNode parent = leaf->GetParent();
			PNode nextleaf = t->GetLeafNext();
			if( ! spdata->Enable) {		// Remove this leaf
				t->RemoveNode(leaf);
				if( t->GetLeafCount() <= 1) {		// one or no leaves remain
					cfg->GTree[i] = NULL;
					delete t;
					t = NULL;
					cfg->TreePruned ++;
					deltreemore ++;
					break;
				}
				if(parent->GetDegree() == 1) {
					PNode root = t->GetRoot();
					if(parent == root)			// special case of root's child leaf removal
						t->Reroot(parent->GetChild());
					t->RemoveNode(parent);
				}
			}
			leaf = nextleaf;
		}
		if(t) {
			t->UpdateLite(t->GetRoot());
			MakeClades(t);
			if(t->GetRoot()->GetClade()->count() == 1) {		// delete more one-species tree
				cfg->GTree[i] = NULL;
				delete t;
				cfg->TreePruned ++;
				deltreemore ++;
			}
		}
	}
   if(deltreemore && cfg->ConIntermediate) 
		*Con TSTAMP << "Removing " << deltreemore << " empty/one-leaf trees." << endl;
   if(deltreemore && cfg->LogIntermediate) 
		*Log TSTAMP << "Removing " << deltreemore << " empty/one-leaf trees." << endl;
   if(cfg->ConIntermediate)
	   *Con TSTAMP << "Refreshing statistics of input data..." << endl;
   if(cfg->LogIntermediate)
	   *Log TSTAMP << "Refreshing statistics of input data..." << endl;
	AnalyzeTrees();
};

// Recursive subroutine to calculate all meetings occurring below given node
void calcMeeting(PNode node) {
	if( !node )
		return;
	if(node->IsLeaf()) 
		cfg->SpeciesData[node->GetSpecies()].Meet ++;
	else {
		if(node->GetClade()->count() == 1) 
			cfg->SpeciesData[node->GetClade()->first()].Meet ++;
		else {
			PNode child = node->GetChild();
			while(child) {
				calcMeeting(child);
				child = child->GetSibling();
			}
		}
	}
};

// Builds sorted set P of all clades from all trees + V0 + all sets of size |V0|-1
void BuildPSetOfSetOfSpecies( ) {
	VData vdata;
	vdata.Basis = false;
	vdata.Cost = 0.0F;
	#ifdef BTREEWEIGHT
	vdata.Weight = 1.0F;
	#endif
	vdata.BasTree = NULL;
	vdata.GoodNum = 0;
   vdata.GoodEdge = 0;
	for(int i = 0; i < cfg->TreeNum; i++) {
		// Milestones
		if(cfg->Milestones && (i & cfg->Milestones) == 0)
			*Con << "T " << setfill(' ') << setw(4) << i << "      \r" << flush;
		PTree t = cfg->GTree[i];
		if(t == NULL)
			continue;
		// First collect all leaves
		PNode node = t->GetLeafFirst();
		while(node) {
			myset clade1;
			clade1.set(node->GetSpecies());
			cfg->PSet.insert(PSetMapPair(clade1,vdata));
			node = t->GetLeafNext();
		}
		// Then collect all inner nodes
		node = t->GetInnerFirst();
		while(node) {
			cfg->PSet.insert(PSetMapPair(*(node->GetClade()),vdata));
			node = t->GetInnerNext();
		}
		if(cfg->ExtendPset) {		// Additional clades
			Leaf3 trinode;
			PNode lnode, rnode, node;
			myset share, clade;
			bool eop = t->GetLeaf2First(trinode);
			// Loop for each pair of leaves (=paths)
			while(eop) {	
				// Nested loop for each pair of nodes from the two paths until junction
				for(lnode = trinode.b; lnode != trinode.a; lnode = lnode->GetParent()) {
					for(rnode = trinode.c; rnode != trinode.a; rnode = rnode->GetParent()) {
						if(!lnode->IsLeaf() && !rnode->IsLeaf()) {			// two inner nodes
							share.assign(*(lnode->GetClade()));
							share.intersect(*(rnode->GetClade()));
							if(share.any()) {				// ignore case of non-intersecting clades
								clade.assign(*(lnode->GetClade()));
								clade.difference(share);
								if(clade.any())
									cfg->PSet.insert(PSetMapPair(clade,vdata));		// C(v1)\I
								clade.assign(*(rnode->GetClade()));
								clade.difference(share);
								if(clade.any())
									cfg->PSet.insert(PSetMapPair(clade,vdata));		// C(v2)\I
								node = lnode->GetParent();
								share.assign(*(lnode->GetClade()));
								for( ; node != trinode.a; node = node->GetParent()) {
									clade.assign(*(node->GetClade()));
									clade.difference(share);
									if(clade.any())
										cfg->PSet.insert(PSetMapPair(clade,vdata));	// C(v)\C(v1)
								}
								node = rnode->GetParent();
								share.assign(*(rnode->GetClade()));
								for( ; node != trinode.a; node = node->GetParent()) {
									clade.assign(*(node->GetClade()));
									clade.difference(share);
									if(clade.any())
										cfg->PSet.insert(PSetMapPair(clade,vdata));	// C(v)\C(v2)
								}
							}
						}
						else if(!lnode->IsLeaf() && rnode->IsLeaf()) {		// inner vs leaf
							int rsp = rnode->GetSpecies();
							clade.assign(*(lnode->GetClade()));
							if(IsContained(clade, rsp)) {
								clade.bit(rsp, false);
								if(clade.any())
									cfg->PSet.insert(PSetMapPair(clade,vdata));		// C(v1)\I
								node = lnode->GetParent();
								share.assign(*(lnode->GetClade()));
								for( ; node != trinode.a; node = node->GetParent()) {
									clade.assign(*(node->GetClade()));
									clade.difference(share);
									if(clade.any())
										cfg->PSet.insert(PSetMapPair(clade,vdata));	// C(v)\C(v1)
								}
							}
						}
						else if(lnode->IsLeaf() && !rnode->IsLeaf()) {		// leaf vs inner
							int lsp = lnode->GetSpecies();
							clade.assign(*(rnode->GetClade()));
							if(IsContained(clade, lsp)) {
								clade.bit(lsp, false);
								if(clade.any())
									cfg->PSet.insert(PSetMapPair(clade,vdata));		// C(v2)\I
								node = rnode->GetParent();
								share.assign(*(rnode->GetClade()));
								for( ; node != trinode.a; node = node->GetParent()) {
									clade.assign(*(node->GetClade()));
									clade.difference(share);
									if(clade.any())
										cfg->PSet.insert(PSetMapPair(clade,vdata));	// C(v)\C(v2)
								}
							}
						}
					}
				}
				eop = t->GetLeaf2Next(trinode);
			}
		}
	}
	// Form V0 set
	myset v0;
	for(int sp = 1; sp <= cfg->SpecNum; sp++) {
		SData *spdata = & cfg->SpeciesData[sp];
		if( ! spdata->Enable)
			continue;
		v0[sp] = true;
	}
	// Add all sets of size |V0|-1
	int i = 0;
	for(int sp = cfg->SpecNum; sp > 0; sp--) {
		// Milestones
		if(cfg->Milestones && (i & cfg->Milestones) == 0)
			*Con << "S " << setfill(' ') << setw(4) << i << "      \r" << flush;
		i++;
		if( ! cfg->SpeciesData[sp].Enable )
			continue;
		v0[sp] = false;
		cfg->PSet.insert(--cfg->PSet.end(), PSetMapPair(v0, vdata));
		v0[sp] = true;
	}
	// Add V0 set
	cfg->PSet.insert(--cfg->PSet.end(), PSetMapPair(v0, vdata));
   if(cfg->ConIntermediate)
	   *Con TSTAMP << "Set P of clades consists of " << cfg->PSet.size() << " elements." << endl;
   if(cfg->LogIntermediate)
	   *Log TSTAMP << "Set P of clades consists of " << cfg->PSet.size() << " elements." << endl;
};
