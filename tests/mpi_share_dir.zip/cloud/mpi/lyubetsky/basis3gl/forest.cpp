//	basis3GL:  A program for basis trees construction, v.2.X.X
//	The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/super3gl]
//	(C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
// E-mail: rubanov{at}iitp.ru
//	This program is free software: you can redistribute it and/or modify
//	it under the terms of the GNU General Public License as published by
//	the Free Software Foundation, either version 3 of the License, or
//	(at your option) any later version.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details.
//
//	You should have received a copy of the GNU General Public License
//	along with this program.  If not, see <http://www.gnu.org/licenses/>.

#include <sstream>
#include <iomanip>
#include <limits>
#include "basis3gl.h"
#include "forest.h"
#include "config.h"

using namespace std;

// Constructs empty node off a tree
Node::Node() {
	Parent = Child = Sibling = NULL;
	Owner = NULL;
	Name = "";
	Index = 0;
	Degree = 0;
	Depth = 0;
	Leaf = false;
	Species = 0;
	Length = 1.0F;
	Clade = NULL;
};

// Constructs named node off a tree
Node::Node(string name) {
	Parent = Child = Sibling = NULL;
	Owner = NULL;
	Name = name;
	Index = 0;
	Degree = 0;
	Depth = 0;
	Leaf = false;
	Species = 0;
	Length = 1.0F;
	Clade = NULL;
};

// Constructs named node off a tree
Node::Node(char* name) {
	Parent = Child = Sibling = NULL;
	Owner = NULL;
	Name = name;
	Index = 0;
	Degree = 0;
	Depth = 0;
	Leaf = false;
	Species = 0;
	Length = 1.0F;
	Clade = NULL;
};

// Constructs indexed node off a tree
Node::Node(int index) {
	Parent = Child = Sibling = NULL;
	Owner = NULL;
	Name = "";
	Index = index;
	Degree = 0;
	Depth = 0;
	Leaf = false;
	Species = 0;
	Length = 1.0F;
	Clade = NULL;
};

// Constructs named & indexed node off a tree
Node::Node(string name, int index) {
	Parent = Child = Sibling = NULL;
	Owner = NULL;
	Name = name;
	Index = index;
	Degree = 0;
	Depth = 0;
	Leaf = false;
	Species = 0;
	Length = 1.0F;
	Clade = NULL;
};

// Destructs a node
Node::~Node() {
	delete Clade;
}

// Constructs empty tree [with shifted index base]
Tree::Tree(int baseindex) {
	Root = Current = NULL;
	Name = "";
	Rooted = false;
	InnerCount = LeafCount = MaxDepth = 0;
	MaxIndex = baseindex;
	MinDegree = numeric_limits<int>::max();
	MaxDegree = 0;
	Inners.clear();
	Leaves.clear();
	GoodCount = 0;
};

// Deletes tree along with its nodes
Tree::~Tree() {
	DeleteNodeTraverse(Root);
	Inners.clear();
	Leaves.clear();
}

// Deletes entire subtree not modifying maps, counts, etc.
// The subroot node itself will be removed from remaining links
void Tree::DeleteNodeTraverse(PNode node) {
	if( !Check(node))
		return;
	PNode parent = node->GetParent();
	if(parent) {				// remove from links
		PNode child = parent->GetChild();
		if(child == node)		// node is leftmost child
			parent->SetChild(node->GetSibling());
		else {					// node isn't leftmost child
			while(child->GetSibling()) {
				if(child->GetSibling() == node) {	// node found
					child->SetSibling(node->GetSibling());
					break;
				}
				child = child->GetSibling();
			}
		}
		parent->DecrementDegree();
		MinMaxDegree(parent);
	}
	else if(node == Root) 
		Root = NULL;
	else
		throw("DeleteNodeTraverse: Nonroot has no parent.");
	if(node == Current)
		Current = NULL;
	deleteNodeTraverse(node);
}

// Deletes subtree rooted at current node not modifying maps, counts, etc.
// The current node itself will be removed from remaining links
void Tree::DeleteNodeTraverse() {
	DeleteNodeTraverse(Current);
}

// Private recursive routine for node deletion
void Tree::deleteNodeTraverse(PNode node) {
	if( !Check(node))
		return;
	PNode child = node->GetChild();
	while(child) {
		PNode nextchild = child->GetSibling();
		deleteNodeTraverse(child);
		child = nextchild; 
	}
	if(node->GetIndex() == MaxIndex)
		MaxIndex--;
	delete node;
};

// Deletes entire subtree and modifies maps & counts
void Tree::RemoveNodeTraverse(PNode node) {
	if( !Check(node))
		return;
	PNode parent = node->GetParent();
	if(parent) {				// remove from links
		PNode child = parent->GetChild();
		if(child == node)		// node is leftmost child
			parent->SetChild(node->GetSibling());
		else {					// node isn't leftmost child
			while(child->GetSibling()) {
				if(child->GetSibling() == node) {	// node found
					child->SetSibling(node->GetSibling());
					break;
				}
				child = child->GetSibling();
			}
		}
		parent->DecrementDegree();
		MinMaxDegree(parent);
	}
	else if(node == Root) 
		Root = NULL;
	else
		throw("RemoveNodeTraverse: Nonroot has no parent.");
	if(node == Current)
		Current = NULL;
	removeNodeTraverse(node);
};

// Deletes subtree rooted at current node and modifies maps & counts
void Tree::RemoveNodeTraverse() {
	RemoveNodeTraverse(Current);
}

// Private recursive routine for node removal
void Tree::removeNodeTraverse(PNode node) {
	if( !Check(node))
		return;
	PNode child = node->GetChild();
	while(child) {
		PNode nextchild = child->GetSibling();
		removeNodeTraverse(child);
		child = nextchild; 
	}
	if(node->IsLeaf()) {
		LeafMap::iterator itl = Leaves.find(node->GetName());
		if(itl != Leaves.end()) {
			Leaves.erase(itl);
			LeafCount--;
		}
		else
			throw("RemoveNodeTraverse: Not found in leaves.");
	}
	else {
		InnerMap::iterator iti = Inners.find(node->GetIndex());
		if(iti != Inners.end()) {
			Inners.erase(iti);
			InnerCount--;
		}
		else
			throw("RemoveNodeTraverse: Not found in inners.");
	}
	if(node == Current)
		Current = NULL;
	if(node->GetIndex() == MaxIndex)
		MaxIndex--;
	delete node;
};

// Deletes a node and modifies Inners/Leaves maps & counts
// The node's subtree will be appended to its parent
// Depths/degrees in the subtree will be updated
void Tree::RemoveNode(PNode node) {
	if( !Check(node))
		return;
	PNode parent = node->GetParent();
	int depth = node->GetDepth();
	if(parent) {					// remove from links
		PNode child = parent->GetChild();
		if(child == node) {		// node is leftmost child
			parent->SetChild(node->GetSibling());
			while(child->GetSibling())		// traverse all siblings but last one
				child = child->GetSibling();
		}
		else {
			while(child->GetSibling()) {
				if(child->GetSibling() == node) {	// if node is righter child
					child->SetSibling(node->GetSibling());
					if( ! node->GetSibling())		// node is rightmost child
						break;
				}
				child = child->GetSibling();
			}
		}
		child->SetSibling(node->GetChild());	// append children to sibling list
		child = node->GetChild();
		while(child) {		// relink children to the node's parent
			child->SetParent(parent);
			child->SetDepth(depth);
			UpdateLite(child);
			child = child->GetSibling();
		}
		parent->SetDegree(parent->GetDegree() + node->GetDegree() - 1);
		MinMaxDegree(parent);
	}
	else if(node == Root) { 
		if(node->GetDegree() == 1) {
			Root = node->GetChild();
			Root->SetParent(NULL);
		}
		else
			throw("RemoveNode: Cannot remove root with two children or more.");
	}
	else
		throw("RemoveNode: Nonroot has no parent.");
	if(node->IsLeaf()) {
		LeafMap::iterator itl = Leaves.find(node->GetName());
		if(itl != Leaves.end()) {
			Leaves.erase(itl);
			LeafCount--;
		}
		else
			throw("RemoveNode: Not found in leaves.");
	}
	else {
		InnerMap::iterator iti = Inners.find(node->GetIndex());
		if(iti != Inners.end()) {
			Inners.erase(iti);
			InnerCount--;
		}
		else
			throw("RemoveNode: Not found in inners.");
	}
	if(node == Current)
		Current = NULL;
	if(node->GetIndex() == MaxIndex)
		MaxIndex--;
	delete node;
};

// Deletes current node and modifies Inners/Leaves maps & counts
// The node itself will be removed from remaining links
// The node's subtree will be appended to its parent
void Tree::RemoveNode() {
	RemoveNode(Current);
};

// Fast inner mode lookup by its index
// Returns node pointer or NULL if not found
PNode Tree::GetInner(int index) {
	InnerIterator = Inners.find(index);
	if(InnerIterator == Inners.end())
		return NULL;
	else
		return (*InnerIterator).second;
};

// Gets first inner node in series
// Returns node pointer or NULL if none
PNode Tree::GetInnerFirst() {
	if(Inners.empty())
		return NULL;
	InnerIterator = Inners.begin();
	return (*InnerIterator).second;
};

// Gets last inner node in series
// Returns node pointer or NULL if none
PNode Tree::GetInnerLast() {
	if(Inners.empty())
		return NULL;
	InnerIterator = Inners.end();
	InnerIterator--;		// since end refers to the location succeeding the map
	return (*InnerIterator).second;
};

// Gets next inner node using current value of InnerIterator
// Returns node pointer or NULL if none
// Nonempty map is assumed
PNode Tree::GetInnerNext() {
	if((++InnerIterator) == Inners.end())
		return NULL;
	return (*InnerIterator).second;
}

// Gets previous inner node using current value of InnerIterator
// Returns node pointer or NULL if none
// Nonempty map is assumed
PNode Tree::GetInnerPrev() {
	if((InnerIterator--) == Inners.begin())
		return NULL;
	return (*InnerIterator).second;
}

// Slow inner node lookup by its position in series
// Returns the node pointer or NULL if not found
// For loops, use GetInnerFirst/Next/Last/Prev instead
PNode Tree::SelectInner(int position) {
	if(position < 0 || position >= (signed)Inners.size())
		return NULL;
	if(position < (signed)Inners.size() / 2) {
		InnerIterator = Inners.begin();
		for(int i=0; i<position; i++)
			InnerIterator++;
	}
	else {
		InnerIterator = Inners.end();
		for(int i=(signed)Inners.size(); i>position; i--)
			InnerIterator--;
	}
	return (*InnerIterator).second;
};

// Fast lookup of a leaf by its name
// Returns pointer to the leaf or NULL if not found
PNode Tree::GetLeaf(const string& name) {
	if(name.empty())
		return NULL;
	LeafIterator = Leaves.find(name);
	if(LeafIterator == Leaves.end())
		return NULL;
	else
		return (*LeafIterator).second;
};

// Gets first leaf in series
// Returns leaf pointer or NULL if none
PNode Tree::GetLeafFirst() {
	if(Leaves.empty())
		return NULL;
	LeafIterator = Leaves.begin();
	return (*LeafIterator).second;
};

// Gets last leaf in series
// Returns leaf pointer or NULL if none
PNode Tree::GetLeafLast() {
	if(Leaves.empty())
		return NULL;
	LeafIterator = Leaves.end();
	LeafIterator--;		// since end refers to the location succeeding the map
	return (*LeafIterator).second;
};

// Gets next leaf using current value of LeafIterator
// Returns leaf pointer or NULL if none
// Nonempty map is assumed
PNode Tree::GetLeafNext() {
	if((++LeafIterator) == Leaves.end())
		return NULL;
	return (*LeafIterator).second;
}

// Gets previous leaf using current value of LeafIterator
// Returns leaf pointer or NULL if none
// Nonempty map is assumed
PNode Tree::GetLeafPrev() {
	if((LeafIterator--) == Leaves.begin())
		return NULL;
	return (*LeafIterator).second;
}

// Slow leaf lookup by its position in series
// Returns the leaf pointer or NULL if not found
// For selection loop, use GetLeafFirst/Next instead
PNode Tree::SelectLeaf(int position) {
	if(position < 0 || position >= (signed)Leaves.size())
		return NULL;
	if(position < (signed)Leaves.size() / 2) {
		LeafIterator = Leaves.begin();
		for(int i=0; i<position; i++)
			LeafIterator++;
	}
	else {
		LeafIterator = Leaves.end();
		for(int i=(signed)Leaves.size(); i>position; i--)
			LeafIterator--;
	}
	return (*LeafIterator).second;
};

// Recreate maps, counts, degrees, depths and MaxDepth from scratch
void Tree::Update() {
	InnerCount = LeafCount = 0;
	Inners.clear();
	Leaves.clear();
	Root->SetDepth(0);
	MaxDepth = 0;
	MinDegree = numeric_limits<int>::max();
	MaxDegree = 0;
	updateTree(Root);
};

// Private recursive routine for tree traverse/update
void Tree::updateTree(PNode node) {
	if( !Check(node))
		return;
	node->SetDegree(0);
	if(node->IsLeaf()) {		// leaf found - terminate recursion
		LeafInsertResult lir = Leaves.insert(LeafMap::value_type(node->GetName(), node));
		if(! lir.second)
			throw("Update: Duplicate leaf name " + node->GetName() + ".");
		LeafCount++;
	}
	else {		// traverse recursively
		InnerInsertResult iir = Inners.insert(InnerMap::value_type(node->GetIndex(), node));
		if(! iir.second) {
			ostringstream oss;
			oss << "Update: Duplicate inner node index " << node->GetIndex() << ".";
			throw(oss.str());
		}
		InnerCount++;
		PNode child = node->GetChild();
		int depth = node->GetDepth() + 1;
		while(child) {
			node->IncrementDegree();
			child->SetDepth(depth);
			if(depth > MaxDepth)
				MaxDepth = depth;
			updateTree(child);
			child = child->GetSibling();
		}
		MinMaxDegree(node);
	}
};

// Recalculates degrees/depths/MaxDepth traversing from given node
void Tree::UpdateLite(PNode node) {
	if( !Check(node))
		return;
	if(! node->GetParent()) {		// Recalculate degree/depth limits if no parent
		node->SetDepth(0);
		MaxDepth = 0;
		MinDegree = numeric_limits<int>::max();
		MaxDegree = 0;
	};
	node->SetDegree(0);
	if(node->IsLeaf())
		return;
	PNode child = node->GetChild();
	int depth = node->GetDepth() + 1;
	while(child) {
		node->IncrementDegree();
		child->SetDepth(depth);
		if(depth > MaxDepth)
			MaxDepth = depth;
		UpdateLite(child);
		child = child->GetSibling();
	}
	MinMaxDegree(node);
};

// Recalculates degrees/depths/MaxDepth traversing from current node
void Tree::UpdateLite() {
	UpdateLite(Current);
};

// Adds new inner node not tied to any other node yet
// Returns the node pointer and moves Current to it if successful
PNode Tree::AddInnerNode() {
	PNode node = new Node(++MaxIndex);
	node->SetOwner(this);
	InnerInsertResult iir = Inners.insert(InnerMap::value_type(MaxIndex,node));
	if(! iir.second) {
		ostringstream oss;
		oss << "AddInnerNode: Duplicate inner node index " << node->GetIndex() << ".";
		throw(oss.str());
	}
	InnerCount++;
	Current = node;
	return node;
};

// Adds new leaf node not tied to any other node yet
// Returns the node pointer and moves Current to it if successful
PNode Tree::AddLeafNode(const string& name) {
	if(name.empty())
		throw("AddLeafNode: Cannot add unnamed leaf.");
	PNode node = new Node(name, ++MaxIndex);
	node->SetOwner(this);
	node->SetLeaf(true);
	LeafInsertResult lir = Leaves.insert(LeafMap::value_type(name,node));
	if(! lir.second)
		throw("AddLeafNode: Duplicate leaf name " + name + ".");
	LeafCount++;
	Current = node;
	return node;
};

// Adds new INNER child to given node
// Returns the child pointer or NULL. Moves Current if successful
PNode Tree::AddInnerChild(PNode parent) {
	if( !Check(parent))
		return NULL;
	PNode node = AddInnerNode();
	node->SetParent(parent);
	int depth = parent->GetDepth() + 1;
	node->SetDepth(depth);
	if(depth > MaxDepth)
		MaxDepth = depth;
	parent->IncrementDegree();
	if(! parent->GetChild())
		parent->SetChild(node);
	else {
		PNode child = parent->GetChild();
		while(child->GetSibling()) 
			child = child->GetSibling();
		child->SetSibling(node);
	}
	MinMaxDegree(parent);
	return (Current = node);
};

// Adds new INNER child to current node
// Returns the child pointer or NULL. Moves Current if successful
PNode Tree::AddInnerChild() {
	return AddInnerChild(Current);
};

// Adds new LEAF child to given node
// Returns the child pointer or NULL. Moves Current if successful
PNode Tree::AddLeafChild(const string& name, PNode parent) {
	if( !Check(parent) || name.empty())
		return NULL;
	PNode node = AddLeafNode(name);
	node->SetParent(parent);
	int depth = parent->GetDepth() + 1;
	node->SetDepth(depth);
	if(depth > MaxDepth)
		MaxDepth = depth;
	parent->IncrementDegree();
	if(! parent->GetChild())
		parent->SetChild(node);
	else {
		PNode child = parent->GetChild();
		while(child->GetSibling()) 
			child = child->GetSibling();
		child->SetSibling(node);
	}
	MinMaxDegree(parent);
	return (Current = node);
};

// Adds new LEAF child to current node
// Returns the child pointer or NULL. Moves Current if successful
PNode Tree::AddLeafChild(const string& name) {
	return AddLeafChild(name, Current);
};

// Adds new INNER sibling to given node
// Returns the sibling pointer or NULL. Moves Current if successful
PNode Tree::AddInnerSibling(PNode sibling) {
	if( !Check(sibling) || !sibling->GetParent())
		return NULL;
	PNode node = AddInnerNode();
	PNode parent = sibling->GetParent();
	node->SetParent(parent);
	node->SetDepth(sibling->GetDepth());
	parent->IncrementDegree();
	MinMaxDegree(parent);
	node->SetSibling(sibling->GetSibling());
	sibling->SetSibling(node);
	return (Current = node);
};

// Adds new INNER sibling to current node
// Returns the sibling pointer or NULL. Moves Current if successful
PNode Tree::AddInnerSibling() {
	return AddInnerSibling(Current);
};

// Adds new LEAF sibling to given node
// Returns the sibling pointer or NULL. Moves Current if successful
PNode Tree::AddLeafSibling(const string& name, PNode sibling) {
	if( !Check(sibling) || !sibling->GetParent() || name.empty())
		return NULL;
	PNode node = AddLeafNode(name);
	PNode parent = sibling->GetParent();
	node->SetParent(parent);
	node->SetDepth(sibling->GetDepth());
	parent->IncrementDegree();
	MinMaxDegree(parent);
	node->SetSibling(sibling->GetSibling());
	sibling->SetSibling(node);
	return (Current = node);
};

// Adds new LEAF sibling to current node
// Returns the sibling pointer or NULL. Moves Current if successful
PNode Tree::AddLeafSibling(const string& name) {
	return AddLeafSibling(name,Current);
};

// Converts given leaf into inner node
// Returns true(OK) of false(errors)
bool Tree::Leaf2Inner(PNode node) {
	if( !Check(node) || !node->IsLeaf() )
		return false;
	node->SetLeaf(false);
	if(node->GetIndex() <= 0)
		node->SetIndex(++MaxIndex);
	InnerInsertResult iir = Inners.insert(InnerMap::value_type(MaxIndex,node));
	if(! iir.second)
		return false;
	InnerCount++;
	LeafMap::size_type lms = Leaves.erase(node->GetName());
	if(lms != 1)
		return false;
	LeafCount--;
	return true;
};

// Converts Current leaf into inner node
// Returns true(OK) of false(errors)
bool Tree::Leaf2Inner() {
	return Leaf2Inner(Current);
};

// Converts inner node into a leaf with given name
// Returns true(OK) of false(errors)
bool Tree::Inner2Leaf(PNode node, const string& name) {
	if( !Check(node) || node->IsLeaf() )
		return false;
	node->SetLeaf(true);
	node->SetName(name);
	InnerMap::size_type ims = Inners.erase(node->GetIndex());
	if(ims != 1)
		return false;
	InnerCount--;
	LeafInsertResult lir = Leaves.insert(LeafMap::value_type(name,node));
	if(! lir.second)
		return false;
	LeafCount++;
	return true;
};

// Converts current inner node into a leaf with given name
// Returns true(OK) of false(errors)
bool Tree::Inner2Leaf(const string& name) {
	return Inner2Leaf(Current,name);
};

// Convert inner node into a leaf with existing or generated name
// Returns true(OK) of false(errors)
bool Tree::Inner2Leaf(PNode node) {
	if( !Check(node) || node->IsLeaf() )
		return false;
	node->SetLeaf();
	if(node->GetName().empty()) {
		ostringstream oss;
		oss << "Node" << node->GetIndex();
		node->SetName(oss.str());
	}
	InnerMap::size_type ims = Inners.erase(node->GetIndex());
	if(ims != 1)
		return false;
	InnerCount--;
	LeafInsertResult lir = Leaves.insert(LeafMap::value_type(node->GetName(),node));
	if(! lir.second)
		return false;
	LeafCount++;
	return true;
};

// Convert inner node into a leaf with existing or generated name
// Returns true(OK) of false(errors)
bool Tree::Inner2Leaf() {
	return Inner2Leaf(Current);
};

// Logically defines rooted subtree with a root at given node
// Counts inners/leaves, fills maps and computes MaxDepth
// Depths/degrees of existing nodes are not modified!
PTree Tree::DefineSubtree(PNode subroot) {
	if( !Check(subroot))
		return NULL;
	PTree subtree = new Tree;
	subtree->Root = subroot;
	subtree->Rooted = true;
	subtree->MaxIndex = MaxIndex;
	subtree->MaxDepth = 0;
	defineSubtree(subtree,subroot);
	subtree->MaxDepth -= subroot->GetDepth();		// to find relative depth
	return subtree;
};

// Private recursive routine for subtree definition
void Tree::defineSubtree(PTree subtree,PNode node) {
	if( !Check(node))
		return;
	int depth = node->GetDepth();
	if(depth > subtree->MaxDepth)
		subtree->MaxDepth = depth;
	if(node->IsLeaf()) {		// leaf found - terminate recursion
		LeafInsertResult lir = subtree->Leaves.insert(LeafMap::value_type(node->GetName(), node));
		if(! lir.second)
			throw("DefineSubtree: Duplicate leaf name " + node->GetName() + ".");
		subtree->LeafCount++;
	}
	else {		// traverse recursively
		InnerInsertResult iir = subtree->Inners.insert(InnerMap::value_type(node->GetIndex(), node));
		if(! iir.second) {
			ostringstream oss;
			oss << "DefineSubtree: Duplicate inner node index " << node->GetIndex() << ".";
			throw(oss.str());
		}
		subtree->InnerCount++;
		PNode child = node->GetChild();
		while(child) {
			defineSubtree(subtree,child);
			child = child->GetSibling();
		}
	}
};

// Logically defines rooted subtree with a root at current node
// Counts inners/leaves, fills maps and computes MaxDepth
// Depths/degrees of existing nodes are not modified!
PTree Tree::DefineSubtree() {
	return DefineSubtree(Current);
};

// Inserts new node between given node and its parent
// Moves Current to the new node
PNode Tree::InsertParent(PNode node) {
	if( !Check(node))
		return NULL;
	PNode parent = node->GetParent();
	PNode mid = AddInnerNode();		// Current moves
	mid->SetParent(parent);
	mid->SetChild(node);
	mid->SetSibling(node->GetSibling());
	mid->SetDegree(1);
	int depth = node->GetDepth();
	mid->SetDepth(depth);
	node->SetParent(mid);
	node->SetSibling(NULL);
	node->SetDepth(depth + 1);
	if(parent) {
		PNode child = parent->GetChild();
		if(child == node) {
			parent->SetChild(mid);
		}
		else {
			while(child->GetSibling() != node)
				child = child->GetSibling();
			child->SetSibling(mid);
		}
	}
	if(node == GetRoot()) {
		SetRoot(mid);
		MinMaxDegree(NULL);
	}
	UpdateLite(node);
	return mid;
};

// Inserts new node between current node and its parent
// Moves Current to the new node
PNode Tree::InsertParent() {
	return InsertParent(Current);
};

// Relinks given node to different parent which must not
// be a descendent of that node (how to assure?)
// to_parent=0 is equivalent to rooting at the node
void Tree::Relink(PNode node, PNode to_parent) {
	if( !Check(node))
		return;
	// Checking that to_parent isn't a descendent of the node
	PNode p = to_parent;
	while(p) {
		if(p == node)
			throw("Tree::Relink - Tree looping is prohibited.");
		else
			p = p->GetParent();
	}
	PNode parent = node->GetParent();
	if(parent == to_parent)
		return;			// Nothing to do
	// Exclude node from parent's children
	if(parent) {		// only if parent exists
		PNode child = parent->GetChild();
		if(child == node)
			parent->SetChild(node->GetSibling());
		else {
			while(child->GetSibling() != node)
				child = child->GetSibling();
			child->SetSibling(node->GetSibling());
		}
		parent->DecrementDegree();
		MinMaxDegree(parent);
	}
	// Include node in to_parent's children
	if(to_parent) {
		node->SetSibling(to_parent->GetChild());
		node->SetParent(to_parent);
		node->SetDepth(to_parent->GetDepth() + 1);
		to_parent->SetChild(node);
		to_parent->IncrementDegree();
		MinMaxDegree(to_parent);
	}
	else {	// Make node a new root, deleting basal remainder
		this->RemoveNodeTraverse(Root);
		node->SetParent(NULL);
		Root = node;
	}
	UpdateLite(node);
};

// Relinks current node to different parent which must not
// be a descendent of that node (how to assure?)
// to_parent=0 is equivalent of rooting at the node
void Tree::Relink(PNode to_parent) {
	Relink(Current,to_parent);
};

// Attaches entire subtree to given node of 'this' tree
// The node is assumed to be the inner one located off the subtree
// The tree maps, count, etc. will be updated!
// If the subtree belongs to a tree, it must be Updated!
void Tree::AttachSubtree(PTree subtree, PNode to_parent) {
	if(!subtree || !Check(to_parent))
		return;			// Nothing to do
	if(to_parent->IsLeaf())
		return;			// Attaching to a leaf is prohibited
	PNode node = subtree->GetRoot();
	// Unlink the subtree root if needed
	PNode parent = node->GetParent();
	if(parent == to_parent)
		return;					// Nothing to do
	if(parent) {		// only if parent exists
		PNode child = parent->GetChild();
		if(child == node)
			parent->SetChild(node->GetSibling());
		else {
			while(child->GetSibling() != node)
				child = child->GetSibling();
			child->SetSibling(node->GetSibling());
		}
		parent->DecrementDegree();
		MinMaxDegree(parent);
	}
	// Include node in to_parent's children
	node->SetSibling(to_parent->GetChild());
	node->SetParent(to_parent);
	node->SetDepth(to_parent->GetDepth() + 1);
	to_parent->SetChild(node);
	to_parent->IncrementDegree();
	MinMaxDegree(to_parent);
	updateTree(node);
};

// Attaches entire subtree to current node of 'this' tree
// The node is assumed to be off the subtree
// The tree maps, count, etc. will be updated!
// If the subtree belongs to a tree, it must be Updated!
void Tree::AttachSubtree(PTree subtree) {
	AttachSubtree(subtree,Current);
};

// Makes given newroot a root of this tree
// Newroot must belong to the tree
// The tree will become rooted if successful
void Tree::Reroot(PNode newroot) {
	if( !Check(newroot) || !Root || newroot == Root)
		return;
	PNode lower = newroot;
	PNode upper = newroot->GetParent();
	// 1st run: exclude lower from upper's children
	while(upper) {
		PNode child = upper->GetChild();
		if(child == lower)
			upper->SetChild(lower->GetSibling());
		else {
			while(child->GetSibling() != lower)
				child = child->GetSibling();
			child->SetSibling(lower->GetSibling());
		}
		lower = upper;
		upper = upper->GetParent();
	}
	lower = newroot;
	upper = newroot->GetParent();
	newroot->SetParent(NULL);
	// 2nd run: include upper in lower's children
	while(upper) {
		PNode nextupper = upper->GetParent();
		upper->SetParent(lower);
		upper->SetSibling(lower->GetChild());
		lower->SetChild(upper);
		lower = upper;
		upper = nextupper;
	}
	SetRoot(newroot);
	SetRooted(true);
	newroot->SetDepth(0);
	MinMaxDegree(NULL);
	UpdateLite(newroot);
};

// Makes current node a root of this tree
// The tree will become rooted if successful
void Tree::Reroot() {
	Reroot(Current);
};

// Modifies min/max degrees by given node
// Clears min/max values if node==NULL
void Tree::MinMaxDegree(PNode node) {
	if(node == NULL) {
		MinDegree = numeric_limits<int>::max( );
		MaxDegree = 0;
		return;
	}
	if( !Check(node) || node->IsLeaf())
		return;
	int degree = node->GetDegree();
	if(degree < MinDegree)
		MinDegree = degree;
	if(degree > MaxDegree)
		MaxDegree = degree;
};

// Modifies min/max degrees by current node
void Tree::MinMaxDegree() {
	if(! Current)
		return;
	MinMaxDegree(Current);
};

// Duplicates an alien (sub)tree as a child of given node
// Returns true(OK) or false(errors)
bool Tree::Clone(PNode subroot, PNode to_parent) {
	if(!subroot || !Check(to_parent))
		return false;
	PTree tree = subroot->GetOwner();
	PNode node = NULL;
	if(subroot->IsLeaf()) {
		node = AddLeafChild(subroot->GetName(), to_parent);
		node->SetSpecies(subroot->GetSpecies());
	}
	else
		node = AddInnerChild(to_parent);
   node->SetLength(subroot->GetLength());
	cloneChildren(subroot,node);
	UpdateLite(to_parent);
	return true;
};

// Duplicates an alien (sub)tree as a child of Current node
// Returns true(OK) or false(errors)
bool Tree::Clone(PNode subroot) {
	return Clone(subroot,Current);
};

// Returns new tree that is a copy of this tree
PTree Tree::Clone(void) {
	PTree tree = new Tree;
	PNode root = tree->AddInnerNode();
	tree->SetRoot(root);
	tree->SetRooted(Rooted);
	root->SetDepth(Root->GetDepth());
	if(Root->IsLeaf()) {		// special case of a tree consisting of only a leaf
		Inner2Leaf(root, Root->GetName());
		root->SetSpecies(Root->GetSpecies());
      root->SetLength(Root->GetLength());
	}
	cloneChildren(Root, root);
	tree->Update();
	return tree;
}

// Returns new tree reduced to a given clade
PTree Tree::CloneCut(const myset& clade) {
   myset c(clade);
   myset *r = Root->GetClade();
   c.intersect(*r);
   if(c.count() == 0)
      return NULL;      // tree is entirely cut

   PTree tree = Clone();
   MakeClades(tree);
   r = Root->GetClade();
   c.assign(clade);
   c.flip();
   c.intersect(*r);
   if(c.count() == 0)
      return tree;      // tree is not changed

	PNode leaf = tree->GetLeafFirst();
   if(!leaf)
      throw("CloneCut: A tree without leaves encountered.");
	while(leaf) {
		PNode parent   = leaf->GetParent();
		PNode nextleaf = tree->GetLeafNext();
		int sp = leaf->GetSpecies();
      if( !clade.test(sp) ) {		// Remove this leaf
			tree->RemoveNode(leaf);
			if( tree->GetLeafCount() <= 1) {		// one or no leaves remain
				delete tree;
				tree = NULL;
				break;
			}
         while(parent && parent->GetDegree() < 2) {
            PNode grandparent = parent->GetParent();
				tree->RemoveNode(parent);
            parent = grandparent;
         }
		}
      if(tree)
         tree->UpdateLite(tree->GetRoot());
		leaf = nextleaf;
	}
	if(tree) {
		//tree->UpdateLite(tree->GetRoot());
      tree->Update();
		MakeClades(tree);
		if(tree->GetRoot()->GetClade()->count() == 1) {		// delete more one-species tree
			delete tree;
			tree = NULL;
		}
	}
   return tree;
}

// Private recoursive cloning routine
// Clones source's children as target's children
void Tree::cloneChildren(PNode source, PNode target) { 
	if( !source || !target)
		return;
	PTree to = target->GetOwner();
	PNode fromchild = source->GetChild();
	PNode child = NULL;
	while(fromchild) {
		if(fromchild->IsLeaf()) {
			if(child)
				child = to->AddLeafSibling(fromchild->GetName(),child);
			else
				child = to->AddLeafChild(fromchild->GetName(),target);
			child->SetSpecies(fromchild->GetSpecies());
		}
		else {
			if(child)
				child = to->AddInnerSibling(child);
			else
				child = to->AddInnerChild(target);
		}
      child->SetFlag(fromchild->GetFlag());
      child->SetLength(fromchild->GetLength());
		cloneChildren(fromchild, child);
		fromchild = fromchild->GetSibling();
	}
};

// Checks if given node belong to 'this' tree
// Returns true(yes) of false(not)
// The latter with nonzero pointer throws an exception
bool Tree::Check(PNode node) {
	if(node == NULL)
		return false;
	if(node->GetOwner() == this)
		return true;
	throw("Cannot work with a node from alien tree.");
	return false;
}

// Fills given struct with 1st triple of leaves with regard to their topology
// Returns true=OK or false(no triple exist)
bool Tree::GetLeaf3First(Leaf3& leaf3) {
	lita = Leaves.begin();
	LeafMap::iterator end = Leaves.end();
	if(lita == end)
		return false;
	litb = lita;
	if(++litb == end)
		return false;
	litc = litb;
	if(++litc == end)
		return false;
	return TripleTopology(leaf3);
};

// Fills given struct with 1st triple of leaves with regard to their topology
// One leaf is fixed equal to the node given
// Returns true=OK or false(no triple exist)
bool Tree::GetLeaf3First(Leaf3& leaf3, const PNode leaf) {
	LeafMap::iterator end = Leaves.end();
	lita = Leaves.find(leaf->GetName());
	if(lita == end)
		return false;
	litb = Leaves.begin();
	if(litb == lita)
		litb++;
	if(litb == end)
		return false;
	litc = ++litb;
	if(litc == lita)
		litc++;
	if(litc == end)
		return false;
	return TripleTopology(leaf3);
};

// Fills given struct with 1st triple of leaves with regard to their topology
// One leaf is fixed equal to the species with given code name
// Returns true=OK or false(no triple exist)
bool Tree::GetLeaf3First(Leaf3& leaf3, const string& name) {
	LeafMap::iterator end = Leaves.end();
	lita = Leaves.find(name);
	if(lita == end)
		return false;
	litb = Leaves.begin();
	if(litb == lita)
		litb++;
	if(litb == end)
		return false;
	litc = litb;
	litc++;
	if(litc == lita)
		litc++;
	if(litc == end)
		return false;
	return TripleTopology(leaf3);
};

// Fills given struct with next triple of leaves with regard to their topology 
// Returns true=OK or false(no more triple exist)
bool Tree::GetLeaf3Next(Leaf3& leaf3) {
	LeafMap::iterator end = Leaves.end();
	if(++litc == end) {			// last C reached
		if(++litb == end) {			// last B reached
			if(++lita == end)				// last A reached
				return false;
			else {							// not last A
				litb = lita;
				if(++litb == end)				// last B reached
					return false;
				litc = litb;					// not last B
				if(++litc == end)				// last C reached
					return false;
				// not last C, process this triple
			}
		}
		else {							// not last B
			litc = litb;
			if(++litc == end) {			// last C reached
				if(++lita == end)				// last A reached
					return false;
				else {							// not last A
					litb = lita;
					if(++litb == end)				// last B reached
						return false;
					litc = litb;					// not last B
					if(++litc == end)				// last C reached
						return false;
					// not last C, process this triple
				}
			}
			// not last C, process this triple
		}
	}
	// not last A, process this triple
	return TripleTopology(leaf3);
};

// Fills given struct with next triple of leaves with regard to their topology
// This "Fixed A" variant retains the first element of the triple
// Returns true=OK or false(no more triple exist)
bool Tree::GetLeaf3NextFA(Leaf3& leaf3) {
	LeafMap::iterator end = Leaves.end();
	if(++litc == end) {			// last C reached
		if(++litb == end) 			// last B reached
			return false;
		else {							// not last B, try to select C
			if(litb == lita) {			// B==A, skip it
				if(++litb == end) 			// last B reached
					return false;
				else {							// not last B, try to select C
					litc = litb;
					if(++litc == end) 			// last C reached
						return false;
					// as C!=A, process this triple
				}
			}
			else {							// B!=A, then select C
				litc = litb;
				if(++litc == end) 			// last C reached
					return false;
				else if(litc == lita) {			// C==A, skip it
					if(++litc == end)					// last C reached
						return false;
					// not last C, process this triple
				}
				// not last C, process this triple
			}
		}
	}
	else if(litc == lita) {		// C==A, skip it
		if(++litc == end) {			// last C reached
			if(++litb == end)				// last B reached
				return false;
			else {							// not last B, try to select C
				if(litb == lita) {			// B==A, skip it
					if(++litb == end) 			// last B reached
						return false;
					else {							// not last B, try to select C
						litc = litb;
						if(++litc == end) 			// last C reached
							return false;
						// as C!=A, process this triple
					}
				}
				else {							// B!=A, then select C
					litc = litb;
					if(++litc == end) 			// last C reached
						return false;
					else if(litc == lita) {			// C==A, skip it
						if(++litc == end)					// last C reached
							return false;
						// not last C, process this triple
					}
					// not last C, process this triple
				}
			}
		}
		// not last C, process this triple
	}
	// not last C & C!=A, process this triple
	return TripleTopology(leaf3);
};

// Arrange Leaf3 elements as per (A,(B,C)) topology
bool Tree::TripleTopology(Leaf3& lf) {
	PNode ana, anb, anc;			// leaf ancestors
	int dpa, dpb, dpc;			// leaf path depths
	ana = lf.a = lita->second; 
	dpa = lf.a->GetDepth();
	anb = lf.b = litb->second;
	dpb = lf.b->GetDepth();
	anc = lf.c = litc->second;
	dpc = lf.c->GetDepth();
	// Find maximum depth and lift it to the next one.
	if(dpa > dpb) {
		if(dpa > dpc) {			// A is the deepest: A,(B|C)
			for( ; dpa != dpb && dpa != dpc; dpa--)
				ana = ana->GetParent();
			if(dpa == dpb && dpa > dpc) {				// (A=B),C
				for( ; dpa != dpc; dpa--,dpb--) {
					ana = ana->GetParent();
					anb = anb->GetParent();
					if(ana == anb) {				// Topo = (C,(A,B))
						PNode tmp = lf.a;
						lf.a = lf.c;
						lf.c = tmp;
						break;
					}
				}
				if(dpa != dpc)	{		// has been determined
					return true;
				}
				// Otherwise, dpa == dpb == dpc below
			}
			else if(dpa == dpc && dpa > dpb) {		// (A=C),B
				for( ; dpa != dpb; dpa--,dpc--) {
					ana = ana->GetParent();
					anc = anc->GetParent();
					if(ana == anc) {				// Topo = (B,(A,C))
						PNode tmp = lf.a;
						lf.a = lf.b;
						lf.b = tmp;
						break;
					}
				}
				if(dpa != dpb)	{		// has been determined
					return true;
				}
				// Otherwise, dpa == dpb == dpc below
			}
			// Otherwise, dpa == dpb == dpc below
		}
		else if(dpa < dpc) {		// C is the deepest: C,A,B
			for( ; dpc != dpa; dpc--)
				anc = anc->GetParent();
			for( ; dpa != dpb; dpa--,dpc--) {		// (C=A),B
				ana = ana->GetParent();
				anc = anc->GetParent();
				if(ana == anc) {				// Topo = (B,(A,C))
					PNode tmp = lf.a;
					lf.a = lf.b;
					lf.b = tmp;
					break;
				}
			}
			if(dpa != dpb)	{		// has been determined
				return true;
			}
			// Otherwise, dpa == dpb == dpc below
		}
		else {						// dpa == dpc: (A=C),B
			for( ; dpa != dpb; dpa--,dpc--) {		// (C=A),B
				ana = ana->GetParent();
				anc = anc->GetParent();
				if(ana == anc) {				// Topo = (B,(A,C))
					PNode tmp = lf.a;
					lf.a = lf.b;
					lf.b = tmp;
					break;
				}
			}
			if(dpa != dpb)	{		// has been determined
				return true;
			}
			// Otherwise, dpa == dpb == dpc below
		}
	}
	else if(dpa < dpb) {
		if(dpc < dpb) {			// B is the deepest: B,(A|C)
			for( ; dpb != dpa && dpb != dpc; dpb--)
				anb = anb->GetParent();
			if(dpb == dpa && dpb > dpc) {				// (A=B),C
				for( ; dpa != dpc; dpa--,dpb--) {
					ana = ana->GetParent();
					anb = anb->GetParent();
					if(ana == anb) {				// Topo = (C,(A,B))
						PNode tmp = lf.a;
						lf.a = lf.c;
						lf.c = tmp;
						break;
					}
				}
				if(dpa != dpc)	{		// has been determined
					return true;
				}
				// Otherwise, dpa == dpb == dpc below
			}
			else if(dpb == dpc && dpb > dpa) {		// (B=C),A
				for( ; dpb != dpa; dpb--,dpc--) {
					anb = anb->GetParent();
					anc = anc->GetParent();
					if(anb == anc) 				// Topo = (A,(B,C))
						break;
				}
				if(dpb != dpa)	{		// has been determined
					return true;
				}
				// Otherwise, dpa == dpb == dpc below
			}
			// Otherwise, dpa == dpb == dpc below
		}
		else if(dpc > dpb) {		// C is the deepest: C,B,A
			for( ; dpc != dpb; dpc--)
				anc = anc->GetParent();
			for( ; dpc != dpa; dpb--,dpc--) {		// (C=B),A
				anb = anb->GetParent();
				anc = anc->GetParent();
				if(anb == anc) 				// Topo = (A,(B,C))
					break;
			}
			if(dpc != dpa)	{		// has been determined
				return true;
			}
			// Otherwise, dpa == dpb == dpc below
		}
		else {						// dpc == dpb: (B=C),A
			for( ; dpc != dpa; dpb--,dpc--) {		// (C=B),A
				anb = anb->GetParent();
				anc = anc->GetParent();
				if(anb == anc) 				// Topo = (A,(B,C))
					break;
			}
			if(dpc != dpa)	{		// has been determined
				return true;
			}
			// Otherwise, dpa == dpb == dpc below
		}
	}
	else {			// dpa == dpb
		if(dpc > dpa) {			// C is the deepest: C,(A=B)
			for( ; dpc != dpa; dpc--)
				anc = anc->GetParent();
			// dpa == dpb == dpc below
		}
		else if(dpc < dpa) {		// dpa == dpb: (A=B),C
			for( ; dpa != dpc; dpa--,dpb--) {
				ana = ana->GetParent();
				anb = anb->GetParent();
				if(ana == anb) {				// Topo = (C,(A,B))
					PNode tmp = lf.a;
					lf.a = lf.c;
					lf.c = tmp;
					break;
				}
			}
			if(dpa != dpc)	{		// has been determined
				return true;
			}
			// Otherwise, dpa == dpb == dpc below
		}
		// Otherwise, dpa == dpb == dpc below
	}
	// Here, A,B,C ancestors are at the same level
	for( ; ; dpa--,dpb--,dpc--) {
		ana = ana->GetParent();
		anb = anb->GetParent();
		anc = anc->GetParent();
		if(ana == anb && ana != anc) {	// Topo = (C,(A,B))
			PNode tmp = lf.a;
			lf.a = lf.c;
			lf.c = tmp;
			return true;
		}
		if(ana == anc && ana != anb) {	// Topo = (B,(A,C))
			PNode tmp = lf.a;
			lf.a = lf.b;
			lf.b = tmp;
			return true;
		}
		if(anb == anc && ana != anb) {	// Topo = (A,(B,C))
			return true;
		}
		if(ana == anb && anb == anc) 
			throw("Cannot determine triple topology in nonbinary tree.");
	}
	return true;
};


// Fills given struct with 1st pair of leaves (b,c) and their nearest common ancestor (a)
// Returns true=OK or false (no pair exists)
bool Tree::GetLeaf2First(Leaf3 &trinode) {
	LeafMap::iterator end = Leaves.end();
	litb = Leaves.begin();
	if(litb == end)
		return false;
	litc = litb;
	if(++litc == end)
		return false;
	PNode ancb = trinode.b = litb->second;
	PNode ancc = trinode.c = litc->second;
	trinode.a = GetNCA(ancb, ancc);
	return (trinode.a != NULL);
};

// Fills given struct with next pair of leaves (b,c) and their nearest common ancestor (a)
bool Tree::GetLeaf2Next(Leaf3 &trinode) {
	LeafMap::iterator end = Leaves.end();
	if(++litc == end) {
		if(++litb == end)
			return false;
		else {
			litc = litb; 
			if(++litc == end)
				return false;
		}
	}
	PNode ancb = trinode.b = litb->second;
	PNode ancc = trinode.c = litc->second;
	trinode.a = GetNCA(ancb, ancc);
	return (trinode.a != NULL);
};

// Returns pointer to the nearest common ancestor of two nodes or NULL
PNode Tree::GetNCA(PNode ancb, PNode ancc) {
	int bdepth = ancb->GetDepth();
	int cdepth = ancc->GetDepth();
	if(bdepth > cdepth) 
		for(int i=0; i < bdepth - cdepth; i++)
			ancb = ancb->GetParent();
	else if(bdepth < cdepth)
		for(int i=0; i < cdepth - bdepth; i++)
			ancc = ancc->GetParent();
	while(ancb != ancc) {
		if(ancb == NULL || ancc == NULL)
			return NULL;
		ancb = ancb->GetParent();
		ancc = ancc->GetParent();
	}
	return ancb;
}

// Changes given leaf name & species as per other species number, not changing the topology
// Returns true(OK) or false(Errors). Modifies LeafMap but clades remain intact.
bool Tree::ChangeLeaf(PNode leaf, const string& name, int species) {
	if(!leaf->IsLeaf() || name.size() == 0 || species <=0)
		return false;
	if(Leaves.erase(leaf->GetName()) != 1)
		return false;
	LeafInsertResult lir = Leaves.insert(LeafMap::value_type(name,leaf));
	if(!lir.second)
		return false;
	leaf->SetName(name);
	leaf->SetSpecies(species);
	return true;
};
