// cpRivals: Model of the regulation by competing promoters.
//
// Copyright (C) 2009-2012 Lev Rubanov <rubanov@iitp.ru>
// Copyright (C) 2009-2012 Institute for Information Transmission Problems of
// the Russian Academy of Sciences (Kharkevich Institute) <http://www.iitp.ru>
//
// This model has been proposed and implemented in the Laboratory of 
// Mathematical Methods and Models in Bioinformatics of the above Institute.
// Head of the Laboratory, Prof. Vassily Lyubetsky <lyubetsky@iitp.ru>
//   
// This file is part of cpRivals.
//
// cpRivals is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// cpRivals is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with cpRivals. If not, see <http://www.gnu.org/licenses/>.
//
// Functions: main
//
#define CPRIVALSMAIN
#include "cprivals.h"

int main(int argc, char** argv) {
	char* filename = new char[FILENAMELEN];
	char* msg = new char[MSGLEN];
	char* tmp = new char[FILEBUFLEN];
	long NextJobOffset, LastJobOffset;
	clock_t clk_t0 = 0, clk_t1, clk_t00;
	time_t ltime;
	try {
		int rc = ParseArguments(argc, argv);
		if( rc == 1 ) return 0;
		if( rc != 0 ) 
			{ sprintf(msg, "Error in arguments."); throw msg; }
        #ifdef PARALLEL
	    int namelen;
	    double mpi_t0 = 0, mpi_t1;
        char* processor_name = new char[MPI_MAX_PROCESSOR_NAME];
		if( cpRivals::mpimode ) {
			MPI::Init(argc, argv);
			if( MPI::Is_initialized() ) {
				cpRivals::numprocs = MPI::COMM_WORLD.Get_size();
				if( cpRivals::numprocs < 2 )
					{ sprintf(msg, "You need at least 2 processes to run in mpi mode!"); throw msg; }
				cpRivals::myid = MPI::COMM_WORLD.Get_rank();
				MPI::Get_processor_name(processor_name, namelen);
				cpRivals::granularity = 0;			// no stamping in mpi mode
				cpRivals::cmdgranularity = true;
			}
			else cpRivals::mpimode = false;
		}
		else strncpy(processor_name, "this machine off the MPI environment", MPI_MAX_PROCESSOR_NAME);
        #else
        cpRivals::mpimode = false;
        cpRivals::numprocs = 1;
        cpRivals::myid = 0;
        #endif
		if( cpRivals::myid == 0 ) {
			printf(
            "\n cpRivals: Model of regulation by competing promoters (CLI&MPI) V%s\n"
            " Copyright (C) 2009-2014 Lev Rubanov <rubanov@iitp.ru>\n"
	        " Copyright (C) 2009-2014 Institute for Information Transmission Problems RAS\n"
	        " Made in Laboratory of Mathematical Methods and Models in Bioinformatics,\n"
            " Head of the Lab: Vassily Lyubetsky <lyubetsk@iitp.ru>  http://lab6.iitp.ru\n"
		    " This is free software, it is distributed WITHOUT ANY WARRANTY. See GNU GPL.\n\n", VERSION);
		}
        #ifdef PARALLEL
		if( (cpRivals::logmpi & cpRivals::tagInit) ) {
			sprintf(msg, "[%04d] cpRivals process #%d of %d starts on %s.\n", myid, myid, numprocs, processor_name);
			if( cpRivals::myid == 0 ) { printf("%s", msg); fflush(stdout); }
			else if( cpRivals::collect ) 
				MPI::COMM_WORLD.Send(msg, (int)strlen(msg)+1, MPI::CHAR, root, cpRivals::tagInfo);
		}
	    delete [] processor_name;
        #endif

		if( ! LoadConfiguration(cpRivals::inifilename) ) 
			{ sprintf(msg, "Error in configuration."); throw msg; }
		if( ! strlen(cpRivals::rjbfilename) ) 
			{ sprintf(msg, "No job file is given."); throw msg; }
		cpRivals::config.CSV = true;
		cpRivals::jobtotal = CountJob( cpRivals::rjbfilename );
		if( cpRivals::jobtotal <= 0 ) 
			{ sprintf(msg, "There are no jobs in the job file."); throw msg; }
		cpRivals::automation = true;
		LastJobOffset = 0L;						// Read job file preamble
		NextJobOffset = LoadRunJob(cpRivals::rjbfilename, &LastJobOffset);
		if( NextJobOffset <= 0 ) 
			{ sprintf(msg, "Error in the job file preamble."); throw msg; }
		if( strlen(cpRivals::outfilename) == 0 ) {
			strncpy(cpRivals::outfilename, cpRivals::tskfilename, FILENAMELEN-1);
			TrimExtension(cpRivals::outfilename);
		}
        #ifdef PARALLEL
		if( cpRivals::mpimode ) mpi_t0 = MPI::Wtime();
        else 
        #endif
        { clk_t0 = clock(); clk_t00 = clk_t0; }
		if( cpRivals::InitialSeed == -1 ) {		// Init RNG by timer
			time(&ltime);
			cpRivals::InitialSeed = labs((long)ltime);
		}
		cpRivals::idum = -(cpRivals::InitialSeed + cpRivals::myid * SEEDSEPARAT);
		Random();
		for( int i=0; i<cpRivals::task->NumAgents; i++ ) {		// store changeble parameters of all agents
			Agent* agent = cpRivals::task->getAgent(i);
			agent->Store();
		}
		if( cpRivals::myid == 0 ) {						// Only root or single branch
			sprintf(filename, "%s.csv", cpRivals::outfilename);
			wcsv = fopen(filename, cpRivals::append ? "a+t" : "wt");
			sprintf(filename, "%s_rejected.csv", cpRivals::outfilename);
			wcsv1 = fopen(filename, cpRivals::append ? "a+t" : "wt");
			sprintf(filename, "%s.log", cpRivals::outfilename);
			wlog = fopen(filename, cpRivals::append ? "a+t" : "wt");
			if( !wcsv || !wcsv1 || !wlog )
				{ sprintf(msg, "Cannot open output file(s)."); throw msg; }
         fseek(wcsv, 0, SEEK_END); if( ftell(wcsv) == 0 )	OutCSVHeader(wcsv);
         fseek(wcsv1, 0, SEEK_END); if( ftell(wcsv1) == 0 )	OutCSVHeader(wcsv1);
			OutLogHeader(wlog);
		}
		else cpRivals::profiling = false;			// do not profile 2ndary branches
		
		if( ! cpRivals::mpimode ) {	//======================================== Single branch mode (-nompi)
			sprintf(filename, "%s_current.csv", cpRivals::outfilename);

			LastJobOffset = NextJobOffset;			// Jobs loop
			while( (NextJobOffset = LoadRunJob(cpRivals::rjbfilename, &LastJobOffset)) > 0 ) {
				if( cpRivals::debugline ) {				// Debug statement - comment and skip
					MarkJobDone(cpRivals::rjbfilename, LastJobOffset);
					LastJobOffset = NextJobOffset;
					continue;
				}
				wcsv0 = fopen(filename, "a+t");
				if( !wcsv0 ) {
					sprintf(msg, "Cannot open current output file \"%s\".", filename);
					throw msg;
				}
				for( int i=0; i<cpRivals::task->NumAgents; i++ ) {			// clear totals for all genes
					Agent* agent = cpRivals::task->getAgent(i);
					if( agent->Type == TypeGene ) ((Gene*)agent)->ResetTotal();
				}
															// try using previously done runs (w/calc totals)
				cpRivals::RunsDone = CountRunsDone(wcsv0);
				if( cpRivals::RunsDone < 0 ) {				// cannot use
					cpRivals::RunsDone = 0;
					wcsv0 = freopen(filename, "w+t", wcsv0);
					if( !wcsv0 ) {
						sprintf(msg, "Cannot reopen current output file \"%s\".", filename);
						throw msg;
					}
				}

				while( cpRivals::RunsDone < cpRivals::Runs ) {			// Runs loop
					for( int i=0; i<cpRivals::task->NumAgents; i++ ) {		// reset all agents of the task
						cpRivals::task->getAgent(i)->Restore();
						cpRivals::task->getAgent(i)->Reset();
					}
					if( SetCurrentParameters(cpRivals::varvalue) ) {			// set variable parameters
						sprintf(msg, "Cannot set parameters from current job.");
						throw msg;
					}					

					if( RunTrajectory() ) break;
					for( int i=0; i<cpRivals::task->NumAgents; i++ ) {		// accumulate totals for genes
						Agent* agent = cpRivals::task->getAgent(i);
						if( agent->Type == TypeGene ) ((Gene*)agent)->Accumulate();
					}
					OutCSVResult(wcsv0, cpRivals::config.PhysicalTime);
					cpRivals::RunsDone ++;
					printf("[0000] J%4d/%d R%4d/%d", cpRivals::jobcount+1, cpRivals::jobtotal, 
						cpRivals::RunsDone, cpRivals::Runs);
					int numgene = 0;
					for( int i=0; i<cpRivals::task->NumAgents; i++ ) {
						Agent* agent = cpRivals::task->getAgent(i);
						if( agent->Type == TypeGene ) {
							Gene* gene = (Gene*)agent;
							if( gene->Transcribed < 1000 ) printf("%4d", gene->Transcribed);
							else if( gene->Transcribed < 9950 ) printf("%2dK%1d", (gene->Transcribed + 50) / 1000,
								((gene->Transcribed + 50) % 1000) / 100);
							else if( gene->Transcribed < 99500 ) printf("%3dK", (gene->Transcribed + 500) / 1000);
							else if( gene->Transcribed < 995000 ) printf("M%02d", (gene->Transcribed + 5000) / 10000);
							else if( gene->Transcribed < 9950000 ) printf("%2dM%1d", (gene->Transcribed + 50000) / 1000000,
								((gene->Transcribed + 50000) % 1000000) / 100000);
							else printf("%3dM", (gene->Transcribed + 500000) / 1000000);
							numgene++;
						}
					}
					for( ; numgene<5; numgene++ ) printf("    ");
					if( cpRivals::decide && RunsDone >= decide && CheckFilter() ) 
						{ break; }
					if( cpRivals::RunsDone < cpRivals::Runs )	// (for last run this line to be continued)
						{ printf("\n"); fflush(stdout); }
				}
				cpRivals::jobcount ++;
				clk_t1 = clock(); 
				double dt = (double)(clk_t1 - clk_t0) / (60 * CLOCKS_PER_SEC);
            double tt = (double)clk_t1 / (60 * CLOCKS_PER_SEC);
				if( cpRivals::RunsDone < cpRivals::Runs ) { 
					printf(" Stop %.0f'\n", dt); fflush(stdout);
					if( CopyFile(wcsv0, wcsv1) ) {
						sprintf(msg, "Error while copying data to rejected csv.");
						throw msg;
					}
               fprintf(wlog, "%5.0fm: Job%5d (line%5d) degenerated, time = %6.1f min\n",
						tt, cpRivals::jobcount, cpRivals::jobline, dt);
				}
				else { 
					printf(" Done %.0f'\n", dt); fflush(stdout);
					if( CopyFile(wcsv0, wcsv) ) {
						sprintf(msg, "Error while copying data to accepted csv."); 
						throw msg;
					}
					fprintf(wlog, "%5.0fm: Job%5d (line%5d) completed,   time = %6.1f min\n",
						tt, cpRivals::jobcount, cpRivals::jobline, dt);
				}
				clk_t0 = clk_t1; 
				fflush(wlog);
				fclose(wcsv0);
				if( remove(filename) ) {
					sprintf(msg, "Cannot delete current csv data file."); 
					throw msg;
				}
				MarkJobDone(cpRivals::rjbfilename, LastJobOffset);
				LastJobOffset = NextJobOffset;
			}
			clk_t1 = clock(); 
			double dt = (double)(clk_t1 - clk_t00) / (60 * CLOCKS_PER_SEC);
			printf("[0000] Job file processing completed after %.0f min.\n", dt); fflush(stdout);
         if( cpRivals::wlog ) { fprintf(wlog, "Job file processing completed after %.0f min.\n", dt); fflush(wlog); }
		}
        #ifdef PARALLEL
		else if( myid == 0 ) {			//=========================================== MPI mode processing: root branch
			MPI::Status status;
			int* procJob = new int[cpRivals::numprocs];
			for( int i=0; i<cpRivals::numprocs; i++ ) procJob[i] = -1;
			int kfree = cpRivals::numprocs - 1;
			int n = 0;							// fill parameters for all jobs
			JobData* job = new JobData[cpRivals::jobtotal];
			LastJobOffset = NextJobOffset;
			while( (NextJobOffset = LoadRunJob(cpRivals::rjbfilename, &LastJobOffset)) > 0 ) {
				if( cpRivals::debugline ) {				// Debug statement - comment and skip
					MarkJobDone(cpRivals::rjbfilename, LastJobOffset);
					LastJobOffset = NextJobOffset;
					continue;
				}
				job[n].Offset = LastJobOffset;
				job[n].LineNumber = cpRivals::jobline;
				job[n].varvalue = new double[cpRivals::varcount];
				for( int i=0; i<cpRivals::varcount; i++ )
					job[n].varvalue[i] = cpRivals::varvalue[i];
				sprintf(job[n].filename, "%s_j%d.csv", cpRivals::outfilename, cpRivals::jobline);
				if( (job[n].wcsv0 = fopen(job[n].filename, "rt")) ) {
					for( int i=0; i<cpRivals::task->NumAgents; i++ ) {		// clear totals for all genes
						Agent* agent = cpRivals::task->getAgent(i);
						agent->Reset();
						if( agent->Type == TypeGene ) ((Gene*)agent)->ResetTotal();
					}
					job[n].RunsDone = CountRunsDone(job[n].wcsv0);
					fclose(job[n].wcsv0); 
					job[n].wcsv0 = NULL;
					if( job[n].RunsDone < 0 )					// cannot use
						{ job[n].RunsDone = 0; remove(job[n].filename); }
				}
				else job[n].RunsDone = 0;
				job[n].RunsToDo = cpRivals::Runs - job[n].RunsDone;
				job[n].Agents = new Agent*[cpRivals::task->NumAgents];
				for( int i=0; i<cpRivals::task->NumAgents; i++ ) {
					Agent* agent = cpRivals::task->getAgent(i);
					if( agent->Type == TypeGene )			job[n].Agents[i] = new Gene((Gene*)agent);
					else if( agent->Type == TypePEP )	job[n].Agents[i] = new PEP((PEP*)agent);
					else if( agent->Type == TypeNEP )	job[n].Agents[i] = new NEP((NEP*)agent);
					else if( agent->Type == TypeRepr )	job[n].Agents[i] = new Repr((Repr*)agent);
					else if( agent->Type == TypeEKor )	job[n].Agents[i] = new EKor((EKor*)agent);
					else if( agent->Type == TypeERpo )	job[n].Agents[i] = new ERpo((ERpo*)agent);
					else if( agent->Type == TypeTerm )	job[n].Agents[i] = new Term((Term*)agent);
					else {
						sprintf(msg, "Invalid agent type encountered in the task.");
						throw msg;
					}
				}
				job[n++].inttime = -1;				// to indicate first time taken
				LastJobOffset = NextJobOffset;
			}
						// distribute jobs and runs from job[] array
			for( n=0; /* n<cpRivals::jobtotal || kfree<cpRivals::numprocs-1 */ ; ) {
				int tasknum, jobnum=-1;
				try {
					if( n < cpRivals::jobtotal ) {
						if( job[n].RunsToDo <= 0 || job[n].RunsDone < 0 )	// job completed or failed
							{ n++; continue; }
						if( job[n].inttime < 0 ) 		// job taken in the first time
							{ job[n].inttime = 0; job[n].starttime = MPI::Wtime(); }
						if( cpRivals::decide && job[n].RunsDone < decide && job[n].RunsToDo == cpRivals::Runs - decide )
							{ n++; continue; }
						if( ! job[n].wcsv0 ) {
							job[n].wcsv0 = fopen(job[n].filename, "a+t");
							if( ! job[n].wcsv0 ) {
								sprintf(msg, "[0000] Cannot open current csv file \"%s\"", job[n].filename);
								throw msg;
							}
						}
					}
										// First check messages from other tasks
					if( MPI::COMM_WORLD.Iprobe(MPI::ANY_SOURCE, MPI::ANY_TAG, status) ) {
						tasknum = status.Get_source();
						jobnum = procJob[tasknum];
						int tag = status.Get_tag();
						if( tag == cpRivals::tagRunError ) {			// <- tagRunError (run failed)
							int count = status.Get_count(MPI::CHAR);
							MPI::COMM_WORLD.Recv(tmp, count, MPI::CHAR, tasknum, tag, status);
							if( (cpRivals::logmpi & cpRivals::tagRunError) ) {
								printf("[0000] <- [%04d] tagRunError @290 %d: '%s'\n", tasknum, count, tmp);
								fflush(stdout);
							}
							sprintf(msg, "[%04d] %s (jobline=%d)", tasknum, tmp, 
								jobnum >= 0 ? job[jobnum].LineNumber : -1);
							throw msg;
						}
						if( tag == cpRivals::tagInfo ) {					// <- tagInfo (line output to console)
							int count = status.Get_count(MPI::CHAR);
							MPI::COMM_WORLD.Recv(msg, count, MPI::CHAR, tasknum, tag, status);
							if( (cpRivals::logmpi & cpRivals::tagInfo) ) {
								printf("[0000] <- [%04d] tagInfo @301 %d: '%s'\n", tasknum, count, msg);
								fflush(stdout);
							}
							printf("%s", msg); fflush(stdout);
							continue;
						}
						if( tag == cpRivals::tagAbortRun ) {			// <- tagAbortRun (ACK from terminated task)
							MPI::COMM_WORLD.Recv(msg, 1, MPI::CHAR, tasknum, tag, status);
							if( (cpRivals::logmpi & cpRivals::tagAbortRun) ) {
								printf("[0000] <- [%04d] tagAbortRun @310 1: x%02X\n", tasknum, msg[0]);
								fflush(stdout);
							}
                     if( procJob[tasknum] >= 0 ) { procJob[tasknum] = -1;  kfree++; }
							continue;
						}
						int count = status.Get_count(MPI::INT);		// <- tagRunCompleted && final counters
						int* result = new int[count];
						MPI::COMM_WORLD.Recv(result, count, MPI::INT, tasknum, tag, status);
						if( (cpRivals::logmpi & cpRivals::tagRunCompleted) ) {
							printf("[0000] <- [%04d] tagRunCompleted @320 %d: %d", tasknum, count, result[0]);
							for( int j=1; j<count; j++ ) printf(",%d", result[j]);
							printf("\n"); fflush(stdout);
						}
						if( jobnum < 0 || job[jobnum].RunsDone < 0 ) 
							{ delete [] result; continue; }		// skip post-cancellation results
						int error = status.Get_error();
						if( error != MPI::SUCCESS ) {
							sprintf(msg, "[0000] MPI_ERR %d in Recv#320 from task [%d]: jobline=%d run=%d", 
								error, tasknum, job[jobnum].LineNumber, job[jobnum].RunsDone+1);
							delete [] result;
							throw msg;
						}
						int resnum = 0;
						int i;		// collect counters into job[] table
						for( i=0; i<cpRivals::task->NumAgents; i++ ) {
							if( resnum >= count ) break;
							Agent* agent = job[jobnum].Agents[i];
							if( agent->Type == TypeGene ) {			// collect Gene counters
								Gene* gene = (Gene*)agent;
								gene->Initiated = result[resnum++];
								if( resnum >= count ) break;
								gene->InitP = result[resnum++];
								if( resnum >= count ) break;
								gene->InitN = result[resnum++];
								if( resnum >= count ) break;
								gene->Transcribed = result[resnum++];
								if( resnum >= count ) break;
								gene->TransP = result[resnum++];
								if( resnum >= count ) break;
								gene->TransN = result[resnum++];
								continue;
							}
							if( agent->Type == TypePEP ) {			// collect PEP counters
								PEP* pep = (PEP*)agent;
								pep->Offered = result[resnum++];
								if( resnum >= count ) break;
								pep->Bound = result[resnum++];
								continue;
							}
							if( agent->Type == TypeNEP ) {			// collect NEP counters
								NEP* nep = (NEP*)agent;
								nep->Offered = result[resnum++];
								if( resnum >= count ) break;
								nep->Bound = result[resnum++];
								continue;
							}
							if( agent->Type == TypeRepr ) {			// collect Repr counters
								Repr* repr = (Repr*)agent;
								repr->Offered = result[resnum++];
								if( resnum >= count ) break;
								repr->Bound = result[resnum++];
								continue;
							}
							if( agent->Type == TypeEKor ) {			// collect EKor counters
								EKor* ekor = (EKor*)agent;
								ekor->Offered = result[resnum++];
								if( resnum >= count ) break;
								ekor->Bound = result[resnum++];
								continue;
							}
							if( agent->Type == TypeERpo ) {			// collect ERpo counters
								ERpo* erpo = (ERpo*)agent;
								erpo->Offered = result[resnum++];
								if( resnum >= count ) break;
								erpo->Bound = result[resnum++];
								continue;
							}
							if( agent->Type == TypeTerm ) {			// collect Term counters
								Term* term = (Term*)agent;
								term->Offered = result[resnum++];
								if( resnum >= count ) break;
								term->Bound = result[resnum++];
								continue;
							}
						}
						if( i < cpRivals::task->NumAgents ) {
							sprintf(msg, "[0000] Not enough results received from [%d]: jobline=%d run=%d",
								tasknum, job[jobnum].LineNumber, job[jobnum].RunsDone+1);
							delete [] result;
							throw msg;
						}
						if( resnum != count ) {
							fprintf(stderr, "[0000] Extra results ignored from [%d]: jobline=%d run=%d\n",
								tasknum, job[jobnum].LineNumber, job[jobnum].RunsDone+1);
							fflush(stderr);
						}
						delete [] result;
						tag = cpRivals::tagGetRecords;					// tagGetRecords ->
						MPI::COMM_WORLD.Send(msg, 1, MPI::CHAR, tasknum, tag);
						if( (cpRivals::logmpi & cpRivals::tagGetRecords) ) {
							printf("[0000] -> [%04d] tagGetRecords @407 1: x%02X\n", tasknum, msg[0]);
							fflush(stdout);
						}
						char* line = new char[FILEBUFLEN];
						char* line2 = new char[FILEBUFLEN];
						while( true ) {							// get csv portion until empty line
							MPI::COMM_WORLD.Probe(tasknum, MPI::ANY_TAG, status);
							if( status.Get_tag() == cpRivals::tagRunError ) {	// error in transfer
								count = status.Get_count(MPI::CHAR);
								MPI::COMM_WORLD.Recv(line, count, MPI::CHAR, tasknum, tagRunError, status);
								if( (cpRivals::logmpi & cpRivals::tagRunError) ) {
									printf("[0000] <- [%04d] tagRunError @418 %d: '%s'\n", tasknum, count, line);
									fflush(stdout);
								}
								sprintf(msg, "[%04d] %s (jobline=%d)", tasknum, line, job[jobnum].LineNumber);
								delete [] line;
								delete [] line2;
								throw msg;
							}
							count = status.Get_count(MPI::CHAR);		// <- tagGetRecords w/record
							MPI::COMM_WORLD.Recv(line, count, MPI::CHAR, tasknum, tag, status);
							if( (cpRivals::logmpi & cpRivals::tagGetRecords) ) {
								printf("[0000] <- [%04d] tagGetRecords @429 %d: '%s'\n", tasknum, count, line);
								fflush(stdout);
							}
							if( strlen(line) == 0 ) break;				// end of portion signal
							char* p = strchr(line, '#');
							if( p == NULL ) {
								sprintf(msg, "[%04d] No number placeholder in csv record.", tasknum);
								delete [] line;
								delete [] line2;
								throw msg;
							}
							*p = 0;
							sprintf(line2, "%s%d%s", line, job[jobnum].RunsDone+1, p+1);
							if( fputs(line2, job[jobnum].wcsv0) < 0 ) {
								sprintf(msg, "[0000] Write error in %s (jobline=%d)", 
									job[jobnum].filename, job[jobnum].LineNumber);
								delete [] line;
								delete [] line2;
								throw msg;
							}
							fflush(job[jobnum].wcsv0);
						}
						delete [] line;
						delete [] line2;
						cpRivals::RunsDone = (++ job[jobnum].RunsDone);			
                  if( procJob[tasknum] >= 0 ) { procJob[tasknum] = -1;  kfree++; }
						for( int i=0; i<cpRivals::task->NumAgents; i++ ) {	// accumulate and copy to the task
							Agent* agent = job[jobnum].Agents[i];
							if( agent->Type == TypeGene ) ((Gene*)agent)->Accumulate();
							cpRivals::task->setAgent(agent, i);
						}
						printf("[%04d] J%4d/%d R%4d/%d", tasknum, jobnum+1, cpRivals::jobtotal, 
							cpRivals::RunsDone, cpRivals::Runs);
						for( int i=0; i<cpRivals::task->NumAgents; i++ ) {
							Agent* agent = cpRivals::task->getAgent(i);
							if( agent->Type == TypeGene ) {
								Gene* gene = (Gene*)agent;
								if( gene->Transcribed < 1000 ) printf("%4d", gene->Transcribed);
								else if( gene->Transcribed < 9950 ) printf("%2dK%1d", (gene->Transcribed + 50) / 1000,
									((gene->Transcribed + 50) % 1000) / 100);
								else if( gene->Transcribed < 99500 ) printf("%3dK", (gene->Transcribed + 500) / 1000);
								else if( gene->Transcribed < 995000 ) printf("M%02d", (gene->Transcribed + 5000) / 10000);
								else if( gene->Transcribed < 9950000 ) printf("%2dM%1d", (gene->Transcribed + 50000) 
									/ 1000000, ((gene->Transcribed + 50000) % 1000000) / 100000);
								else printf("%3dM", (gene->Transcribed + 500000) / 1000000);
							}
						}
						if( cpRivals::decide && job[jobnum].RunsDone >= decide && CheckFilter() ) {
							double dt = (MPI::Wtime() - job[jobnum].starttime) / 60.;
                     double tt = (MPI::Wtime() - mpi_t0) / 60.;
							printf(" Stop %.0f'\n", dt); fflush(stdout);
							if( CopyFile(job[jobnum].wcsv0, wcsv1) ) {
								sprintf(msg, "Error while copying data to rejected csv.");
								throw msg;
							}
                     fprintf(wlog, "%5.0fm: Job%5d (line%5d) degenerated, time = %6.1f min\n",
								tt, jobnum+1, job[jobnum].LineNumber, dt);
							fflush(wlog);
							MarkJobDone(cpRivals::rjbfilename, job[jobnum].Offset);
							job[jobnum].RunsToDo = 0; job[jobnum].RunsDone = -1;		// to mark the job as finished
							for( int k=1; k<cpRivals::numprocs; k++ ) {
								if( k == tasknum || procJob[k] != jobnum ) continue;
								MPI::COMM_WORLD.Send(msg, 1, MPI::CHAR, k, cpRivals::tagAbortRun);
								if( (cpRivals::logmpi & cpRivals::tagAbortRun) ) {
									printf("[0000] -> [%04d] tagAbortRun @492 1: x%02X\n", k, msg[0]);
									fflush(stdout);
								}
							}
							for( int k=1; k<cpRivals::numprocs; k++ ) {
								if( k == tasknum || procJob[k] != jobnum ) continue;
								while( true ) {
									if( ! MPI::COMM_WORLD.Iprobe(k, MPI::ANY_TAG, status) ) continue;
									int tag = status.Get_tag();
									if( tag == cpRivals::tagRunError || tag ==cpRivals::tagInfo || tag == tagGetRecords ) {
										int count = status.Get_count(MPI::CHAR);
										MPI::COMM_WORLD.Recv(tmp, count, MPI::CHAR, k, tag);
										if( (cpRivals::logmpi & tag) ) {
											char *tagname = new char[16];
											if( tag == cpRivals::tagRunError ) sprintf(tagname, "tagRunError");
											else if( tag == cpRivals::tagInfo ) sprintf(tagname, "tagInfo");
											else if( tag == cpRivals::tagGetRecords ) sprintf(tagname, "tagGetRecords");
											printf("[0000] <- [%04d] %s @505 %d: '%s'\n", k, tagname, count, tmp);
											fflush(stdout);
											delete [] tagname;
										}
										if( tag == tagGetRecords && strlen(tmp) == 0 ) break;
									}
									else if( tag == tagRunCompleted ) {
										int count = status.Get_count(MPI::INT);
										int *result = new int[count];
										MPI::COMM_WORLD.Recv(result, count, MPI::INT, k, tag);
										if( (cpRivals::logmpi & cpRivals::tagRunCompleted) ) {
											printf("[0000] <- [%04d] tagRunCompleted @520 %d: %d", k, count, result[0]);
											for( int j=1; j<count; j++ ) printf(",%d", result[i]);
											printf("\n"); fflush(stdout);
										}
										delete [] result;
									}
									else {		// tagAbortRun acknowledgement
										MPI::COMM_WORLD.Recv(msg, 1, MPI::CHAR, k, cpRivals::tagAbortRun);
										if( (cpRivals::logmpi & cpRivals::tagAbortRun) ) {
											printf("[0000] -> [%04d] tagAbortRun @529 1: x%02X\n", k, msg[0]);
											fflush(stdout);
										}
										break;
									}
								}
                        if( procJob[k] >= 0 ) { procJob[k] = -1;  kfree++; }
							}
							fclose(job[jobnum].wcsv0); job[jobnum].wcsv0 = NULL; // free everything
							if( remove(job[jobnum].filename) ) {
								sprintf(msg, "Cannot delete current csv data file.");
								throw msg;
							}
							if( job[jobnum].varvalue ) { delete [] job[jobnum].varvalue; job[jobnum].varvalue = NULL; }
							if( job[jobnum].Agents ) {
								for( int i=0; i<cpRivals::task->NumAgents; i++ )
									if( job[jobnum].Agents[i] ) delete job[jobnum].Agents[i];
								delete [] job[jobnum].Agents; job[jobnum].Agents = NULL;
							}
                     if( procJob[tasknum] >= 0 ) { procJob[tasknum] = -1; kfree++; }
							continue;
						}
											// successful job complete
						if( job[jobnum].RunsDone == cpRivals::Runs ) {
							double dt = (MPI::Wtime() - job[jobnum].starttime) / 60.;
                     double tt = (MPI::Wtime() - mpi_t0) / 60.;
							printf(" Done %.0f'\n", dt); fflush(stdout);
							if( CopyFile(job[jobnum].wcsv0, wcsv) ) {
								sprintf(msg, "Error while copying data to accepted csv.");
								throw msg;
							}
                     fprintf(wlog, "%5.0fm: Job%5d (line%5d) completed,   time = %6.1f min\n",
								tt, jobnum+1, job[jobnum].LineNumber, dt);
							fflush(wlog);
							MarkJobDone(cpRivals::rjbfilename, job[jobnum].Offset);
							job[jobnum].RunsToDo = 0;
							fclose(job[jobnum].wcsv0); job[jobnum].wcsv0 = NULL; // free everything
							if( remove(job[jobnum].filename) ) {
								sprintf(msg, "Cannot delete current csv data file.");
								throw msg;
							}
							if( job[jobnum].varvalue ) delete [] job[jobnum].varvalue;
							job[jobnum].varvalue = NULL;
							if( job[jobnum].Agents ) {
								for( int i=0; i<cpRivals::task->NumAgents; i++ )
									if( job[jobnum].Agents[i] ) delete job[jobnum].Agents[i];
								delete [] job[jobnum].Agents; job[jobnum].Agents = NULL;
							}
							n = 0; continue;
						}
						else {
							printf("\n"); fflush(stdout);
							n = 0; continue;
						}
					}
					if( n >= cpRivals::jobtotal ) {
						for( n=0; n<cpRivals::jobtotal; n++ )
							if( job[n].RunsToDo > 0 ) break;
						if( n >= cpRivals::jobtotal && kfree >= cpRivals::numprocs-1 ) break;
						else continue;
					}
					if( kfree > 0 ) {						// Assign job's run to a free task
						for( tasknum = 1; tasknum < cpRivals::numprocs; tasknum++ )		// find first free 
							if( procJob[tasknum] < 0 ) break;
						if( tasknum >= cpRivals::numprocs ) {
							fprintf(stderr, "[0000] Internal error: inconsistent kfree and procJob[].\n");
							fflush(stderr); break;
						}
						if( job[n].RunsToDo <= 0 || job[n].RunsDone < 0 ) {	// job completed or failed
							if( job[n].wcsv0 ) { fclose(job[n].wcsv0); job[n].wcsv0 = NULL; }
							if( strlen(job[n].filename) ) remove(job[n].filename);
							if( job[n].varvalue ) { delete [] job[n].varvalue; job[n].varvalue = NULL; }
							if( job[n].Agents ) {
								for( int i=0; i<cpRivals::task->NumAgents; i++ )
									if( job[n].Agents[i] ) delete job[n].Agents[i];
								delete [] job[n].Agents; job[n].Agents = NULL;
							}
							n++; continue; 
						}
						MPI::COMM_WORLD.Send(job[n].varvalue, cpRivals::varcount, MPI::DOUBLE,
							tasknum, cpRivals::tagJobVariables);
						if( (cpRivals::logmpi & cpRivals::tagJobVariables) ) {
							printf("[0000] -> [%04d] tagJobVariables @609 %d: %.2g", tasknum, varcount, job[n].varvalue[0]);
							for( int j=1; j<cpRivals::varcount; j++ ) printf(" %.2g", job[n].varvalue[j]);
							printf("\n"); fflush(stdout);
						}
						job[n].RunsToDo --;
						procJob[tasknum] = n; kfree --;
						continue;
					}
					continue;	// no free tasks, continue with message checking
				}
				catch (char *err) {
					fprintf(stderr, "%s\n[0000] Job %d in line %d terminated.\n", err, jobnum, job[jobnum].LineNumber);
					fflush(stderr);
					char *msg = new char[MSGLEN];
					strcpy(msg, err);
					for( int k=1; k<cpRivals::numprocs; k++ ) {
						if( procJob[k] != jobnum ) continue;
						MPI::COMM_WORLD.Send(msg, 1, MPI::CHAR, k, cpRivals::tagAbortRun);
						if( (cpRivals::logmpi & cpRivals::tagAbortRun) ) {
							printf("[0000] -> [%04d] tagAbortRun @627 1: x%02X\n", k, msg[0]);
							fflush(stdout);
						}
					}
					for( int k=1; k<cpRivals::numprocs; k++ ) {
						if( procJob[k] != jobnum ) continue;
						while( true ) {
							if( ! MPI::COMM_WORLD.Iprobe(k, MPI::ANY_TAG, status) ) continue;
							int tag = status.Get_tag();
							if( tag == cpRivals::tagRunError || tag ==cpRivals::tagInfo ) { 
								int count = status.Get_count(MPI::CHAR);
								char* tagname = new char[16];
								if( tag == cpRivals::tagRunError ) sprintf(tagname, "tagRunError");
								else if( tag ==cpRivals::tagInfo ) sprintf(tagname, "tagInfo");
								MPI::COMM_WORLD.Recv(tmp, count, MPI::CHAR, k, tag);
								if( (cpRivals::logmpi & tag) ) {
									printf("[0000] <- [%04d] %s @643 %d: '%s'\n", k, tagname, count, tmp);
									fflush(stdout);
								}
								delete [] tagname;
							}
							else if( tag == tagRunCompleted ) {
								int count = status.Get_count(MPI::INT);
								int* result = new int[count];
								MPI::COMM_WORLD.Recv(result, count, MPI::INT, k, tag);
								if( (cpRivals::logmpi & cpRivals::tagRunCompleted) ) {
									printf("[0000] <- [%04d] tagRunCompleted @652 %d: %d", k, count, result[0]);
									for( int j=1; j<count; j++ ) printf(",%d", result[j]);
									printf("\n"); fflush(stdout);
								}
								delete [] result;
							}
							else {		// tagAbortRun acknowledgement
								MPI::COMM_WORLD.Recv(msg, 1, MPI::CHAR, k, cpRivals::tagAbortRun);
								if( (cpRivals::logmpi & cpRivals::tagAbortRun) ) {
									printf("[0000] <- [%04d] tagAbortRun @662 1: x%02X\n", k, msg[0]);
									fflush(stdout);
								}
								break;
							}
						}
						procJob[k] = -1;  kfree++;
					}
					job[jobnum].RunsDone = -1;		// to mark the job as finished
					if( job[jobnum].wcsv0 ) { fclose(job[jobnum].wcsv0); job[jobnum].wcsv0 = NULL; }
               remove(job[jobnum].filename);
					if( job[jobnum].varvalue ) { delete [] job[jobnum].varvalue; job[jobnum].varvalue = NULL; }
					if( job[jobnum].Agents ) {
						for( int i=0; i<cpRivals::task->NumAgents; i++ )
							if( job[jobnum].Agents[i] ) delete job[jobnum].Agents[i];
						delete [] job[jobnum].Agents; job[jobnum].Agents = NULL;
					}
					delete [] msg;
				}
			}
			mpi_t1 = MPI::Wtime();
			double dt = (mpi_t1 - mpi_t0) / 60;
			printf("[0000] Job file processing completed after %.0f min.\n", dt); fflush(stdout);
         if( cpRivals::wlog ) { fprintf(wlog, "Job file processing completed after %.0f min.\n", dt); fflush(wlog); }
			delete [] procJob; 
			for( int j=0; j<cpRivals::jobtotal; j++ ) {
				if( job[j].RunsDone < 0 ) continue;
				if( job[j].wcsv0 ) fclose(job[j].wcsv0);
				if( job[j].varvalue ) delete [] job[j].varvalue; 
				if( job[j].Agents ) {
					for( int i=0; i<cpRivals::task->NumAgents; i++ )
						if( job[j].Agents[i] ) delete job[j].Agents[i];
					delete [] job[j].Agents;
				}
			}
			delete [] job;
		}
		else {								//===================================== MPI mode processing: secondary branches
			char* line = new char[FILEBUFLEN];
			int* counters = new int[cpRivals::task->NumAgents * 6];	// 4=>6 after adding two more counters for a gene
			msg[0] = 0; filename[0] = 0;
			cpRivals::RunsDone = -1;		// to print # as run number in csv portion
			MPI::Status status;
			while( true ) {		// main loop of processing
				try {
					if( MPI::COMM_WORLD.Iprobe(root, MPI::ANY_TAG, status) ) {	// Message ready
						int tag = status.Get_tag();
						if( tag == cpRivals::tagAbortRun ) {		// Abort processing
							MPI::COMM_WORLD.Recv(msg, 1, MPI::CHAR, root, tagAbortRun);
							if( cpRivals::wcsv0 ) { fclose(wcsv0); wcsv0 = NULL; }
							if( strlen(filename) ) { remove(filename); filename[0] = 0; }
							MPI::COMM_WORLD.Send(msg, 1, MPI::CHAR, root, tagAbortRun);
							continue;
						}
						if( tag == cpRivals::tagFinalize ) {		// Finalize all
							MPI::COMM_WORLD.Recv(msg, 1, MPI::CHAR, root, tagFinalize);
							break;
						}
						if( tag == cpRivals::tagJobVariables ) {	// Job assigned
							int count = status.Get_count(MPI::DOUBLE);
							if( count != cpRivals::varcount ) {
								sprintf(msg, "Incorrect number of job variables received");
								throw msg;
							}
							MPI::COMM_WORLD.Recv(cpRivals::varvalue, count, MPI::DOUBLE, root, tag, status);
							int error = status.Get_error();
							if( error != MPI::SUCCESS ) {
								sprintf(msg, "[%04d] MPI_ERR %d in Recv from the root task", cpRivals::myid, error);
								throw msg;
							}
							sprintf(filename, "%s%s_current_%d.csv", 
								cpRivals::scratch, cpRivals::outfilename, cpRivals::myid);
							cpRivals::wcsv0 = fopen(filename, "wt");
							if( !wcsv0 ) {
								sprintf(msg, "Cannot open current output file."); 
								throw msg;
							}
							for( int i=0; i<cpRivals::task->NumAgents; i++ ) {		// reset all agents of the task
								cpRivals::task->getAgent(i)->Restore();
								cpRivals::task->getAgent(i)->Reset();
							}
							if( SetCurrentParameters(cpRivals::varvalue) ) {		// set variable parameters
								sprintf(msg, "Cannot set parameters from current job.");
								throw msg;
							}

							int rc = RunTrajectory();
							if( rc < 0 ) { sprintf(msg, "Trajectory failed."); throw msg; }
							if( rc > 0 ) continue;
							/* rc == 0 */	// last (or single) record
							OutCSVResult(wcsv0, cpRivals::config.PhysicalTime);
							fclose(wcsv0); wcsv0 = NULL;

							count = 0;		// fill tagRunCompleted message buffer to send to the root
							for( int i=0; i<cpRivals::task->NumAgents; i++ ) {
								Agent* agent = cpRivals::task->getAgent(i);
								if( agent->Type == TypeGene ) {			// provide Gene counters
									Gene* gene = (Gene*)agent;
									counters[count++] = gene->Initiated;
									counters[count++] = gene->InitP;
									counters[count++] = gene->InitN;
									counters[count++] = gene->Transcribed;
									counters[count++] = gene->TransP;
									counters[count++] = gene->TransN;
									continue;
								}
								if( agent->Type == TypePEP ) {			// provide PEP counters
									PEP* pep = (PEP*)agent;
									counters[count++] = pep->Offered;
									counters[count++] = pep->Bound;
									continue;
								}
								if( agent->Type == TypeNEP ) {			// provide NEP counters
									NEP* nep = (NEP*)agent;
									counters[count++] = nep->Offered;
									counters[count++] = nep->Bound;
									continue;
								}
								if( agent->Type == TypeRepr ) {			// provide Repr counters
									Repr* repr = (Repr*)agent;
									counters[count++] = repr->Offered;
									counters[count++] = repr->Bound;
									continue;
								}
								if( agent->Type == TypeEKor ) {			// provide EKor counters
									EKor* ekor = (EKor*)agent;
									counters[count++] = ekor->Offered;
									counters[count++] = ekor->Bound;
									continue;
								}
								if( agent->Type == TypeERpo ) {			// provide ERpo counters
									ERpo* erpo = (ERpo*)agent;
									counters[count++] = erpo->Offered;
									counters[count++] = erpo->Bound;
									continue;
								}
								if( agent->Type == TypeTerm ) {			// provide Term counters
									Term* term = (Term*)agent;
									counters[count++] = term->Offered;
									counters[count++] = term->Bound;
									continue;
								}
							}
							MPI::COMM_WORLD.Send(counters, count, MPI::INT, root, tagRunCompleted);

							cpRivals::wcsv0 = fopen(filename, "rt");
							if( !wcsv0 ) {
								sprintf(msg, "Cannot reopen ready output file.");
								throw msg;
							}
							MPI::COMM_WORLD.Probe(root, MPI::ANY_TAG, status);
							if( status.Get_tag() == cpRivals::tagAbortRun ) {
								MPI::COMM_WORLD.Recv(msg, 1, MPI::CHAR, root, tagAbortRun);
								if( cpRivals::wcsv0 ) { fclose(wcsv0); wcsv0 = NULL; }
								if( strlen(filename) ) { remove(filename); filename[0] = 0; }
								MPI::COMM_WORLD.Send(msg, 1, MPI::CHAR, root, tagAbortRun);
								continue;
							}		
							if( tag == cpRivals::tagFinalize ) {		// Finalize all
								MPI::COMM_WORLD.Recv(msg, 1, MPI::CHAR, root, tagFinalize);
								break;
							}
							tag = tagGetRecords;		// otherwise, tagGetRecords: send all csv records
							MPI::COMM_WORLD.Recv(msg, 1, MPI::CHAR, root, tag);
							while( fgets(line, FILEBUFLEN, wcsv0) ) {
								if( MPI::COMM_WORLD.Iprobe(root, cpRivals::tagAbortRun) ) {
									MPI::COMM_WORLD.Recv(msg, 1, MPI::CHAR, root, tagAbortRun);
									if( cpRivals::wcsv0 ) { fclose(wcsv0); wcsv0 = NULL; }
									if( strlen(filename) ) { remove(filename); filename[0] = 0; }
									MPI::COMM_WORLD.Send(msg, 1, MPI::CHAR, root, tagAbortRun);
									break;
								}
								MPI::COMM_WORLD.Send(line, (int)strlen(line)+1, MPI::CHAR, root, tag);
							}
							if( ferror(wcsv0) ) {
								sprintf(msg, "Result file I/O error."); 
								throw msg;
							}
							if( feof(wcsv0) ) {
								msg[0] = 0;	// eof indicator
								MPI::COMM_WORLD.Send(msg, 1, MPI::CHAR, root, tag);
								if( cpRivals::wcsv0 ) { fclose(wcsv0); wcsv0 = NULL; }
								if( strlen(filename) ) { remove(filename); filename[0] = 0; }
							}
						}
					}
					continue;		// continue check for messages
				}
				catch (char *err) {		// inform the root about error and wait for instructions
					MPI::COMM_WORLD.Send(err, (int)strlen(err)+1, MPI::CHAR, root, cpRivals::tagRunError);
				}
			}
			delete [] line;
			delete [] counters;
		}
        #endif
	}
	catch (char *err) {
        char* msg1 = new char[MSGLEN];
		sprintf(msg1, "[%04d] %s\n", cpRivals::myid, err);
		if( cpRivals::myid == 0 ) { fprintf(stderr, "%s", msg1); fflush(stderr); }
        #ifdef PARALLEL
		else if( cpRivals::mpimode && MPI::Is_initialized() ) {
			if( collect ) 
				MPI::COMM_WORLD.Send(msg1, (int)strlen(msg1)+1, MPI::CHAR, root, cpRivals::tagInfo);
			MPI::Finalize();
		}
        #endif
        delete [] msg1;
	}
//Final:
    #ifdef PARALLEL
	if( cpRivals::mpimode && MPI::Is_initialized() ) {
		if( cpRivals::myid == 0 ) {
			MPI::Status status;
			char* msg1 = new char[MSGLEN];
			while(MPI::COMM_WORLD.Iprobe(MPI::ANY_SOURCE, cpRivals::tagInfo, status)) {
				MPI::COMM_WORLD.Recv(msg1, status.Get_count(MPI::CHAR), MPI::CHAR, status.Get_source(),
											cpRivals::tagInfo, status);
				fprintf(stderr, "%s", msg1); fflush(stderr);
			}
			delete [] msg1;
			for( int k=1; k<cpRivals::numprocs; k++ ) {
				MPI::COMM_WORLD.Send(msg, 1, MPI::CHAR, k, cpRivals::tagFinalize);
				if( (cpRivals::logmpi & cpRivals::tagFinalize) )
					printf("[0000] -> [%04d] tagFinalize @869 1: x%02X\n", k, msg[0]);
			}
		}
		MPI::Finalize();
	}
    #endif
	if( cpRivals::task ) { delete cpRivals::task; cpRivals::task = NULL; }
	delete [] tmp;
	delete [] msg;
	delete [] filename;
	return 0;
}
