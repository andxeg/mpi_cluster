// cpRivals: Model of the regulation by competing promoters.
//
// Copyright (C) 2009-2012 Lev Rubanov <rubanov@iitp.ru>
// Copyright (C) 2009-2012 Institute for Information Transmission Problems of
// the Russian Academy of Sciences (Kharkevich Institute) <http://www.iitp.ru>
//
// This model has been proposed and implemented in the Laboratory of 
// Mathematical Methods and Models in Bioinformatics of the above Institute.
// Head of the Laboratory, Prof. Vassily Lyubetsky <lyubetsky@iitp.ru>
//   
// This file is part of cpRivals.
//
// cpRivals is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// cpRivals is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with cpRivals. If not, see <http://www.gnu.org/licenses/>.
//
// Functions: LeftToRight, ByTouchTime, Random, CopyFile, CheckFilter
//
#include "cprivals.h"

int cpRivals::LeftToRight(const void *x, const void *y) {
	cpRivals::Agent* ax = *(cpRivals::Agent**)x;
	cpRivals::Agent* ay = *(cpRivals::Agent**)y;
	#ifdef CIRCULAR
	if( ax->Begin <= ax->End && ay->Begin > ay->End ) {			// only Y wraps
		return -1;
	}
	else if( ax->Begin > ax->End && ay->Begin <= ay->End ) {		// only X wraps
		return 1;
	}
	else if( ax->Begin <= ax->End && ay->Begin <= ay->End ) {	// Both X and Y don't wrap
	#endif
		if( ax->End < ay->Begin ) return -1;						// non-overlap cases - trivial
		if( ax->Begin > ay->End ) return 1;
		if( ax->Begin == ay->Begin && ax->End == ay->End )		// case of coincidence -  by name
			return strcmp(ax->Name, ay->Name);
		if( ax->Type != TypeGene && ax->Type != TypeRepr && ax->Type != TypeTerm &&
			ay->Type != TypeGene && ay->Type != TypeRepr && ay->Type != TypeTerm ) {
				int tx = -1;
				if( ax->Type == TypePEP )			tx = ((PEP*)ax)->Tcenter;
				else if( ax->Type == TypeNEP )	tx = ((NEP*)ax)->Tcenter;
				else if( ax->Type == TypeEKor )	tx = ((EKor*)ax)->Tcenter;
				else if( ax->Type == TypeERpo )	tx = ((ERpo*)ax)->Tcenter;
				int ty = -1;
				if( ay->Type == TypePEP )			ty = ((PEP*)ay)->Tcenter;
				else if( ay->Type == TypeNEP )	ty = ((NEP*)ay)->Tcenter;
				else if( ay->Type == TypeEKor )	ty = ((EKor*)ay)->Tcenter;
				else if( ay->Type == TypeERpo )	ty = ((ERpo*)ay)->Tcenter;
				return tx < ty ? -1 : 1;
		}
		if( ax->Begin < ay->Begin && ax->End <= ay->End ) return -1;		// unambiguous left edge
		if( ax->Begin < ay->Begin && ax->End > ay->End )
			return ay->Begin - ax->Begin > ax->End - ay->End ? -1 : 1;
		if( ax->Begin > ay->Begin && ax->End >= ay->End ) return 1;			// unambiguous right edge
		if( ax->Begin > ay->Begin && ax->End < ay->End )
			return ax->Begin - ay->Begin < ay->End - ax->End ? -1 : 1;
		if( ax->Begin == ay->Begin )
			return ax->End < ay->End ? -1 : 1;
	#ifdef CIRCULAR
	}
	else {		// Both X and Y wrap => overlap
		if( ax->Begin == ay->Begin && ax->End == ay->End )		// case of coincidence -  by name
			return strcmp(ax->Name, ay->Name);
		if( ax->Type != TypeGene && ax->Type != TypeRepr && ax->Type != TypeTerm &&
			ay->Type != TypeGene && ay->Type != TypeRepr && ay->Type != TypeTerm ) {
				int tx = -1;
				if( ax->Type == TypePEP )			tx = ((PEP*)ax)->Tcenter;
				else if( ax->Type == TypeNEP )	tx = ((NEP*)ax)->Tcenter;
				else if( ax->Type == TypeEKor )	tx = ((EKor*)ax)->Tcenter;
				else if( ax->Type == TypeERpo )	tx = ((ERpo*)ax)->Tcenter;
				int ty = -1;
				if( ay->Type == TypePEP )			ty = ((PEP*)ay)->Tcenter;
				else if( ay->Type == TypeNEP )	ty = ((NEP*)ay)->Tcenter;
				else if( ay->Type == TypeEKor )	ty = ((EKor*)ay)->Tcenter;
				else if( ay->Type == TypeERpo )	ty = ((ERpo*)ay)->Tcenter;
				if(tx > ax->Begin && ty > ay->Begin || tx < ax->Begin && ty < ay->Begin) 
					return tx < ty ? -1 : 1;		// both centers are on one side of the margin
				else
					return tx < ty ? 1 : -1;		// both centers are on different sides
		}
		if( ax->Begin < ay->Begin && ax->End <= ay->End ) return -1;		// unambiguous left edge
		if( ax->Begin < ay->Begin && ax->End > ay->End )
			return ay->Begin - ax->Begin > ax->End - ay->End ? -1 : 1;
		if( ax->Begin > ay->Begin && ax->End >= ay->End ) return 1;			// unambiguous right edge
		if( ax->Begin > ay->Begin && ax->End < ay->End )
			return ax->Begin - ay->Begin < ay->End - ax->End ? -1 : 1;
		if( ax->Begin == ay->Begin )
			return ax->End < ay->End ? -1 : 1;
	}
	#endif
	return 0;															// impossible case
}

//int cpRivals::ByTouchTime(const void *x, const void *y) {
//	cpRivals::Agent* ax = *(cpRivals::Agent**)x;
//	cpRivals::Agent* ay = *(cpRivals::Agent**)y;
//	if( ax->TouchTime < ay->TouchTime ) return -1;		
//	else if( ax->TouchTime > ay->TouchTime ) return 1;
//	else return 0;
//};

// Long period (>2.0E18) random number generator of L'Ecuyer with Bays-Durham
// shuffle and added safeguards. Returns a uniform random deviate between 0.0
// and 1.0 (exclusive of the endpoints values). Call with idum a negative
// integer to initialize; thereafter, do not alter idum between successive
// deviates in a sequence. RNMX should approximate the largest floating value
// that is less than 1. This generator meets all known statistical tests.
// The function is based on idea from the book "Numerical Recipes in C".
#define	IM1	2147483563
#define	IM2	2147483399
#define	AM		(1.0/IM1)
#define	IMM1	(IM1-1)
#define	IA1	40014
#define	IA2	40692
#define	IQ1	53668
#define	IQ2	52774
#define	IR1	12211
#define	IR2	3791
#define	NTAB	32
#define	NDIV	(1+IMM1/NTAB)
#define	RNEPS	1.2E-7
#define	RNMX	(1.0-RNEPS)
//
// long *idum is defined in cprivals.h
double cpRivals::Random(void) {
	int j;
   long k;
   static long idum2=123456789;
   static long iy=0;
   static long iv[NTAB];
   float temp;
	long *idum = & cpRivals::idum;
   if( *idum<=0 ) {						// Initialize
   	if( -(*idum)<1 ) *idum=1;		// Be sure to prevent idum=0
      else *idum=-(*idum);
      idum2=(*idum);
      for( j=NTAB+7; j>=0; j-- ) {	// Load the shuffle table (after 8 warm-ups)
      	k=(*idum)/IQ1;
         *idum=IA1*(*idum-k*IQ1)-k*IR1;
         if( *idum<0 ) *idum += IM1;
         if( j<NTAB ) iv[j]=*idum;
      }
      iy=iv[0];
   }
   k=(*idum)/IQ1;							// Start here when not initializing
   *idum=IA1*(*idum-k*IQ1)-k*IR1;	// Compute idum=(IA1*idum)%IM1 without
   if( *idum<0 ) *idum += IM1;		//  overflows by Schrage's method
   k=idum2/IQ2;
   idum2=IA2*(idum2-k*IQ2)-k*IR2;	// Compute idum2=(IA2*idum2)%IM2 likewise
   if( idum2<0 ) idum2 += IM2;
   j=iy/NDIV;								// Will be in the range 0...NTAB-1
   iy=iv[j]-idum2;						// Here idum is shuffled, idum and idum2
   iv[j]=*idum;							//  are combined to generate output
   if( iy<1 ) iy += IMM1;
   if( (temp=(float)(AM*iy))>RNMX )				// Because user don't expect endpoint values
   	return (double)RNMX;
   else return (double)temp;
}

// Append all records from source file to destination file (both properly opened)
// Since v1.4 also takes sample, average, stdev, precision into account
// Returns: false=OK, true=errors
bool cpRivals::CopyFile(FILE* from, FILE* to) {
	char* line = new char[FILEBUFLEN];
	const char delim[2]={ cpRivals::config.Delimiter, '\0' };
	int grpsize = (cpRivals::regular == 0) ? 1 :		// records per trajectory 
		(cpRivals::config.PhysicalTime - cpRivals::config.StartupTime + cpRivals::regular - 1) / 
			cpRivals::regular + 1;
	double (*psum)[MAXFIELD] = new double[grpsize][MAXFIELD];
	double (*psqr)[MAXFIELD] = new double[grpsize][MAXFIELD];
	double *var = new double[MAXPARAM];
	double *fld = new double[MAXFIELD];
	for( int i=0; i<grpsize; i++ )						// clear summators and buffers
		for( int j=0; j<cpRivals::fldcount; j++ )
			{ psum[i][j] = 0.; psqr[i][j] = 0.; }
	for( int i=0; i<MAXPARAM; i++ )  var[i] = 0.;
	for( int i=0; i<MAXFIELD; i++ )  fld[i] = 0.;
   if( fseek(from, 0L, SEEK_SET) ) 
		{ delete [] fld; delete [] var; delete [] psqr; delete [] psum; delete [] line; return true; }
	int traject = 0;					// trajectory number
	int group = 0;						// record number within a group
	char* p = NULL;
	while( fgets(line, FILEBUFLEN, from) ) {
		if( cpRivals::sample ) {		// copy sample records
			if( fputs(line, to) < 0 ) 
				{ delete [] fld; delete [] var; delete [] psqr; delete [] psum; delete [] line; return true; }
			fflush(to);
		}
		if( cpRivals::average || cpRivals::stdev ) {
			p = strtok(line, delim);
			int k = 0;
			while( p ) {
				if( traject==0 && group==0 )	// fill var[] from the first line
					var[k] = atof(p);
				k++;
				p = strtok(NULL, delim);
				if( k >= cpRivals::varcount ) { k = 0; break; }
			}
			while( p ) {							// fill fld[i] from the current line
				fld[k++] = atof(p);
				p = strtok(NULL, delim);
			}
			if( cpRivals::regular==0 && k!=cpRivals::fldcount+1 || 
				cpRivals::regular!=0 && k!=cpRivals::fldcount+2 )
				{ delete [] fld; delete [] var; delete [] psqr; delete [] psum; delete [] line; return true; }
			for( int i=0; i<cpRivals::fldcount; i++ ) 		// accumulate average values
				if( cpRivals::fldagent[i] ) 
					psum[group][i] += fld[i];
				else psum[group][i] = -1.0;							// number field indicator
			if( cpRivals::regular )										// time field if needed
				psum[group][cpRivals::fldcount] = fld[fldcount];
			if( cpRivals::stdev ) {									
				for( int i=0; i<cpRivals::fldcount; i++ ) 	// accumulate stdev values
					if( cpRivals::fldagent[i] ) 
						psqr[group][i] += fld[i] * fld[i];
					else psum[group][i] = -1.0;						// number field indicator
				if( cpRivals::regular )									// time field if needed
					psqr[group][cpRivals::fldcount] = fld[fldcount];
			}
			if( ++group >= grpsize ) {
				group = 0;
				traject++;
			}
		}
	}
	if( ferror(from) ) 
		{ delete [] fld; delete [] var; delete [] psqr; delete [] psum; delete [] line; return true; }
	for( int g=0; g<grpsize; g++ ) {
		if( cpRivals::average ) {		// output average record
			for( int i=0; i<cpRivals::varcount; i++ )
				fprintf(to, "%.*f%c", cpRivals::ParamPrecision, var[i], cpRivals::config.Delimiter);
			for( int i=0; i<cpRivals::fldcount; i++ )
				if( psum[g][i] < 0 ) fprintf(to, "\"Mean\"%c", cpRivals::config.Delimiter);
				else {
					double f = psum[g][i] / traject;
					fprintf(to, "%.*f%c", cpRivals::ResultPrecision, f, cpRivals::config.Delimiter);
				}
			if( cpRivals::regular )
				fprintf(to, "%d%c\n", (int)psum[g][cpRivals::fldcount], cpRivals::config.Delimiter);
			else fprintf(to, "\n");
			fflush(to);
		}
		if( cpRivals::stdev && traject > 1 ) {			// output stdev record
			for( int i=0; i<cpRivals::varcount; i++ )
				fprintf(to, "%.*f%c", cpRivals::ParamPrecision, var[i], cpRivals::config.Delimiter);
			for( int i=0; i<cpRivals::fldcount; i++ )
				if( psum[g][i] < 0 ) fprintf(to, "\"StDev\"%c", cpRivals::config.Delimiter);
				else {
					double d = psum[g][i] / traject;
					double f = psqr[g][i] - traject * d * d;
					f = sqrt(f / (traject-1));
					fprintf(to, "%.*f%c", cpRivals::ResultPrecision, f, cpRivals::config.Delimiter);
				}
			if( cpRivals::regular )
				fprintf(to, "%d%c\n", (int)psqr[g][cpRivals::fldcount], cpRivals::config.Delimiter);
			else fprintf(to, "\n");
			fflush(to);
		}
	}
	for( int i=0; i<grpsize; i++ )						// clear summators and buffers again
		for( int j=0; j<cpRivals::fldcount; j++ )
			{ psum[i][j] = 0.; psqr[i][j] = 0.; }
	for( int i=0; i<MAXPARAM; i++ )  var[i] = 0.;
	for( int i=0; i<MAXFIELD; i++ )  fld[i] = 0.;
	if( cpRivals::Runs > 1 && cpRivals::sample )		// Add empty line after entire job data
		{ fputs("\n", to); fflush(to); }
	delete [] fld; delete [] var; delete [] psqr; delete [] psum; delete [] line;
	return false;
}

// Check if the job is degenerated. Return true: terminate, false: continue
bool cpRivals::CheckFilter(void) {
	double sum = 0, minimum = 1000000000;
	try {
		for( int i=0; i<cpRivals::task->NumAgents; i++ ) {
			Agent* agent = cpRivals::task->getAgent(i);
			if( agent->Type != TypeGene ) continue;
			Gene* gene = (Gene*)agent;
			sum += (double)gene->TotalTrans;
			if( gene->TotalTrans < minimum )
				minimum = (double)gene->TotalTrans;
		}
		if( sum < 0.0001 || minimum / sum < cpRivals::minratio ) return true;
		return false;
	}
	catch (...) {
		return true;
	}
}
