// cpRivals: Model of the regulation by competing promoters.
//
// Copyright (C) 2009-2012 Lev Rubanov <rubanov@iitp.ru>
// Copyright (C) 2009-2012 Institute for Information Transmission Problems of
// the Russian Academy of Sciences (Kharkevich Institute) <http://www.iitp.ru>
//
// This model has been proposed and implemented in the Laboratory of 
// Mathematical Methods and Models in Bioinformatics of the above Institute.
// Head of the Laboratory, Prof. Vassily Lyubetsky <lyubetsky@iitp.ru>
//   
// This file is part of cpRivals.
//
// cpRivals is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// cpRivals is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with cpRivals. If not, see <http://www.gnu.org/licenses/>.
//
// Functions: ParseArguments, ShowHelp, TrimExtension
//
#include "cprivals.h"

#ifdef _MSC_VER
#if _MSC_VER >= 1300
#pragma warning(disable: 4996)
#endif
#endif

// Return: 0: OK, -1: argument error, 1: help requested
int cpRivals::ParseArguments(int argc, char** argv) {
	if( argc<2 || argc==2 && argv[1][0]=='?' ) { 
		ShowHelp(); 
		return 1; 
	}
	for( int i=1; i<argc; i++ ) {
		char *p = argv[i];
		if( *p == '-' || *p == '/' ) {	// - or / option
			if( p[1]=='a' || p[1]=='A' ) {			// append
				cpRivals::cmdappend = true;
				cpRivals::append = true;
				continue;
			}
			if( p[1]=='c' || p[1]=='C' ) {			// collect to console (mpi)
				cpRivals::collect = true;
				continue;
			}
			if( strnicmp(p+1, "dcsn", 4)==0 ) {		// decision
				cpRivals::cmddecision = true;
				cpRivals::decide = atoi(p+5);
				continue;
			}
			if( strnicmp(p+1, "gran", 4)==0 ) {		// granularity
				cpRivals::cmdgranularity = true;
				cpRivals::granularity = atoi(p+5);
				continue;
			}
			if( p[1]=='g' || p[1]=='G' ) {			// granularity
				cpRivals::cmdgranularity = true;
				cpRivals::granularity = atoi(p+2);
				continue;
			}
			if( p[1]=='h' || p[1]=='H' || p[1]=='?' ) {	// help requested
				ShowHelp(); 
				return 1; 
			}
			if( p[1]=='i' || p[1]=='I' ) {			// .ini file name
				strncpy(cpRivals::inifilename, p+2, FILENAMELEN-1);
				continue;
			}
			if( p[1]=='j' || p[1]=='J' ) {			// job marking
				cpRivals::jobmarking = true;
				continue;
			}
			if( p[1]=='l' || p[1]=='L' ) {			// log mpi commands
				cpRivals::logmpi = atoi(p+2);
				continue;
			}
			if( strnicmp(p+1, "mrat", 4)==0 ) {		// minratio
				cpRivals::cmdminratio = true;
				cpRivals::minratio = atof(p+5);
				continue;
			}
            #ifdef PARALLEL
			if( strnicmp(p+1, "nompi", 5)==0 ) {	// nompi mode
				cpRivals::mpimode = false;
				cpRivals::myid = 0;
				continue; 
			}
            #endif
			if( p[1]=='o' || p[1]=='O' ) {			// output file name (.csv&.log)
				strncpy(cpRivals::outfilename, p+2, FILENAMELEN-1);
				TrimExtension(cpRivals::outfilename);
				continue;
			}
			if( p[1]=='p' || p[1]=='P' ) {			// profiling
				cpRivals::profiling = true;
				continue;
			}
			if( strnicmp(p+1, "runs", 4)==0 ) {		// runs
				cpRivals::cmdruns = true;
				cpRivals::Runs = atoi(p+5);
				continue;
			}
			if( p[1]=='r' || p[1]=='R' ) {			// .rjb file name
				strncpy(cpRivals::rjbfilename, p+2, FILENAMELEN-1);
				continue;
			}
			if( strnicmp(p+1, "seed", 4)==0 ) {		// seed
				cpRivals::InitialSeed = labs(atol(p+5));
				continue;
			}
			if( strnicmp(p+1, "step", 4)==0 ) {		// step
				cpRivals::cmdstep = true;
				cpRivals::regular = atoi(p+5) * 60;
				continue;
			}
			if( strnicmp(p+1, "stup", 4)==0 ) {		// startup
				cpRivals::cmdstartup = true;
				cpRivals::config.StartupTime = atoi(p+5) * 60;
				continue;
			}
			if( p[1]=='s' || p[1]=='S' ) {			// seed
				cpRivals::InitialSeed = labs(atol(p+2));
				continue;
			}
			if( strnicmp(p+1, "time", 4)==0 ) {		// time
				cpRivals::cmdtime = true;
				cpRivals::config.PhysicalTime = atoi(p+5) * 60;
				continue;
			}
			if( p[1]=='t' || p[1]=='T' ) {			// .tsk file name
				strncpy(cpRivals::tskfilename, p+2, FILENAMELEN-1);
				continue;
			}
			if( p[1]=='u' || p[1]=='U' ) {			// startup
				cpRivals::cmdstartup = true;
				cpRivals::config.StartupTime = atoi(p+2) * 60;
				continue;
			}
			if( p[1]=='-' || p[1]=='/' ) {			// cancelling an option
				if( p[2]=='a' || p[2]=='A' ) {
					cpRivals::cmdappend = true;
					cpRivals::append = false;
					continue;
				}
				if( p[2]=='c' || p[2]=='C' ) {
					cpRivals::collect = false;
					continue;
				}
				if( p[2]=='j' || p[2]=='J' ) {
					cpRivals::jobmarking = false;
					continue;
				}
			}
		}
		if( cpRivals::myid == 0 ) {
			fprintf(stderr, "\nInvalid command line option \"%s\"", p);
			fflush(stderr);
		}
		return -1;
	}
	return 0;
}

void cpRivals::ShowHelp() {
	if( cpRivals::myid != 0 ) return;
	printf(
        "\n cpRivals: Model of regulation by competing promoters (CLI&MPI) V%s\n"
        " Copyright (C) 2009-2014 Lev Rubanov <rubanov@iitp.ru>\n"
		" Copyright (C) 2009-2014 Institute for Information Transmission Problems RAS\n"
		" Made in the Laboratory of Mathematical Methods and Models in Bioinformatics,\n"
        " Head of the Lab: Vassily Lyubetsky <lyubetsk@iitp.ru>  http://lab6.iitp.ru\n"
		" This is free software, it is distributed WITHOUT ANY WARRANTY. See GNU GPL.\n\n"
		" Command line options (case insensitive):\n\n"
		" -Ifile     path/file name of the configuration file (default rivals.ini)\n"
		" -Tfile   * path/file name of the task file (.tsk)\n"
		" -Rfile     path/file name of the job file (.rjb)\n"
		" -Ofile   * path/file name of the output files (.log & .csv)\n"
		" -A       * append to output files (--A to overwrite)\n"
		" -C         collect console output from all tasks (default, --C to cancel)\n"
		" -Gn      * granularity of console output, iterations (%d default, 0=none)\n" 
		" -H         show on-screen help\n"
		" -Ln        MPIlog 1:job 2:rOK 4:get 8:abort 16:rErr 32:fin 64:inf 128:ini [%d]\n"
		" -J         comment completed jobs in the job file (default, --J to cancel)\n"
		" -Sn      * seed value for random number generator (0: by timer)\n"
		" -Un      * duration of the model startup phase in minutes\n"
		" -DCSNn   * number of runs before a decision for going on (0: none)\n"
		" -GRANn   * same as -Gn\n"
		" -MRATf   * treshold ratio of Min/Sum transcripts to continue (%g default)\n"
        #ifdef PARALLEL
		" -NOMPI     single CPU mode off the MPI environment\n"
        #endif
		" -RUNSn   * number of times to repeat each modeling\n"
		" -SEEDn   * same as -Sn\n"
		" -STEPn   * interval of intermediate data output in minutes (0: none)\n"
		" -STUPn   * duration of the model startup phase in minutes, same as -Un\n"
		" -TIMEn   * physical time of modeling in minutes\n"
		"\n Options labeled with \"*\" supersede the settings in config/task/job files.\n",
		VERSION, cpRivals::granularity, cpRivals::logmpi, cpRivals::minratio);
	fflush(stdout);
}

void cpRivals::TrimExtension(char* filename) {
	char *p = strrchr(filename, '.');	// last dot
	if( p == NULL ) return;
	char *q = strrchr(filename, '/');	// last slash
	if( q == NULL || p > q )
		*p = 0; 			// no slash after dot - cut extension
}
