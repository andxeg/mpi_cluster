// cpRivals: Model of the regulation by competing promoters.
//
// Copyright (C) 2009-2012 Lev Rubanov <rubanov@iitp.ru>
// Copyright (C) 2009-2012 Institute for Information Transmission Problems of
// the Russian Academy of Sciences (Kharkevich Institute) <http://www.iitp.ru>
//
// This model has been proposed and implemented in the Laboratory of 
// Mathematical Methods and Models in Bioinformatics of the above Institute.
// Head of the Laboratory, Prof. Vassily Lyubetsky <lyubetsky@iitp.ru>
//   
// This file is part of cpRivals.
//
// cpRivals is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// cpRivals is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with cpRivals. If not, see <http://www.gnu.org/licenses/>.
//
// Functions: RunTrajectory, CheckGene, CheckTerm, MoveHolo, MoveKor, MoveRpo
//
#include "cprivals.h"

#ifdef _MSC_VER
#if _MSC_VER >= 1300
#pragma warning(disable: 4996)
#endif
#endif

#ifdef LOGMEMORY
// User-defined operator new.
void* operator new( size_t stAllocateBlock ) {
   static int fInOpNew = 0;   // Guard flag.
	void* p = malloc( stAllocateBlock );
   if ( cpRivals::fLogMemory && !fInOpNew ) {
      fInOpNew = 1;
		printf("%p: Memory block %d allocated for %d bytes\n", p, ++cBlocksAllocated, stAllocateBlock);
		fflush(stdout);
      fInOpNew = 0;
   }
   return p;
}

// User-defined operator delete.
void operator delete( void *pvMem ) {
   static int fInOpDelete = 0;   // Guard flag.
   if ( cpRivals::fLogMemory && !fInOpDelete ) {
      fInOpDelete = 1;
		printf("%p: Memory block %d deallocated\n", pvMem, cBlocksAllocated--);
		fflush(stdout);
      fInOpDelete = 0;
   }
   free( pvMem );
}
#endif

// Executes single run of the model. Modifies all counters and totals.
// Returns: 0: OK, 1: canceled, -1: errors
int cpRivals::RunTrajectory(void) {
	int circle = 0;	// linear sequence by default
	#ifdef CIRCULAR
	circle = cpRivals::task->Circular;
	#endif
	bool cancel;
	#ifdef LOGMEMORY
	cpRivals::fLogMemory = 1;			// memory logging ON
	#endif
	char* msg = new char[MSGLEN];
	char* therr = new char[MSGLEN];
	char* tmp = new char[FILEBUFLEN];
	#ifdef LOGGING
	char* result = NULL;
	char* record = new char[FILEBUFLEN];				// log record
	#endif
	Model* model = new Model;
	try {
		if( !msg || !therr || !tmp ) { strncpy(therr, "Cannot create common buffers @64.", MSGLEN-1); throw therr; }
		#ifdef LOGGING
		if( !record ) { strncpy(therr, "Cannot create log buffer @66.", MSGLEN-1); throw therr; }
		record[0] = 0;
		#endif
		if( !model ) { strncpy(therr, "Cannot create new Model @69.", MSGLEN-1); throw therr; }
		cpRivals::model = model;
		int inttime = 0;
		int steptime = cpRivals::config.StartupTime + cpRivals::regular;
		bool filter;
		cancel = false;
		if( cpRivals::regular && !model->Startup ) 		// initial record of regular output at origin
			OutCSVResult(wcsv0, cpRivals::config.StartupTime );

		while( model->Time <= (double)cpRivals::config.PhysicalTime ) {	// Main loop of the modeling
			model->Iteration ++;
            #ifdef PARALLEL
			if( cpRivals::myid != 0 ) { // Servicing premature termination request from the root task
				if( MPI::COMM_WORLD.Iprobe(root, cpRivals::tagAbortRun) ) { 
					MPI::COMM_WORLD.Recv(tmp, 1, MPI::CHAR, root, tagAbortRun);
					cancel = true;
					strncpy(therr, "Forced termination of the trajectory.", MSGLEN-1); 
					throw therr;
				}
			}
            #endif
			if( cpRivals::granularity && model->Iteration % cpRivals::granularity == 0 ) {
				sprintf(msg, "[%04d] %6.0f min, Q:%4d,%14lld\r",		// 40 chars 
					cpRivals::myid, model->Time/60.0, model->Quelen, model->Iteration);
				if( cpRivals::myid == 0 ) { printf("%s", msg); fflush(stdout); }
                #ifdef PARALLEL
				else if( cpRivals::collect ) 
					MPI::COMM_WORLD.Send(msg, (int)strlen(msg)+1, MPI::CHAR, root, cpRivals::tagInfo);
                #endif
			}
			filter = false; 
			cpRivals::ingene = false; 
			cpRivals::outgene = false; 
			cpRivals::collision = false;
			#ifdef LOGGING
			if( CheckLogging() ) {
				sprintf(record, "%ld) %.3f:", (long)model->Iteration, model->Time);
            Agent* ag = model->PQueue.top();
            sprintf(tmp, "%s %s_%.3f (1st of %d) ", record, ag->Name, ag->TouchTime, model->Quelen);
				strcpy(record, tmp);
				//for( int q=0; q<model->Quelen && (cpRivals::Quelen==0 || q<cpRivals::Quelen); q++ ) {
				//	sprintf(tmp, "%s %s_%.3f ", record, model->Queue[q]->Name, model->Queue[q]->TouchTime);
				//	strcpy(record, tmp);
				//}
				//if( cpRivals::Quelen ) {	// print queue length and last time
				//	sprintf(tmp, "%s ...#%d_%.3f ", record, model->Quelen, model->Queue[model->Quelen-1]->TouchTime);
				//	strcpy(record, tmp);
				//}
			}
			#endif
			if( model->Quelen <= 0 ) break;				// Queue empty
         Agent* agent = model->PQueue.top( );
			//Agent* agent = model->Queue[0];
			model->Time = agent->TouchTime;
			if( model->Time > (double)cpRivals::config.PhysicalTime ) {	// 1st in queue is too late 
				model->Time = (double)cpRivals::config.PhysicalTime;
				break;
			}
			if( model->Startup && model->Time > (double)cpRivals::config.StartupTime ) {	// terminate startup phase
				model->Startup = false;
				for( int i=0; i < cpRivals::task->NumAgents; i++ ) {		// reset counters
					Agent* agent = cpRivals::task->getAgent(i);
					agent->StartupClear();
				}
				if( cpRivals::regular ) 		// initial record of regular output in the meantime
					OutCSVResult(wcsv0, cpRivals::config.StartupTime );
			}
			inttime = (int)(model->Time);
			if( !model->Startup && cpRivals::regular && inttime == steptime ) {	// regular output
				steptime += cpRivals::regular;
				OutCSVResult(wcsv0, inttime);
			}
			//
			// Do actions depending on the agent type, and sort queue if not done yet
			//
         if( agent->IsKilled() ) {                 // Remove previously killed agent
            model->removeQueue(agent);
            delete agent;
            continue;
         }
			else if( agent->Type == TypeDynam ) {		// === Dynam === (parameter change)
				Dynam* dynam = (Dynam*)agent;
				dynam->Set();
				if( dynam->operation == cpRivals::Set ) {		// change all duplicates to a new reset value
					double newpreset = dynam->agent->GetValue(dynam->parnum);
               // temporary duplicate priority_queue to modify the dynam agent instances
               std::priority_queue <Agent*, std::vector<Agent*>, PQueueLater > PQ;
               while( !model->PQueue.empty() ) {
                  Dynam* dag = (Dynam*)model->PQueue.top();
						if( dag->Type == cpRivals::TypeDynam && dag->agent == dynam->agent && 
							dag->parnum == dynam->parnum )
								dag->Preset(newpreset);
                  PQ.push(dag);
                  model->PQueue.pop();
               }
               // restore modified priority_queue
               while( !PQ.empty() ) {
                  Agent* ag = PQ.top();
                  model->PQueue.push(ag);
                  PQ.pop();
               }
				}
				model->removeQueue(agent);
				delete agent;
			}
			else if( agent->Type == TypePEP ) {			// === PEP ===
				PEP* pep = (PEP*)agent;
				pep->Offer();
				if( model->IsFreeRange(pep->Begin, pep->End) ) {		// Holoenzyme binding
					pep->Bind();
					Holo* holo = new Holo(pep, circle);
					if( !holo ) { strncpy(therr, "Cannot create new Holo @123.", MSGLEN-1); throw therr; }
					holo->SetCount();
               model->removeQueue(pep);
					pep->Touch();
               model->addQueue(pep);
					model->addQueue(holo);
					model->OccupyRange(pep->Begin, pep->End, holo);
					#ifdef LOGGING
					if( CheckLogging() && (Logmode & (PEPBound | PEPOffered | All)) ) {
						int begin = holo->Begin + Origin;
						if( begin > task->SeqLength ) begin -= task->SeqLength;
						int end = holo->End + Origin;
						if( end > task->SeqLength ) end -= task->SeqLength;
						fprintf(wlog, "%s// PEP %s bound Holo %s [%d,%d] Count=%d ", 
							record, pep->Name, holo->Name, begin, end, holo->Countback);
						filter = true;
					}
					#endif
				}
				else {
               model->removeQueue(pep);
					pep->Touch();
               model->addQueue(pep);
					#ifdef LOGGING
					if( CheckLogging() && (Logmode & (PEPOffered | All)) ) {
						int begin = pep->Begin + Origin;
						if( begin > task->SeqLength ) begin -= task->SeqLength;
						int end = pep->End + Origin;
						if( end > task->SeqLength ) end -= task->SeqLength;
						fprintf(wlog, "%s// PEP %s [%d,%d] - Blocked", record, pep->Name, begin, end);
						filter = true;
					}
					#endif
				}
			}
			else if( agent->Type == TypeNEP ) {		// === NEP ===
				NEP* nep = (NEP*)agent;
				nep->Offer();
				if( model->IsFreeRange(nep->Begin, nep->End) ) {		// Phage polymerase binding
					nep->Bind();
					Rpo* rpo = new Rpo(nep, circle);
					if( !rpo ) { strncpy(therr, "Cannot create new Rpo @173.", MSGLEN-1); throw therr; }
               model->removeQueue(nep);
					nep->Touch();
               model->addQueue(nep);
					model->addQueue(rpo);
					model->OccupyRange(nep->Begin, nep->End, rpo);
					#ifdef LOGGING
					if( CheckLogging() && (Logmode & (NEPBound | NEPOffered | All)) ) {
						int begin = nep->Begin + Origin;
						if( begin > task->SeqLength ) begin -= task->SeqLength;
						int end = nep->End + Origin;
						if( end > task->SeqLength ) end -= task->SeqLength;
						fprintf(wlog, "%s// NEP %s bound Rpo %s [%d,%d] ", record, nep->Name, rpo->Name, begin, end);
						filter = true;
					}
					#endif
				}
				else {
               model->removeQueue(nep);
					nep->Touch();
               model->addQueue(nep);
					#ifdef LOGGING
					if( CheckLogging() && (Logmode & (NEPOffered | All)) ) {
						int begin = nep->Begin + Origin;
						if( begin > task->SeqLength ) begin -= task->SeqLength;
						int end = nep->End + Origin;
						if( end > task->SeqLength ) end -= task->SeqLength;
						fprintf(wlog, "%s// NEP %s [%d,%d] - Blocked", record, nep->Name, begin, end);
						filter = true;
					}
					#endif
				}
			}
			else if( agent->Type == TypeRepr ) {	// === Repr ===
				Repr* repr = (Repr*)agent;
				repr->Offer();
				if( model->IsFreeRange(repr->Begin, repr->End) ) {		// Repressor binding
					repr->Bind();
					model->OccupyRange(repr->Begin, repr->End, repr);
					#ifdef LOGGING
					if( CheckLogging() && (Logmode & (ReprBound | ReprOffered | All)) ) {
						int begin = repr->Begin + Origin;
						if( begin > task->SeqLength ) begin -= task->SeqLength;
						int end = repr->End + Origin;
						if( end > task->SeqLength ) end -= task->SeqLength;
						fprintf(wlog, "%s// Repressor %s#%d bound [%d,%d]", record, repr->Name, repr->Bound, begin, end);
						filter = true;
					}
					#endif
				}
				#ifdef LOGGING
				else {																	// Repression site is occupied
					if( CheckLogging() && (Logmode & (ReprOffered | All)) ) {
						int begin = repr->Begin + Origin;
						if( begin > task->SeqLength ) begin -= task->SeqLength;
						int end = repr->End + Origin;
						if( end > task->SeqLength ) end -= task->SeqLength;
						fprintf(wlog, "%s// Repression site %s [%d,%d] blocked", record, repr->Name, begin, end);
						filter = true;
					}
				}
				#endif
            model->removeQueue(repr);
				repr->Touch();
            model->addQueue(repr);
			}
			else if( agent->Type == TypeEKor ) {	// === EKor ===
				EKor* ekor = (EKor*)agent;
				ekor->Offer();
				if( model->IsFreeRange(ekor->Begin, ekor->End) ) {	// External Kor appears
					ekor->Bind();
					Kor* kor = new Kor(ekor, circle);
					if( !kor ) { strncpy(therr, "Cannot create new Kor @265.", MSGLEN-1); throw therr; }
               model->removeQueue(ekor);
					ekor->Touch();
               model->addQueue(ekor);
					kor->Touch();
					model->addQueue(kor);
					model->OccupyRange(kor->Begin, kor->End, kor);
					#ifdef LOGGING
					if( (result = CheckGene(kor, circle))==NULL ) 
						{ strncpy(therr, "Cannot check Gene @274.", MSGLEN-1); throw therr; }
					#else
					CheckGene(kor, circle);
					#endif
					#ifdef LOGGING
					if( CheckLogging() && ( (Logmode & (EKorBound | EKorOffered | All)) || 
						(ingene && (Logmode & GeneInitiated)) || (outgene && (Logmode & GeneTranscribed)) ) ) {
							int begin = kor->Begin + Origin;
							if( begin > task->SeqLength ) begin -= task->SeqLength;
							int end = kor->End + Origin;
							if( end > task->SeqLength ) end -= task->SeqLength;
							int tcenter = kor->Tcenter + Origin;
							if( tcenter > task->SeqLength ) tcenter -= task->SeqLength;
							fprintf(wlog, "%s// EKor %s generated Kor %s %d [%d,%d]", 
								record, ekor->Name, kor->Name, tcenter, begin, end);
							if( result ) fprintf(wlog, "%s", result);
							filter = true;
					}
					if( result ) { delete [] result; result = NULL; }
					#endif
				}
				else {																	// EKor passes its move
               model->removeQueue(ekor);
					ekor->Touch();
               model->addQueue(ekor);
					#ifdef LOGGING
					if( CheckLogging() && (Logmode & (EKorOffered | All)) ) {
						int begin = ekor->Begin + Origin;
						if( begin > task->SeqLength ) begin -= task->SeqLength;
						int end = ekor->End + Origin;
						if( end > task->SeqLength ) end -= task->SeqLength;
						fprintf(wlog, "%s// EKor %s [%d,%d] - Blocked", record, ekor->Name, begin, end);
						filter = true;
					}
					#endif
				}
			}
			else if( agent->Type == TypeERpo ) {	// === ERpo ===
				ERpo* erpo = (ERpo*)agent;
				erpo->Offer();
				if( model->IsFreeRange(erpo->Begin, erpo->End) ) {	// External Rpo appears
					erpo->Bind();
					Rpo* rpo = new Rpo(erpo, circle);
					if( !rpo ) { strncpy(therr, "Cannot create new Rpo @322.", MSGLEN-1); throw therr; }
               model->removeQueue(erpo);
					erpo->Touch();
               model->addQueue(erpo);
					rpo->Touch();
					model->addQueue(rpo);
					model->OccupyRange(rpo->Begin, rpo->End, rpo);
					#ifdef LOGGING
					if( (result = CheckGene(rpo, circle))==NULL )
						{ strncpy(therr, "Cannot check Gene @331.", MSGLEN-1); throw therr; }
					#else
					CheckGene(rpo, circle);
					#endif
					#ifdef LOGGING
					if( CheckLogging() && ( (Logmode & (ERpoBound | ERpoOffered | All)) ||
						(ingene && (Logmode & GeneInitiated)) || (outgene && (Logmode & GeneTranscribed)) ) ) {
							int begin = rpo->Begin + Origin;
							if( begin > task->SeqLength ) begin -= task->SeqLength;
							int end = rpo->End + Origin;
							if( end > task->SeqLength ) end -= task->SeqLength;
							int tcenter = rpo->Tcenter + Origin;
							if( tcenter > task->SeqLength ) tcenter -= task->SeqLength;
							fprintf(wlog, "%s// ERpo %s generated Rpo %s %d [%d,%d]", 
								record, erpo->Name, rpo->Name, tcenter, begin, end);
							if( result ) fprintf(wlog, "%s", result);
							filter = true;
					}
					if( result ) { delete [] result; result = NULL; }
					#endif
				}
				else {																	// ERpo passes its move
               model->removeQueue(erpo);
					erpo->Touch();
               model->addQueue(erpo);
					#ifdef LOGGING
					if( CheckLogging() && (Logmode & (ERpoOffered | All)) ) {
						int begin = erpo->Begin + Origin;
						if( begin > task->SeqLength ) begin -= task->SeqLength;
						int end = erpo->End + Origin;
						if( end > task->SeqLength ) end -= task->SeqLength;
						fprintf(wlog, "%s// ERpo %s [%d,%d] - Blocked", record, erpo->Name, begin, end);
						filter = true;
					}
					#endif
				}
			}
			else if( agent->Type == TypeHolo ) {	// === Holo ===
				Holo* holo = (Holo*)agent;
				if( holo->Shift == holo->AbortRange ) {				// Aborting range reached
					if( holo->Countback-- ) {	// Move back
						if( holo->Strand )
							model->FreeRange(holo->End - holo->Shift + 1, holo->End);
						else
							model->FreeRange(holo->Begin, holo->Begin + holo->Shift - 1);
                  holo->ResetKor(circle); 
						#ifdef LOGGING
						if( CheckLogging() && (Logmode & All) ) {
							int begin = holo->Begin + Origin;
							if( begin > task->SeqLength ) begin -= task->SeqLength;
							int end = holo->End + Origin;
							if( end > task->SeqLength ) end -= task->SeqLength;
							fprintf(wlog, "%s// Holo %s back: [%d,%d], Count=%d ", 
								record, holo->Name, begin, end, holo->Countback);
							filter = true;
						}
						#endif
					}
					else {		// Convert Holoenzyme -> Kor
						if( holo->Strand )		// Free positions occupied by Sigma subunit
							model->FreeRange(holo->Begin, holo->Begin + holo->SigLength + holo->Shift - 1);
						else
							model->FreeRange(holo->End - holo->SigLength - holo->Shift + 1, holo->End);
						Kor* kor = new Kor(holo, circle);
						if( !kor ) { strncpy(therr, "Cannot create new Kor @412.", MSGLEN-1); throw therr; }
						//agent = kor;
                  model->PQueue.pop();
                  model->PQueue.push(kor);
						model->OccupyRange(kor->Begin, kor->End, kor);
						// Check if a gene is initiated
						#ifdef LOGGING
						if( (result = CheckGene(kor, circle))==NULL )
							{ strncpy(therr, "Cannot check Gene @421.", MSGLEN-1); throw therr; }
						#else
						CheckGene(kor, circle);
						#endif
						// Next loop with the same time, but only new Kor remains
						#ifdef LOGGING
						if( CheckLogging() && ( (Logmode & All) ||
							(ingene && (Logmode & GeneInitiated)) || (outgene && (Logmode & GeneTranscribed)) ) ) {
								int begin = kor->Begin + Origin;
								if( begin > task->SeqLength ) begin -= task->SeqLength;
								int end = kor->End + Origin;
								if( end > task->SeqLength ) end -= task->SeqLength;
								int tcenter = kor->Tcenter + Origin;
								if( tcenter > task->SeqLength ) tcenter -= task->SeqLength;
								fprintf(wlog, "%s// Holo %s became Kor %s %d [%d,%d]", 
									record, holo->Name, kor->Name, tcenter, begin, end);
								if( result ) fprintf(wlog, "%s", result);
								filter = true;
						}
						if( result ) { delete [] result; result = NULL; }
						#endif
						delete holo; holo = NULL;
					}
				}
				else {	// next move within aborting range
					int shift = holo->Shift;
					int begin, end;
					#ifdef LOGGING
					char* holoname = new char[AGENTNAMELEN];
					if( !holoname ) { strncpy(therr, "Cannot create new Holo name @449.", MSGLEN-1); throw therr; }
					strncpy(holoname, holo->Name, AGENTNAMELEN-1); holoname[AGENTNAMELEN-1] = 0;
					#endif
					if( holo->Strand ) {												// Try move to the right
						begin = holo->Begin + Origin;
						if( begin > task->SeqLength ) begin -= task->SeqLength;
						end = holo->End + Origin + 1;
						if( end > task->SeqLength ) end -= task->SeqLength;
						#ifdef LOGGING
						if( (result = MoveHolo(holo, holo->End + 1, circle))==NULL )
							{ strncpy(therr, "Cannot move Holo @460.", MSGLEN-1); throw therr; }
						#else
						MoveHolo(holo, holo->End + 1, circle);
						#endif
					}
					else {																// Try move to the left
						begin = holo->Begin + Origin - 1;
						if( begin > task->SeqLength ) begin -= task->SeqLength;
						if( begin <= 0 ) begin += task->SeqLength;
						end = holo->End + Origin;
						if( end > task->SeqLength ) end -= task->SeqLength;
						#ifdef LOGGING
						if( (result = MoveHolo(holo, holo->Begin - 1, circle))==NULL )
							{ strncpy(therr, "Cannot move Holo @475.", MSGLEN-1); throw therr; }
						#else
						MoveHolo(holo, holo->Begin - 1, circle);
						#endif
					}
					#ifdef LOGGING
					if( CheckLogging() && ( (Logmode & All) || (collision && (Logmode & Collision)) ) ) {
							fprintf(wlog, "%s// Holo %s try shift %d: [%d,%d] - %s", record, holoname, 
								shift, begin, end, (noholo || holo->Shift == shift) ? "Blocked" : "OK");
							if( result ) fprintf(wlog, "%s", result);
							filter = true;
					}				
					if( result ) { delete [] result; result = NULL; }
					delete [] holoname;
					#endif
				}
			}
			else if( agent->Type == TypeKor ) {		// === Kor ===
				Kor* kor = (Kor*)agent;
				int oldcenter = kor->Tcenter;
				int d = kor->Strand ? 1 : -1;
				int begin = kor->Begin;
				int end = kor->End; 
				int tcenter = kor->Tcenter;
				#ifdef LOGGING
				char* korname = new char[AGENTNAMELEN];
				if( !korname ) { strncpy(therr, "Cannot create new Kor name @500.", MSGLEN-1); throw therr; }
				strncpy(korname, kor->Name, AGENTNAMELEN-1); korname[AGENTNAMELEN-1] = 0;
				#endif
				if( kor->Strand ) { 
					if( circle || kor->Begin <= cpRivals::task->End ) {
						// Try move to the right
						#ifdef LOGGING
						if( (result = MoveKor(kor, kor->Begin, kor->End + 1, circle))==NULL )
							{ strncpy(therr, "Cannot move Kor @509.", MSGLEN-1); throw therr; }
						#else
						MoveKor(kor, kor->Begin, kor->End + 1, circle);
						#endif
					}
					#ifdef LOGGING
					else if(circle == 0) {
						result = new char[MSGLEN];
						if( !result ) { strncpy(therr, "Cannot create new Result @516.", MSGLEN-1); throw therr; }
						strncpy(result, ". End of the task", MSGLEN-1);
					}
					#endif
				}
				else {
					if( circle || kor->End >= cpRivals::task->Begin ) {
						// Try move to the left
						#ifdef LOGGING
						if( (result = MoveKor(kor, kor->End, kor->Begin - 1, circle))==NULL )
							{ strncpy(therr, "Cannot move Kor @527.", MSGLEN-1); throw therr; }
						#else
						MoveKor(kor, kor->End, kor->Begin - 1, circle);
						#endif
					}
					#ifdef LOGGING
					else if(circle == 0) {
						result = new char[MSGLEN];
						if( !result ) { strncpy(therr, "Cannot create new Result @534.", MSGLEN-1); throw therr; }
						strncpy(result, ". Begin of the task", MSGLEN-1);
					}
					#endif
				}
				#ifdef LOGGING
				if( CheckLogging() && ( (Logmode & All) || (collision && (Logmode & Collision)) ||
					(ingene && (Logmode & GeneInitiated)) || (outgene && (Logmode & GeneTranscribed)) ) ) {
						begin += Origin + d;
						if( begin > task->SeqLength ) begin -= task->SeqLength;
						if( begin <= 0 ) begin += task->SeqLength;
						end += Origin + d;
						if( end > task->SeqLength ) end -= task->SeqLength;
						if( end <= 0 ) end += task->SeqLength;
						tcenter += Origin + d;
						if( tcenter > task->SeqLength ) tcenter -= task->SeqLength;
						if( tcenter <= 0 ) tcenter += task->SeqLength;
						fprintf(wlog, "%s// Kor %s try shift %d [%d,%d] - %s", record, korname, 
							tcenter, begin, end, (nokor || kor->Tcenter == oldcenter) ? "Blocked" : "OK");
						if( result ) fprintf(wlog, "%s", result);
						filter = true;
				}
				if( result ) { delete [] result; result = NULL; }
				delete [] korname;
				#endif
					// Remove this Kor from the model at task/sequence edges
				if( circle == 0 && !nokor && (kor->Strand && (kor->Begin > task->End || kor->End >= 
					task->SeqLength - 1) || !kor->Strand && (kor->End < task->Begin || kor->Begin <= 0)) ) {
					model->FreeRange(kor->Begin, kor->End);
					//model->removeQueue( kor );
					//delete kor; 
               kor->Kill();
               kor = NULL;
					#ifdef LOGGING
					if( CheckLogging() && (Logmode & All) ) fprintf(wlog, ". Removed off the model.");
					#endif
				}
			}
			else if( agent->Type == TypeRpo ) {		// === Rpo ===
				Rpo* rpo = (Rpo*)agent;
				int oldcenter = rpo->Tcenter;
				int d = rpo->Strand ? 1 : -1;
				int begin = rpo->Begin;
				int end = rpo->End;
				int tcenter = rpo->Tcenter;
				#ifdef LOGGING
				char* rponame = new char[AGENTNAMELEN];
				if( !rponame ) { strncpy(therr, "Cannot create new Rpo name @583.", MSGLEN-1); throw therr; }
				strncpy(rponame, rpo->Name, AGENTNAMELEN-1); rponame[AGENTNAMELEN-1] = 0;
				#endif
				if( rpo->Strand ) {
					if( circle || rpo->Begin <= cpRivals::task->End ) {
						// Try move to the right
						#ifdef LOGGING
						if( (result = MoveRpo(rpo, rpo->Begin, rpo->End + 1, circle))==NULL )
							{ strncpy(therr, "Cannot move Rpo @592.", MSGLEN-1); throw therr; }
						#else
						MoveRpo(rpo, rpo->Begin, rpo->End + 1, circle);
						#endif
					}
					#ifdef LOGGING
					else if(circle == 0) {
						result = new char[MSGLEN];
						if( !result ) { strncpy(therr, "Cannot create new Result @599.", MSGLEN-1); throw therr; }
						strncpy(result, ". End of the task", MSGLEN-1);
					}
					#endif
				}
				else {
					if( circle || rpo->End >= cpRivals::task->Begin ) {
						// Try move to the left
						#ifdef LOGGING
						if( (result = MoveRpo(rpo, rpo->End, rpo->Begin - 1, circle))==NULL )
							{ strncpy(therr, "Cannot move Rpo @610.", MSGLEN-1); throw therr; }
						#else
						MoveRpo(rpo, rpo->End, rpo->Begin - 1, circle);
						#endif
					}
					#ifdef LOGGING
					else if(circle == 0) {
						result = new char[MSGLEN];
						if( !result ) { strncpy(therr, "Cannot create new Result @617.", MSGLEN-1); throw therr; }
						strncpy(result, ". Begin of the task", MSGLEN-1);
					}
					#endif
				}
				#ifdef LOGGING
				if( CheckLogging() && ( (Logmode & All) || (collision && (Logmode & Collision)) ||
					(ingene && (Logmode & GeneInitiated)) || (outgene && (Logmode & GeneTranscribed)) ) ) {
						begin += Origin + d;
						if( begin > task->SeqLength ) begin -= task->SeqLength;
						if( begin <= 0 ) begin += task->SeqLength;
						end += Origin + d;
						if( end > task->SeqLength ) end -= task->SeqLength;
						if( end <= 0 ) end += task->SeqLength;
						tcenter += Origin + d;
						if( tcenter > task->SeqLength ) tcenter -= task->SeqLength;
						if( tcenter <= 0 ) tcenter += task->SeqLength;
						fprintf(wlog, "%s// Rpo %s try shift %d [%d,%d] - %s", record, rponame, 
							tcenter, begin, end, (norpo || rpo->Tcenter == oldcenter) ? "Blocked" : "OK");
						if( result ) fprintf(wlog, "%s", result);
						filter = true;
				}
				if( result ) { delete [] result; result = NULL; }
				delete [] rponame;
				#endif
					// Remove this Rpo from the model at task/sequence edges
				if( circle == 0 && !norpo && (rpo->Strand && (rpo->Begin > task->End || rpo->End >= 
					task->SeqLength - 1) || !rpo->Strand && (rpo->End < task->Begin || rpo->Begin <= 0)) ) {
					model->FreeRange(rpo->Begin, rpo->End);
					//model->removeQueue( rpo );
					//delete rpo; 
               rpo->Kill();
               rpo = NULL;
					#ifdef LOGGING
					if( CheckLogging() && (Logmode & All) ) fprintf(wlog, ". Removed off the model.");
					#endif
				}
			}
			else if( agent->Type == TypeTerm ) {	// === Term ===
				Term* term = (Term*)agent;
				#ifdef LOGGING
				result = new char[FILEBUFLEN];
				if( !result ) { strncpy(therr, "Cannot create new Result @661.", MSGLEN-1); throw therr; }
				result[0] = 0;
				#endif
				term->Offer(); 
				// Terminator is bound irrespectively of whether its site is free or not.
				// The only exception is the terminator already bound (no repeated binding allowed).
				if( term->Active ) {			// skip repeated terminator
               model->removeQueue(term);
					term->Touch();
               model->addQueue(term);
				}
				else {							// Term appears
					term->Bind();
					term->Active = true;
					#ifdef LOGGING
					if( CheckLogging() && (Logmode & (ReprBound | ReprOffered | All)) ) {
						int begin = term->Begin + Origin;
						if( begin > task->SeqLength ) begin -= task->SeqLength;
						int end = term->End + Origin;
						if( end > task->SeqLength ) end -= task->SeqLength;
						fprintf(wlog, "%s// Terminator %s#%d bound [%d,%d]", record, term->Name, term->Bound, begin, end);
						filter = true;
					}
					#endif
					// bind and execute established rules for all polymerases occupying the site (if any)
					bool RemoveTermAfter = false;
					int repeat = term->End - term->Begin + 1;
					if(repeat < 0) repeat += circle;
					for( int k1 = 0; k1 < repeat; k1++ ) {
						int k = term->Begin + k1;
						if(circle && k >= circle) k -= circle;
						Agent* contragent = model->Hold[k];
						if( contragent == NULL || contragent->Strand != term->Strand ) continue;
						if( contragent->Type == TypeKor && term->SenseKor ) {
							collision = true;
							Kor* kor = (Kor*)contragent;
							int korrule = kor->Rule;
							if( cpRivals::config.DAT[korrule] ) {			// delete Kor
								#ifdef LOGGING
								sprintf(tmp, "%s. Remove %s", result, kor->Name);
								strcpy(result, tmp);		// Possible buffer overrun!
								#endif
								model->FreeRange(kor->Begin, kor->End);
								//model->removeQueue(kor);
								//delete kor; 
                        kor->Kill();
                        kor = NULL;
							}
							if( cpRivals::config.DPT[korrule] )				// Delete terminator
								RemoveTermAfter = true;
						}
						else if( contragent->Type == TypeRpo && term->SenseRpo ) {
							collision = true;
							Rpo* rpo = (Rpo*)contragent;
							int rporule = rpo->Rule;
							if( cpRivals::config.DAT[rporule] ) {			// delete Rpo
								#ifdef LOGGING
								sprintf(tmp, "%s. Remove %s", result, rpo->Name);
								strcpy(result, tmp);		// Possible buffer overrun!
								#endif
								model->FreeRange(rpo->Begin, rpo->End);
								//model->removeQueue(rpo);
								//delete rpo; 
                        rpo->Kill();
                        rpo = NULL;
							}
							if( cpRivals::config.DPT[rporule] ) 			// Delete terminator
								RemoveTermAfter = true;
						}
					}
					if( RemoveTermAfter ) {
						#ifdef LOGGING
						sprintf(tmp, "%s. Remove terminator %s#%d", result, term->Name, term->Bound);
						strcpy(result, tmp);		// Possible but improbable buffer overrun!
						#endif
						term->Active = false;
					}
               model->removeQueue(term);
					term->Touch();
               model->addQueue(term);
					#ifdef LOGGING
					if( CheckLogging() && (Logmode & (ReprBound | ReprOffered | All)) ) {
						fprintf(wlog, "%s", result);
						filter = true;
					}
					#endif
				}
				#ifdef LOGGING
				if( result ) { delete [] result; result = NULL; }
				#endif
			}
			else { strncpy(therr, "Incorrect agent type encountered in a queue.", MSGLEN-1); throw therr; }
			
			#ifdef LOGGING
			if( CheckLogging() && ((Logmode & All) || filter) ) {
				if( filter == false ) fprintf(wlog, "%s\n", record);
				else fprintf(wlog, "\n"); 
				fflush(wlog);
			}
			#endif
		}
		delete [] msg;
		if( model ) { delete model; model = NULL; }
		cpRivals::model = NULL;
		#ifdef LOGGING
		if( result ) { delete [] result; result = NULL; } 
		delete [] record;											// free record
		#endif
		#ifdef LOGMEMORY
		cpRivals::fLogMemory = 0;			// memory logging OFF
		#endif
		delete [] tmp;
		delete [] therr;
		return 0;
	}
	catch (char *err) {
		char *msg = new char[MSGLEN];
		sprintf(msg, "[%04d] %s\n", cpRivals::myid, err);
		if( cpRivals::myid == 0 ) { fprintf(stderr, "%s", msg); fflush(stderr); }
        #ifdef PARALLEL
		else if( cpRivals::collect ) 
			MPI::COMM_WORLD.Send(msg, (int)strlen(msg)+1, MPI::CHAR, root, cpRivals::tagInfo);
        #endif
		delete [] msg;
		if( model ) { delete model; model = NULL; }
		cpRivals::model = NULL;
		#ifdef LOGGING
		if( result ) { delete [] result; result = NULL; } 
		delete [] record;											// free record
		#endif
		#ifdef LOGMEMORY
		cpRivals::fLogMemory = 0;			// memory logging OFF
		#endif
        #ifdef PARALLEL
		if( cancel ) MPI::COMM_WORLD.Send(tmp, 1, MPI::CHAR, root, tagAbortRun);
        #endif
		delete [] tmp;
		delete [] therr;
		return cancel ? 1 : -1;
	}
}

// Check if any gene is initiated or transcribed
// #ifdef LOGGING: Return ptr to result string or NULL (errors)
// #else Return void
#ifdef LOGGING
char* cpRivals::CheckGene(Agent* poly, int circle) {
	char* result = new char[MSGLEN];
	char* tmp = new char[MSGLEN];
	if( !result || !tmp ) return NULL;
	result[0] = 0;
#else
void cpRivals::CheckGene(Agent* poly, int circle) {
#endif
	Kor* kor = (Kor*)poly;
	Rpo* rpo = (Rpo*)poly;
	cpRivals::ingene = false; cpRivals::outgene = false;
	int n = cpRivals::task->NumAgents;
	if( poly->Strand ) {								// Main strand
		for( int i=0; i<n; i++ ) {
			Agent* agent = cpRivals::task->getAgent(i);
			if( agent->Type != TypeGene || !agent->Enabled || !agent->Strand ) 
				continue;
			Gene* gene = (Gene*)agent;
			if( cpRivals::config.CountCenter ) {		// Count with regard to Tcenter
				if( poly->Type == TypeKor ) {						// Kor
					if( kor->Tcenter == gene->End + 1 || 
						(circle && gene->End + 1 == circle && kor->Tcenter == 0) ) {
						gene->Leave(); cpRivals::outgene = true;
						gene->TransP ++;
						#ifdef LOGGING
						sprintf(tmp, "%s. Gene %s transcribed #%d", result, gene->Name, gene->Transcribed);
						strcpy(result, tmp);
						#endif
					}
					if( kor->Tcenter == gene->Begin ) {
						gene->Enter(); cpRivals::ingene = true;
						gene->InitP ++;
						#ifdef LOGGING
						sprintf(tmp, "%s. Gene %s entered #%d", result, gene->Name, gene->Initiated);
						strcpy(result, tmp);
						#endif
					}
               if( kor->Tcenter < gene->Begin && !cpRivals::model->GeneWrapM )
						break;	// because genes in the task are sorted along a strand
				}
				else {															// Rpo
					if( rpo->Tcenter == gene->End + 1 ||
						(circle && gene->End + 1 == circle && rpo->Tcenter == 0) ) {
						gene->Leave(); cpRivals::outgene = true;
						gene->TransN ++;
						#ifdef LOGGING
						sprintf(tmp, "%s. Gene %s transcribed #%d", result, gene->Name, gene->Transcribed);
						strcpy(result, tmp);
						#endif
					}
					if( rpo->Tcenter == gene->Begin ) {
						gene->Enter(); cpRivals::ingene = true;
						gene->InitN ++;
						#ifdef LOGGING
						sprintf(tmp, "%s. Gene %s entered #%d", result, gene->Name, gene->Initiated);
						strcpy(result, tmp);
						#endif
					}
					if( rpo->Tcenter < gene->Begin && !cpRivals::model->GeneWrapM )
						break;	// because genes in the task are sorted along a strand
				}
			}
			else {												// Count with regard to entire polymerase	
				if( poly->Begin == gene->End + 1 ||
					(circle && gene->End + 1 == circle && poly->Begin == 0) ) {
					gene->Leave(); cpRivals::outgene = true;
					if( poly->Type == TypeKor )		gene->TransP ++;
					else if( poly->Type == TypeRpo )	gene->TransN ++;
					#ifdef LOGGING
					sprintf(tmp, "%s. Gene %s transcribed #%d", result, gene->Name, gene->Transcribed);
					strcpy(result, tmp);
					#endif
				}
				if( poly->End == gene->Begin ) {
					gene->Enter(); cpRivals::ingene = true;
					if( poly->Type == TypeKor )		gene->InitP ++;
					else if( poly->Type == TypeRpo )	gene->InitN ++;
					#ifdef LOGGING
					sprintf(tmp, "%s. Gene %s entered #%d", result, gene->Name, gene->Initiated);
					strcpy(result, tmp);
					#endif
				}
				if( poly->End < gene->Begin && !cpRivals::model->GeneWrapM )
					break;	// because genes in the task are sorted along a strand
			}
		}
	}
	else {												// Complementary strand
		for( int i=n-1; i>=0; i-- ) {
			Agent* agent = cpRivals::task->getAgent(i);
			if( agent->Type != TypeGene || !agent->Enabled || agent->Strand ) 
				continue;
			Gene* gene = (Gene*)agent;
			if( cpRivals::config.CountCenter ) {		// Count with regard to Tcenter
				if( poly->Type == TypeKor ) {						// Kor
					if( kor->Tcenter == gene->Begin - 1 ||
						(circle && gene->Begin == 0 && kor->Tcenter == circle - 1) ) {
						gene->Leave(); cpRivals::outgene = true;
						gene->TransP ++;
						#ifdef LOGGING
						sprintf(tmp, "%s. Gene %s transcribed #%d", result, gene->Name, gene->Transcribed);
						strcpy(result, tmp);
						#endif
					}
					if( kor->Tcenter == gene->End ) {
						gene->Enter(); cpRivals::ingene = true;
						gene->InitP ++;
						#ifdef LOGGING
						sprintf(tmp, "%s. Gene %s entered #%d", result, gene->Name, gene->Initiated);
						strcpy(result, tmp);
						#endif
					}
					if( kor->Tcenter > gene->End && !cpRivals::model->GeneWrapC )
						break;	// because genes in the task are sorted along a strand
				}
				else {															// Rpo
					if( rpo->Tcenter == gene->Begin - 1 ||
						(circle && gene->Begin == 0 && rpo->Tcenter == circle - 1) ) {
						gene->Leave(); cpRivals::outgene = true;
						gene->TransN ++;
						#ifdef LOGGING
						sprintf(tmp, "%s. Gene %s transcribed #%d", result, gene->Name, gene->Transcribed);
						strcpy(result, tmp);
						#endif
					}
					if( rpo->Tcenter == gene->End ) {
						gene->Enter(); cpRivals::ingene = true;
						gene->InitN ++;
						#ifdef LOGGING
						sprintf(tmp, "%s. Gene %s entered #%d", result, gene->Name, gene->Initiated);
						strcpy(result, tmp);
						#endif
					}
					if( rpo->Tcenter > gene->End && !cpRivals::model->GeneWrapC )
						break;	// because genes in the task are sorted along a strand
				}
			}
			else {												// Count with regard to entire polymerase	
				if( poly->End == gene->Begin - 1 ||
					(circle && gene->Begin == 0 && poly->End == circle - 1) ) {
					gene->Leave(); cpRivals::outgene = true;
					if( poly->Type == TypeKor )		gene->TransP ++;
					else if( poly->Type == TypeRpo )	gene->TransN ++;
					#ifdef LOGGING
					sprintf(tmp, "%s. Gene %s transcribed #%d", result, gene->Name, gene->Transcribed);
					strcpy(result, tmp);
					#endif
				}
				if( poly->Begin == gene->End ) {
					gene->Enter(); cpRivals::ingene = true;
					if( poly->Type == TypeKor )		gene->InitP ++;
					else if( poly->Type == TypeRpo )	gene->InitN ++;
					#ifdef LOGGING
					sprintf(tmp, "%s. Gene %s entered #%d", result, gene->Name, gene->Initiated);
					strcpy(result, tmp);
					#endif
				}
				if( poly->Begin > gene->End && !cpRivals::model->GeneWrapC )
					break;	// because genes in the task are sorted along a strand
			}
		}
	}
	#ifdef LOGGING
	delete [] tmp;
	return result;
	#endif
}

// Check if a terminator is entered. Returns pointer to it or NULL.
Agent* cpRivals::CheckTerm(Agent* poly, int circle) {
	if( !cpRivals::model->HasTerm ) return NULL;
	Agent* agent = NULL;
	cpRivals::collision = false;
	int n = cpRivals::task->NumAgents;
	if( poly->Strand ) {								// Main strand
		for( int i=0; i<n; i++ ) {
			agent = cpRivals::task->getAgent(i);
			if( agent->Type != TypeTerm || !agent->Enabled || !agent->Strand ) 
				continue;
			Term* term = (Term*)agent;
			if( !term->Active || poly->Type==TypeKor && !term->SenseKor || poly->Type==TypeRpo && !term->SenseRpo ) 
				continue;
			if( poly->End == term->Begin ) {			// active Term encountered
				cpRivals::collision = true; 
				return term;
			}
			if( poly->End < term->Begin && circle == 0 ) break;
		}
	}
	else {												// Complement strand
		for( int i=n-1; i>=0; i-- ) {
			agent = cpRivals::task->getAgent(i);
			if( agent->Type != TypeTerm || !agent->Enabled || agent->Strand ) 
				continue;
			Term* term = (Term*)agent;
			if( !term->Active || poly->Type==TypeKor && !term->SenseKor || poly->Type==TypeRpo && !term->SenseRpo ) 
				continue;
			if( poly->Begin == term->End ) {			// active Term encountered
				cpRivals::collision = true; 
				return term;
			}
			if( poly->Begin > term->End && circle == 0 ) break;
		}
	}
	return NULL;
}

// Make a holoenzyme move
// #ifdef LOGGING: Return pointer to the result string or NULL (errors)
// #else Return void
#ifdef LOGGING
char* cpRivals::MoveHolo(Holo* holo, int ToPosition, int circle) {
	Model* model = cpRivals::model;
	char* result = new char[MSGLEN];
	char* tmp = new char[MSGLEN];
	if( !model || !result || !tmp ) return NULL;
	result[0] = 0;
#else
void cpRivals::MoveHolo(Holo* holo, int ToPosition, int circle) {
	Model* model = cpRivals::model;
	if( !model ) return;
#endif
	if(circle) {	// Check & adjust ToPosition
		if(ToPosition >= circle) ToPosition -= circle;
		if(ToPosition < 0) ToPosition += circle;
	}
	cpRivals::noholo = false;
	cpRivals::collision = false;
	Agent* contragent = CheckTerm(holo, circle);
	if( contragent ) {									// Terminator encountered
		cpRivals::collision = true;
		Term* term = (Term*)contragent;
		if( cpRivals::config.DPT[holo->Rule] ) {							// Delete terminator
			#ifdef LOGGING
			sprintf(tmp, "%s. Remove terminator %s#%d", result, term->Name, term->Bound);
			strcpy(result, tmp);
			#endif
			term->Active = false;
		}
		if( cpRivals::config.DAT[holo->Rule] ) {							// Delete itself
			#ifdef LOGGING
			sprintf(tmp, "%s. Remove %s", result, holo->Name);
			strcpy(result, tmp);
			#endif
			model->FreeRange(holo->Begin, holo->End);
			model->removeQueue(holo);
			cpRivals::noholo = true;
			delete holo; holo = NULL;
			#ifdef LOGGING
			delete [] tmp;
			return result;
			#else
			return;
			#endif
		}
		else if( cpRivals::config.SAT[holo->Rule] ) {					// Pass move
         model->removeQueue(holo);
			holo->Touch();
         model->addQueue(holo);
			#ifdef LOGGING
			delete [] tmp;
			return result;
			#else
			return;
			#endif
		}
	}
	contragent = model->Hold[ToPosition];
	if( !contragent ) {											// No rivals, shift
		model->Hold[ToPosition] = holo;
      holo->ShiftKor(circle);
      model->removeQueue(holo);
		holo->Touch();
      model->addQueue(holo);
	}
	else if( contragent->Type == TypeRepr ) {		      // Repressor encountered
		Repr* repr = (Repr*)contragent;
		if( cpRivals::config.DPR[holo->Rule] ) {							// Delete repressor
			#ifdef LOGGING
			sprintf(tmp, "%s. Remove repressor %s#%d", result, repr->Name, repr->Bound);
			strcpy(result, tmp);
			#endif
			model->FreeRange(repr->Begin, repr->End);
		}
		if( cpRivals::config.DAR[holo->Rule] ) {							// Delete itself
			#ifdef LOGGING
			sprintf(tmp, "%s. Remove %s", result, holo->Name);
			strcpy(result, tmp);
			#endif
			model->FreeRange(holo->Begin, holo->End);
			model->removeQueue(holo);
			cpRivals::noholo = true;
			delete holo; holo = NULL;
		}
		else if( ! cpRivals::config.SAR[holo->Rule] ) {					// + Shift
			model->Hold[ToPosition] = holo;
         holo->ShiftKor(circle);
         model->removeQueue(holo);
			holo->Touch();
         model->addQueue(holo);
		}
		else {																		// Pass move
         model->removeQueue(holo);
			holo->Touch();
         model->addQueue(holo);
		}
		cpRivals::collision = true;
	}
	else if( contragent->Strand == holo->Strand ) {		// A rival in the same direction
		int carule = contragent->Rule;
		if( cpRivals::config.DPP[holo->Rule][carule] ) {			// Delete contragent
			#ifdef LOGGING
			sprintf(tmp, "%s. Remove %s", result, contragent->Name);
			strcpy(result, tmp);
			#endif
			model->FreeRange(contragent->Begin, contragent->End);
			//model->removeQueue(contragent);
			//delete contragent; 
         contragent->Kill();
         contragent = NULL;
		}
		if( cpRivals::config.DAP[holo->Rule][carule] ) {			// Delete itself
			#ifdef LOGGING
			sprintf(tmp, "%s. Remove %s", result, holo->Name);
			strcpy(result, tmp);
			#endif
			model->FreeRange(holo->Begin, holo->End);
			model->removeQueue(holo);
			cpRivals::noholo = true;
			delete holo; holo = NULL;
		}
		else if( ! cpRivals::config.SAP[holo->Rule][carule] ) {	// + Shift
			model->Hold[ToPosition] = holo;
         holo->ShiftKor(circle);
         model->removeQueue(holo);
			holo->Touch();
         model->addQueue(holo);
		}
		else {																		// Pass move
         model->removeQueue(holo);
			holo->Touch();
         model->addQueue(holo);
		}
		cpRivals::collision = true;
	}
	else {															// A rival in the opposite direction
		int carule = contragent->Rule;
		if( cpRivals::config.DPC[holo->Rule][carule] ) {			// Delete contragent
			#ifdef LOGGING
			sprintf(tmp, "%s. Remove %s}", result, contragent->Name);
			strcpy(result, tmp);
			#endif
			model->FreeRange(contragent->Begin, contragent->End);
			//model->removeQueue(contragent);
			//delete contragent; 
         contragent->Kill();
         contragent = NULL;
		}
		if( cpRivals::config.DAC[holo->Rule][carule] ) {			// Delete itself
			#ifdef LOGGING
			sprintf(tmp, "%s. Remove %s", result, holo->Name);
			strcpy(result, tmp);
			#endif
			model->FreeRange(holo->Begin, holo->End);
			model->removeQueue(holo);
			cpRivals::noholo = true;
			delete holo; holo = NULL;
		}
		else if( ! cpRivals::config.SAC[holo->Rule][carule] ) {	// + Shift
			model->Hold[ToPosition] = holo;
         holo->ShiftKor(circle);
         model->removeQueue(holo);
			holo->Touch();
         model->addQueue(holo);
		}
		else {																	// Pass move
         model->removeQueue(holo);
			holo->Touch();
         model->addQueue(holo);
		}
		cpRivals::collision = true;
	}
	#ifdef LOGGING
	delete [] tmp;
	return result;
	#endif
}

// Make a Kor move
// #ifdef LOGGING: Return pointer to the result string or NULL (errors)
// #else Return void
#ifdef LOGGING
char* cpRivals::MoveKor(Kor* kor, int FromPosition, int ToPosition, int circle ) {
	Model* model = cpRivals::model;
	char* result = new char[MSGLEN];
	char* tmp = new char[MSGLEN];
	if( !model || !result || !tmp ) return NULL;
	result[0] = 0;
#else
void cpRivals::MoveKor(Kor* kor, int FromPosition, int ToPosition, int circle ) {
	Model* model = cpRivals::model;
	if( !model ) return;
#endif
	if(circle) {	// Check & adjust FromPosition,ToPosition
		if(FromPosition >= circle) FromPosition -= circle;
		if(FromPosition < 0) FromPosition += circle;
		if(ToPosition >= circle) ToPosition -= circle;
		if(ToPosition < 0) ToPosition += circle;
	}
	cpRivals::nokor = false;
	cpRivals::collision = false;
	Agent* contragent = CheckTerm(kor, circle);
	if( contragent ) {									// Terminator encountered
		cpRivals::collision = true;
		Term* term = (Term*)contragent;
		if( cpRivals::config.DPT[kor->Rule] ) {							// Delete terminator
			#ifdef LOGGING
			sprintf(tmp, "%s. Remove terminator %s#%d", result, term->Name, term->Bound);
			strcpy(result, tmp);
			#endif
			term->Active = false;
		}
		if( cpRivals::config.DAT[kor->Rule] ) {							// Delete itself
			#ifdef LOGGING
			sprintf(tmp, "%s. Remove %s", result, kor->Name);
			strcpy(result, tmp);
			#endif
			model->FreeRange(kor->Begin, kor->End);
			model->removeQueue(kor);
			cpRivals::nokor = true;
			delete kor; kor = NULL;
			#ifdef LOGGING
			delete [] tmp;
			return result;
			#else
			return;
			#endif
		}
		else if( cpRivals::config.SAT[kor->Rule] ) {						// Future move
         model->removeQueue(kor);
			kor->Touch();
         model->addQueue(kor);
			#ifdef LOGGING
			delete [] tmp;
			return result;
			#else
			return;
			#endif
		}
	}
	contragent = model->Hold[ToPosition];
	if( !contragent ) {													// No rivals, shift
		model->Hold[FromPosition] = NULL;
		model->Hold[ToPosition] = kor;
		kor->Shift(circle);
      model->removeQueue(kor);
		kor->Touch();
      model->addQueue(kor);
		#ifdef LOGGING
		char* res1 = CheckGene(kor, circle);
		if( res1 ) { strcat(result, res1); delete [] res1; res1 = NULL; }
		else return NULL;
		#else
		CheckGene(kor, circle);
		#endif
	}
	else if( contragent->Type == TypeRepr ) {						// Repressor encountered
		Repr* repr = (Repr*)contragent;
		if(repr->Pass(kor->Strand)) {										// "Pass" scenario
			#ifdef LOGGING
			sprintf(tmp, "%s. Pass Kor removing repressor %s#%d", result, repr->Name, repr->Bound);
			strcpy(result, tmp);
			#endif
			model->FreeRange(repr->Begin, repr->End);							// Delete repressor
			model->Hold[FromPosition] = NULL;									// Shift Kor
			model->Hold[ToPosition] = kor;
			kor->Shift(circle);
         model->removeQueue(kor);
			kor->Touch();
         model->addQueue(kor);
			#ifdef LOGGING
			char* res1 = CheckGene(kor, circle);
			if( res1 ) { strcat(result, res1); delete [] res1; res1 = NULL; }
			else return NULL;
			#else
			CheckGene(kor, circle);
			#endif
		}
		else {																	// "Terminate" scenario
			if( cpRivals::config.DPR[kor->Rule] ) {							// Delete repressor
				#ifdef LOGGING
				sprintf(tmp, "%s. Remove repressor %s#%d", result, repr->Name, repr->Bound);
				strcpy(result, tmp);
				#endif
				model->FreeRange(repr->Begin, repr->End);
			}
			if( cpRivals::config.DAR[kor->Rule] ) {							// Delete itself
				#ifdef LOGGING
				sprintf(tmp, "%s. Remove %s", result, kor->Name);
				strcpy(result, tmp);
				#endif
				if(kor->Strand) repr->Mterminated++;
				else repr->Cterminated++;
				model->FreeRange(kor->Begin, kor->End);
				model->removeQueue(kor);
				cpRivals::nokor = true;
				delete kor; kor = NULL;
			}
			else if( ! cpRivals::config.SAR[kor->Rule] ) {					// Shift
				model->Hold[FromPosition] = NULL;
				model->Hold[ToPosition] = kor;
				kor->Shift(circle);
            model->removeQueue(kor);
				kor->Touch();
            model->addQueue(kor);
				#ifdef LOGGING
				char* res1 = CheckGene(kor, circle);
				if( res1 ) { strcat(result, res1); delete [] res1; res1 = NULL; }
				else return NULL;
				#else
				CheckGene(kor, circle);
				#endif
			}
			else {																		// Future move
            model->removeQueue(kor);
				kor->Touch();
            model->addQueue(kor);
			}
		}
		cpRivals::collision = true;
	}
	else if( contragent->Strand == kor->Strand ) {				// A non-repressor rival in the same direction
		int carule = contragent->Rule;
		if( cpRivals::config.DPP[kor->Rule][carule] ) {				// Delete contragent
			#ifdef LOGGING
			sprintf(tmp, "%s. Remove %s", result, contragent->Name);
			strcpy(result, tmp);
			#endif
			model->FreeRange(contragent->Begin, contragent->End);
			//model->removeQueue(contragent);
			//delete contragent; 
         contragent->Kill();
         contragent = NULL;
		}
		if( cpRivals::config.DAP[kor->Rule][carule] ) {				// Delete itself
			#ifdef LOGGING
			sprintf(tmp, "%s. Remove %s", result, kor->Name);
			strcpy(result, tmp);
			#endif
			model->FreeRange(kor->Begin, kor->End);
			model->removeQueue(kor);
			cpRivals::nokor = true;
			delete kor; kor = NULL;
		}
		else if( ! cpRivals::config.SAP[kor->Rule][carule] ) {	// Shift
			model->Hold[FromPosition] = NULL;
			model->Hold[ToPosition] = kor;
			kor->Shift(circle);
         model->removeQueue(kor);
			kor->Touch();
         model->addQueue(kor);
			#ifdef LOGGING
			char* res1 = CheckGene(kor, circle);
			if( res1 ) { strcat(result, res1); delete [] res1; res1 = NULL; }	
			else return NULL;
			#else
			CheckGene(kor, circle);
			#endif
		}
		else {																	// Future move
         model->removeQueue(kor);
			kor->Touch();
         model->addQueue(kor);
		}
		cpRivals::collision = true;
	}
	else {																	// A non-repressor rival in the opposite direction
		int carule = contragent->Rule;
		if( cpRivals::config.DPC[kor->Rule][carule] ) {				// Delete contragent
			#ifdef LOGGING
			sprintf(tmp, "%s. Remove %s", result, contragent->Name);
			strcpy(result, tmp);
			#endif
			model->FreeRange(contragent->Begin, contragent->End);
			//model->removeQueue(contragent);
			//delete contragent; 
         contragent->Kill();
         contragent = NULL;
		}
		if( cpRivals::config.DAC[kor->Rule][carule] ) {				// Delete itself
			#ifdef LOGGING
			sprintf(tmp, "%s. Remove %s", result, kor->Name);
			strcpy(result, tmp);
			#endif
			model->FreeRange(kor->Begin, kor->End);
			model->removeQueue(kor);
			cpRivals::nokor = true;
			delete kor; kor = NULL;
		}
		else if( ! cpRivals::config.SAC[kor->Rule][carule] ) {	// Shift
			model->Hold[FromPosition] = NULL;
			model->Hold[ToPosition] = kor;
			kor->Shift(circle);
         model->removeQueue(kor);
			kor->Touch();
         model->addQueue(kor);
			#ifdef LOGGING
			char* res1 = CheckGene(kor, circle);
			if( res1 ) { strcat(result, res1); delete [] res1; res1 = NULL; }	
			else return NULL;
			#else
			CheckGene(kor, circle);
			#endif
		}
		else {																	// Future move
         model->removeQueue(kor);
			kor->Touch();
         model->addQueue(kor);
		}
		cpRivals::collision = true;
	}
	#ifdef LOGGING
	delete [] tmp;
	return result;
	#endif
}

// Make an Rpo move
// #ifdef LOGGING: Return pointer to the result string or NULL (errors)
// #else Return void
#ifdef LOGGING
char* cpRivals::MoveRpo(Rpo* rpo, int FromPosition, int ToPosition, int circle ) {
	Model* model = cpRivals::model;
	char* result = new char[MSGLEN];
	char* tmp = new char[MSGLEN];
	if( !model || !result || !tmp ) return NULL;
	result[0] = 0;
#else
void cpRivals::MoveRpo(Rpo* rpo, int FromPosition, int ToPosition, int circle ) {
	Model* model = cpRivals::model;
	if( !model ) return;
#endif
	if(circle) {	// Check & adjust FromPosition,ToPosition
		if(FromPosition >= circle) FromPosition -= circle;
		if(FromPosition < 0) FromPosition += circle;
		if(ToPosition >= circle) ToPosition -= circle;
		if(ToPosition < 0) ToPosition += circle;
	}
	cpRivals::norpo = false;
	cpRivals::collision = false;
	Agent* contragent = CheckTerm(rpo, circle);
	if( contragent ) {									// Terminator encountered
		cpRivals::collision = true;
		Term* term = (Term*)contragent;
		if( cpRivals::config.DPT[rpo->Rule] ) {							// Delete terminator
			#ifdef LOGGING
			sprintf(tmp, "%s. Remove terminator %s#%d", result, term->Name, term->Bound);
			strcpy(result, tmp);
			#endif
			term->Active = false;
		}
		if( cpRivals::config.DAT[rpo->Rule] ) {							// Delete itself
			#ifdef LOGGING
			sprintf(tmp, "%s. Remove %s", result, rpo->Name);
			strcpy(result, tmp);
			#endif
			model->FreeRange(rpo->Begin, rpo->End);
			model->removeQueue(rpo);
			cpRivals::norpo = true;
			delete rpo; rpo = NULL;
			#ifdef LOGGING
			delete [] tmp;
			return result;
			#else
			return;
			#endif
		}
		else if( cpRivals::config.SAT[rpo->Rule] ) {						// Future move
         model->removeQueue(rpo);
			rpo->Touch();
         model->removeQueue(rpo);
			#ifdef LOGGING
			delete [] tmp;
			return result;
			#else
			return;
			#endif
		}
	}
	contragent = model->Hold[ToPosition];
	if( !contragent ) {													// No rivals, shift
		model->Hold[FromPosition] = NULL;
		model->Hold[ToPosition] = rpo;
		rpo->Shift(circle);
      model->removeQueue(rpo);
		rpo->Touch();
      model->addQueue(rpo);
		#ifdef LOGGING
		char* res1 = CheckGene(rpo, circle);
		if( res1 ) { strcat(result, res1); delete [] res1; res1 = NULL; }
		else return NULL;
		#else
		CheckGene(rpo, circle);
		#endif
	}
	else if( contragent->Type == TypeRepr ) {						// Repressor encountered
		Repr* repr = (Repr*)contragent;
		if(repr->Pass(rpo->Strand)) {										// "Pass" scenario
			#ifdef LOGGING
			sprintf(tmp, "%s. Pass Rpo removing repressor %s#%d", result, repr->Name, repr->Bound);
			strcpy(result, tmp);
			#endif
			model->FreeRange(repr->Begin, repr->End);							// Delete repressor
			model->Hold[FromPosition] = NULL;									// Shift Rpo
			model->Hold[ToPosition] = rpo;
			rpo->Shift(circle);
         model->removeQueue(rpo);
			rpo->Touch();
         model->addQueue(rpo);
			#ifdef LOGGING
			char* res1 = CheckGene(rpo, circle);
			if( res1 ) { strcat(result, res1); delete [] res1; res1 = NULL; }
			else return NULL;
			#else
			CheckGene(rpo, circle);
			#endif
		}
		else {																	// "Terminate" scenario
			if( cpRivals::config.DPR[rpo->Rule] ) {							// Delete repressor
				#ifdef LOGGING
				sprintf(tmp, "%s. Remove repressor %s#%d", result, repr->Name, repr->Bound);
				strcpy(result, tmp);
				#endif
				model->FreeRange(repr->Begin, repr->End);
			}
			if( cpRivals::config.DAR[rpo->Rule] ) {							// Delete itself
				#ifdef LOGGING
				sprintf(tmp, "%s. Remove %s", result, rpo->Name);
				strcpy(result, tmp);
				#endif
				if(rpo->Strand) repr->Mterminated++;
				else repr->Cterminated++;
				model->FreeRange(rpo->Begin, rpo->End);
				model->removeQueue(rpo);
				cpRivals::norpo = true;
				delete rpo; rpo = NULL;
			}
			else if( ! cpRivals::config.SAR[rpo->Rule] ) {					// Shift
				model->Hold[FromPosition] = NULL;
				model->Hold[ToPosition] = rpo;
				rpo->Shift(circle);
            model->removeQueue(rpo);
				rpo->Touch();
            model->addQueue(rpo);
				#ifdef LOGGING
				char* res1 = CheckGene(rpo, circle);
				if( res1 ) { strcat(result, res1); delete [] res1; res1 = NULL; }
				else return NULL;
				#else
				CheckGene(rpo, circle);
				#endif
			}
			else {																		// Future move
            model->removeQueue(rpo);
				rpo->Touch();
            model->addQueue(rpo);
			}
		}
		cpRivals::collision = true;
	}
	else if( contragent->Strand == rpo->Strand ) {				// A non-repressor rival in the same direction
		int carule = contragent->Rule;
		if( cpRivals::config.DPP[rpo->Rule][carule] ) {					// Delete contragent
			#ifdef LOGGING
			sprintf(tmp, "%s. Remove %s", result, contragent->Name);
			strcpy(result, tmp);
			#endif
			model->FreeRange(contragent->Begin, contragent->End);
			//model->removeQueue(contragent);
			//delete contragent; 
         contragent->Kill();
         contragent = NULL;
		}
		if( cpRivals::config.DAP[rpo->Rule][carule] ) {					// Delete itself
			#ifdef LOGGING
			sprintf(tmp, "%s. Remove %s", result, rpo->Name);
			strcpy(result, tmp);
			#endif
			model->FreeRange(rpo->Begin, rpo->End);
			model->removeQueue(rpo);
			cpRivals::norpo = true;
			delete rpo; rpo = NULL;
		}
		else if( ! cpRivals::config.SAP[rpo->Rule][carule] ) {		// Shift
			model->Hold[FromPosition] = NULL;
			model->Hold[ToPosition] = rpo;
			rpo->Shift(circle);
         model->removeQueue(rpo);
			rpo->Touch();
         model->addQueue(rpo);
			#ifdef LOGGING
			char* res1 = CheckGene(rpo, circle);
			if( res1 ) { strcat(result, res1); delete [] res1; res1 = NULL; }
			else return NULL;
			#else
			CheckGene(rpo, circle);
			#endif
		}
		else {																		// Future move
         model->removeQueue(rpo);
			rpo->Touch();
         model->addQueue(rpo);
		}
		cpRivals::collision = true;
	}
	else {																	// A non-repressor rival in the opposite direction
		int carule = contragent->Rule;
		if( cpRivals::config.DPC[rpo->Rule][carule] ) {					// Delete contragent
			#ifdef LOGGING
			sprintf(tmp, "%s. Remove %s", result, contragent->Name);
			strcpy(result, tmp);
			#endif
			model->FreeRange(contragent->Begin, contragent->End);
			//model->removeQueue(contragent);
			//delete contragent; 
         contragent->Kill();
         contragent = NULL;
		}
		if( cpRivals::config.DAC[rpo->Rule][carule] ) {					// Delete itself
			#ifdef LOGGING
			sprintf(tmp, "%s. Remove %s", result, rpo->Name);
			strcpy(result, tmp);
			#endif
			model->FreeRange(rpo->Begin, rpo->End);
			model->removeQueue(rpo);
			cpRivals::norpo = true;
			delete rpo; rpo = NULL;
		}
		else if( ! cpRivals::config.SAC[rpo->Rule][carule] ) {		// Shift
			model->Hold[FromPosition] = NULL;
			model->Hold[ToPosition] = rpo;
			rpo->Shift(circle);
         model->removeQueue(rpo);
			rpo->Touch();
         model->addQueue(rpo);
			#ifdef LOGGING
			char* res1 = CheckGene(rpo, circle);
			if( res1 ) { strcat(result, res1); delete [] res1; res1 = NULL; }
			else return NULL;
			#else
			CheckGene(rpo, circle);
			#endif
		}
		else {																		// Pass move
         model->removeQueue(rpo);
			rpo->Touch();
         model->addQueue(rpo);
		}
		cpRivals::collision = true;
	}
	#ifdef LOGGING
	delete [] tmp;
	return result;
	#endif
}
