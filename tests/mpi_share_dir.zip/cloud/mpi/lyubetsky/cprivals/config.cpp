// cpRivals: Model of the regulation by competing promoters.
//
// Copyright (C) 2009-2012 Lev Rubanov <rubanov@iitp.ru>
// Copyright (C) 2009-2012 Institute for Information Transmission Problems of
// the Russian Academy of Sciences (Kharkevich Institute) <http://www.iitp.ru>
//
// This model has been proposed and implemented in the Laboratory of 
// Mathematical Methods and Models in Bioinformatics of the above Institute.
// Head of the Laboratory, Prof. Vassily Lyubetsky <lyubetsky@iitp.ru>
//   
// This file is part of cpRivals.
//
// cpRivals is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// cpRivals is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with cpRivals. If not, see <http://www.gnu.org/licenses/>.
//
// Functions: LoadConfiguration
//
#include "cprivals.h"

#ifdef _MSC_VER
#if _MSC_VER >= 1300
#pragma warning(disable: 4996)
#endif
#endif

// Return: true=OK, false=Errors
bool cpRivals::LoadConfiguration(char *filename) {
	FILE *rini = NULL;
	char* line = new char[FILEBUFLEN];
	char* msg = new char[MSGLEN];
	try {
      if( strlen(filename)==0 ) { sprintf(msg, "Empty name of configuration file."); throw msg; }
		rini = fopen(filename, "rt");
		if( !rini ) {
			sprintf(msg, "Cannot open configuration file \"%s\"\n", filename);
			throw msg;
		}
		int num = 0;
		char delim[] = "=,: \t\n\r";
		while( fgets(line, FILEBUFLEN, rini) ) {
			num++;
			char* key = strtok(line, delim);
			if( key==NULL || key[0]==';' || key[0]=='[' || key[0]=='/' ) 
				continue;
			char* value = strtok(NULL, delim);
			if( value==NULL ) {
				sprintf(msg, "[%04d] Config error: no value in line %d (skipped).\n", cpRivals::myid, num );
                if( cpRivals::myid == 0 ) { fprintf(stderr, "%s", msg ); fflush(stderr); }
                #ifdef PARALLEL
				else if( cpRivals::collect )
					MPI::COMM_WORLD.Send(msg, (int)strlen(msg)+1, MPI::CHAR, root, cpRivals::tagInfo);
                #endif
				continue;
			}
			int n;									// Parsing key/value pairs
			char name[KEYNAMELEN];
			if( ! stricmp(key, "Version") ) { 
				if( stricmp(value, VERSION) ) {
					sprintf(msg, "[%04d] Warning: Configuration and program versions mismatch.\n", cpRivals::myid );
					if( cpRivals::myid == 0 ) { fprintf(stderr, "%s", msg); fflush(stderr); }
                    #ifdef PARALLEL
					else if( cpRivals::collect )
						MPI::COMM_WORLD.Send(msg, (int)strlen(msg)+1, MPI::CHAR, root, cpRivals::tagInfo);
                    #endif
				}
				continue; 
			}
			if( ! stricmp(key, "Scratch") ) { strcpy(cpRivals::scratch, value); continue; }
			if( ! stricmp(key, "PhysicalTime") ) { 
				if( !cpRivals::cmdtime ) cpRivals::config.PhysicalTime = atoi(value); 
				continue; 
			}
			if( ! stricmp(key, "StartupTime") ) {
				if( !cpRivals::cmdstartup ) cpRivals::config.StartupTime = atoi(value); 
				continue; 
			}
			if( ! stricmp(key, "ElapsedTime") )	
				{ cpRivals::config.ElapsedTime = atoi(value); continue; }
			if( ! stricmp(key, "CountCenter") )	
				{ cpRivals::config.CountCenter = stricmp(value, "true") ? false : true; continue; }
			if( ! stricmp(key, "CSV") )
				{ cpRivals::config.CSV = stricmp(value, "true") ? false : true; continue; }
			if( ! stricmp(key, "Both") )
				{ cpRivals::config.Both = stricmp(value, "true") ? false : true; continue; }
			if( ! stricmp(key, "Delimiter") )
				{ cpRivals::config.Delimiter = atoi(value); continue; }
			if( ! stricmp(key, "SAP") ) {
				n = 0;
				for( int i=0; i<3; i++ )
					for( int j=0; j<3; j++ ) 
						cpRivals::config.SAP[i][j] = (value[n++]=='1') ? true : false;
				continue;
			}
			if( ! stricmp(key, "DAP") ) {
				n = 0;
				for( int i=0; i<3; i++ )
					for( int j=0; j<3; j++ ) 
						cpRivals::config.DAP[i][j] = (value[n++]=='1') ? true : false;
				continue;
			}
			if( ! stricmp(key, "DPP") ) {
				n = 0;
				for( int i=0; i<3; i++ )
					for( int j=0; j<3; j++ ) 
						cpRivals::config.DPP[i][j] = (value[n++]=='1') ? true : false;
				continue;
			}
			if( ! stricmp(key, "SAC") ) {
				n = 0;
				for( int i=0; i<3; i++ )
					for( int j=0; j<3; j++ ) 
						cpRivals::config.SAC[i][j] = (value[n++]=='1') ? true : false;
				continue;
			}
			if( ! stricmp(key, "DAC") ) {
				n = 0;
				for( int i=0; i<3; i++ )
					for( int j=0; j<3; j++ ) 
						cpRivals::config.DAC[i][j] = (value[n++]=='1') ? true : false;
				continue;
			}
			if( ! stricmp(key, "DPC") ) {
				n = 0;
				for( int i=0; i<3; i++ )
					for( int j=0; j<3; j++ ) 
						cpRivals::config.DPC[i][j] = (value[n++]=='1') ? true : false;
				continue;
			}
			if( ! stricmp(key, "SAR") ) {
				n = 0;
				for( int i=0; i<3; i++ )
					cpRivals::config.SAR[i] = (value[n++]=='1') ? true : false;
				continue;
			}
			if( ! stricmp(key, "DAR") ) {
				n = 0;
				for( int i=0; i<3; i++ )
					cpRivals::config.DAR[i] = (value[n++]=='1') ? true : false;
				continue;
			}
			if( ! stricmp(key, "DPR") ) {
				n = 0;
				for( int i=0; i<3; i++ )
					cpRivals::config.DPR[i] = (value[n++]=='1') ? true : false;
				continue;
			}
			if( ! stricmp(key, "SAT") ) {
				n = 0;
				for( int i=0; i<3; i++ )
					cpRivals::config.SAT[i] = (value[n++]=='1') ? true : false;
				continue;
			}
			if( ! stricmp(key, "DAT") ) {
				n = 0;
				for( int i=0; i<3; i++ )
					cpRivals::config.DAT[i] = (value[n++]=='1') ? true : false;
				continue;
			}
			if( ! stricmp(key, "DPT") ) {
				n = 0;
				for( int i=0; i<3; i++ )
					cpRivals::config.DPT[i] = (value[n++]=='1') ? true : false;
				continue;
			}
			for( n=0; n<6; n++ ) {
				sprintf(name, "PEPSig%d", n+1);
				if( ! stricmp(key, name) ) break;
			}
			if( n < 6) continue;
			for( n=0; n<6; n++ ) {
				sprintf(name, "BindSig%d", n+1);
				if( ! stricmp(key, name) ) break; 
			}
			if( n < 6) continue;
			for( n=0; n<6; n++ ) {
				sprintf(name, "LengthSig%d", n+1);
				if( ! stricmp(key, name) ) break; 
			}
			if( n < 6) continue;
			for( n=0; n<6; n++ ) {
				sprintf(name, "AbortSig%d", n+1);
				if( ! stricmp(key, name) ) break; 
			}
			if( n < 6) continue;
			if( ! stricmp(key, "KorLeft") ) continue; 
			if( ! stricmp(key, "KorRight") ) continue;
			if( ! stricmp(key, "AbortRange") ) continue; 
			if( ! stricmp(key, "KorRate") ) continue; 
			for( n=0; n<5; n++ ) {
				sprintf(name, "NEP%s", cpRivals::RpoName[n]);
				if( ! stricmp(key, name) ) break; 
			}
			if( n < 5) continue;
			for( n=0; n<5; n++ ) {
				sprintf(name, "Bind%s", cpRivals::RpoName[n]);
				if( ! stricmp(key, name) ) break; 
			}
			if( n < 5) continue;
			for( n=0; n<5; n++ ) {
				sprintf(name, "Left%s", cpRivals::RpoName[n]);
				if( ! stricmp(key, name) ) break; 
			}
			if( n < 5) continue;
			for( n=0; n<5; n++ ) {
				sprintf(name, "Right%s", cpRivals::RpoName[n]);
				if( ! stricmp(key, name) ) break; 
			}
			if( n < 5) continue;
			for( n=0; n<5; n++ ) {
				sprintf(name, "Rate%s", cpRivals::RpoName[n]);
				if( ! stricmp(key, name) ) break; 
			}
			if( n < 5) continue; 
			if( ! stricmp(key, "PEPover") ) {
				cpRivals::config.PEPover = atoi(value); 
				continue; 
			}
			if( ! stricmp(key, "NEPover") ) {
				cpRivals::config.NEPover = atoi(value); 
				continue; 
			}
			// Unknown key
			sprintf(msg, "[%04d] Config error: Unknown key \"%s\" in line %d ignored.\n", cpRivals::myid, key, num);
			if( cpRivals::myid == 0 ) { fprintf(stderr, "%s", msg); fflush(stderr); }
            #ifdef PARALLEL
			else if( cpRivals::collect )
				MPI::COMM_WORLD.Send(msg, (int)strlen(msg)+1, MPI::CHAR, root, cpRivals::tagInfo);
            #endif
			continue;
		}
		if( ferror(rini) ) {
			sprintf(line, "Config error: I/O error in line %d", num);
			throw line;
		}
		delete [] line; line = NULL;
		delete [] msg; msg = NULL;
		fclose(rini); rini = NULL;
		return true;
	}
	catch (char *err) {
		char* msg1 = new char[MSGLEN];
		sprintf(msg1, "[%04d] %s\n", cpRivals::myid, err);
		if( cpRivals::myid == 0 ) { fprintf(stderr, "%s", msg1); fflush(stderr); }
        #ifdef PARALLEL
		else if( cpRivals::collect )
			MPI::COMM_WORLD.Send(msg1, (int)strlen(msg1)+1, MPI::CHAR, root, cpRivals::tagInfo);
        #endif 
		delete [] msg1;
		delete [] line; line = NULL;
		delete [] msg; msg = NULL;
		if( rini ) fclose(rini); 
		return false;
	}
}
