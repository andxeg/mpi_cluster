// cpRivals: Model of the regulation by competing promoters.
//
// Copyright (C) 2009-2012 Lev Rubanov <rubanov@iitp.ru>
// Copyright (C) 2009-2012 Institute for Information Transmission Problems of
// the Russian Academy of Sciences (Kharkevich Institute) <http://www.iitp.ru>
//
// This model has been proposed and implemented in the Laboratory of 
// Mathematical Methods and Models in Bioinformatics of the above Institute.
// Head of the Laboratory, Prof. Vassily Lyubetsky <lyubetsky@iitp.ru>
//   
// This file is part of cpRivals.
//
// cpRivals is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// cpRivals is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with cpRivals. If not, see <http://www.gnu.org/licenses/>.
//
// Functions: OutCSVHeader, OutLogHeader, OutCSVResult, CheckLogging
//
#include "cprivals.h"

void cpRivals::OutCSVHeader(FILE *wcsv) {
	if( !wcsv ) return;
	for( int i=0; i<cpRivals::varcount; i++ ) {			// Print variables in csv header line
		Agent* agent = cpRivals::varagent[i];
		fprintf(wcsv, "\"%s.%c\"%c", agent->Name, cpRivals::varparam[i], cpRivals::config.Delimiter);
	}
	// Print CSV header
	if( ! cpRivals::customcsv ) {								// Default csv record format
		if( cpRivals::Runs > 1 ) 		// print run number if averaging
			fprintf(wcsv, "\"#\"%c", cpRivals::config.Delimiter); 
		for( int i=0; i<cpRivals::task->NumAgents; i++ ) {
			Agent* agent = cpRivals::task->getAgent(i);
			if( ! agent->Enabled ) continue;
			if( cpRivals::joint || agent->Type != TypeGene ) {		// joint gene transcription data
				if( cpRivals::config.Both ) 
					fprintf(wcsv, "\"%s ok\"%c\"%s try\"", agent->Name, 
						cpRivals::config.Delimiter, agent->Name);
				else fprintf(wcsv, "\"%s\"", agent->Name);
				if( agent->Type == TypeRepr )
					fprintf(wcsv, "%c\"%s Tm\"%c\"%s Tc\"", cpRivals::config.Delimiter, 
						agent->Name, cpRivals::config.Delimiter, agent->Name);
			}
			else if( agent->Type == TypeGene ) {						// split gene transcription data
				if( cpRivals::config.Both ) 
					fprintf(wcsv, "\"%s PEP\"%c\"%s NEP\"%c\"%s Ptry\"%c\"%s Ntry\"", agent->Name,
						cpRivals::config.Delimiter, agent->Name,
						cpRivals::config.Delimiter, agent->Name,
						cpRivals::config.Delimiter, agent->Name);
				else 
					fprintf(wcsv, "\"%s PEP\"%c\"%s NEP\"", agent->Name,
						cpRivals::config.Delimiter, agent->Name);
			}
			fprintf(wcsv, "%c", cpRivals::config.Delimiter);
		}
	}
	else {															// Custom csv record format
		for( int i=0; i<cpRivals::fldcount; i++ ) {
			Agent* agent = cpRivals::fldagent[i];
			if( agent == NULL ) 	// indicates run count
				fprintf(wcsv, "\"#\"%c", cpRivals::config.Delimiter); 
			else if( agent->Enabled ) 
				fprintf(wcsv, "\"%s.%c\"%c", agent->Name, cpRivals::fldparam[i], 
					cpRivals::config.Delimiter);
		}
	}
	if( cpRivals::regular ) 		// add minutes column 
		fprintf(wcsv, "\"Minutes\"%c", cpRivals::config.Delimiter);
	fprintf(wcsv, "\n"); 
	fflush(wcsv); 
}

void cpRivals::OutCSVResult(FILE *wcsv, int inttime) {
	if( !wcsv ) return;
	for( int i=0; i<cpRivals::varcount; i++ ) {			// Print variables in csv header line
		fprintf(wcsv, "%.*f%c", cpRivals::ParamPrecision, cpRivals::varvalue[i], cpRivals::config.Delimiter);
	}
	if( ! cpRivals::customcsv ) {								// Default csv record format
		if( cpRivals::Runs > 1 ) {										// print run number if averaging
			if( cpRivals::RunsDone < 0 ) fprintf(wcsv, "#%c", cpRivals::config.Delimiter);
			else fprintf(wcsv, "%d%c", cpRivals::RunsDone+1, cpRivals::config.Delimiter);
		}
		for( int i=0; i<cpRivals::task->NumAgents; i++ ) {		// print fields
			Agent* agent = cpRivals::task->getAgent(i);
			if( ! agent->Enabled ) continue;
			if( agent->Type == TypeGene ) {
				Gene* gene = (Gene*)agent;
				if( cpRivals::joint ) 
					fprintf(wcsv, "%d%c", gene->Transcribed, cpRivals::config.Delimiter);
				else 
					fprintf(wcsv, "%d%c%d%c", gene->TransP, cpRivals::config.Delimiter, 
						gene->TransN, cpRivals::config.Delimiter);
				if( cpRivals::config.Both ) { 
					if( cpRivals::joint )
						fprintf(wcsv, "%d%c", gene->Initiated, cpRivals::config.Delimiter);
					else
						fprintf(wcsv, "%d%c%d%c", gene->InitP, cpRivals::config.Delimiter, 
							gene->InitN, cpRivals::config.Delimiter);
				}
				continue;
			}
			if( agent->Type == TypePEP ) {
				PEP* pep = (PEP*)agent;
				fprintf(wcsv, "%d%c", pep->Bound, cpRivals::config.Delimiter);
				if( cpRivals::config.Both ) 
					fprintf(wcsv, "%d%c", pep->Offered, cpRivals::config.Delimiter);
				continue;
			}
			if( agent->Type == TypeNEP ) {
				NEP* nep = (NEP*)agent;
				fprintf(wcsv, "%d%c", nep->Bound, cpRivals::config.Delimiter);
				if( cpRivals::config.Both ) 
					fprintf(wcsv, "%d%c", nep->Offered, cpRivals::config.Delimiter);
				continue;
			}
			if( agent->Type == TypeRepr ) {
				Repr* repr = (Repr*)agent;
				fprintf(wcsv, "%d%c", repr->Bound, cpRivals::config.Delimiter);
				if( cpRivals::config.Both ) 
					fprintf(wcsv, "%d%c", repr->Offered, cpRivals::config.Delimiter);
				fprintf(wcsv, "%d%c%d%c", repr->Mterminated, cpRivals::config.Delimiter, 
					repr->Cterminated, cpRivals::config.Delimiter);
				continue;
			}
			if( agent->Type == TypeEKor ) {
				EKor* ekor = (EKor*)agent;
				fprintf(wcsv, "%d%c", ekor->Bound, cpRivals::config.Delimiter);
				if( cpRivals::config.Both ) 
					fprintf(wcsv, "%d%c", ekor->Offered, cpRivals::config.Delimiter);
				continue;
			}
			if( agent->Type == TypeERpo ) {
				ERpo* erpo = (ERpo*)agent;
				fprintf(wcsv, "%d%c", erpo->Bound, cpRivals::config.Delimiter);
				if( cpRivals::config.Both ) 
					fprintf(wcsv, "%d%c", erpo->Offered, cpRivals::config.Delimiter);
				continue;
			}
			if( agent->Type == TypeTerm ) {
				Term* term = (Term*)agent;
				fprintf(wcsv, "%d%c", term->Bound, cpRivals::config.Delimiter);
				if( cpRivals::config.Both ) 
					fprintf(wcsv, "%d%c", term->Offered, cpRivals::config.Delimiter);
				continue;
			}
		}
	}
	else {															// Custom csv record format
		for( int i=0; i<cpRivals::fldcount; i++ ) {
			Agent* agent = cpRivals::fldagent[i];
			if( agent == NULL ) {	// indicates run count
				if( cpRivals::RunsDone < 0 ) fprintf(wcsv, "#%c", cpRivals::config.Delimiter);
				else fprintf(wcsv, "%d%c", cpRivals::RunsDone+1, cpRivals::config.Delimiter);
				continue;
			}
			if( ! agent->Enabled ) continue;
			if( agent->Type == TypeGene ) {
				Gene* gene = (Gene*)agent;
				switch( cpRivals::fldparam[i] ) {
					case 'I': case 'i': fprintf(wcsv, "%d", gene->Initiated); break;
					case 'E': case 'e': fprintf(wcsv, "%d", gene->InitP); break;
					case 'F': case 'f': fprintf(wcsv, "%d", gene->InitN); break;
					case 'T': case 't': fprintf(wcsv, "%d", gene->Transcribed); break;
					case 'P': case 'p': fprintf(wcsv, "%d", gene->TransP); break;
					case 'N': case 'n': fprintf(wcsv, "%d", gene->TransN); break;
					default: fprintf(wcsv, "\"???\"");
				}
				fprintf(wcsv, "%c", cpRivals::config.Delimiter);
				continue;
			}
			if( agent->Type == TypePEP ) {
				PEP* pep = (PEP*)agent;
				switch( cpRivals::fldparam[i] ) {
					case 'O': case 'o': fprintf(wcsv, "%d", pep->Offered); break;
					case 'B': case 'b': fprintf(wcsv, "%d", pep->Bound); break;
					case 'L': case 'l': fprintf(wcsv, "%g", pep->Lambda); break;
					case 'R': case 'r': fprintf(wcsv, "%g", pep->Rate); break;
					case 'A': case 'a': fprintf(wcsv, "%g", pep->Aborting); break;
					case 'G': case 'g': fprintf(wcsv, "%d", pep->AbortRange); break;
					default: fprintf(wcsv, "\"???\"");
				}
				fprintf(wcsv, "%c", cpRivals::config.Delimiter);
				continue;
			}
			if( agent->Type == TypeNEP ) {
				NEP* nep = (NEP*)agent;
				switch( cpRivals::fldparam[i] ) {
					case 'O': case 'o': fprintf(wcsv, "%d", nep->Offered); break;
					case 'B': case 'b': fprintf(wcsv, "%d", nep->Bound); break;
					case 'L': case 'l': fprintf(wcsv, "%g", nep->Lambda); break;
					case 'R': case 'r': fprintf(wcsv, "%g", nep->Rate); break;
					default: fprintf(wcsv, "\"???\"");
				}
				fprintf(wcsv, "%c", cpRivals::config.Delimiter);
				continue;
			}
			if( agent->Type == TypeRepr ) {
				Repr* repr = (Repr*)agent;
				switch( cpRivals::fldparam[i] ) {
					case 'O': case 'o': fprintf(wcsv, "%d", repr->Offered); break;
					case 'B': case 'b': fprintf(wcsv, "%d", repr->Bound); break;
					case 'D': case 'd': fprintf(wcsv, "%d", repr->Mterminated); break;
					case 'K': case 'k': fprintf(wcsv, "%d", repr->Cterminated); break;
					case 'L': case 'l': fprintf(wcsv, "%g", repr->Lambda); break;
					case 'M': case 'm': fprintf(wcsv, "%g", repr->Qm); break;
					case 'Q': case 'q': fprintf(wcsv, "%g", repr->Qc); break;
					default: fprintf(wcsv, "\"???\"");
				}
				fprintf(wcsv, "%c", cpRivals::config.Delimiter);
				continue;
			}
			if( agent->Type == TypeEKor ) {
				EKor* ekor = (EKor*)agent;
				switch( cpRivals::fldparam[i] ) {
					case 'O': case 'o': fprintf(wcsv, "%d", ekor->Offered); break;
					case 'B': case 'b': fprintf(wcsv, "%d", ekor->Bound); break;
					case 'L': case 'l': fprintf(wcsv, "%g", ekor->Lambda); break;
					case 'R': case 'r': fprintf(wcsv, "%g", ekor->Rate); break;
					default: fprintf(wcsv, "\"???\"");
				}
				fprintf(wcsv, "%c", cpRivals::config.Delimiter);
				continue;
			}
			if( agent->Type == TypeERpo ) {
				ERpo* erpo = (ERpo*)agent;
				switch( cpRivals::fldparam[i] ) {
					case 'O': case 'o': fprintf(wcsv, "%d", erpo->Offered); break;
					case 'B': case 'b': fprintf(wcsv, "%d", erpo->Bound); break;
					case 'L': case 'l': fprintf(wcsv, "%g", erpo->Lambda); break;
					case 'R': case 'r': fprintf(wcsv, "%g", erpo->Rate); break;
					default: fprintf(wcsv, "\"???\"");
				}
				fprintf(wcsv, "%c", cpRivals::config.Delimiter);
				continue;
			}
			if( agent->Type == TypeTerm ) {
				Term* term = (Term*)agent;
				switch( cpRivals::fldparam[i] ) {
					case 'O': case 'o': fprintf(wcsv, "%d", term->Offered); break;
					case 'B': case 'b': fprintf(wcsv, "%d", term->Bound); break;
					case 'L': case 'l': fprintf(wcsv, "%g", term->Lambda); break;
					default: fprintf(wcsv, "\"???\"");
				}
				fprintf(wcsv, "%c", cpRivals::config.Delimiter);
				continue;
			}
		}
	}
	if( cpRivals::regular ) 		// add minutes column 
		fprintf(wcsv, "%d%c", inttime / 60, cpRivals::config.Delimiter);
	fprintf(wcsv, "\n"); 
	fflush(wcsv); 
}

void cpRivals::OutLogHeader(FILE* wlog) {
	if( !wlog ) return;
	// Print whole job description line to wlog
	if( cpRivals::automation ) {
		fprintf(wlog, "Job=%s (%d remain) Task=%s Runs=%d Time=%d Startup=%d Seed=%ld ",
			cpRivals::rjbfilename, cpRivals::jobtotal, cpRivals::tskfilename, cpRivals::Runs, 
			cpRivals::config.PhysicalTime / 60, cpRivals::config.StartupTime / 60, cpRivals::InitialSeed);
      if( cpRivals::mpimode )
         fprintf(wlog, "MPI=%d ", cpRivals::numprocs);
      fprintf(wlog, "v."VERSION"\n"); 
		fflush(wlog);
	}
	if( !cpRivals::MiniLog && cpRivals::jobcount <= 1 ) {		// Print log file header
		char prefix[3], postfix[3];
		for( int i=0; i<cpRivals::task->NumAgents; i++ ) {
			Agent* agent = cpRivals::task->getAgent(i);
			if( ! agent->Enabled ) continue;
			if( agent->Strand ) { prefix[0] = 0; sprintf(postfix, "->"); }
			else { sprintf(prefix, "<-"); postfix[0] = 0; }
			int begin = agent->Begin + cpRivals::Origin;
			if( begin > cpRivals::task->SeqLength ) begin -= cpRivals::task->SeqLength;
			int end = agent->End + cpRivals::Origin;
			if( end > cpRivals::task->SeqLength ) end -= cpRivals::task->SeqLength;
			if( agent->Type == TypeGene ) {
				Gene* gene = (Gene*)agent;
				fprintf(wlog, "%sGene%s %s [%d,%d]  ", prefix, postfix, gene->Name, begin, end);
				continue;
			}
			if( agent->Type == TypePEP ) {
				PEP* pep = (PEP*)agent;
				int tcenter = pep->Tcenter + cpRivals::Origin;
				if( tcenter > cpRivals::task->SeqLength ) tcenter -= cpRivals::task->SeqLength;
				fprintf(wlog, "%sPEP%s %s %d[%d,%d]  ", prefix, postfix, pep->Name, tcenter, begin, end);
				continue;
			}
			if( agent->Type == TypeNEP ) {
				NEP* nep = (NEP*)agent;
				int tcenter = nep->Tcenter + cpRivals::Origin;
				if( tcenter > cpRivals::task->SeqLength ) tcenter -= cpRivals::task->SeqLength;
				fprintf(wlog, "%sNEP%s %s %d[%d,%d]  ", prefix, postfix, nep->Name, tcenter, begin, end);
				continue;
			}
			if( agent->Type == TypeRepr ) {
				Repr* repr = (Repr*)agent;
				fprintf(wlog, "Repr %s [%d,%d]  ", repr->Name, begin, end);
				continue;
			}
			if( agent->Type == TypeEKor ) {
				EKor* ekor = (EKor*)agent;
				int tcenter = ekor->Tcenter + cpRivals::Origin;
				if( tcenter > cpRivals::task->SeqLength ) tcenter -= cpRivals::task->SeqLength;
				fprintf(wlog, "%sEKor%s %s %d[%d,%d]  ", prefix, postfix, ekor->Name, tcenter, begin, end);
				continue;
			}
			if( agent->Type == TypeERpo ) {
				ERpo* erpo = (ERpo*)agent;
				int tcenter = erpo->Tcenter + cpRivals::Origin;
				if( tcenter > cpRivals::task->SeqLength ) tcenter -= cpRivals::task->SeqLength;
				fprintf(wlog, "%sERpor%s %s %d[%d,%d]  ", prefix, postfix, erpo->Name, tcenter, begin, end);
				continue;
			}
			if( agent->Type == TypeTerm ) {
				Term* term = (Term*)agent;
				char sensep[2], sensen[2];
				if( term->SenseKor ) sprintf(sensep, "P"); 
				else sensep[0] = 0;
				if( term->SenseRpo ) sprintf(sensen, "N");
				else sensen[0] = 0;
				fprintf(wlog, "%sTerm(%s%s)%s %s [%d,%d]  ", prefix, sensep, sensen, postfix, 
					term->Name, begin, end);
				continue;
			}
			fprintf(wlog, "\nInvalid agent type (%d) in the task\n", agent->Type);
			fflush(wlog); return;
		}
		fprintf(wlog, "\n"); fflush(wlog);
	}
	if( !cpRivals::MiniLog ) {											// Print parameters
		for( int i=0; i<cpRivals::task->NumAgents; i++ ) {		
			Agent* agent = cpRivals::task->getAgent(i);
			if( ! agent->Enabled || agent->Type == TypeGene ) 
				continue;
			if( agent->Type == TypePEP ) { 
				PEP* pep = (PEP*)agent;
				fprintf(wlog, "PEP %s: Lambda=%g,Aborting=%g  ", pep->Name, pep->Lambda, pep->Aborting);
				continue;
			}
			if( agent->Type == TypeNEP ) {
				NEP* nep = (NEP*)agent;
				fprintf(wlog, "NEP %s: Lambda=%g  ", nep->Name, nep->Lambda);
				continue;
			}
			if( agent->Type == TypeRepr ) {
				Repr* repr = (Repr*)agent;
				fprintf(wlog, "Repr %s: Lambda=%g Qm=%g Qc=%g ", repr->Name, repr->Lambda, repr->Qm, repr->Qc);
				continue;
			}
			if( agent->Type == TypeEKor ) {
				EKor* ekor = (EKor*)agent;
				fprintf(wlog, "EKor %s: Lambda=%g  ", ekor->Name, ekor->Lambda);
				continue;
			}
			if( agent->Type == TypeERpo ) {
				ERpo* erpo = (ERpo*)agent;
				fprintf(wlog, "ERpo %s: Lambda=%g  ", erpo->Name, erpo->Lambda);
				continue;
			}
			if( agent->Type == TypeTerm ) {
				Term* term = (Term*)agent;
				fprintf(wlog, "Term %s: Lambda=%g  ", term->Name, term->Lambda);
				continue;
			}
			fprintf(wlog, "\nInvalid agent type (%d) in the task\n", agent->Type);
			fflush(wlog); return;
		}
		fprintf(wlog, "\n"); fflush(wlog);
	}
}

#ifdef LOGGING
// Check if logging is enabled: true=yes, false=no
bool cpRivals::CheckLogging(void) {
	if( cpRivals::myid ) return false;		// only root branch can be logged/debugged
	if( cpRivals::Logstart == 0 || cpRivals::Logmode == 0 ) 
		return false;
	if( cpRivals::RunsDone + 1 < cpRivals::Logrun )
		return false;
	if( cpRivals::model->Iteration >= cpRivals::Logstart && 
		(cpRivals::Logstop == 0 || cpRivals::model->Iteration <= cpRivals::Logstop) )
		return true;
	else return false;
}
#endif
