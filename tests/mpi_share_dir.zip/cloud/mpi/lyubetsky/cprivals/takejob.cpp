// cpRivals: Model of the regulation by competing promoters.
//
// Copyright (C) 2009-2012 Lev Rubanov <rubanov@iitp.ru>
// Copyright (C) 2009-2012 Institute for Information Transmission Problems of
// the Russian Academy of Sciences (Kharkevich Institute) <http://www.iitp.ru>
//
// This model has been proposed and implemented in the Laboratory of 
// Mathematical Methods and Models in Bioinformatics of the above Institute.
// Head of the Laboratory, Prof. Vassily Lyubetsky <lyubetsky@iitp.ru>
//   
// This file is part of cpRivals.
//
// cpRivals is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// cpRivals is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with cpRivals. If not, see <http://www.gnu.org/licenses/>.
//
// Functions: CountJob, LoadRunJob, MarkJobDone, CountRunsDone
//
#include "cprivals.h"

#ifdef _MSC_VER
#if _MSC_VER >= 1300
#pragma warning(disable: 4996)
#endif
#endif

// Returns the number of remaining jobs in the run file (w/o detailed check) or -1 (Errors)
int cpRivals::CountJob(char* filename) {
	FILE* rrjb = NULL;
	char* line = new char[FILEBUFLEN];
	char* msg = new char[MSGLEN];
	char delim[] = "=,: \t\n\r";
	int linenum = 0, jobs = 0;
	try {
		if( strlen(filename)==0 ) {
			sprintf(msg, "Empty name of job file."); 
			throw msg;
		}
		rrjb = fopen(filename, "rt");
		if( !rrjb ) {
			sprintf(line, "Cannot open job file \"%s\"\n", filename);
			throw line;
		}
		while( fgets(line, FILEBUFLEN, rrjb) ) {	// skip until job section
			linenum ++;
			char* key = strtok(line, delim);
			if( key==NULL || key[0]==';' || key[0]=='/' ) 
				continue;
			if( ! stricmp(key, "[Job") )	// job header (up to 1st delimiter)
				break;
		}
		while( fgets(line, FILEBUFLEN, rrjb) ) {
			linenum ++;
			char* key = strtok(line, delim);
			if( key==NULL || key[0]==';' || key[0]=='/' || stricmp(key, "Debug")==0 )
				continue;	// skip comment & Debug lines
			jobs ++;
		}
		if( ferror(rrjb) ) {
			sprintf(line, "Job file I/O error in line %d", linenum);
			throw line;
		}
	}
	catch (char *err) {
		char *msg = new char[MSGLEN];
		sprintf(msg, "[%04d] %s\n", cpRivals::myid, err);
		if( cpRivals::myid == 0 ) { fprintf(stderr, "%s", msg); fflush(stderr); }
        #ifdef PARALLEL
		else if( cpRivals::collect ) 
			MPI::COMM_WORLD.Send(msg, (int)strlen(msg)+1, MPI::CHAR, root, cpRivals::tagInfo);
        #endif
		delete [] line; delete [] msg;
		if( rrjb ) fclose(rrjb);
		return -1;
	}
	delete [] line;
	delete [] msg;
	fclose(rrjb);
	return jobs;
}

// offset=0L: read/parse the preamble of the job file
// otherwise: read/parse the next job starting from the offset
// Debug & comment lines are properly processed, but not counted as jobs
// Returns: new offset (next job to do), 0 (all done) or -1 (errors)
long cpRivals::LoadRunJob(char* filename, long* offset) {
	FILE* rrjb = NULL;
	char* line = new char[FILEBUFLEN];
	char* msg = new char[MSGLEN];
	char delim[] = "=,: \t\n\r";
	char fldelim[] = ".%?!";
	long newoffset;
	try {
		if( strlen(filename)==0 ) {
			sprintf(msg, "Empty name of job file.");
			throw msg;
		}
		rrjb = fopen(filename, "rt");
		if( !rrjb ) {
			sprintf(line, "Cannot open job file \"%s\"\n", filename);
			throw line;
		}
		if( *offset == 0L ) {			// first call - read preamble
			for( int param=0; param<MAXDYNAM; param++ ) {	// Init table of dynamics
				Dyn[param].agent = NULL;
				Dyn[param].parnum = cpRivals::None;
				Dyn[param].operation = cpRivals::Nop;
				for( int ctr=0; ctr<MAXDSTEP; ctr++ ) {
					Dyn[param].modtime[ctr] = -1;
					Dyn[param].val1[ctr] = 0;
					Dyn[param].val2[ctr] = 0;
				}
			}
			int numdyn = 0;
			while( fgets(line, FILEBUFLEN, rrjb) ) {	// parse preamble lines
				cpRivals::jobline ++;
				char* key = strtok(line, delim);
				if( key==NULL || key[0]==';' || key[0]=='/' ) 
					continue;
				if( ! stricmp(key, "[Job") )	// job header found (up to 1st blank)
					break;
				char* value = strtok(NULL, delim);
				if( value == NULL ) {
					sprintf(msg, "[%04d] Preamble statement without value in line %d (skipped).\n", 
						cpRivals::myid, cpRivals::jobline);
					if( cpRivals::myid == 0 ) { fprintf(stderr, "%s", msg); fflush(stderr); }
                    #ifdef PARALLEL
					else if( cpRivals::collect ) 
						MPI::COMM_WORLD.Send(msg, (int)strlen(msg)+1, MPI::CHAR, root, cpRivals::tagInfo);
                    #endif
					continue;
				}
				if( stricmp(key, "Task")==0 ) {			// Task file name
					if( strlen(cpRivals::tskfilename) == 0 ) {	// cmd line has priority
						strncpy(cpRivals::tskfilename, value, FILENAMELEN-1);
						int curlen = (int)strlen(cpRivals::tskfilename);
						while( (value = strtok(NULL, delim)) ) {
							if( curlen + strlen(value) >= FILENAMELEN ) {
								sprintf(line, "FILENAMELEN overflow in job file line %d.", jobline); 
								throw line;
							}
							cpRivals::tskfilename[curlen++] = ' ';
							strcpy(cpRivals::tskfilename + curlen, value);
							curlen += (int)strlen(value);
						}
					}
					if( ! LoadTask(cpRivals::tskfilename ) ) {	// set taskloaded flag if success
						sprintf(line, "Cannot load specified task.");
						throw line;
					}
					continue;
				}
				if( stricmp(key, "Result")==0 ) {		// Output file(s) name
					if( strlen(cpRivals::outfilename) == 0 ) {	// cmd line has priority
						strncpy(cpRivals::outfilename, value, FILENAMELEN-1);
						TrimExtension(cpRivals::outfilename);
					}
					continue;
				}
				if( stricmp(key, "Scratch")==0 ) 
					{ strcpy(cpRivals::scratch, value); continue; }
				if( stricmp(key, "Append")==0 ) {		// Append mode
					if( ! cmdappend )		// cmd line has priority
						cpRivals::append = stricmp(value, "True") ? false : true;
					continue;
				}
				if( stricmp(key, "Granularity")==0 ) {	// Refresh granularity
					if( !cpRivals::cmdgranularity ) cpRivals::granularity = atoi(value);
					continue;
				}
				if( stricmp(key, "Repeat")==0 ) {		// Number of repetitions
					if( !cpRivals::cmdruns ) cpRivals::Runs = atoi(value);
					continue;
				}
				if( stricmp(key, "Pminutes")==0 ) {		// Physical time
					if( !cpRivals::cmdtime ) cpRivals::config.PhysicalTime = atoi(value) * 60;
					continue;
				}
				if( stricmp(key, "Startup")==0 ) {		// Startup phase duration
					if( !cpRivals::cmdstartup ) cpRivals::config.StartupTime = atoi(value) * 60;
					continue;
				}
				if( stricmp(key, "Interval")==0 ) {		// Intermediate data output interval
					if( !cpRivals::cmdstep ) cpRivals::regular = atoi(value) * 60;
					continue;
				}
				if( stricmp(key, "Seed")==0 ) {			// Initial seed for RNG
					if( cpRivals::InitialSeed == -1 )			// none in cmdline
						cpRivals::InitialSeed = labs(atol(value));
					else if( cpRivals::InitialSeed == 0 )		// randomize in cmdline
						cpRivals::InitialSeed = -1;
					continue;
				}
				if( stricmp(key, "BothCSV")==0 ) {		// Print both values in CSV
					cpRivals::config.Both = stricmp(value, "True") ? false : true;
					continue;
				}
				if( stricmp(key, "Decision")==0 ) {		// Number of runs to decide acceptance
					if( !cpRivals::cmddecision ) cpRivals::decide = atoi(value);
					if( cpRivals::decide < 0 ) cpRivals::decide = 0;
					continue;
				}
				if( stricmp(key, "Minratio")==0 ) {		// Smallest Min/Sum transcription ratio to accept
					if( !cpRivals::cmdminratio ) cpRivals::minratio = atof(value);
					continue;
				}
				if( stricmp(key, "Joint")==0 ) {			// Joint/split transcription data
					cpRivals::joint = stricmp(value, "True") ? false : true;
					continue;
				}
				if( stricmp(key, "Sample")==0 ) {		// Whole sample output or not
					cpRivals::sample = stricmp(value, "True") ? false : true;
					continue;
				}
				if( stricmp(key, "Average")==0 || stricmp(key, "Mean")==0 ) {	// Average output or not
					cpRivals::average = stricmp(value, "True") ? false : true;
					continue;
				}
				if( stricmp(key, "StDev")==0 ) {			// Std deviation output or not
					cpRivals::stdev = stricmp(value, "True") ? false : true;
					continue;
				}
				if( stricmp(key, "ResultPrecision")==0 ) { // Number of decimal places in avg/stdev
					cpRivals::ResultPrecision = atoi(value);
					if( cpRivals::ResultPrecision < 0 ) cpRivals::ResultPrecision = 0;
					continue;
				}
				if( stricmp(key, "ParamPrecision")==0 ) { // Number of decimal places in arguments
					cpRivals::ParamPrecision = atoi(value);
					if( cpRivals::ParamPrecision < 0 ) cpRivals::ParamPrecision = 0;
					continue;
				}
				// Used: ABCDEFGHIJKLMNOPQRSTUXYZ, Free: VW 0 etc.
				if( stricmp(key, "Names")==0 ) {			// Names
					if( ! cpRivals::taskloaded ) {
						char *curline = line + strlen(line) + 1;	// skip key
						curline[strlen(curline)] = delim[0];		// restore value
						LoadTask(cpRivals::tskfilename);	// sets taskloaded flag on success
						value = strtok(curline, delim);
					}
					if( ! cpRivals::taskloaded ) {
						sprintf(msg, "Cannot process names in job file because no task is loaded.");
						throw msg;
					}
					int i = 0;
					char *agname = new char[AGENTNAMELEN];
					for( ; i<MAXPARAM; i++ ) {
						agname[0] = 0;
						size_t dot1 = strcspn(value, fldelim);
						if( value[dot1] ) {
							size_t dot2 = strcspn(value + dot1 + 1, fldelim);
							if( value[dot1 + dot2 + 1] ) {
								sprintf(msg, "Cannot parse parameter name \"%s\" in job line %d",
									value, cpRivals::jobline);
								delete [] agname;
								throw msg;
							}
						}
						memcpy(agname, value, dot1);		// also default .L
						agname[dot1] = 0;
						cpRivals::varagent[i] = cpRivals::task->findAgent(agname);
						if( ! cpRivals::varagent[i] || cpRivals::varagent[i]->Type == TypeGene ||
								cpRivals::varagent[i]->Type == TypeHolo || 
								cpRivals::varagent[i]->Type == TypeKor || 
								cpRivals::varagent[i]->Type == TypeRpo ) {
							sprintf(msg, "Invalid agent name \"%s\" in job line %d.", 
								value, cpRivals::jobline);
							delete [] agname;
							throw msg;
						}
						else if( value[dot1] == 0 )
							cpRivals::varparam[i] = 'L';			// Lambda (by default)
						else if( (value[dot1 + 1] == 'A' || value[dot1 + 1] == 'a') && 
							cpRivals::varagent[i]->Type == TypePEP )
								cpRivals::varparam[i] = 'A';		// Aborting
						else if( (value[dot1 + 1] == 'C' || value[dot1 + 1] == 'c') && 
							cpRivals::varagent[i]->Type != TypeGene &&
							cpRivals::varagent[i]->Type != TypeRepr &&
							cpRivals::varagent[i]->Type != TypeTerm )
								cpRivals::varparam[i] = 'C';		// Tcenter
						else if( (value[dot1 + 1] == 'G' || value[dot1 + 1] == 'g') && 
							cpRivals::varagent[i]->Type == TypePEP )
								cpRivals::varparam[i] = 'G';		// Aborting range
						else if( (value[dot1 + 1] == 'H' || value[dot1 + 1] == 'h') && 
							cpRivals::varagent[i]->Type == TypePEP )
								cpRivals::varparam[i] = 'H';		// SigLength
						else if( value[dot1 + 1] == 'L' || value[dot1 + 1] == 'l' )
							cpRivals::varparam[i] = 'L';			// Lambda
						else if( (value[dot1 + 1] == 'M' || value[dot1 + 1] == 'm') && 
							cpRivals::varagent[i]->Type == TypeRepr )
								cpRivals::varparam[i] = 'M';		// Qm (pass probability on main strand)
						else if( (value[dot1 + 1] == 'Q' || value[dot1 + 1] == 'q') && 
							cpRivals::varagent[i]->Type == TypeRepr )
								cpRivals::varparam[i] = 'Q';		// Qc (pass probability on complement strand)
						else if( (value[dot1 + 1] == 'R' || value[dot1 + 1] == 'r' ) &&
							cpRivals::varagent[i]->Type != TypeRepr && cpRivals::varagent[i]->Type != TypeTerm )
								cpRivals::varparam[i] = 'R';		// Polymerase rate
						else if( (value[dot1 + 1] == 'S' || value[dot1 + 1] == 's') && 
							cpRivals::varagent[i]->Type == TypePEP )
								cpRivals::varparam[i] = 'S';		// Sigma
						else if( (value[dot1 + 1] == 'X' || value[dot1 + 1] == 'x') && 
							cpRivals::varagent[i]->Type == TypeTerm )
								cpRivals::varparam[i] = 'X';		// SenseKor (Term)
						else if( (value[dot1 + 1] == 'Y' || value[dot1 + 1] == 'y') && 
							cpRivals::varagent[i]->Type == TypeNEP )
								cpRivals::varparam[i] = 'Y';		// Polym
						else if( (value[dot1 + 1] == 'Z' || value[dot1 + 1] == 'z') && 
							cpRivals::varagent[i]->Type == TypeTerm )
								cpRivals::varparam[i] = 'Z';		// SenseRpo (Term)
						else {
							sprintf(msg, "Invalid parameter name \"%s\" in job line %d.", 
								value + dot1 + 1, cpRivals::jobline);
							delete [] agname;
							throw msg;
						}
						value = strtok(NULL, delim);
						if( value == NULL ) break;
					}
					delete [] agname;
					if( i >= MAXPARAM ) {
						sprintf(msg, "MAXPARAM overflow in the Names statement.");
						throw msg;
					}
					cpRivals::varcount = i + 1;
					continue;
				}
				if( stricmp(key, "Record")==0 ) {			// CSV record structure
					if( ! cpRivals::taskloaded ) {
						char *curline = line + strlen(line) + 1;	// skip key
						curline[strlen(curline)] = delim[0];		// restore value
						LoadTask(cpRivals::tskfilename);	// sets taskloaded flag if success
						value = strtok(curline, delim);
					}
					if( ! cpRivals::taskloaded ) {
						sprintf(msg, "Cannot set CSV file record structure because no task is loaded.");
						throw msg;
					}
					int i = 0;
					char *agname = new char[AGENTNAMELEN];
					for( ; i<MAXFIELD; i++ ) {
						agname[0] = 0;
						if( value[0] == '#' ) {
							cpRivals::fldagent[i] = NULL;		// indicator of the number column
							cpRivals::fldparam[i] = '#';
						}
						else {
							size_t dot1 = strcspn(value, fldelim);
							if( value[dot1] ) {
								size_t dot2 = strcspn(value + dot1 + 1, fldelim);
								if( value[dot1 + dot2 + 1] ) {
									sprintf(msg, "Cannot parse field name \"%s\" in job line %d.", 
										value, cpRivals::jobline);
									delete [] agname;
									throw msg;
								}
								memcpy(agname, value, dot1);
								agname[dot1] = 0;
							}
							cpRivals::fldagent[i] = cpRivals::task->findAgent(agname);
							if( ! cpRivals::fldagent[i] || cpRivals::fldagent[i]->Type == TypeHolo ||
									cpRivals::fldagent[i]->Type == TypeKor ||
									cpRivals::fldagent[i]->Type == TypeRpo ) {
								sprintf(msg, "Invalid agent name \"%s\" in job line %d.", 
									value, cpRivals::jobline);
								delete [] agname;
								throw msg;
							}
							else if( (value[dot1 + 1] == 'A' || value[dot1 + 1] == 'a') && 
								cpRivals::fldagent[i]->Type == TypePEP )
									cpRivals::fldparam[i] = 'A';		// Aborting
							else if( (value[dot1 + 1] == 'B' || value[dot1 + 1] == 'b') && 
								cpRivals::fldagent[i]->Type != TypeGene )
									cpRivals::fldparam[i] = 'B';		// Bound
							else if( (value[dot1 + 1] == 'C' || value[dot1 + 1] == 'c') &&
								cpRivals::fldagent[i]->Type != TypeGene &&
								cpRivals::fldagent[i]->Type != TypeRepr && 
								cpRivals::fldagent[i]->Type != TypeTerm )
									cpRivals::fldparam[i] = 'C';		// Tcenter
							else if( (value[dot1 + 1] == 'D' || value[dot1 + 1] == 'd') &&
								cpRivals::fldagent[i]->Type == TypeRepr )
									cpRivals::fldparam[i] = 'D';		// Mterminated
							else if( (value[dot1 + 1] == 'E' || value[dot1 + 1] == 'e') && 
								cpRivals::fldagent[i]->Type == TypeGene )
									cpRivals::fldparam[i] = 'E';		// InitP
							else if( (value[dot1 + 1] == 'F' || value[dot1 + 1] == 'f') && 
								cpRivals::fldagent[i]->Type == TypeGene )
									cpRivals::fldparam[i] = 'F';		// InitN
							else if( (value[dot1 + 1] == 'G' || value[dot1 + 1] == 'g') && 
								cpRivals::fldagent[i]->Type == TypePEP )
									cpRivals::fldparam[i] = 'G';		// Aborting range
							else if( (value[dot1 + 1] == 'H' || value[dot1 + 1] == 'h') && 
								cpRivals::fldagent[i]->Type == TypePEP )
									cpRivals::fldparam[i] = 'H';		// SigLength
							else if( (value[dot1 + 1] == 'I' || value[dot1 + 1] == 'i') && 
								cpRivals::fldagent[i]->Type == TypeGene )
									cpRivals::fldparam[i] = 'I';		// Initiated
							else if( (value[dot1 + 1] == 'J' || value[dot1 + 1] == 'j') && 
								cpRivals::fldagent[i]->Type == TypeGene )
									cpRivals::fldparam[i] = 'J';		// TotalInit
							else if( (value[dot1 + 1] == 'K' || value[dot1 + 1] == 'k') &&
								cpRivals::fldagent[i]->Type == TypeRepr )
									cpRivals::fldparam[i] = 'K';		// Cterminated
							else if( (value[dot1 + 1] == 'L' || value[dot1 + 1] == 'l') &&
								cpRivals::fldagent[i]->Type != TypeGene )
									cpRivals::fldparam[i] = 'L';		// Lambda
							else if( (value[dot1 + 1] == 'M' || value[dot1 + 1] == 'm') &&
								cpRivals::fldagent[i]->Type == TypeRepr )
									cpRivals::fldparam[i] = 'M';		// Qm (pass probability on main strand)
							else if( (value[dot1 + 1] == 'N' || value[dot1 + 1] == 'n') && 
								cpRivals::fldagent[i]->Type == TypeGene )
									cpRivals::fldparam[i] = 'N';		// TransN
							else if( (value[dot1 + 1] == 'O' || value[dot1 + 1] == 'o') && 
								cpRivals::fldagent[i]->Type != TypeGene )
									cpRivals::fldparam[i] = 'O';		// Offered
							else if( (value[dot1 + 1] == 'P' || value[dot1 + 1] == 'p') && 
								cpRivals::fldagent[i]->Type == TypeGene )
									cpRivals::fldparam[i] = 'P';		// TransP
							else if( (value[dot1 + 1] == 'Q' || value[dot1 + 1] == 'q') &&
								cpRivals::fldagent[i]->Type == TypeRepr )
									cpRivals::fldparam[i] = 'Q';		// Qc (pass probability on complement strand)
							else if( (value[dot1 + 1] == 'R' || value[dot1 + 1] == 'r') &&
								cpRivals::fldagent[i]->Type != TypeGene &&
								cpRivals::fldagent[i]->Type != TypeRepr && 
								cpRivals::fldagent[i]->Type != TypeTerm )
									cpRivals::fldparam[i] = 'R';		// Polymerase rate
							else if( (value[dot1 + 1] == 'S' || value[dot1 + 1] == 's') && 
								cpRivals::fldagent[i]->Type == TypePEP )
									cpRivals::fldparam[i] = 'S';		// Sigma
							else if( (value[dot1 + 1] == 'T' || value[dot1 + 1] == 't') && 
								cpRivals::fldagent[i]->Type == TypeGene )
									cpRivals::fldparam[i] = 'T';		// Transcribed
							else if( (value[dot1 + 1] == 'U' || value[dot1 + 1] == 'u') && 
								cpRivals::fldagent[i]->Type == TypeGene )
									cpRivals::fldparam[i] = 'U';		// TotalTrans
							else if( (value[dot1 + 1] == 'X' || value[dot1 + 1] == 'x') && 
								cpRivals::fldagent[i]->Type == TypeTerm )
									cpRivals::fldparam[i] = 'X';		// SenseKor (Term)
							else if( (value[dot1 + 1] == 'Y' || value[dot1 + 1] == 'y') && 
								cpRivals::fldagent[i]->Type == TypeNEP )
									cpRivals::fldparam[i] = 'Y';		// Polym
							else if( (value[dot1 + 1] == 'Z' || value[dot1 + 1] == 'z') && 
								cpRivals::fldagent[i]->Type == TypeTerm )
									cpRivals::fldparam[i] = 'Z';		// SenseRpo (Term)
							else {
								sprintf(msg, "Invalid parameter name \"%s\" in job line %d.", 
									value + dot1 + 1, cpRivals::jobline);
								delete [] agname;
								throw msg;
							}
						}
						value = strtok(NULL, delim);
						if( value == NULL ) break;
					}
					delete [] agname;
					if( i >= MAXFIELD ) { 
						sprintf(msg, "MAXFIELD overflow in the Names statement");
						throw msg;
					}
					cpRivals::fldcount = i + 1;
					cpRivals::customcsv = true;
					continue;
				}
				if( stricmp(key, "Dynamic")==0 ) {			// Dynamic parameter changes
					if( ! cpRivals::taskloaded ) {
						char *curline = line + strlen(line) + 1;	// skip key
						curline[strlen(curline)] = delim[0];		// restore value
						LoadTask(cpRivals::tskfilename);	// sets taskloaded flag if success
						value = strtok(curline, delim);
					}
					if( ! cpRivals::taskloaded ) {
						sprintf(msg, "Cannot apply dynamics because no task is loaded.");
						throw msg;
					}
					char *agname = new char[AGENTNAMELEN];
					agname[0] = 0;
					size_t dot1 = strcspn(value, fldelim);
					if( value[dot1] ) {
						size_t dot2 = strcspn(value + dot1 + 1, fldelim);
						if( value[dot1 + dot2 + 1] ) {
							sprintf(msg, "Cannot parse field name \"%s\" in job line %d.", 
								value, cpRivals::jobline);
							delete [] agname;
							throw msg;
						}
						memcpy(agname, value, dot1);
						agname[dot1] = 0;
					}
					Agent *agent = cpRivals::task->findAgent(agname);
					cpRivals::Dyn[numdyn].agent = agent;
					delete [] agname;
					if( !agent || agent->Type==TypeHolo || agent->Type==TypeKor || agent->Type==TypeRpo ) {
						sprintf(msg, "Invalid agent name \"%s\" in job line %d.", 
							value, cpRivals::jobline);
						delete [] agname;
						throw msg;
					}
					else if( (value[dot1 + 1] == 'A' || value[dot1 + 1] == 'a') && agent->Type == TypePEP )
						cpRivals::Dyn[numdyn].parnum = Aborting;
					else if( (value[dot1 + 1] == 'B' || value[dot1 + 1] == 'b') && agent->Type != TypeGene )
						cpRivals::Dyn[numdyn].parnum = Bound;
					else if( (value[dot1 + 1] == 'C' || value[dot1 + 1] == 'c') &&
						agent->Type != TypeGene && agent->Type != TypeRepr && agent->Type != TypeTerm )
							cpRivals::Dyn[numdyn].parnum = Tcenter;
					else if( (value[dot1 + 1] == 'E' || value[dot1 + 1] == 'e') && agent->Type == TypeGene )
						cpRivals::Dyn[numdyn].parnum = InitP;
					else if( (value[dot1 + 1] == 'F' || value[dot1 + 1] == 'f') && agent->Type == TypeGene )
						cpRivals::Dyn[numdyn].parnum = InitN;
					else if( (value[dot1 + 1] == 'G' || value[dot1 + 1] == 'g') && agent->Type == TypePEP )
						cpRivals::Dyn[numdyn].parnum = AbortRange;
					else if( (value[dot1 + 1] == 'H' || value[dot1 + 1] == 'h') && agent->Type == TypePEP )
						cpRivals::Dyn[numdyn].parnum = SigLength;
					else if( (value[dot1 + 1] == 'I' || value[dot1 + 1] == 'i') && agent->Type == TypeGene )
						cpRivals::Dyn[numdyn].parnum = Initiated;
					else if( (value[dot1 + 1] == 'J' || value[dot1 + 1] == 'j') && agent->Type == TypeGene )
						cpRivals::Dyn[numdyn].parnum = TotalInit;
					else if( (value[dot1 + 1] == 'L' || value[dot1 + 1] == 'l') && agent->Type != TypeGene )
						cpRivals::Dyn[numdyn].parnum = Lambda;
					else if( (value[dot1 + 1] == 'M' || value[dot1 + 1] == 'm') && agent->Type == TypeRepr )
						cpRivals::Dyn[numdyn].parnum = Qmain;
					else if( (value[dot1 + 1] == 'N' || value[dot1 + 1] == 'n') && agent->Type == TypeGene )
						cpRivals::Dyn[numdyn].parnum = TransN;
					else if( (value[dot1 + 1] == 'O' || value[dot1 + 1] == 'o') && agent->Type != TypeGene )
						cpRivals::Dyn[numdyn].parnum = Offered;
					else if( (value[dot1 + 1] == 'P' || value[dot1 + 1] == 'p') && agent->Type == TypeGene )
						cpRivals::Dyn[numdyn].parnum = TransP;
					else if( (value[dot1 + 1] == 'Q' || value[dot1 + 1] == 'q') && agent->Type == TypeRepr )
						cpRivals::Dyn[numdyn].parnum = Qcomp;
					else if( (value[dot1 + 1] == 'R' || value[dot1 + 1] == 'r') &&
						agent->Type != TypeGene && agent->Type != TypeRepr && agent->Type != TypeTerm )
							cpRivals::Dyn[numdyn].parnum = Rate;
					else if( (value[dot1 + 1] == 'S' || value[dot1 + 1] == 's') && agent->Type == TypePEP )
						cpRivals::Dyn[numdyn].parnum = Sigma;
					else if( (value[dot1 + 1] == 'T' || value[dot1 + 1] == 't') && agent->Type == TypeGene )
						cpRivals::Dyn[numdyn].parnum = Transcribed;
					else if( (value[dot1 + 1] == 'U' || value[dot1 + 1] == 'u') && agent->Type == TypeGene )
						cpRivals::Dyn[numdyn].parnum = TotalTrans;
					else if( (value[dot1 + 1] == 'X' || value[dot1 + 1] == 'x') && agent->Type == TypeTerm )
						cpRivals::Dyn[numdyn].parnum = SenseKor;
					else if( (value[dot1 + 1] == 'Y' || value[dot1 + 1] == 'y') && agent->Type == TypeNEP )
						cpRivals::Dyn[numdyn].parnum = Polym;
					else if( (value[dot1 + 1] == 'Z' || value[dot1 + 1] == 'z') && agent->Type == TypeTerm )
						cpRivals::Dyn[numdyn].parnum = SenseRpo;
					else {
						sprintf(msg, "Invalid parameter name \"%s\" in job line %d.", 
							value + dot1 + 1, cpRivals::jobline);
						delete [] agname;
						throw msg;
					}
					cpRivals::Dyn[numdyn].operation = cpRivals::Set;
					int i = 0;
					for( ; i<MAXDSTEP; i++ ) {
						value = strtok(NULL, delim);
						if( value == NULL ) break;
						Dyn[numdyn].modtime[i] = (int)floor( atof(value) * 60 );	// because 0.1m > 1s
						value = strtok(NULL, delim);
						if( value == NULL ) {
							sprintf(msg, "Value absent in the Dynamic statement");
							throw msg;
						}
						Dyn[numdyn].val1[i] = atof(value);
					}
					if( i >= MAXDSTEP ) { 
						sprintf(msg, "MAXDSTEP overflow in the Dynamic statement");
						throw msg;
					}
					numdyn++;
					continue;
				}
				if( stricmp(key, "DynLinear")==0 ) {		// Dynamic parameter changes
					if( ! cpRivals::taskloaded ) {
						char *curline = line + strlen(line) + 1;	// skip key
						curline[strlen(curline)] = delim[0];		// restore value
						LoadTask(cpRivals::tskfilename);	// sets taskloaded flag if success
						value = strtok(curline, delim);
					}
					if( ! cpRivals::taskloaded ) {
						sprintf(msg, "Cannot apply dynamics because no task is loaded.");
						throw msg;
					}
					char *agname = new char[AGENTNAMELEN];
					agname[0] = 0;
					size_t dot1 = strcspn(value, fldelim);
					if( value[dot1] ) {
						size_t dot2 = strcspn(value + dot1 + 1, fldelim);
						if( value[dot1 + dot2 + 1] ) {
							sprintf(msg, "Cannot parse field name \"%s\" in job line %d.", 
								value, cpRivals::jobline);
							delete [] agname;
							throw msg;
						}
						memcpy(agname, value, dot1);
						agname[dot1] = 0;
					}
					Agent *agent = cpRivals::task->findAgent(agname);
					cpRivals::Dyn[numdyn].agent = agent;
					delete [] agname;
					if( !agent || agent->Type==TypeHolo || agent->Type==TypeKor || agent->Type==TypeRpo ) {
						sprintf(msg, "Invalid agent name \"%s\" in job line %d.", 
							value, cpRivals::jobline);
						delete [] agname;
						throw msg;
					}
					else if( (value[dot1 + 1] == 'A' || value[dot1 + 1] == 'a') && agent->Type == TypePEP )
						cpRivals::Dyn[numdyn].parnum = Aborting;
					else if( (value[dot1 + 1] == 'B' || value[dot1 + 1] == 'b') && agent->Type != TypeGene )
						cpRivals::Dyn[numdyn].parnum = Bound;
					else if( (value[dot1 + 1] == 'C' || value[dot1 + 1] == 'c') &&
						agent->Type != TypeGene && agent->Type != TypeRepr && agent->Type != TypeTerm )
							cpRivals::Dyn[numdyn].parnum = Tcenter;
					else if( (value[dot1 + 1] == 'E' || value[dot1 + 1] == 'e') && agent->Type == TypeGene )
						cpRivals::Dyn[numdyn].parnum = InitP;
					else if( (value[dot1 + 1] == 'F' || value[dot1 + 1] == 'f') && agent->Type == TypeGene )
						cpRivals::Dyn[numdyn].parnum = InitN;
					else if( (value[dot1 + 1] == 'G' || value[dot1 + 1] == 'g') && agent->Type == TypePEP )
						cpRivals::Dyn[numdyn].parnum = AbortRange;
					else if( (value[dot1 + 1] == 'H' || value[dot1 + 1] == 'h') && agent->Type == TypePEP )
						cpRivals::Dyn[numdyn].parnum = SigLength;
					else if( (value[dot1 + 1] == 'I' || value[dot1 + 1] == 'i') && agent->Type == TypeGene )
						cpRivals::Dyn[numdyn].parnum = Initiated;
					else if( (value[dot1 + 1] == 'J' || value[dot1 + 1] == 'j') && agent->Type == TypeGene )
						cpRivals::Dyn[numdyn].parnum = TotalInit;
					else if( (value[dot1 + 1] == 'L' || value[dot1 + 1] == 'l') && agent->Type != TypeGene )
						cpRivals::Dyn[numdyn].parnum = Lambda;
					else if( (value[dot1 + 1] == 'M' || value[dot1 + 1] == 'm') && agent->Type == TypeRepr )
						cpRivals::Dyn[numdyn].parnum = Qmain;
					else if( (value[dot1 + 1] == 'N' || value[dot1 + 1] == 'n') && agent->Type == TypeGene )
						cpRivals::Dyn[numdyn].parnum = TransN;
					else if( (value[dot1 + 1] == 'O' || value[dot1 + 1] == 'o') && agent->Type != TypeGene )
						cpRivals::Dyn[numdyn].parnum = Offered;
					else if( (value[dot1 + 1] == 'P' || value[dot1 + 1] == 'p') && agent->Type == TypeGene )
						cpRivals::Dyn[numdyn].parnum = TransP;
					else if( (value[dot1 + 1] == 'Q' || value[dot1 + 1] == 'q') && agent->Type == TypeRepr )
						cpRivals::Dyn[numdyn].parnum = Qcomp;
					else if( (value[dot1 + 1] == 'R' || value[dot1 + 1] == 'r') &&
						agent->Type != TypeGene && agent->Type != TypeRepr && agent->Type != TypeTerm )
							cpRivals::Dyn[numdyn].parnum = Rate;
					else if( (value[dot1 + 1] == 'S' || value[dot1 + 1] == 's') && agent->Type == TypePEP )
						cpRivals::Dyn[numdyn].parnum = Sigma;
					else if( (value[dot1 + 1] == 'T' || value[dot1 + 1] == 't') && agent->Type == TypeGene )
						cpRivals::Dyn[numdyn].parnum = Transcribed;
					else if( (value[dot1 + 1] == 'U' || value[dot1 + 1] == 'u') && agent->Type == TypeGene )
						cpRivals::Dyn[numdyn].parnum = TotalTrans;
					else if( (value[dot1 + 1] == 'X' || value[dot1 + 1] == 'x') && agent->Type == TypeTerm )
						cpRivals::Dyn[numdyn].parnum = SenseKor;
					else if( (value[dot1 + 1] == 'Y' || value[dot1 + 1] == 'y') && agent->Type == TypeNEP )
						cpRivals::Dyn[numdyn].parnum = Polym;
					else if( (value[dot1 + 1] == 'Z' || value[dot1 + 1] == 'z') && agent->Type == TypeTerm )
						cpRivals::Dyn[numdyn].parnum = SenseRpo;
					else {
						sprintf(msg, "Invalid parameter name \"%s\" in job line %d.", 
							value + dot1 + 1, cpRivals::jobline);
						delete [] agname;
						throw msg;
					}
					cpRivals::Dyn[numdyn].operation = cpRivals::Linear;
					int i = 0;
					for( ; i<MAXDSTEP; i++ ) {
						value = strtok(NULL, delim);
						if( value == NULL ) break;
						Dyn[numdyn].modtime[i] = (int)floor( atof(value) * 60 );	// because 0.1m > 1s
						value = strtok(NULL, delim);
						if( value == NULL ) {
							sprintf(msg, "Value1 absent in the DynLinear statement");
							throw msg;
						}
						Dyn[numdyn].val1[i] = atof(value);
						value = strtok(NULL, delim);
						if( value == NULL ) {
							sprintf(msg, "Value2 absent in the DynLinear statement");
							throw msg;
						}
						Dyn[numdyn].val2[i] = atof(value);
					}
					if( i >= MAXDSTEP ) { 
						sprintf(msg, "MAXDSTEP overflow in the Dynamic statement");
						throw msg;
					}
					numdyn++;
					continue;
				}
				else {
					sprintf(msg, "Invalid key \"%s\" in the job file line %d.", key, cpRivals::jobline); 
					throw msg;
				}
			}
			if( ferror(rrjb) || feof(rrjb) ) {		//	EOF reached or I/O error
				sprintf(msg, "End of job file or I/O error in line %d.", cpRivals::jobline); 
				throw msg;
			}
			if(cpRivals::fldcount == 0) {		// There was no Record statement in the job file
				int j = 0;
				if(cpRivals::Runs > 1) {				// # field
					cpRivals::fldagent[j] = NULL; cpRivals::fldparam[j++] = '#';
				}
				for(int i = 0; i < cpRivals::task->NumAgents; i++ ) {
					Agent* agent = cpRivals::task->getAgent(i);
					if( !agent->Enabled ) continue;
					if(agent->Type == TypeGene) {
						if(cpRivals::joint) {
							cpRivals::fldagent[j] = agent; cpRivals::fldparam[j++] = 'T';
						}
						else {
							cpRivals::fldagent[j] = agent; cpRivals::fldparam[j++] = 'P';
							cpRivals::fldagent[j] = agent; cpRivals::fldparam[j++] = 'N';
						}
						if(cpRivals::config.Both) {
							if(cpRivals::joint) {
								cpRivals::fldagent[j] = agent; cpRivals::fldparam[j++] = 'I';
							}
							else {
								cpRivals::fldagent[j] = agent; cpRivals::fldparam[j++] = 'E';
								cpRivals::fldagent[j] = agent; cpRivals::fldparam[j++] = 'F';
							}
						}
					}
					else {		// all task agents but genes
						cpRivals::fldagent[j] = agent; cpRivals::fldparam[j++] = 'B';
						if(cpRivals::config.Both) {
							cpRivals::fldagent[j] = agent; cpRivals::fldparam[j++] = 'O';
						}
					}
				}
				cpRivals::fldcount = j;
			}
			newoffset = ftell(rrjb);
			delete [] line; delete [] msg;
			if( rrjb ) fclose(rrjb);
			return newoffset;
		}
		else {								// subsequent calls
         if( fseek(rrjb, *offset, SEEK_SET) ) {
				sprintf(msg, "Cannot seek job line %d (offset %ld).", cpRivals::jobline + 1, *offset); 
				throw msg;
			}
			while( fgets(line, FILEBUFLEN, rrjb) ) {
				cpRivals::jobline ++;
				char* key = strtok(line, delim);
				if( key == NULL || key[0] == ';' || key[0] == '/' ) {
					*offset = ftell(rrjb);
					continue;	// skip empty/comment lines until job/debug line
				}
				else if( stricmp(key, "Debug")==0 ) { // Debug {[Run[Queue[Start[Stop[Mode]]]]] | Off | Mode...}
					cpRivals::debugline = true;
					key = strtok(NULL, delim);
					if( key ) {
						if( stricmp(key, "Off") == 0 ) {
							cpRivals::Quelen = 3; cpRivals::Logstart = 0; cpRivals::Logstop = 0;
							cpRivals::Logrun = 1; cpRivals::Logmode = 0x00003FFE;
						}
						else if( stricmp(key, "Mode") == 0 ) {
							cpRivals::Logmode = 0;
							while( (key = strtok(NULL, delim)) ) {
								if( stricmp(key, "All") == 0 ) cpRivals::Logmode |= All;
								else if( stricmp(key, "GeneInitiated")==0 || stricmp(key, "GeneI")==0 ) 
									cpRivals::Logmode |= GeneInitiated;
								else if( stricmp(key, "GeneTranscribed")==0 || stricmp(key, "GeneT")==0 ) 
									cpRivals::Logmode |= GeneTranscribed;
								else if( stricmp(key, "PEPOffered")==0 || stricmp(key, "PEPO")==0 ) 
									cpRivals::Logmode |= PEPOffered;
								else if( stricmp(key, "PEPBound")==0 || stricmp(key, "PEPB")==0 ) 
									cpRivals::Logmode |= PEPBound;
								else if( stricmp(key, "NEPOffered")==0 || stricmp(key, "NEPO")==0 ) 
									cpRivals::Logmode |= NEPOffered;
								else if( stricmp(key, "NEPBound")==0 || stricmp(key, "NEPB")==0 ) 
									cpRivals::Logmode |= NEPBound;
								else if( stricmp(key, "Collision")==0 || stricmp(key, "Coll")==0 ) 
									cpRivals::Logmode |= Collision;
								else if( stricmp(key, "ReprOffered")==0 || stricmp(key, "ReprO")==0 ) 
									cpRivals::Logmode |= ReprOffered;
								else if( stricmp(key, "ReprBound")==0 || stricmp(key, "ReprB")==0 ) 
									cpRivals::Logmode |= ReprBound;
								else if( stricmp(key, "EKorOffered")==0 || stricmp(key, "EKorO")==0 ) 
									cpRivals::Logmode |= EKorOffered;
								else if( stricmp(key, "EKorBound")==0 || stricmp(key, "EKorB")==0 ) 
									cpRivals::Logmode |= EKorBound;
								else if( stricmp(key, "ERpoOffered")==0 || stricmp(key, "ERpoO")==0 ) 
									cpRivals::Logmode |= ERpoOffered;
								else if( stricmp(key, "ERpoBound")==0 || stricmp(key, "ERpoB")==0 ) 
									cpRivals::Logmode |= ERpoBound;
								else cpRivals::Logmode |= atoi(key);
							}
						}
						else {
							cpRivals::Logrun = atoi(key);
							key = strtok(NULL, delim);
							if( key ) {
								cpRivals::Quelen = atoi(key);
								key = strtok(NULL, delim);
								if( key ) {
									cpRivals::Logstart = atoi(key);
									key = strtok(NULL, delim);
									if( key ) {
										cpRivals::Logstop = atoi(key);
										key = strtok(NULL, delim);
										if( key ) {
											cpRivals::Logmode = atoi(key);
										}
										else cpRivals::Logmode = 0x00003FFE;
									}
									else { cpRivals::Logstop = 0; cpRivals::Logmode = 0x00003FFE; }
								}
								else { cpRivals::Logstart = 1; cpRivals::Logstop = 0; cpRivals::Logmode = 0x00003FFE; }
							}
							else {
								cpRivals::Quelen = 3; cpRivals::Logmode = 0x00003FFE;
								cpRivals::Logstart = 1; cpRivals::Logstop = 0;
							}
						}
					}
					else {
						cpRivals::Quelen = 3; cpRivals::Logstart = 1; cpRivals::Logstop = 0;
						cpRivals::Logrun = 1; cpRivals::Logmode = 0x00003FFE;
					}
					break;
				}
				else {				// Usual job line
					cpRivals::debugline = false;
               bool allzeroes = true;
					for( int i=0; i<cpRivals::varcount; i++ ) {		// Set parameter values from this job line
						if( key == NULL ) {
							sprintf(msg, "Not enough parameters in job line %d.", cpRivals::jobline);
							throw msg;
						}
						cpRivals::varvalue[i] = atof(key);
                  if( cpRivals::varvalue[i] != 0.0 ) allzeroes = false;
						key = strtok(NULL, delim);
					}
					if( key ) {
						sprintf(msg, "Too many parameters in job line %d.", cpRivals::jobline);
						throw msg;
					}
               if( allzeroes ) continue;     // Skip nonumber lines silently
					break;
				}
			}
			if( feof(rrjb) ) return 0L;	//	EOF reached
			if( ferror(rrjb) ) {				//	I/O error in job file
				sprintf(msg, "Job file I/O error in line %d.", cpRivals::jobline); 
				throw msg;
			}
			newoffset = ftell(rrjb);
			delete [] line; delete [] msg;
			if( rrjb ) fclose(rrjb);
			return newoffset;
		}
	}
	catch (char *err) {
		char *msg = new char[MSGLEN];
		sprintf(msg, "[%04d] %s\n", cpRivals::myid, err);
		if( cpRivals::myid == 0 ) { fprintf(stderr, "%s", msg); fflush(stderr); }
        #ifdef PARALLEL
		else if( cpRivals::collect ) 
			MPI::COMM_WORLD.Send(msg, (int)strlen(msg)+1, MPI::CHAR, root, cpRivals::tagInfo);
        #endif
		delete [] line; delete [] msg;
		if( rrjb ) fclose(rrjb);
		return -1L;
	}
}

// Mark job at the given offset as done
// Returns: OK=false, Error=true
bool cpRivals::MarkJobDone(char* filename, long offset) {
	if( cpRivals::jobmarking == false ) return false;
	FILE* urjb = NULL;
	char* msg = new char[MSGLEN];
	try {
		if( strlen(filename)==0 ) {
			sprintf(msg, "Empty name of job file."); 
			throw msg;
		}
		urjb = fopen(filename, "r+t");
		if( urjb == NULL ) {
			sprintf(msg, "Cannot reopen job file \"%s\".", filename);
			throw msg;
		}
      if( fseek(urjb, offset, SEEK_SET) ) {
			sprintf(msg, "Cannot seek job file to offset %ld.", offset);
			throw msg;
		}
		if( fputc(';', urjb) == EOF ) {
			sprintf(msg, "Cannot write job file at offset %ld.", offset);
			throw msg;
		}
		if( urjb ) fclose(urjb);
		delete [] msg;
		return false;
	}
	catch (char *err) {
		char* msg1 = new char[MSGLEN];
		sprintf(msg1, "[%04d] %s\n", cpRivals::myid, err);
		delete [] err;
		if( cpRivals::myid == 0 ) { fprintf(stderr, "%s", msg1); fflush(stderr); }
        #ifdef PARALLEL
		else if( cpRivals::collect )
			MPI::COMM_WORLD.Send(msg1, (int)strlen(msg1)+1, MPI::CHAR, root, cpRivals::tagInfo);
        #endif
		if( urjb ) fclose(urjb);
		delete [] msg1;
		return true;
	}
}

// Returns the number of executed runs in the current csv file or -1 (if errors)
// Also, calculates and sets totals for all genes of the task
int cpRivals::CountRunsDone(FILE* wcsv0) {
	char* line = new char[FILEBUFLEN];
	char* msg = new char[MSGLEN];
	int runs = 0;
	char delim[2] = {cpRivals::config.Delimiter,'\0'};
	char* p;
	try {
      if( fseek(wcsv0, 0L, SEEK_SET) ) {
			sprintf(line, "Cannot rewind current csv file."); 
			throw line;
		}
		while( fgets(line, FILEBUFLEN, wcsv0) ) {
			if( cpRivals::regular ) {						// skip intermediate output
				p = strrchr(line, cpRivals::config.Delimiter);
				if( p == NULL ) continue; 
				else *p = 0;
				p = strrchr(line, cpRivals::config.Delimiter);
				if( p == NULL ) continue; 
				int minutes = atoi(p+1);
				if( minutes*60 < cpRivals::config.PhysicalTime )
					continue;
			}
			p = strtok(line, delim);						// parse final output record
			if( p == NULL ) {
				sprintf(line, "Invalid record in current csv file (error 3)."); 
				throw line;
			}
			int i = 1;
			for( ; i<cpRivals::varcount; i++ )			// skip parameters
				if( strtok(NULL, delim) == NULL ) {
					sprintf(line, "Invalid record in current csv file (error 4)."); 
					throw line;
				}
			for( i=0; i<cpRivals::fldcount; i++ ) {	// set counters for genes
				p = strtok(NULL, delim);
				if( p == NULL ) {
					sprintf(line, "Invalid record in current csv file (error 5)."); 
					throw line;
				}
				if( cpRivals::fldagent[i] == NULL || cpRivals::fldagent[i]->Type != TypeGene )
					continue;
				Gene* gene = (Gene*)cpRivals::fldagent[i];
				if( cpRivals::fldparam[i] == 'I' )			gene->Initiated = atoi(p);
				else if( cpRivals::fldparam[i] == 'E' )	gene->InitP = atoi(p);
				else if( cpRivals::fldparam[i] == 'F' )	gene->InitN = atoi(p);
				else if( cpRivals::fldparam[i] == 'T' )	gene->Transcribed = atoi(p);
				else if( cpRivals::fldparam[i] == 'P' )	gene->TransP = atoi(p);
				else if( cpRivals::fldparam[i] == 'N' )	gene->TransN = atoi(p);
			}
			for( i=0; i<cpRivals::task->NumAgents; i++ ) {		// accumulate totals for genes
				Agent* agent = cpRivals::task->getAgent(i);
				if( agent->Type == TypeGene )
					((Gene*)agent)->Accumulate();
			}
			runs ++;
		}
		if( ferror(wcsv0) ) {
			sprintf(line, "I/O error in the current csv file."); 
			throw line;
		}
	}
	catch (char *err) {
		char *msg = new char[MSGLEN];
		sprintf(msg, "[%04d] %s\n", cpRivals::myid, err);
		if( cpRivals::myid == 0 ) { fprintf(stderr, "%s", msg); fflush(stderr); }
        #ifdef PARALLEL
		else if( cpRivals::collect )
			MPI::COMM_WORLD.Send(msg, (int)strlen(msg)+1, MPI::CHAR, root, cpRivals::tagInfo);
        #endif
		delete [] line; delete [] msg;
		return -1;
	}
	delete [] line; delete [] msg;
	return runs;
}
