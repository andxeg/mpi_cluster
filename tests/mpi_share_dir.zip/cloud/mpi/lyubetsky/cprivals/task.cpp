// cpRivals: Model of the regulation by competing promoters.
//
// Copyright (C) 2009-2012 Lev Rubanov <rubanov@iitp.ru>
// Copyright (C) 2009-2012 Institute for Information Transmission Problems of
// the Russian Academy of Sciences (Kharkevich Institute) <http://www.iitp.ru>
//
// This model has been proposed and implemented in the Laboratory of 
// Mathematical Methods and Models in Bioinformatics of the above Institute.
// Head of the Laboratory, Prof. Vassily Lyubetsky <lyubetsky@iitp.ru>
//   
// This file is part of cpRivals.
//
// cpRivals is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// cpRivals is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with cpRivals. If not, see <http://www.gnu.org/licenses/>.
//
// Functions: LoadTask, SetCurrentParameters
//
#include "cprivals.h"

#ifdef _MSC_VER
#if _MSC_VER >= 1300
#pragma warning(disable: 4996)
#endif
#endif

// Load task file and set taskloaded flag. Returns: true=OK, false=errors
bool cpRivals::LoadTask(char* filename) {
	FILE *rtsk = NULL;
	char* line = new char[FILEBUFLEN];
	char* msg = new char[MSGLEN];
	try {
		Task* tsk = new Task;
		cpRivals::task = tsk;
		if( strlen(filename) == 0 ) {
			sprintf(line, "Empty name of the task file."); throw line;
		}
		rtsk = fopen(filename, "rt");
		if( ! rtsk ) {
			sprintf(line, "Cannot open configuration file \"%s\".", filename);
			throw line;
		}
		int num = 0, curlen = 0;
		char delim[] = "=,: \t\n\r";
		while( fgets(line, FILEBUFLEN, rtsk) ) {
			num++;
			char* key = strtok(line, delim);
			char* value = NULL;
			if( key==NULL || key[0]==';' || key[0]=='/' ) 
				continue;
			if( stricmp(key, "Version") == 0 ) { 
				value = strtok(NULL, delim);
				if( stricmp(value, VERSION) ) {
					sprintf(msg, "[%04d] Warning: Task and program versions mismatch.\n", cpRivals::myid);
					if( cpRivals::myid == 0 ) { fprintf(stderr, "%s", msg ); fflush(stderr); }
                    #ifdef PARALLEL
					else if( cpRivals::collect ) 
						MPI::COMM_WORLD.Send(msg, (int)strlen(msg)+1, MPI::CHAR, root, cpRivals::tagInfo);
                    #endif
				}
				continue; 
			}
			if( stricmp(key, "[DNA") == 0 ) {		// [DNA...] section
				int len = 0;
				while( fgets(line, FILEBUFLEN, rtsk) ) {
					num++;
					key = strtok(line, delim);
					if( key==NULL || key[0]==';' || key[0]=='/' ) 
						continue;
					if( key[0] == '[' ) break;				// goto to next section
					if( stricmp(key, "Length") == 0 ) {	// Length=
						value = strtok(NULL, delim);
						if( value == NULL ) {
							sprintf(line, "DNA length value missed in the task file."); 
							throw line;
						}
						len = atoi(value);
						if( cpRivals::task->Sequence ) delete [] task->Sequence;
						cpRivals::task->Sequence = new char[len];
						cpRivals::task->SeqLength = len;
						continue;
					}
					#ifdef CIRCULAR
					if( stricmp(key, "Circular") == 0 ) { // Circular=
						value = strtok(NULL, delim);
						if( value == NULL ) {
							sprintf(line, "Circular mode value missed in the task file."); 
							throw line;
						}
						if( stricmp(value, "True") == 0 ) {
							if( !cpRivals::task->Sequence || cpRivals::task->SeqLength <= 0 ) {
								sprintf(line, "Unknown length of circular sequence."); 
								throw line;
							}
							cpRivals::task->Circular = cpRivals::task->SeqLength;
						}
						else
							cpRivals::task->Circular = 0;
						continue;
					}
					#endif
					while( (value = strtok(NULL, delim)) != NULL ) {
						char base[] = "acgturymkswhbvdn?x";		// IUPAC-IUB + {?,X}
					//	char base[] = "acgt";
						if( curlen >= len ) { 
							sprintf(line, "DNA sequence length exceeds specified value.");
							throw line;
						}
						for( int k=0; value[k] && curlen<len; k++ ) {
							if( strchr("-_*", value[k]) ) continue;
							char c = tolower(value[k]);
							if( strchr(base, c) ) 
								cpRivals::task->Sequence[curlen++] = c;
							else { 
								sprintf(msg, "[%04d] Bad character '%c'=%x in the sequence ignored (task line %d).\n",
									cpRivals::myid, value[k], value[k], num);
								if( cpRivals::myid == 0 ) { fprintf(stderr, "%s", msg); fflush(stderr); }
                                #ifdef PARALLEL
								else if( cpRivals::collect )
									MPI::COMM_WORLD.Send(msg, (int)strlen(msg)+1, MPI::CHAR, root, cpRivals::tagInfo);
                                #endif
							}
						}
					} 
				}
				if( feof(rtsk) || ferror(rtsk) ) {
					sprintf(line, "End of task file or I/O error in line %d.", num);
					throw line;
				}
				if( curlen != len ) {
					sprintf(line, "Inconsistent sequence length (%d <> %d).", curlen, len);
					throw line;
				}
			}
			while( key && key[0] == '[' ) {			// Agent specific input
				if( stricmp(key, "[Gene]") == 0 ) {				// [Gene] section
					Gene* gene = new Gene;
					while( fgets(line, FILEBUFLEN, rtsk) ) {
						num++;
						key = strtok(line, delim);
						if( key==NULL || key[0]==';' || key[0]=='/' ) 
							continue;
						if( key[0] == '[' ) break; 					// goto next section
						value = strtok(NULL, delim);
						if( value == NULL ) continue;
						if( stricmp(key, "Name") == 0 ) {			// Name=
							strncpy(gene->Name, value, AGENTNAMELEN-1); gene->Name[AGENTNAMELEN-1] = 0;
							int curlen = (int)strlen(gene->Name);
							while( (value = strtok(NULL, delim)) ) {
								if( curlen + strlen(value) >= AGENTNAMELEN ) {
									sprintf(line, "AGENTNAMELEN overflow in the task line %d.", num); 
									throw line;
								}
								gene->Name[curlen++] = ' ';
								strcpy(gene->Name + curlen, value);
								curlen += (int)strlen(value);
							}
							continue;
						}
						if( stricmp(key, "Strand") == 0 ) {			// Strand=
							gene->Strand = stricmp(value, "True") ? false : true;
							continue;
						}
						if( stricmp(key, "Display") == 0 ) 			// Display=
							continue;
						if( stricmp(key, "Enabled") == 0 ) {		// Enabled=
							gene->Enabled = stricmp(value, "True") ? false : true;
							continue;
						}
						if( stricmp(key, "Begin") == 0 || stricmp(key, "Left") == 0 ) {	// Begin=
							gene->Begin = atoi(value) - cpRivals::Origin;	// cvt to zero-based
							if( gene->Begin < 0 ) 
								gene->Begin += cpRivals::task->SeqLength;
							continue;
						}
						if( stricmp(key, "End") == 0 || stricmp(key, "Right") == 0 ) {		// End=
							gene->End = atoi(value) - cpRivals::Origin;		// cvt to zero-based
							if( gene->End < 0 )
								gene->End += cpRivals::task->SeqLength;
							continue;
						}
						if( stricmp(key, "Comment") == 0 ) 			// Comment=
							continue;
						if( stricmp(key, "Color")==0 )				// Color=
							continue;
						sprintf(msg, "[%04d] Unknown Gene parameter \"%s\" in task line %d ignored.\n", 
							cpRivals::myid, key, num);
						if( cpRivals::myid == 0 ) { fprintf(stderr, "%s", msg); fflush(stderr); }
                        #ifdef PARALLEL
						else if( cpRivals::collect ) 
							MPI::COMM_WORLD.Send(msg, (int)strlen(msg)+1, MPI::CHAR, root, cpRivals::tagInfo);
                        #endif
					}
					if( ferror(rtsk) ) {
						sprintf(line, "Task file I/O error in line %d.", num);
						throw line;
					}
					if( cpRivals::task->addAgent(gene) ) { delete gene; gene = NULL; }
					if( feof(rtsk) ) break;
					continue;
				}
				else if( stricmp(key, "[PEP]") == 0 ) {	// [PEP] section
					PEP* pep = new PEP;
					while( fgets(line, FILEBUFLEN, rtsk) ) {
						num++;
						key = strtok(line, delim);
						if( key==NULL || key[0]==';' || key[0]=='/' ) 
							continue;
						if( key[0] == '[' ) break; 					// goto next section
						value = strtok(NULL, delim);
						if( value == NULL ) continue;
						if( stricmp(key, "Name") == 0 ) {			// Name=
							strncpy(pep->Name, value, AGENTNAMELEN-1); pep->Name[AGENTNAMELEN-1] = 0;
							int curlen = (int)strlen(pep->Name);
							while( (value = strtok(NULL, delim)) ) {
								if( curlen + strlen(value) >= AGENTNAMELEN ) {
									sprintf(line, "AGENTNAMELEN overflow in the task line %d.", num); 
									throw line;
								}
								pep->Name[curlen++] = ' ';
								strcpy(pep->Name + curlen, value);
								curlen += (int)strlen(value);
							}
							continue;
						}
						if( stricmp(key, "Strand") == 0 ) {			// Strand=
							pep->Strand = stricmp(value, "True") ? false : true;
							continue;
						}
						if( stricmp(key, "Display") == 0 )			// Display=
							continue;
						if( stricmp(key, "Enabled") == 0 ) {		// Enabled=
							pep->Enabled = stricmp(value, "True") ? false : true;
							continue;
						}
						if( stricmp(key, "TrPoint") == 0 || stricmp(key, "Tcenter") == 0 ) {		// TrPoint=
							pep->Tcenter = atoi(value) - cpRivals::Origin;		// cvt to zero-based
							if( pep->Tcenter < 0 ) 
								pep->Tcenter += cpRivals::task->SeqLength;
							continue;
						}
						if( stricmp(key, "Sigma") == 0 ) {			// Sigma=
							pep->Sigma = atoi(value);
							continue;
						}
						if( stricmp(key, "SigLength") == 0 ) {		// SigLength
							pep->SigLength = atoi(value);
							continue;
						}
						if( stricmp(key, "Lambda") == 0 ) {			// Lambda=
							pep->Lambda = atof(value);
							continue;
						}
						if( stricmp(key, "Left") == 0 || stricmp(key, "Begin") == 0 ) {	// Left=
							pep->Begin = atoi(value) - cpRivals::Origin;		// cvt to zero-based
							if( pep->Begin < 0 )
								pep->Begin += cpRivals::task->SeqLength;
							continue;
						}
						if( stricmp(key, "Right") == 0 || stricmp(key, "End") == 0 ) {		// Right=
							pep->End = atoi(value) - cpRivals::Origin;		// cvt to zero-based
							if( pep->End < 0 )
								pep->End += cpRivals::task->SeqLength;
							continue;
						}
						if( stricmp(key, "Rate") == 0 ) {			// Rate=
							pep->Rate = atof(value);
							continue;
						}
						if( stricmp(key, "Aborting") == 0 ) {		// Aborting=
							pep->Aborting = atof(value);
							continue;
						}
						if( stricmp(key, "AbortRange") == 0 ) {	// AbortRange=
							pep->AbortRange = atoi(value);
							continue;
						}
						if( stricmp(key, "Comment") == 0 ) 			// Comment=
							continue;
						if( stricmp(key, "Color")==0 )				// Color=
							continue;
						sprintf(msg, "[%04d] Unknown PEP parameter \"%s\" in task line %d ignored.\n", 
							cpRivals::myid, key, num);
						if( cpRivals::myid == 0 ) { fprintf(stderr, "%s", msg); fflush(stderr); }
                        #ifdef PARALLEL
						else if( cpRivals::collect ) 
							MPI::COMM_WORLD.Send(msg, (int)strlen(msg)+1, MPI::CHAR, root, cpRivals::tagInfo);
                        #endif
					}
					if( ferror(rtsk) ) {
						sprintf(line, "Task file I/O error in line %d.", num);
						throw line;
					}
					if( cpRivals::task->addAgent(pep) ) { delete pep; pep = NULL; }
					if( feof(rtsk) ) break;
					continue;
				}
				else if( stricmp(key, "[NEP]") == 0 ) {	// [NEP] section
					NEP* nep = new NEP;
					while( fgets(line, FILEBUFLEN, rtsk) ) {
						num++;
						key = strtok(line, delim);
						if( key==NULL || key[0]==';' || key[0]=='/' ) 
							continue;
						if( key[0] == '[' ) break; 					// goto next section
						value = strtok(NULL, delim);
						if( value == NULL ) continue;
						if( stricmp(key, "Name") == 0 ) {			// Name=
							strncpy(nep->Name, value, AGENTNAMELEN-1); nep->Name[AGENTNAMELEN-1] = 0;
							int curlen = (int)strlen(nep->Name);
							while( (value = strtok(NULL, delim)) ) {
								if( curlen + strlen(value) >= AGENTNAMELEN ) {
									sprintf(line, "AGENTNAMELEN overflow in the task line %d.", num); 
									throw line;
								}
								nep->Name[curlen++] = ' ';
								strcpy(nep->Name + curlen, value);
								curlen += (int)strlen(value);
							}
							continue;
						}
						if( stricmp(key, "Strand") == 0 ) {			// Strand=
							nep->Strand = stricmp(value, "True") ? false : true;
							continue;
						}
						if( stricmp(key, "Display") == 0 )			// Display=
							continue;
						if( stricmp(key, "Enabled") == 0 ) {		// Enabled=
							nep->Enabled = stricmp(value, "True") ? false : true;
							continue;
						}
						if( stricmp(key, "TrPoint") == 0 || stricmp(key, "Tcenter") == 0 ) {		// TrPoint=
							nep->Tcenter = atoi(value) - cpRivals::Origin;		// cvt to zero-based
							if( nep->Tcenter < 0 ) 
								nep->Tcenter += cpRivals::task->SeqLength;
							continue;
						}
						if( stricmp(key, "Polym") == 0 ) {			// Rpo type
							nep->Polym = atoi(value);
							continue;
						}
						if( stricmp(key, "Lambda") == 0 ) {			// Lambda=
							nep->Lambda = atof(value);
							continue;
						}
						if( stricmp(key, "Left") == 0 || stricmp(key, "Begin") == 0 ) {	// Left=
							nep->Begin = atoi(value) - cpRivals::Origin;		// cvt to zero-based
							if( nep->Begin < 0 )
								nep->Begin += cpRivals::task->SeqLength;
							continue;
						}
						if( stricmp(key, "Right") == 0 || stricmp(key, "End") == 0 ) {		// Right=
							nep->End = atoi(value) - cpRivals::Origin;		// cvt to zero-based
							if( nep->End < 0 )
								nep->End += cpRivals::task->SeqLength;
							continue;
						}
						if( stricmp(key, "Rate") == 0 ) {			// Rate=
							nep->Rate = atof(value);
							continue;
						}
						if( stricmp(key, "Comment") == 0 ) 			// Comment=
							continue;
						if( stricmp(key, "Color")==0 )				// Color=
							continue;
						sprintf(msg, "[%04d] Unknown NEP parameter \"%s\" in task line %d ignored.\n", 
							cpRivals::myid, key, num);
						if( cpRivals::myid == 0 ) { fprintf(stderr, "%s", msg); fflush(stderr); }
                        #ifdef PARALLEL
						else if( cpRivals::collect ) 
							MPI::COMM_WORLD.Send(msg, (int)strlen(msg)+1, MPI::CHAR, root, cpRivals::tagInfo);
                        #endif
					}
					if( ferror(rtsk) ) {
						sprintf(line, "Task file I/O error in line %d.", num);
						throw line;
					}
					if( cpRivals::task->addAgent(nep) ) { delete nep; nep = NULL; }
					if( feof(rtsk) ) break;
					continue;
				}
				else if( stricmp(key, "[Repr]") == 0 ) {	// [Repr] section
					Repr* repr = new Repr;
					while( fgets(line, FILEBUFLEN, rtsk) ) {
						num++;
						key = strtok(line, delim);
						if( key==NULL || key[0]==';' || key[0]=='/' ) 
							continue;
						if( key[0] == '[' ) break; 					// goto next section
						value = strtok(NULL, delim);
						if( value == NULL ) continue;
						if( stricmp(key, "Name") == 0 ) {			// Name=
							strncpy(repr->Name, value, AGENTNAMELEN-1); repr->Name[AGENTNAMELEN-1] = 0;
							int curlen = (int)strlen(repr->Name);
							while( (value = strtok(NULL, delim)) ) {
								if( curlen + strlen(value) >= AGENTNAMELEN ) {
									sprintf(line, "AGENTNAMELEN overflow in the task line %d.", num); 
									throw line;
								}
								repr->Name[curlen++] = ' ';
								strcpy(repr->Name + curlen, value);
								curlen += (int)strlen(value);
							}
							continue;
						}
						if( stricmp(key, "Display") == 0 )			// Display=
							continue;
						if( stricmp(key, "Enabled") == 0 ) {		// Enabled=
							repr->Enabled = stricmp(value, "True") ? false : true;
							continue;
						}
						if( stricmp(key, "Begin") == 0 || stricmp(key, "Left") == 0 ) {		// Begin=
							repr->Begin = atoi(value) - cpRivals::Origin;		// cvt to zero-based
							if( repr->Begin < 0 ) 
								repr->Begin += cpRivals::task->SeqLength;
							continue;
						}
						if( stricmp(key, "End") == 0 || stricmp(key, "Right") == 0 ) {			// End=
							repr->End = atoi(value) - cpRivals::Origin;		// cvt to zero-based
							if( repr->End < 0 ) 
								repr->End += cpRivals::task->SeqLength;
							continue;
						}
						if( stricmp(key, "Lambda") == 0 ) {			// Lambda=
							repr->Lambda = atof(value);
							continue;
						}
						if( stricmp(key, "Qmain") == 0 ) {			// Qmain=
							repr->Qm = atof(value);
							if(repr->Qm < 0) repr->Qm = 0;
							else if(repr->Qm > 1) repr->Qm = 1;
							continue;
						}
						if( stricmp(key, "Qcomp") == 0 ) {			// Qcomp=
							repr->Qc = atof(value);
							if(repr->Qc < 0) repr->Qc = 0;
							else if(repr->Qc > 1) repr->Qc = 1;
							continue;
						}
						if( stricmp(key, "Comment") == 0 ) 			// Comment=
							continue;
						if( stricmp(key, "Color")==0 )				// Color=
							continue;
						sprintf(msg, "[%04d] Unknown Repr parameter \"%s\" in task line %d ignored.\n", 
							cpRivals::myid, key, num);
						if( cpRivals::myid == 0 ) { fprintf(stderr, "%s", msg); fflush(stderr); }
                        #ifdef PARALLEL
						else if( cpRivals::collect ) 
							MPI::COMM_WORLD.Send(msg, (int)strlen(msg)+1, MPI::CHAR, root, cpRivals::tagInfo);
                        #endif
					}
					if( ferror(rtsk) ) {
						sprintf(line, "Task file I/O error in line %d.", num);
						throw line;
					}
					if( cpRivals::task->addAgent(repr) ) { delete repr; repr = NULL; }
					if( feof(rtsk) ) break;
					continue;
				}
				else if( stricmp(key, "[EKor]") == 0 ) {	// [EKor] section
					EKor* ekor = new EKor;
					while( fgets(line, FILEBUFLEN, rtsk) ) {
						num++;
						key = strtok(line, delim);
						if( key==NULL || key[0]==';' || key[0]=='/' ) 
							continue;
						if( key[0] == '[' ) break; 					// goto next section
						value = strtok(NULL, delim);
						if( value == NULL ) continue;
						if( stricmp(key, "Name") == 0 ) {			// Name=
							strncpy(ekor->Name, value, AGENTNAMELEN-1); ekor->Name[AGENTNAMELEN-1] = 0;
							int curlen = (int)strlen(ekor->Name);
							while( (value = strtok(NULL, delim)) ) {
								if( curlen + strlen(value) >= AGENTNAMELEN ) {
									sprintf(line, "AGENTNAMELEN overflow in the task line %d.", num); 
									throw line;
								}
								ekor->Name[curlen++] = ' ';
								strcpy(ekor->Name + curlen, value);
								curlen += (int)strlen(value);
							}
							continue;
						}
						if( stricmp(key, "Strand") == 0 ) {			// Strand=
							ekor->Strand = stricmp(value, "True") ? false : true;
							continue;
						}
						if( stricmp(key, "Display") == 0 )			// Display=
							continue;
						if( stricmp(key, "Enabled") == 0 ) {		// Enabled=
							ekor->Enabled = stricmp(value, "True") ? false : true;
							continue;
						}
						if( stricmp(key, "TrPoint") == 0 || stricmp(key, "Tcenter") == 0 ) {		// TrPoint=
							ekor->Tcenter = atoi(value) - cpRivals::Origin;		// cvt to zero-based
							if( ekor->Tcenter < 0 ) 
								ekor->Tcenter += cpRivals::task->SeqLength;
							continue;
						}
						if( stricmp(key, "Lambda") == 0 ) {			// Lambda=
							ekor->Lambda = atof(value);
							continue;
						}
						if( stricmp(key, "Left") == 0 || stricmp(key, "Begin") == 0 ) {		// Left=
							ekor->Begin = atoi(value) - cpRivals::Origin;		// cvt to zero-based
							if( ekor->Begin < 0 )
								ekor->Begin += cpRivals::task->SeqLength;
							continue;
						}
						if( stricmp(key, "Right") == 0 || stricmp(key, "End") == 0 ) {		// Right=
							ekor->End = atoi(value) - cpRivals::Origin;		// cvt to zero-based
							if( ekor->End < 0 )
								ekor->End += cpRivals::task->SeqLength;
							continue;
						}
						if( stricmp(key, "Rate") == 0 ) {			// Rate=
							ekor->Rate = atof(value);
							continue;
						}
						if( stricmp(key, "Comment") == 0 ) 			// Comment=
							continue;
						if( stricmp(key, "Color")==0 )				// Color=
							continue;
						sprintf(msg, "[%04d] Unknown EKor parameter \"%s\" in task line %d ignored.\n", 
							cpRivals::myid, key, num);
						if( cpRivals::myid == 0 ) { fprintf(stderr, "%s", msg); fflush(stderr); }
                        #ifdef PARALLEL
						else if( cpRivals::collect ) 
							MPI::COMM_WORLD.Send(msg, (int)strlen(msg)+1, MPI::CHAR, root, cpRivals::tagInfo);
                        #endif
					}
					if( ferror(rtsk) ) {
						sprintf(line, "Task file I/O error in line %d.", num);
						throw line;
					}
					if( cpRivals::task->addAgent(ekor) ) { delete ekor; ekor = NULL; }
					if( feof(rtsk) ) break;
					continue;
				}
				else if( stricmp(key, "[ERpo]") == 0 ) {	// [ERpo] section
					ERpo* erpo = new ERpo;
					while( fgets(line, FILEBUFLEN, rtsk) ) {
						num++;
						key = strtok(line, delim);
						if( key==NULL || key[0]==';' || key[0]=='/' ) 
							continue;
						if( key[0] == '[' ) break; 					// goto next section
						value = strtok(NULL, delim);
						if( value == NULL ) continue;
						if( stricmp(key, "Name") == 0 ) {			// Name=
							strncpy(erpo->Name, value, AGENTNAMELEN-1); erpo->Name[AGENTNAMELEN-1] = 0;
							int curlen = (int)strlen(erpo->Name);
							while( (value = strtok(NULL, delim)) ) {
								if( curlen + strlen(value) >= AGENTNAMELEN ) {
									sprintf(line, "AGENTNAMELEN overflow in the task line %d.", num); 
									throw line;
								}
								erpo->Name[curlen++] = ' ';
								strcpy(erpo->Name + curlen, value);
								curlen += (int)strlen(value);
							}
							continue;
						}
						if( stricmp(key, "Strand") == 0 ) {			// Strand=
							erpo->Strand = stricmp(value, "True") ? false : true;
							continue;
						}
						if( stricmp(key, "Display") == 0 )			// Display=
							continue;
						if( stricmp(key, "Enabled") == 0 ) {		// Enabled=
							erpo->Enabled = stricmp(value, "True") ? false : true;
							continue;
						}
						if( stricmp(key, "TrPoint") == 0 || stricmp(key, "Tcenter") == 0 ) {		// TrPoint=
							erpo->Tcenter = atoi(value) - cpRivals::Origin;		// cvt to zero-based
							if( erpo->Tcenter < 0 ) 
								erpo->Tcenter += cpRivals::task->SeqLength;
							continue;
						}
						if( stricmp(key, "Lambda") == 0 ) {			// Lambda=
							erpo->Lambda = atof(value);
							continue;
						}
						if( stricmp(key, "Left") == 0 || stricmp(key, "Begin") == 0 ) {	// Left=
							erpo->Begin = atoi(value) - cpRivals::Origin;		// cvt to zero-based
							if( erpo->Begin < 0 )
								erpo->Begin += cpRivals::task->SeqLength;
							continue;
						}
						if( stricmp(key, "Right") == 0 || stricmp(key, "End") == 0 ) {		// Right=
							erpo->End = atoi(value) - cpRivals::Origin;		// cvt to zero-based
							if( erpo->End < 0 )
								erpo->End += cpRivals::task->SeqLength;
							continue;
						}
						if( stricmp(key, "Rate") == 0 ) {			// Rate=
							erpo->Rate = atof(value);
							continue;
						}
						if( stricmp(key, "Comment") == 0 ) 			// Comment=
							continue;
						if( stricmp(key, "Color")==0 )				// Color=
							continue;
						sprintf(msg, "[%04d] Unknown ERpo parameter \"%s\" in task line %d ignored.\n", 
							cpRivals::myid, key, num);
						if( cpRivals::myid == 0 ) { fprintf(stderr, "%s", msg); fflush(stderr); }
                        #ifdef PARALLEL
						else if( cpRivals::collect ) 
							MPI::COMM_WORLD.Send(msg, (int)strlen(msg)+1, MPI::CHAR, root, cpRivals::tagInfo);
                        #endif
					}
					if( ferror(rtsk) ) {
						sprintf(line, "Task file I/O error in line %d.", num);
						throw line;
					}
					if( cpRivals::task->addAgent(erpo) ) { delete erpo; erpo = NULL; }
					if( feof(rtsk) ) break;
					continue;
				}
				else if( stricmp(key, "[Term]") == 0 ) {	// [Term] section
					Term* term = new Term;
					while( fgets(line, FILEBUFLEN, rtsk) ) {
						num++;
						key = strtok(line, delim);
						if( key==NULL || key[0]==';' || key[0]=='/' ) 
							continue;
						if( key[0] == '[' ) break; 					// goto next section
						value = strtok(NULL, delim);
						if( value == NULL ) continue;
						if( stricmp(key, "Name") == 0 ) {			// Name=
							strncpy(term->Name, value, AGENTNAMELEN-1); term->Name[AGENTNAMELEN-1] = 0;
							int curlen = (int)strlen(term->Name);
							while( (value = strtok(NULL, delim)) ) {
								if( curlen + strlen(value) >= AGENTNAMELEN ) {
									sprintf(line, "AGENTNAMELEN overflow in the task line %d.", num); 
									throw line;
								}
								term->Name[curlen++] = ' ';
								strcpy(term->Name + curlen, value);
								curlen += (int)strlen(value);
							}
							continue;
						}
						if( stricmp(key, "Strand") == 0 ) {			// Strand=
							term->Strand = stricmp(value, "True") ? false : true;
							continue;
						}
						if( stricmp(key, "Display") == 0 )			// Display=
							continue;
						if( stricmp(key, "Enabled") == 0 ) {		// Enabled=
							term->Enabled = stricmp(value, "True") ? false : true;
							continue;
						}
						if( stricmp(key, "Begin") == 0 || stricmp(key, "Left") == 0 ) {	// Begin=
							term->Begin = atoi(value) - cpRivals::Origin;		// cvt to zero-based
							if( term->Begin < 0 ) 
								term->Begin += cpRivals::task->SeqLength;
							continue;
						}
						if( stricmp(key, "End") == 0 || stricmp(key, "Right") == 0 ) {		// End=
							term->End = atoi(value) - cpRivals::Origin;		// cvt to zero-based
							if( term->End < 0 ) 
								term->End += cpRivals::task->SeqLength;
							continue;
						}
						if( stricmp(key, "Lambda") == 0 ) {			// Lambda=
							term->Lambda = atof(value);
							continue;
						}
						if( stricmp(key, "Comment") == 0 ) 			// Comment=
							continue;
						if( stricmp(key, "Color") == 0 )				// Color=
							continue;
						if( stricmp(key, "SenseKor") == 0 ) {		// Kor-sensitive
							term->SenseKor = stricmp(value, "True") ? false : true;
							continue;
						}
						if( stricmp(key, "SenseRpo") == 0 ) {		// Rpo-sensitive
							term->SenseRpo = stricmp(value, "True") ? false : true;
							continue;
						}
						sprintf(msg, "[%04d] Unknown Term parameter \"%s\" in task line %d ignored.\n", 
							cpRivals::myid, key, num);
						if( cpRivals::myid == 0 ) { fprintf(stderr, "%s", msg); fflush(stderr); }
                        #ifdef PARALLEL
						else if( cpRivals::collect ) 
							MPI::COMM_WORLD.Send(msg, (int)strlen(msg)+1, MPI::CHAR, root, cpRivals::tagInfo);
                        #endif
					}
					if( ferror(rtsk) ) {
						sprintf(line, "Task file I/O error in line %d.", num);
						throw line;
					}
					if( cpRivals::task->addAgent(term) ) { delete term; term = NULL; }
					if( feof(rtsk) ) break;
					continue;
				}
				else {
					sprintf(line, "Invalid section %s in line %d", key, num);
					throw line;
				}
			}
			if( feof(rtsk) ) break;
		}
		if( ferror(rtsk) ) {
			sprintf(line, "Task file I/O error in line %d.", num);
			throw line;
		}
		cpRivals::taskloaded = true;
		delete [] line; delete [] msg;
		if( rtsk ) fclose(rtsk); 
		return true;
	}
	catch (char *err) {
		char *msg = new char[MSGLEN];
		sprintf(msg, "[%04d] %s\n", cpRivals::myid, err);
		if( cpRivals::myid == 0 ) { fprintf(stderr, "%s", msg); fflush(stderr); }
        #ifdef PARALLEL
		else if( cpRivals::collect ) 
			MPI::COMM_WORLD.Send(msg, (int)strlen(msg)+1, MPI::CHAR, root, cpRivals::tagInfo);
        #endif
		if( cpRivals::task ) { delete cpRivals::task; cpRivals::task = NULL; }
		delete [] line; delete [] msg;
		if( rtsk ) fclose(rtsk);
		return false;
	}
}

// Set parameters from the varvalue array. Return: false=OK, true=errors
bool cpRivals::SetCurrentParameters(double* varvalue) {
	int i;
	cpRivals::Param parnum;
	for( i=0; i<cpRivals::varcount; i++ ) {
		Agent* agent = cpRivals::varagent[i];
		switch( cpRivals::varparam[i] ) {	// not used letter: W
			case 'A':	parnum = cpRivals::Aborting; break;
			case 'B':	parnum = cpRivals::Bound; break;
			case 'C':	parnum = cpRivals::Tcenter; break;
			case 'D':	parnum = cpRivals::Mterminated; return true;		// non-chancheable counter
			case 'E':	parnum = cpRivals::InitP; break;
			case 'F':	parnum = cpRivals::InitN; break;
			case 'G':	parnum = cpRivals::AbortRange; break;
			case 'H':	parnum = cpRivals::SigLength; break;
			case 'I':	parnum = cpRivals::Initiated; break;
			case 'J':	parnum = cpRivals::TotalInit; break;
			case 'K':	parnum = cpRivals::Cterminated; return true;		// non-chancheable counter
			case 'L':	parnum = cpRivals::Lambda; break;
			case 'M':	parnum = cpRivals::Qmain; break;
			case 'N':	parnum = cpRivals::TransN; break;
			case 'O':	parnum = cpRivals::Offered; break;
			case 'P':	parnum = cpRivals::TransP; break;
			case 'Q':	parnum = cpRivals::Qcomp; break;
			case 'R':	parnum = cpRivals::Rate; break;
			case 'S':	parnum = cpRivals::Sigma; break;
			case 'T':	parnum = cpRivals::Transcribed; break;
			case 'U':	parnum = cpRivals::TotalTrans; break;
			case 'V':	parnum = cpRivals::Active; break;
			case 'X':	parnum = cpRivals::SenseKor; break;
			case 'Y':	parnum = cpRivals::Polym; break;
			case 'Z':	parnum = cpRivals::SenseRpo; break;
			default:	return true;
		}
		agent->Modify(parnum, varvalue[i]);
	}
	if( i < cpRivals::varcount ) return true;
	return false;
}
