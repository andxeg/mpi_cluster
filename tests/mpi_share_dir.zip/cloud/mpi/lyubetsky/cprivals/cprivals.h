// cpRivals: Model of the regulation by competing promoters.
//
// Copyright (C) 2009-2012 Lev Rubanov <rubanov@iitp.ru>
// Copyright (C) 2009-2012 Institute for Information Transmission Problems of
// the Russian Academy of Sciences (Kharkevich Institute) <http://www.iitp.ru>
//
// This model has been proposed and implemented in the Laboratory of 
// Mathematical Methods and Models in Bioinformatics of the above Institute.
// Head of the Laboratory, Prof. Vassily Lyubetsky <lyubetsky@iitp.ru>
//   
// This file is part of cpRivals.
//
// cpRivals is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// cpRivals is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with cpRivals. If not, see <http://www.gnu.org/licenses/>.
//
// Functions: common header file
//
#ifndef CPRIVALSHEADER
#define CPRIVALSHEADER
#define PARALLEL        // enable MPI parallelization code
#define _CRT_SECURE_NO_WARNINGS
#define MPICH_IGNORE_CXX_SEEK    // For MPICH/MVAPICH
#define OMPI_IGNORE_CXX_SEEK     // For OpenMPI
#ifdef PARALLEL
#include <mpi.h>
#endif
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#include <time.h>
#include <queue>
#include <vector>

namespace cpRivals {

//#define LOGGING			// enable logging trajectory details
//#define LOGMEMORY		// enable memory leakage debugging (-nompi only)
#define CIRCULAR		// enable circular DNA related code

#ifdef __GNUC__
#define stricmp(str1, str2) strcasecmp((str1), (str2))
#define strnicmp(str1, str2, count) strncasecmp((str1), (str2), (count))
#endif

#define VERSION		"1.5.3.3"
#define FILENAMELEN	256
#define FILEBUFLEN	16384
#define KEYNAMELEN	32
#define MAXPARAM		32
#define MAXFIELD		256
#define AGENTNAMELEN	32
#define AGQUANTUM		32
#define SMLAMBDA		1.0e-8
#define BIGTIME		1.0e9
#define SEEDSEPARAT	1000
#define MSGLEN			1024
#define MAXDYNAM		64		// number of modifiable agents (each one may be doubled)
#define MAXDSTEP		16

// Forward declarations
double Random(void);
int	LeftToRight(const void *arg1, const void *arg2);	// qsort callback function
class Model;
#ifdef CPRIVALSMAIN
	double exponential = 1.0;				// last computed value of exponential
	double oldabrate = 0.0;					// last argument of exponential
	#ifdef LOGMEMORY
	int fLogMemory = 0;			// Perform logging (0=no; nonzero=yes)?
	int cBlocksAllocated = 0;  // Count of blocks allocated.
	#endif
#else
	extern double exponential, oldabrate;
	#ifdef LOGMEMORY
	extern int fLogMemory, cBlocksAllocated;
	#endif
#endif
#ifdef LOGMEMORY
void *operator new( size_t stAllocateBlock );		// user-defined operator new
void operator delete( void *pvMem );					// user-defined operator delete
#endif

typedef struct structConfiguration {
	int PhysicalTime;			// Upper bound for internal model time (sec)
	int StartupTime;			// Duration of the startup phase (sec)
	int ElapsedTime;			// Upper bound for computing time (sec)
	bool CSV;					// Write also .CSV file
	bool Both;					// Write both OK/Try data into the .CSV file (or only OK)
	bool CountCenter;			// Count transcriptions with regard to the polymerase center
	char Delimiter;			// Delimiter character for .CSV file
	bool SAP[3][3];			// Stop Active pro rules (Holo, Kor, Rpo)
	bool DAP[3][3];			// Delete Active pro rules (Holo, Kor, Rpo)
	bool DPP[3][3];			// Delete Passive pro rules (Holo, Kor, Rpo)
	bool SAC[3][3];			// Stop Active contra rules (Holo, Kor, Rpo)
	bool DAC[3][3];			// Delete Active contra rules (Holo, Kor, Rpo)
	bool DPC[3][3];			// Delete Passive contra rules (Holo, Kor, Rpo)
	bool SAR[3];				// Stop Active rules for Repr collisions (Holo, Kor, Rpo)
	bool DAR[3];				// Delete Active rules for Repr collisions (Holo, Kor, Rpo)
	bool DPR[3];				// Delete Passive rules for Repr collisions (Holo, Kor, Rpo)
	bool SAT[3];				// Stop Active rules for entering Term (Holo, Kor, Rpo)
	bool DAT[3];				// Delete Active rules for entering Term (Holo, Kor, Rpo)
	bool DPT[3];				// Delete Passive rules for entering Term (Holo, Kor, Rpo)
	int PEPover;	         // Maximum of PEP center overlaps a gene
	int NEPover;	         // Maximum of NEP center overlaps a gene
} Configuration;
// Agent parameters enumeration (except specific ones of movable agents)
enum Param {		// Used: ABCDEFGHIJKLMNOPQRSTUVXYZ, Free: W 0 etc.
						//  #  type				agent(s)						symbol / note
	None,				//  0: dummy parameter
	Type,				//  1: AgentTypes		all							unmodifiable
	Name,				//  2: char*			all							unmodifiable
	Strand,			//  3: bool				all							unmodifiable
	Enabled,			//  4: bool				all							unmodifiable
	Begin,			//  5: int				all							unmodifiable
	End,				//  6: int				all							unmodifiable
	TouchTime,		//  7: double			all							unmodifiable
	Rule,				//  8: int				all							unmodifiable
	Initiated,		//  9: int				Gene										I
	InitP,			// 10: int				Gene										E
	InitN,			// 11: int				Gene										F
	Transcribed,	// 12: int				Gene										T
	TransP,			// 13: int				Gene										P
	TransN,			// 14: int				Gene										N
	TotalInit,		// 15: long long		Gene										J
	TotalTrans,		// 16: long long		Gene										U
	Lambda,			// 17: double			PEP NEP Repr EKor ERpo Term		L
	Sigma,			// 18: int				PEP										S
	Tcenter,			// 19: int				PEP NEP EKor ERpo Holo Kor Rpo	C
	Aborting,		// 20: double			PEP Holo									A
	AbortRange,		// 21: int				PEP Holo									G
	SigLength,		// 22: int				PEP Holo									H
	Rate,				// 23: double			PEP NEP EKor ERpo Holo Kor Rpo	R
	Offered,			// 24: int				PEP NEP Repr EKor ERpo Term		O
	Bound,			// 25: int				PEP NEP Repr EKor ERpo Term		B
	Polym,			// 26: int				NEP										Y
	Active,			// 27: bool				Term										V
	SenseKor,		// 28: bool				Term										X
	SenseRpo,		// 29: bool				Term										Z
	Qmain,			// 30: double			Repr										M
	Qcomp,			// 31: double			Repr										Q
	Mterminated,	// 32: int				Repr										D
	Cterminated		// 33: int				Repr										K
};
// Type of parameter modification
enum Dynatype {
	Nop, Set, Linear
};
// Logging mode enumeration
enum LogIter {
	All					= 0x00000001,
	GeneInitiated		= 0x00000002,
	GeneTranscribed	= 0x00000004,
	PEPOffered			= 0x00000008,
	PEPBound				= 0x00000010,
	NEPOffered			= 0x00000020,
	NEPBound				= 0x00000040,
	Collision			= 0x00000080,
	ReprOffered			= 0x00000100,
	ReprBound			= 0x00000200,
	EKorOffered			= 0x00000400,
	EKorBound			= 0x00000800,
	ERpoOffered			= 0x00001000,
	ERpoBound			= 0x00002000
};
// Agent subtypes enumeration
enum AgentTypes {
	TypeEmpty	= 0, 
	TypeGene		= 1,
	TypePEP		= 2,
	TypeNEP		= 3,
	TypeRepr		= 4,
	TypeEKor		= 5,
	TypeERpo		= 6,
	TypeHolo		= 7,
	TypeKor		= 8,
	TypeRpo		= 9,
	TypeTerm		= 10,
	TypeDynam	= 11
};

// The common class for agents: genes, promoters, repression sites, edge conditions, polymerases
class Agent {
public:
	Agent(void) {			// Constructor
		Type = TypeEmpty;
		Name[0] = 0;
		Strand = true;
		Enabled = true;
      Killed = false;
		Begin = -1; End = -1;
		TouchTime = 0.;
		Rule = -1;
	}
	virtual ~Agent(void) {}
	double TouchTime;				// Next time to touch the agent
	AgentTypes Type;				// Type of the agent
	char Name[AGENTNAMELEN];	// Name of the agent
	bool Strand;					// true=main, false=complementary
	bool Enabled;					// Enable/disable agent functions in the model
   bool Killed;               // Postpone the agent removal from both queue and memory
	int Begin;						// left edge - 5' coordinate in main(!) thread
	int End;							// right edge - 3' coordinate in main(!) thread
	int Rule;						// Type number for rules (-1 if motionless)
	virtual void Reset(void) { }
	virtual void Reset(Agent* agent, int circle = 0) { }
	virtual void Touch(void) { }
	virtual void StartupClear(void) { }
	virtual void Modify(Param parnum, double value) { }
	virtual double GetValue(Param parnum) { return -1.0; }
	virtual void Store(void) { }
	virtual void Restore(void) { }
   void Kill(void) { Killed = true; }
   bool IsKilled(void) { return Killed; }
};

// The class representing a gene, derived from the Agent base class
class Gene: public Agent {
public:
	Gene(void) {			// Constructor
		Type = TypeGene;
		Reset();
		ResetTotal();
	}
	Gene(Gene* gene) {	// Copy constructor
		Type = TypeGene;
		strncpy(Name, gene->Name, AGENTNAMELEN-1); Name[AGENTNAMELEN-1] = 0;
		Strand = gene->Strand;
		Enabled = gene->Enabled;
		Begin = gene->Begin;
		End = gene->End;
		TouchTime = gene->TouchTime;
		Rule = gene->Rule;
		Initiated = gene->Initiated;
		InitP = gene->InitP;
		InitN = gene->InitN;
		Transcribed = gene->Transcribed;
		TransP = gene->TransP;
		TransN = gene->TransN;
		TotalInit = gene->TotalInit;
		TotalTrans = gene->TotalTrans;
	}
	int Initiated; 		// Overall number of polymerases entered the gene
	int InitP;				// Overall number of PEP polymerases entered the gene
	int InitN;				// Overall number of NEP polymerases entered the gene
	int Transcribed;		// Overall number of polymerases passed the entire gene
	int TransP;				// Overall number of transcriptions by PEP polymerases
	int TransN;				// Overall number of transcriptions by NEP polymerases
	long long TotalInit;		// Total number of entered polymerases over all trajectories
	long long TotalTrans;	// Total number of passed polymerases over all trajectories
	// Reset counters
	virtual void Reset(void) {
		Initiated = 0;
		InitP = 0;
		InitN = 0;
		Transcribed = 0;
		TransP = 0;
		TransN = 0;
	}
	virtual void Reset(Agent* agent, int circle = 0) { }
	// Reset totals
	void ResetTotal(void) {
		TotalInit = 0;
		TotalTrans = 0;
	}
	// Accumulate totals
	void Accumulate(void) {
		if( Initiated ) TotalInit += Initiated;
		else if( InitP || InitN ) TotalInit += InitP + InitN;
		if( Transcribed ) TotalTrans += Transcribed;
		else if( TransP || TransN ) TotalTrans += TransP + TransN;
	}
	// incrementing Initiated counter
	void Enter(void) {
		Initiated ++;
	}
	// incrementing Transcribed counter
	void Leave(void) {
		Transcribed ++;
	}
	// clear main counters when startup terminates
	virtual void StartupClear(void) { 
		Initiated = 0;
		InitP = 0;
		InitN = 0;
		Transcribed = 0;
		TransP = 0;
		TransN = 0;
	}
	// dynamic parameter modification
	virtual void Modify(Param parnum, double value) { 
		switch( parnum ) {
			case cpRivals::Initiated:		Initiated = (int)value; break;
			case cpRivals::InitP:			InitP = (int)value; break;
			case cpRivals::InitN:			InitN = (int)value; break;
			case cpRivals::Transcribed:	Transcribed = (int)value; break;
			case cpRivals::TransP:			TransP = (int)value; break;
			case cpRivals::TransN:			TransN = (int)value; break;
			case cpRivals::TotalInit:		TotalInit = (long long)value; break;
			case cpRivals::TotalTrans:		TotalTrans = (long long)value; break;
		};
	}
	// get parameter value
	virtual double GetValue(Param parnum) { 
		switch( parnum ) {
			case cpRivals::Initiated:		return (double)Initiated;
			case cpRivals::InitP:			return (double)InitP;
			case cpRivals::InitN:			return (double)InitN;
			case cpRivals::Transcribed:	return (double)Transcribed;
			case cpRivals::TransP:			return (double)TransP;
			case cpRivals::TransN:			return (double)TransN;
			case cpRivals::TotalInit:		return (double)TotalInit;
			case cpRivals::TotalTrans:		return (double)TotalTrans;
			default:								return -1.0;
		};
	}
};

// The class representing a PEP promoter, derived from the Agent base class
class PEP: public Agent {
public:
	PEP(void) {			// Constructor
		Type = TypePEP;
		Lambda = 0.0;
		Sigma = -1;
		Tcenter = -1;
		Aborting = 0.0;
		AbortRange = 0;
		SigLength = 0;
		Rate = 0.0;
		Reset();
	}
	PEP(PEP* pep) {	// Copy constructor
		Type = TypePEP;
		strncpy(Name, pep->Name, AGENTNAMELEN-1); Name[AGENTNAMELEN-1] = 0;
		Strand = pep->Strand;
		Enabled = pep->Enabled;
		Begin = pep->Begin;
		End = pep->End;
		TouchTime = pep->TouchTime;
		Rule = pep->Rule;
		Lambda = pep->Lambda;
		Sigma = pep->Sigma;
		Tcenter = pep->Tcenter;
		Aborting = pep->Aborting;
		AbortRange = pep->AbortRange;
		SigLength = pep->SigLength;
		Rate = pep->Rate;
		Offered = pep->Offered;
		Bound = pep->Bound;
	}
	double Lambda;			// Binding intensity of the promoter
	int Sigma;				// Holoenzyme number: 0=Sig1,...,5=Sig6 
	int Tcenter;			// Transcription center position in main strand
	double Aborting;		// Aborting process intensity
	int AbortRange;		// Aborting process range
	int SigLength;			// Specific Sigma subunit length
	double Rate;			// Specific Kor rate
	int Offered;			// Overall number of holoenzymes offered by the promoter
	int Bound;				// Overall number of holoenzymes bound to the promoter
	// Reset counters etc.
	virtual void Reset(void) {	
		TouchTime = 0;
		Offered = 0;
		Bound = 0;
	}
	virtual void Reset(Agent* agent, int circle = 0) { }
	// Caclulate and set new TouchTime
	virtual void Touch(void) {
		if( Lambda < SMLAMBDA ) TouchTime = BIGTIME;
		else TouchTime += - log( Random() ) / Lambda;
	}
	// Incrementing Offered counter
	void Offer(void) {
		Offered++;
	}
	// Incrementing Bound counter
	void Bind(void) {
		Bound++;
	}
	// clear main counters when startup terminates
	virtual void StartupClear(void) { 
		Offered = 0;
		Bound = 0;
	}
	// dynamic parameter modification
	virtual void Modify(Param parnum, double value) { 
		switch( parnum ) {
			case cpRivals::Lambda:			Lambda = value; break;
			case cpRivals::Sigma:			Sigma = (int)value; break;
			case cpRivals::Tcenter:			Tcenter = (int)value; break;
			case cpRivals::Aborting:		Aborting = value; break;
			case cpRivals::AbortRange:		AbortRange = (int)value; break;
			case cpRivals::SigLength:		SigLength = (int)value; break;
			case cpRivals::Rate:				Rate = value; break;
			case cpRivals::Offered:			Offered = (int)value; break;
			case cpRivals::Bound:			Bound = (int)value; break;
		};
	}
	// get parameter value
	virtual double GetValue(Param parnum) { 
		switch( parnum ) {
			case cpRivals::Lambda:			return Lambda;
			case cpRivals::Sigma:			return (double)Sigma;
			case cpRivals::Tcenter:			return (double)Tcenter;
			case cpRivals::Aborting:		return Aborting;
			case cpRivals::AbortRange:		return (double)AbortRange;
			case cpRivals::SigLength:		return (double)SigLength;
			case cpRivals::Rate:				return Rate;
			case cpRivals::Offered:			return (double)Offered;
			case cpRivals::Bound:			return (double)Bound;
			default:								return -1.0;
		};
	}
	// Store current values of changeable properties
	virtual void Store(void) {
		_Lambda = Lambda; _Aborting = Aborting; _Rate = Rate;
		_Sigma = Sigma; _Tcenter = Tcenter; _AbortRange = AbortRange;
		_SigLength = SigLength; _Offered = Offered; _Bound = Bound;
	}
	// Restore initial values of changeable properties
	virtual void Restore(void) { 
		Lambda = _Lambda; Aborting = _Aborting; Rate = _Rate;
		Sigma = _Sigma; Tcenter = _Tcenter; AbortRange = _AbortRange;
		SigLength = _SigLength; Offered = _Offered; Bound = _Bound;
	}
private:
	double _Lambda, _Aborting, _Rate;
	int _Sigma, _Tcenter, _AbortRange, _SigLength, _Offered, _Bound;
};

// The class representing a NEP promoter, derived from the Agent base class
class NEP: public Agent {
public:
	NEP(void) {			// Constructor
		Type = TypeNEP;
		Lambda = 0.0;
		Tcenter = -1;
		Rate = 0.0;
		Reset();
	}
	NEP(NEP* nep) {	// Copy constructor
		Type = TypeNEP;
		strncpy(Name, nep->Name, AGENTNAMELEN-1); Name[AGENTNAMELEN-1] = 0;
		Strand = nep->Strand;
		Enabled = nep->Enabled;
		Begin = nep->Begin;
		End = nep->End;
		TouchTime = nep->TouchTime;
		Rule = nep->Rule;
		Lambda = nep->Lambda;
		Polym = nep->Polym;
		Tcenter = nep->Tcenter;
		Rate = nep->Rate;
		Offered = nep->Offered;
		Bound = nep->Bound;
	}
	double Lambda;			// Binding intensity of the promoter
	int Polym;				// Rpo type: 0=RpoT1,1=RpoT2,2=RpoTp,3=RpoTm,4=RpoTmp (see config.Rpo[])
	int Tcenter;			// Transcription center position in main strand
	double Rate;			// Specific phage polymerase rate
	int Offered;			// Overall number of phage type polymerases offered by the promoter
	int Bound;				// Overall number of phage type polymerases bound to the promoter
	// Reset counters etc.
	virtual void Reset(void) {
		TouchTime = 0;
		Offered = 0;
		Bound = 0;
	}
	virtual void Reset(Agent* agent, int circle = 0) { }
	// Caclulate and set new TouchTime
	virtual void Touch(void) {
		if( Lambda < SMLAMBDA ) TouchTime = BIGTIME;
		else TouchTime += - log( Random() ) / Lambda;
	}
	// incrementing Offered counter
	void Offer(void) {
		Offered++;
	}
	// incrementing Bound counter
	void Bind(void) {
		Bound++;
	}
	// clear main counters when startup terminates
	virtual void StartupClear(void) { 
		Offered = 0;
		Bound = 0;
	}
	// dynamic parameter modification
	virtual void Modify(Param parnum, double value) { 
		switch( parnum ) {
			case cpRivals::Lambda:			Lambda = value; break;
			case cpRivals::Polym:			Polym = (int)value; break;
			case cpRivals::Tcenter:			Tcenter = (int)value; break;
			case cpRivals::Rate:				Rate = value; break;
			case cpRivals::Offered:			Offered = (int)value; break;
			case cpRivals::Bound:			Bound = (int)value; break;
		};
	}
	// get parameter value
	virtual double GetValue(Param parnum) { 
		switch( parnum ) {
			case cpRivals::Lambda:			return Lambda;
			case cpRivals::Polym:			return (double)Polym;
			case cpRivals::Tcenter:			return (double)Tcenter;
			case cpRivals::Rate:				return Rate;
			case cpRivals::Offered:			return (double)Offered;
			case cpRivals::Bound:			return (double)Bound;
			default:								return -1.0;
		};
	}
	// Store current values of changeable properties
	virtual void Store(void) {
		_Lambda = Lambda; _Rate = Rate;
		_Polym = Polym; _Tcenter = Tcenter;
		_Offered = Offered; _Bound = Bound;
	}
	// Restore initial values of changeable properties
	virtual void Restore(void) { 
		Lambda = _Lambda; Rate = _Rate;
		Polym = _Polym; Tcenter = _Tcenter;
		Offered = _Offered; Bound = _Bound;
	}
private:
	double _Lambda, _Rate;
	int _Polym, _Tcenter, _Offered, _Bound;
};

// The class representing a repression site, derived from the Agent base class
class Repr: public Agent {
public:
	Repr(void) {			// Constructor
		Type = TypeRepr;
		Lambda = 0.0;
		Reset();
	}
	Repr(Repr* repr) {	// Copy constructor
		Type = TypeRepr;
		strncpy(Name, repr->Name, AGENTNAMELEN-1); Name[AGENTNAMELEN-1] = 0;
		Strand = repr->Strand;
		Enabled = repr->Enabled;
		Begin = repr->Begin;
		End = repr->End;
		TouchTime = repr->TouchTime;
		Rule = repr->Rule;
		Lambda = repr->Lambda;
		Offered = repr->Offered;
		Bound = repr->Bound;
		Mterminated = repr->Mterminated;
		Cterminated = repr->Cterminated;
		Qm = repr->Qm;
		Qc = repr->Qc;
	}
	double Lambda;			// Binding intensity of the promoter
	int Offered;			// Overall number of proteins offered by the repression site
	int Bound;				// Overall number of proteins bound to the repression site
	int Mterminated;		// Overall number of polymerases terminated on main strand
	int Cterminated;		// Overall number of polymerases terminated on complement strand
	double Qm;				// Probability of RNAP to pass the repressor at main strand
	double Qc;				// Probability of RNAP to pass the repressor at complement strand
	// Reset counters etc.
	virtual void Reset(void) {	
		TouchTime = 0;
		Offered = 0;
		Bound = 0;
		Mterminated = 0;
		Cterminated = 0;
	}
	virtual void Reset(Agent* agent, int circle = 0) { }
	// Caclulate and set new TouchTime
	virtual void Touch(void) {
		if( Lambda < SMLAMBDA ) TouchTime = BIGTIME;
		else TouchTime += - log( Random() ) / Lambda;
	}
	// Check if RNAP passes the repressor
	bool Pass(bool strand) {
		if(strand && Qm == 1) return true;
		if(!strand && Qc == 1) return true;
		if(strand && Qm == 0) return false;
		if(!strand && Qc == 0) return false;
		double r = Random();
		if(strand && r < Qm || !strand && r < Qc)
			return true;
		else
			return false;
	}
	// incrementing Offered counter
	void Offer(void) {
		Offered++;
	}
	// incrementing Bound counter
	void Bind(void) {
		Bound++;
	}
	// clear main counters when startup terminates
	virtual void StartupClear(void) { 
		Offered = 0;
		Bound = 0;
		Mterminated = 0;
		Cterminated = 0;
	}
	// dynamic parameter modification
	virtual void Modify(Param parnum, double value) { 
		switch( parnum ) {
			case cpRivals::Lambda:			Lambda = value; break;
			case cpRivals::Offered:			Offered = (int)value; break;
			case cpRivals::Bound:			Bound = (int)value; break;
			case cpRivals::Qmain:			Qm = value; break;
			case cpRivals::Qcomp:			Qc = value; break;
         case cpRivals::Mterminated:   Mterminated = (int)value; break;
         case cpRivals::Cterminated:   Cterminated = (int)value; break;
		};
	}
	// get parameter value
	virtual double GetValue(Param parnum) { 
		switch( parnum ) {
			case cpRivals::Lambda:			return Lambda;
			case cpRivals::Offered:			return (double)Offered;
			case cpRivals::Bound:			return (double)Bound;
			case cpRivals::Qmain:			return Qm;
			case cpRivals::Qcomp:			return Qc;
         case cpRivals::Mterminated:   return (double)Mterminated;
         case cpRivals::Cterminated:   return (double)Cterminated;
			default:								return -1.0;
		};
	}
	// Store current values of changeable properties
	virtual void Store(void) {
		_Lambda = Lambda;
		_Offered = Offered; _Bound = Bound;
		_Qm = Qm; _Qc = Qc;
      _Mterminated = Mterminated;
      _Cterminated = Cterminated;
	}
	// Restore initial values of changeable properties
	virtual void Restore(void) { 
		Lambda = _Lambda;
		Offered = _Offered; Bound = _Bound;
		Qm = _Qm; Qc = _Qc;
      Mterminated = _Mterminated;
      Cterminated = _Cterminated;
	}
private:
	double _Lambda, _Qm, _Qc;
	int _Offered, _Bound, _Mterminated, _Cterminated;
};

// The class representing an external Kor enzyme source, derived from the Agent base class
class EKor: public Agent {
public:
	EKor(void) {			// Constructor
		Type = TypeEKor;
		Lambda = 0.0;
		Tcenter = -1;
		Rate = 0.0;
		Reset();
	}
	EKor(EKor* ekor) {	// Copy constructor
		Type = TypeEKor;
		strncpy(Name, ekor->Name, AGENTNAMELEN-1); Name[AGENTNAMELEN-1] = 0;
		Strand = ekor->Strand;
		Enabled = ekor->Enabled;
		Begin = ekor->Begin;
		End = ekor->End;
		TouchTime = ekor->TouchTime;
		Rule = ekor->Rule;
		Lambda = ekor->Lambda;
		Tcenter = ekor->Tcenter;
		Rate = ekor->Rate;
		Offered = ekor->Offered;
		Bound = ekor->Bound;
	}
	double Lambda;			// Binding intensity of the promoter
	int Tcenter;			// Transcription center position in main strand
	double Rate;			// Specific Kor rate
	int Offered;			// Overall number of Kor enzymes offered by the external source
	int Bound;				// Overall number of external Kor enzymes bound to the sequence
	// Reset counters etc.
	virtual void Reset(void) {
		TouchTime = 0;
		Offered = 0;
		Bound = 0;
	}
	virtual void Reset(Agent* agent, int circle = 0) { }
	// Caclulate and set new TouchTime
	virtual void Touch(void) {
		if( Lambda < SMLAMBDA ) TouchTime = BIGTIME;
		else TouchTime += - log( Random() ) / Lambda;
	}
	// Incrementing Offered counter
	void Offer(void) {
		Offered++;
	}
	// Incrementing Bound counter
	void Bind(void) {
		Bound++;
	}
	// clear main counters when startup terminates
	virtual void StartupClear(void) { 
		Offered = 0;
		Bound = 0;
	}
	// dynamic parameter modification
	virtual void Modify(Param parnum, double value) { 
		switch( parnum ) {
			case cpRivals::Lambda:			Lambda = value; break;
			case cpRivals::Tcenter:			Tcenter = (int)value; break;
			case cpRivals::Rate:				Rate = value; break;
			case cpRivals::Offered:			Offered = (int)value; break;
			case cpRivals::Bound:			Bound = (int)value; break;
		};
	}
	// get parameter value
	virtual double GetValue(Param parnum) { 
		switch( parnum ) {
			case cpRivals::Lambda:			return Lambda;
			case cpRivals::Tcenter:			return (double)Tcenter;
			case cpRivals::Rate:				return Rate;
			case cpRivals::Offered:			return (double)Offered;
			case cpRivals::Bound:			return (double)Bound;
			default:								return -1.0;
		};
	}
	// Store current values of changeable properties
	virtual void Store(void) {
		_Lambda = Lambda; _Rate = Rate;
		_Tcenter = Tcenter; _Offered = Offered; _Bound = Bound;
	}
	// Restore initial values of changeable properties
	virtual void Restore(void) { 
		Lambda = _Lambda; Rate = _Rate;
		Tcenter = _Tcenter; Offered = _Offered; Bound = _Bound;
	}
private:
	double _Lambda, _Rate;
	int _Tcenter, _Offered, _Bound;
};

// The class representing an external phage polymerase source, derived from the Agent base class
class ERpo: public Agent {
public:
	ERpo(void) {			// Constructor
		Type = TypeERpo;
		Lambda = 0.0;
		Tcenter = -1;
		Rate = 0.0;
		Reset();
	}
	ERpo(ERpo* erpo) {	// Copy constructor
		Type = TypeERpo;
		strncpy(Name, erpo->Name, AGENTNAMELEN-1); Name[AGENTNAMELEN-1] = 0;
		Strand = erpo->Strand;
		Enabled = erpo->Enabled;
		Begin = erpo->Begin;
		End = erpo->End;
		TouchTime = erpo->TouchTime;
		Rule = erpo->Rule;
		Lambda = erpo->Lambda;
		Tcenter = erpo->Tcenter;
		Rate = erpo->Rate;
		Offered = erpo->Offered;
		Bound = erpo->Bound;
	}
	double Lambda;			// Binding intensity of the promoter
	int Tcenter;			// Transcription center position in main strand
	double Rate;			// Specific phage polymerase rate
	int Offered;			// Overall number of Rpo's offered by the external source
	int Bound;				// Overall number of external Rpo's bound to the sequence
	// Reset counters and etc.
	virtual void Reset(void) {	
		TouchTime = 0;
		Offered = 0;
		Bound = 0;
	}
	virtual void Reset(Agent* agent, int circle = 0) { }
	// Caclulate and set new TouchTime
	virtual void Touch(void) {
		if( Lambda < SMLAMBDA ) TouchTime = BIGTIME;
		else TouchTime += - log( Random() ) / Lambda;
	}
	// incrementing Offered counter
	void Offer(void) {
		Offered++;
	}
	// incrementing Bound counter
	void Bind(void) {
		Bound++;
	}
	// clear main counters when startup terminates
	virtual void StartupClear(void) { 
		Offered = 0;
		Bound = 0;
	}
	// dynamic parameter modification
	virtual void Modify(Param parnum, double value) { 
		switch( parnum ) {
			case cpRivals::Lambda:			Lambda = value; break;
			case cpRivals::Tcenter:			Tcenter = (int)value; break;
			case cpRivals::Rate:				Rate = value; break;
			case cpRivals::Offered:			Offered = (int)value; break;
			case cpRivals::Bound:			Bound = (int)value; break;
		};
	}
	// get parameter value
	virtual double GetValue(Param parnum) { 
		switch( parnum ) {
			case cpRivals::Lambda:			return Lambda;
			case cpRivals::Tcenter:			return (double)Tcenter;
			case cpRivals::Rate:				return Rate;
			case cpRivals::Offered:			return (double)Offered;
			case cpRivals::Bound:			return (double)Bound;
			default:								return -1.0;
		};
	}
	// Store current values of changeable properties
	virtual void Store(void) {
		_Lambda = Lambda; _Rate = Rate;
		_Tcenter = Tcenter; _Offered = Offered; _Bound = Bound;
	}
	// Restore initial values of changeable properties
	virtual void Restore(void) { 
		Lambda = _Lambda; Rate = _Rate;
		Tcenter = _Tcenter; Offered = _Offered; Bound = _Bound;
	}
private:
	double _Lambda, _Rate;
	int _Tcenter, _Offered, _Bound;
};

// The class representing a holoenzyme while Sig exists, derived from the Agent base class
class Holo: public Agent {
public:
	Holo(PEP* pep, int circle = 0) {			// Constructor
		Type = TypeHolo;
		Reset(pep, circle);
	}
	PEP* Pep;				// PEP promoter that is the holoenzyme owner
	int Tcenter;			// Transcription center (position in the main strand)
	int Shift;				// Shift of the Kor from the initial position
	double Aborting;		// Aborting process intensity
	int AbortRange;		// Aborting process range
	int Countback;			// Countback of remaining aborting moves
	int SigLength;			// Specific Sigma subunit length
	double Rate;			// Specific Kor rate
	// Reset variables
	virtual void Reset(void) { }
	virtual void Reset(Agent* agent, int circle = 0) {
		this->Pep = (PEP*)agent;
		char *name = new char[AGENTNAMELEN*2];
		sprintf(name, "H%s#%d", Pep->Name, Pep->Bound);
		strncpy(this->Name, name, AGENTNAMELEN-1); this->Name[AGENTNAMELEN-1] = 0;
		delete [] name; name = NULL;
		this->Strand = Pep->Strand;
		this->Enabled = true;
		this->Begin = Pep->Begin;
		this->End = Pep->End;
		this->TouchTime = Pep->TouchTime;
		this->Tcenter = Pep->Tcenter;
		this->Shift = 0;
		this->Aborting = Pep->Aborting;
		this->AbortRange = Pep->AbortRange;
		this->SigLength = Pep->SigLength;
		this->Rate = Pep->Rate; _Rate_1 = 1 / this->Rate;
		this->Rule = 0;
		this->Touch();
	}
	// Caclulate and set new TouchTime
	virtual void Touch(void) {
		this->TouchTime += _Rate_1;
	}
	// Set random number of abortive processes
	void SetCount(void) {
		// Simple trick to calculate exponential only as needed
		if( fabs(this->Aborting - cpRivals::oldabrate) > 1.E-6 ) {	
			cpRivals::oldabrate = this->Aborting;
			cpRivals::exponential = exp( - cpRivals::oldabrate );
		}
		// Here a number of events from the Poisson distribution is simulated
		double t = 1.0;
		for( Countback = 0; t >= cpRivals::exponential; Countback++ )
			t *= Random();
	}
   // Increment shift and modify holo margin & center
	void ShiftKor(int circle = 0) {		// 0 for linear, otherwise circle length
      this->Shift++;
      if( this->Strand ) { 
			this->End++;
			this->Tcenter++;
			#ifdef CIRCULAR
			if(circle && this->End >= circle) this->End = 0;
			if(circle && this->Tcenter >= circle) this->Tcenter = 0;
			#endif
		}
      else { 
			this->Begin--;
			this->Tcenter--;
			#ifdef CIRCULAR
			if(circle && this->Begin < 0) this->Begin = circle - 1;
			if(circle && this->Tcenter < 0) this->Tcenter = circle - 1;
			#endif
		}
	}
   // Clear shift and restore holo margin & center
   void ResetKor(int circle = 0) {		// 0 for linear, otherwise circle length
      this->Shift = 0;
      if( this->Strand ) { 
			this->End -= this->AbortRange;
			this->Tcenter -= this->AbortRange; 
			#ifdef CIRCULAR
			if(circle && this->End < 0) this->End += circle;
			if(circle && this->Tcenter < 0) this->Tcenter += circle;
			#endif
		}
      else { 
			this->Begin += this->AbortRange; 
			this->Tcenter += this->AbortRange; 
			#ifdef CIRCULAR
			if(circle && this->Begin >= circle) this->Begin -= circle;
			if(circle && this->Tcenter >= circle) this->Tcenter -= circle;
			#endif
		}
   }
	// clear main counters when startup terminates
	virtual void StartupClear(void) { }
private:
	double _Rate_1;		// =1/Rate
};

// The class representing a Kor, derived from the Agent base class
class Kor: public Agent {
public:
	Kor(Agent* parent, int circle = 0) {		// Constructor (parent: Holo | EKor)
		Type = TypeKor;
		Reset(parent, circle);
	}
	int Tcenter;			// Transcription center (position in the main strand)
	double Rate;			// Specific Kor rate
	// Reset variables
	virtual void Reset(void) { }
	virtual void Reset(Agent* agent, int circle = 0) {		// 0: linear, >0: length of circular
		char *name = new char[AGENTNAMELEN*2];
		sprintf(name, "K%s", agent->Name + 1);
		this->Strand = agent->Strand;
		this->Enabled = true;
		if( agent->Type == TypeHolo ) {		// Generated by holoenzyme
			Holo* holo = (Holo*)agent;
			if( holo->Strand ) {
				this->Begin = holo->Begin + holo->SigLength + holo->Shift;
				#ifdef CIRCULAR
				if(circle && this->Begin >= circle) this->Begin -= circle;
				#endif
				this->End = holo->End;
				this->Tcenter = holo->Tcenter;
			}
			else {
				this->Begin = holo->Begin;
				this->End = holo->End - holo->SigLength - holo->Shift;
				#ifdef CIRCULAR
				if(circle && this->End < 0) this->End += circle;
				#endif
				this->Tcenter = holo->Tcenter;
			}
			this->Rate = holo->Rate; _Rate_1 = 1 / this->Rate;
		}
		else {														// Generated by external source
			EKor* ekor = (EKor*)agent;
			sprintf(name + strlen(name), "#%d", ekor->Bound);
			this->Begin = ekor->Begin;
			this->End = ekor->End;
			this->Tcenter = ekor->Tcenter;
			this->Rate = ekor->Rate; _Rate_1 = 1 / this->Rate;
		}
		this->Rule = 1;
		this->TouchTime = agent->TouchTime;
		strncpy(this->Name, name, AGENTNAMELEN-1); this->Name[AGENTNAMELEN-1] = 0;
		delete [] name; name = NULL;
	}
	// Caclulate and set new TouchTime
	virtual void Touch(void) {
		this->TouchTime += _Rate_1;
	}
	// Shift Kor by one position to proper direction
	void Shift(int circle = 0) {
		int step = this->Strand ? 1 : -1;
		this->Begin += step;
		this->End += step;
		this->Tcenter += step;
		#ifdef CIRCULAR
		if(circle) { 
			if(this->Begin >= circle) this->Begin = 0;
			else if(this->Begin < 0) this->Begin = circle - 1;
			if(this->End >= circle) this->End = 0;
			else if(this->End < 0) this->End = circle - 1;
			if(this->Tcenter >= circle) this->Tcenter = 0;
			else if(this->Tcenter < 0) this->Tcenter = circle - 1;
		}
		#endif
	}
	// clear main counters when startup terminates
	virtual void StartupClear(void) { }
private:
	double _Rate_1;		// =1/Rate
};

// The class representing an Rpo, derived from the Agent base class
class Rpo: public Agent {
public:
	Rpo(Agent* parent, int circle = 0) {		// Constructor (parent: NEP | ERpo)
		Type = TypeRpo;
		Reset(parent, circle);
	}
	int Tcenter;			// Transcription center (position in the main strand)
	double Rate;	// Specific Rpo rate
	// Reset variables
	virtual void Reset(void) { }
	virtual void Reset(Agent* agent, int circle = 0) {
		char *name = new char[AGENTNAMELEN*2];
		this->Strand = agent->Strand;
		this->Enabled = true;
		if( agent->Type == TypeNEP ) {		// Generated by NEP promoter
			NEP* nep = (NEP*)agent;
			sprintf(name, "R%s#%d", nep->Name, nep->Bound);
			this->Begin = nep->Begin;
			this->End = nep->End;
			this->Tcenter = nep->Tcenter;
			this->Rate = nep->Rate; _Rate_1 = 1 / this->Rate;
		}
		else {										// Generated by external source
			ERpo* erpo = (ERpo*)agent;
			sprintf(name, "R%s#%d", erpo->Name, erpo->Bound);
			this->Begin = erpo->Begin;
			this->End = erpo->End;
			this->Tcenter = erpo->Tcenter;
			this->Rate = erpo->Rate; _Rate_1 = 1 / this->Rate;
		}
		this->Rule = 2;
		this->TouchTime = agent->TouchTime;
		strncpy(this->Name, name, AGENTNAMELEN-1); this->Name[AGENTNAMELEN-1] = 0;
		delete [] name; name = NULL;
	}
	// Caclulate and set new TouchTime
	virtual void Touch(void) {
		this->TouchTime += _Rate_1;
	}
	// Shift Rpo by one position to proper direction
	void Shift(int circle = 0) {
		int step = this->Strand ? 1 : -1;
		this->Begin += step;
		this->End += step;
		this->Tcenter += step;
		#ifdef CIRCULAR
		if(circle) { 
			if(this->Begin >= circle) this->Begin = 0;
			else if(this->Begin < 0) this->Begin = circle - 1;
			if(this->End >= circle) this->End = 0;
			else if(this->End < 0) this->End = circle - 1;
			if(this->Tcenter >= circle) this->Tcenter = 0;
			else if(this->Tcenter < 0) this->Tcenter = circle - 1;
		}
		#endif
	}
	// clear main counters when startup terminates
	virtual void StartupClear(void) { }
private:
	double _Rate_1;			// =1/Rate
};

// The class representing a terminator (single-strand repressor), derived from the Agent base class
class Term: public Agent {
public:
	Term(void) {			// Constructor
		Type = TypeTerm;
		Lambda = 0.0;
		Active = false;
		SenseKor = true;
		SenseRpo = true;
		Reset();
	}
	Term(Term* term) {	// Copy constructor
		Type = TypeTerm;
		strncpy(Name, term->Name, AGENTNAMELEN-1); Name[AGENTNAMELEN-1] = 0;
		Strand = term->Strand;
		Enabled = term->Enabled;
		Begin = term->Begin;
		End = term->End;
		TouchTime = term->TouchTime;
		Rule = term->Rule;
		Lambda = term->Lambda;
		Offered = term->Offered;
		Bound = term->Bound;
		Active = term->Active;
		SenseKor = term->SenseKor;
		SenseRpo = term->SenseRpo;
	}
	double Lambda;			// Binding intensity of the terminator
	int Offered;			// Overall number of terminators offered for this site
	int Bound;				// Overall number of terminators bound to this site
	bool Active;			// Flag to indicate if the terminator is currently exist
	bool SenseKor;			// Flag to indicate if the terminator is Kor-sensitive
	bool SenseRpo;			// Flag to indicate if the terminator is Rpo-sensitive
	// Reset counters etc.
	virtual void Reset(void) {	
		TouchTime = 0;
		Offered = 0;
		Bound = 0;
	}
	virtual void Reset(Agent* agent, int circle = 0) { }
	// Caclulate and set new TouchTime
	virtual void Touch(void) {
		if( Lambda < SMLAMBDA ) TouchTime = BIGTIME;
		else TouchTime += - log( Random() ) / Lambda;
	}
	// incrementing Offered counter
	void Offer(void) {
		Offered++;
	}
	// incrementing Bound counter
	void Bind(void) {
		Bound++;
	}
	// clear main counters when startup terminates
	virtual void StartupClear(void) { 
		Offered = 0;
		Bound = 0;
	}
	// dynamic parameter modification
	virtual void Modify(Param parnum, double value) { 
		switch( parnum ) {
			case cpRivals::Lambda:			Lambda = value; break;
			case cpRivals::Active:			Active = (value!=0); break;
			case cpRivals::SenseKor:		SenseKor = (value!=0); break;
			case cpRivals::SenseRpo:		SenseRpo = (value!=0); break;
			case cpRivals::Offered:			Offered = (int)value; break;
			case cpRivals::Bound:			Bound = (int)value; break;
		};
	}
	// get parameter value
	virtual double GetValue(Param parnum) { 
		switch( parnum ) {
			case cpRivals::Lambda:			return Lambda;
			case cpRivals::Active:			return Active ? -1.0 : 0.0;
			case cpRivals::SenseKor:		return SenseKor ? -1.0 : 0.0;
			case cpRivals::SenseRpo:		return SenseRpo ? -1.0 : 0.0;
			case cpRivals::Offered:			return (double)Offered;
			case cpRivals::Bound:			return (double)Bound;
			default:								return -1.0;
		};
	}
	// Store current values of changeable properties
	virtual void Store(void) {
		_Lambda = Lambda;
		_Active = Active; _SenseKor = SenseKor; _SenseRpo = SenseRpo;
		_Offered = Offered; _Bound = Bound;
	}
	// Restore initial values of changeable properties
	virtual void Restore(void) { 
		Lambda = _Lambda;
		Active = _Active; SenseKor = _SenseKor; SenseRpo = _SenseRpo;
		Offered = _Offered; Bound = _Bound;
	}
private:
	double _Lambda;
	bool _Active, _SenseKor, _SenseRpo;
	int _Offered, _Bound;
};

typedef struct structDynparam {
	Agent *agent;				// Agent with dynamically variated parameter (NULL=EOList)
	Param parnum;				// Parameter to modify
	Dynatype operation;		// Operation to apply
	int modtime[MAXDSTEP];	// Model time to modify (sec) (-1=EOList)
	double val1[MAXDSTEP];	// New value to set/add/multiply in that moment
	double val2[MAXDSTEP];	// Value2 to modify the parameter
} Dynparam;
// Dummy class for inclusion of dynamic parameter changes in common queue of events
class Dynam: public Agent {
public:
	Dynam(void) {			// Constructor
		Type = TypeDynam;
		agent = NULL;
		parnum = None;
		operation = Nop;
		modtime = -1;
		val1 = 0;
		val2 = 0;
		preset = -1;
	}
	Dynam(Dynparam *dyn, int step) {		// Copy constructor
		Type = TypeDynam;
		agent = dyn->agent;
		parnum = dyn->parnum;
		operation = dyn->operation;
		modtime = dyn->modtime[step];
		val1 = dyn->val1[step];
		val2 = dyn->val2[step];
		preset = agent->GetValue(parnum);
      this->Begin = agent->Begin;
      this->End = agent->End;
	}
	// Caclulate and set new TouchTime
	virtual void Touch(void) {
		TouchTime = modtime;
	}
	// Set a parameter
	void Set(void) {		// Set a parameter
		if( operation == cpRivals::Set ) {
			agent->Modify(parnum, val1);
			// preset = val1;		// not necessary as it will be done for all copies
		}
		else if( operation == cpRivals::Linear )
			agent->Modify(parnum, val1 * preset + val2);
		// else nothing to do
	}
	// externally change preset value
	void Preset(double value) {
		preset = value;
	}
	Agent *agent;			// Agent to modify
	Param	parnum;			// Parameter to modify
	Dynatype operation;	// Type of operation
private:
	int	modtime;			// Time of modification
	double val1;			// Value for Set / Factor for Linear
	double val2;			// Shift for Linear
	double preset;			// Presetted value (-1 = none)
};

// The class representing a task and its immovable agents
class Task {
public:
	Task() {						// Constructor code
		Agents = (Agent**)calloc(AGQUANTUM, sizeof(Agent*));
		#ifdef LOGMEMORY
		if( cpRivals::fLogMemory ) {
			printf("%p: Memory block * allocated for %d bytes\n", Agents, AGQUANTUM * (int)sizeof(Agent*));
			fflush(stdout);
		}
		#endif
		MaxAgents = Agents ? AGQUANTUM : 0;
		Sequence = NULL;
		SeqLength = 0;
		NumAgents = 0;
		Begin = 0;
		End = 0;
		#ifdef CIRCULAR
		Circular = 0;						// default linear
		#endif
	}
	~Task() {
		for( int n=0; n<NumAgents; n++ )
			if( Agents[n] ) { delete Agents[n]; Agents[n] = NULL; }
		if( Agents ) { 
			#ifdef LOGMEMORY
			if( cpRivals::fLogMemory ) {
				printf("%p: Memory block * deallocated\n", Agents);
				fflush(stdout);
			}
			#endif
			free(Agents); Agents = NULL; 
		}
		if( Sequence ) { delete [] Sequence; Sequence = NULL; } 
	}
	char*	Sequence;						// DNA sequence itself
	int	SeqLength;						// Sequence length
	int	NumAgents;						// Number of immovable agents
	int	Begin;							// Position of the task begin (not used if circular)
	int	End;								// Position of the task end (not used if circular)
	#ifdef CIRCULAR
	int	Circular;						// 0: linear, >0: length of circle
	#endif
	// Get the Agent by its index
	Agent* getAgent(int i) {						
		if( i<0 || i>=NumAgents ) return NULL; 
		return Agents[i];
	}
	// Get the index of the Agent (-1 if absent)
	int getIndex(Agent* agent) {					
		int i;
		for( i=0; i<NumAgents; i++ )
			if( Agents[i] == agent ) break;
		if( i >= NumAgents ) return -1;
		else return i;
	}
	// Set the Agent's counters by its index (false=OK true=Error)
	bool setAgent(Agent* agent, int i) {	
		if( !agent || i<0 || i>=NumAgents ) return true;
		if( agent->Type == TypeGene ) {
			Gene* gene = (Gene*)agent;
			((Gene*)Agents[i])->Initiated = gene->Initiated;
			((Gene*)Agents[i])->InitP = gene->InitP;
			((Gene*)Agents[i])->InitN = gene->InitN;
			((Gene*)Agents[i])->Transcribed = gene->Transcribed;
			((Gene*)Agents[i])->TransP = gene->TransP;
			((Gene*)Agents[i])->TransN = gene->TransN;
			((Gene*)Agents[i])->TotalInit = gene->TotalInit;
			((Gene*)Agents[i])->TotalTrans = gene->TotalTrans;
			return false;
		}
		if( agent->Type == TypePEP ) {
			PEP* pep = (PEP*)agent;
			((PEP*)Agents[i])->Offered = pep->Offered;
			((PEP*)Agents[i])->Bound = pep->Bound;
			return false;
		}
		if( agent->Type == TypeNEP ) {
			NEP* nep = (NEP*)agent;
			((NEP*)Agents[i])->Offered = nep->Offered;
			((NEP*)Agents[i])->Bound = nep->Bound;
			return false;
		}
		if( agent->Type == TypeRepr ) {
			Repr* repr = (Repr*)agent;
			((Repr*)Agents[i])->Offered = repr->Offered;
			((Repr*)Agents[i])->Bound = repr->Bound;
			return false;
		}
		if( agent->Type == TypeEKor ) {
			EKor* ekor = (EKor*)agent;
			((EKor*)Agents[i])->Offered = ekor->Offered;
			((EKor*)Agents[i])->Bound = ekor->Bound;
			return false;
		}
		if( agent->Type == TypeERpo ) {
			ERpo* erpo = (ERpo*)agent;
			((ERpo*)Agents[i])->Offered = erpo->Offered;
			((ERpo*)Agents[i])->Bound = erpo->Bound;
			return false;
		}
		if( agent->Type == TypeTerm ) {
			Term* term = (Term*)agent;
			((Term*)Agents[i])->Offered = term->Offered;
			((Term*)Agents[i])->Bound = term->Bound;
			return false;
		}
		return true;
	}
	// Add the Agent (false=OK true=Error)
	bool addAgent(Agent* agent) {				
		if( strlen(agent->Name) == 0 ) 
			return true;
		if( agent->Type != TypeGene && agent->Type != TypePEP && agent->Type != TypeNEP && 
			 agent->Type != TypeRepr && agent->Type != TypeEKor && agent->Type != TypeERpo && 
			 agent->Type != TypeTerm ) return true;
		for( int i=0; i<NumAgents; i++ )
			if( strcmp(Agents[i]->Name, agent->Name) == 0 ) 
				return true;
		if( MaxAgents <= NumAgents ) {
			#ifdef LOGMEMORY
			Agent** oldAgents = Agents;
			#endif
			Agents = (Agent**)realloc(Agents, (MaxAgents + AGQUANTUM) * (int)sizeof(Agent*) );
			if( Agents == NULL ) return true;
			#ifdef LOGMEMORY
			if( cpRivals::fLogMemory ) {
				printf("%p: Memory block [%p] reallocated for %d bytes\n", 
					Agents, oldAgents, (MaxAgents + AGQUANTUM) * (int)sizeof(Agent*));
				fflush(stdout);
			}
			#endif
			MaxAgents += AGQUANTUM;
			for( int i=1; i<AGQUANTUM; i++ )
				Agents[NumAgents + i] = NULL;
		}
		Agents[NumAgents] = agent;
		NumAgents++;
		sortAgents();
		return false;
	}
	// Remove the Agent by its index (false=OK true=Error)
	bool removeAgentIdx(int i) {				
		if( i<0 || i>=NumAgents ) return true;
		delete Agents[i];
		for( ; i<NumAgents-1; i++ )
			Agents[i] = Agents[i+1];
		Agents[i] = NULL;
		NumAgents--;
		Begin = Agents[0]->Begin;
		End = Agents[NumAgents-1]->End;
		return false;
	}
	// Remove the Agent by its pointer (false=OK true=Error)
	bool removeAgent(Agent* agent) {			
		int i;
		for( i=0; i<NumAgents; i++ )
			if( Agents[i] == agent ) break;
		if( i >= NumAgents ) return true;
		delete Agents[i];
		for( ; i<NumAgents-1; i++ )
			Agents[i] = Agents[i+1];
		Agents[i] = NULL;
		NumAgents--;
		Begin = Agents[0]->Begin;
		End = Agents[NumAgents-1]->End;
		return false;
	}
	// Find the Agent by its name (NULL if absent)
	Agent* findAgent(char* name) {				
		int i;
		for( i=0; i<NumAgents; i++ )
			if( strcmp(Agents[i]->Name, name) == 0 ) break;
		if( i >= NumAgents ) return NULL;
		return Agents[i];
	}
	// Find the Index by the Agent name (-1 if absent)
	int findIndex(char* name) {					
		int i;
		for( i=0; i<NumAgents; i++ )
			if( strcmp(Agents[i]->Name, name) == 0 ) break;
		if( i >= NumAgents ) return -1;
		return i;
	}
	// Retrieve Agent list by type (NULL if error or absent)
	Agent** getAgentList(enum AgentTypes type) {	
		if( NumAgents == 0 ) return NULL;
		Agent** list = (Agent**)calloc(NumAgents+1, sizeof(Agent*));
		#ifdef LOGMEMORY
		if( cpRivals::fLogMemory ) {
			printf("%p: Memory block * allocated for %d bytes\n", list, (NumAgents+1) * (int)sizeof(Agent*));
			fflush(stdout);
		}
		#endif
		if( list == NULL ) return NULL;
		int i, j;
		for( i=j=0; i<NumAgents; i++ )
			if( Agents[i]->Type == type )
				list[j++] = Agents[i];
		if( j == 0 ) return NULL;
		list[j++] = NULL;
		#ifdef LOGMEMORY
		Agent** oldlist = list;
		#endif
		list = (Agent**)realloc(list, j * (int)sizeof(Agent*));
		#ifdef LOGMEMORY
		if( cpRivals::fLogMemory ) {
			printf("%p: Memory block [%p] reallocated for %d bytes\n", list, oldlist, j * (int)sizeof(Agent*));
			fflush(stdout);
		}
		#endif
		return list;
	}
private: 
	void sortAgents(void) {
		qsort(Agents, (size_t)NumAgents, sizeof(Agent*), LeftToRight);
		Begin = Agents[0]->Begin;
		End = Agents[NumAgents-1]->End;
	}
private:
	Agent** Agents;						// Array of immovable agents
	int	MaxAgents;						// Variable length of the array
};

typedef struct structJobData {		// Job data structure
	long	Offset;				// offset in the job file to mark when done
	int	LineNumber;			// line number in the job file
	int	RunsDone;			// -1 means terminated jobs
	int	RunsToDo;			// remaining runs to start when possible
	int	inttime;				// current trajectory time
	char	filename[FILENAMELEN];		// intermediate file name
	FILE* wcsv0;				// intermediate file handle
	double	starttime;		// start time of this job
	double*	varvalue;		// ptr to varvalue[varcount]
	Agent**	Agents;			// ptr to the task agents array [task->NumAgents]
} JobData;
#ifdef CPRIVALSMAIN
// MPI related data
	bool	mpimode = true;					// set false by -nompi option
	int	numprocs = 1;						// number of parallel processes
	int	myid = 0;							// my process ID
	int	root = 0;							// root branch ID
	int	tagJobVariables	= 1;			// root -> : assign job with variable values
	int	tagRunCompleted	= 2;			// -> root : model run completed with counter values
	int	tagGetRecords		= 4;			// root -> : get csv portion of the completed run
	int	tagAbortRun			= 8;			// root -> : abort and clear current run
	int	tagRunError			= 16;			// -> root : error encountered during run
	int	tagFinalize			= 32;			// root -> : finalize work
	int	tagInfo				= 64;			// -> root : message to concole
	int	tagInit				= 128;		// dummy tag for logmpi
	bool	collect = true;					// true: console output in the root, false=none
	int	logmpi = 0;		// 1:JobVar 2:RunComp 4:GetRec 8:AbRun 16:RunErr 32:Final 64:Info 128:Init
// Global data
	Configuration config;					// general configuration
	Task* task;									// task in process
	Model* model;								// model of current trajectory
	long	idum;									// working variable for RNG
	int	Origin = 1;							// origin of the circular sequence - don't touch at all!
	char	RpoName[5][8] = {"RpoT1", "RpoT2", "RpoTp", "RpoTm", "RpoTmp"};
	char	inifilename[FILENAMELEN] = "rivals.ini";		// configuration file
	char	tskfilename[FILENAMELEN] = "";					// task file name
	char	rjbfilename[FILENAMELEN] = "";					// job file name
	char	outfilename[FILENAMELEN] = "";					// out file name
	char	scratch[FILENAMELEN] = "";							// scratch directory
	FILE*	wcsv = NULL;						// comma delimited result file
	FILE* wcsv0 = NULL;						// current job portion of csv result
	FILE* wcsv1 = NULL;						// rejected jobs csv result
	FILE* wlog = NULL;						// log file
	bool	MiniLog = true;					// print only minimum data in the log file
	bool	append = false;					// if true, append to output
	bool	automation = false;				// job file processing
	bool	customcsv = false;				// custom format of CSV record
	bool	taskloaded = false;				// indicates if the task has been successfully loaded
	bool	profiling = false;				// true: collect profile data (root only), false: none
	bool	debugline;							// true: job line is Debug statement, false: normal job
	bool	jobmarking = true;				// true: mark done jobs, false: do not mark
	bool	cmdappend = false;				// append mode specified in cmd line
	bool	cmdtime = false;					// physical time specified in cmd line
	bool	cmdstartup = false;				// startup duration specified in cmd line
	bool	cmdstep = false;					// output interval specified in cmd line
	bool	cmdruns = false;					// number of runs specified in cmd line
	bool	cmddecision = false;				// number of runs before decision specified in cmd line
	bool	cmdminratio = false;				// decision threshold specified in cmd line
	bool	cmdgranularity = false;			// console output granularity specified in cmd line
	int	jobline = 0;						// Current line of job file
	int	jobcount = 0;						// Current job number in automation mode
	int	jobtotal = 0;						// Total number of jobs (approximate)
	int	varcount = 0;						// Number of variable parameters
	int	fldcount = 0;						// Number of fields in the CSV record
	Agent* varagent[MAXPARAM];				// Pointers to parameterized agents
	char	varparam[MAXPARAM];				// Parameter codes
	double varvalue[MAXPARAM];				// Parameter values
	Agent* fldagent[MAXFIELD];				// Pointers to printable agents
	char	fldparam[MAXFIELD];				// Field codes
	int	granularity = 10000;				// Operative output setting
	int	Runs = 1;							// Number of runs (to average result)
	int	RunsDone = 0;						// Number of executed runs
	long	InitialSeed = -1;					// Initial seed value for RNG (-1 means time dependent)
	int	regular = 0;						// time step (sec) to output result (0 = only completed)
	int	decide = 0;							// number of runs to decide whether the point is acceptable
	double minratio = 0.001;				// smallest acceptable Min / Sum transcription ratio
	bool	joint = true;						// true: joint number of transcriptions, false: separate P,N
	int	Quelen = 3;							// Queue length to include in the log (0=entire queue)
	int	Logstart = 0;						// Iteration number to start the log (0=no log)
	int	Logstop = 0;						// Iteration number to stop the log (0=never)
	int	Logrun = 1;							// Number of runs to start the log
	int	Logmode = 0x00003FFE;			// Iteration types to log (see LogIter enumeration)
	bool	ingene, outgene, collision;	// Event flags
	bool	noholo, nokor, norpo;			// Flags to mark if an agent was deleted during move
	bool	sample = false;					// true: whole sample output; false: none 
	bool	average = true;					// true: output average record over whole sample; false: none 
	bool	stdev = true;						// true: output std deviation record over whole sample; false: none 
	int	ResultPrecision = 0;				// Number of decimal places in average/stdev field values
	int	ParamPrecision = 2;				// Number of decimal places in argument values
	Dynparam Dyn[MAXDYNAM];					// Table of dynamic modification
#else		// CPRIVALSMAIN not defined
	extern int numprocs, myid, root, logmpi;
	extern int tagJobVariables, tagRunCompleted, tagGetRecords, tagAbortRun, tagRunError, tagFinalize, tagInfo, tagInit;
	extern bool mpimode, collect; 
	extern Configuration config;
	extern char RpoName[5][8];
	extern char inifilename[FILENAMELEN], tskfilename[FILENAMELEN];
	extern char rjbfilename[FILENAMELEN], outfilename[FILENAMELEN], scratch[FILENAMELEN];
	extern FILE *wcsv, *wcsv0, *wcsv1, *wlog;
	extern bool append, automation, customcsv, taskloaded, joint, MiniLog, profiling, jobmarking;
	extern bool cmdappend, cmdtime, cmdstartup, cmdstep, cmdruns, cmddecision, cmdminratio, cmdgranularity;
	extern int jobline, jobcount, jobtotal, varcount, fldcount;
	extern int granularity, Runs, RunsDone, regular, decide;
	extern double minratio;
	extern Agent *varagent[MAXPARAM], *fldagent[MAXFIELD];
	extern char varparam[MAXPARAM], fldparam[MAXFIELD];
	extern double varvalue[MAXPARAM];
	extern Task *task;
	extern Model *model;
	extern long idum, InitialSeed;
	extern int Origin, Quelen, Logstart, Logstop, Logrun, Logmode;
	extern bool ingene, outgene, collision, debugline, noholo, nokor, norpo;
	extern bool sample, average, stdev;
	extern int ResultPrecision, ParamPrecision;
	extern Dynparam Dyn[MAXDYNAM];
#endif	// CPRIVALSMAIN

// This class defines a comparison function for PQueue
class PQueueLater {
public:
   bool operator() (Agent* ag1, Agent* ag2) const {
      if(ag1->TouchTime == ag2->TouchTime) {    // collision avoidance
         if(ag1->Begin == ag2->Begin) {
            // This is possible only for Dynam agents
            Dynam* da1 = (Dynam*)ag1;
            Dynam* da2 = (Dynam*)ag2;
            return (da1->parnum > da2->parnum);
         }
         else return (ag1->Begin > ag2->Begin);
      }
      else return (ag1->TouchTime > ag2->TouchTime);
   }
};
// The class representing current state of the model
class Model {
public:
	Model() {					// Constructor code
		try {
			Time = 0.;
			Startup = cpRivals::config.StartupTime > 0 ? true : false;
			Iteration = 0;
			Hold_P = NULL;
			Hold_P = new Agent*[cpRivals::task->SeqLength + 2];
			for( int n=0; n<cpRivals::task->SeqLength + 2; n++ ) Hold_P[n] = NULL;
			Hold = Hold_P + 1;
			Quelen = 0;
         GeneWrapM = GeneWrapC = HasTerm = false;
			InitializeQueue();
		}
		catch (char *err) {
			char* msg = new char[MSGLEN];
			sprintf(msg, "[%04d] %s\n", cpRivals::myid, err);
			delete [] err;
			if( cpRivals::myid == 0 ) { fprintf(stderr, "%s", msg); fflush(stderr); }
            #ifdef PARALLEL
			else if( cpRivals::collect ) 
				MPI::COMM_WORLD.Send(msg, (int)strlen(msg)+1, MPI::CHAR, root, cpRivals::tagInfo);
            #endif
			if( Hold_P ) delete [] Hold_P;
			delete [] msg;
			//throw;
		}
	}
	~Model() {
		if(Hold_P) delete [] Hold_P;
      while( !PQueue.empty() ) {
         Agent* agent = PQueue.top();
         if(agent && (agent->Type == TypeHolo || agent->Type == TypeKor || 
            agent->Type == TypeRpo || agent->Type == TypeDynam) )
            delete agent;
         PQueue.pop();
      }
	}
	double		Time;				// Physical time of the model
	bool			Startup;			// true: startup phase of the model, false: normal work
	long long	Iteration;		// Iteration number
	Agent**		Hold;				// Moving agents occupying every position of the sequence
   std::priority_queue <Agent*, std::vector<Agent*>, PQueueLater > PQueue;
	int			Quelen;			// Queue length
   bool        GeneWrapM;     // true: a gene on the main strand wraps
   bool        GeneWrapC;     // true: a gene on the complement strand wraps
	bool			HasTerm;			// true: the task contains terminators
	// Add an agent to the queue.
	void addQueue(Agent* agent) {
		if( agent == NULL ) return;
		try {
         PQueue.push(agent);
			Quelen++;
		}
		catch (char *err) {
			char* msg = new char[MSGLEN];
			sprintf(msg, "[%04d] %s\n", cpRivals::myid, err);
			delete [] err;
			if( cpRivals::myid == 0 ) { fprintf(stderr, "%s", msg); fflush(stderr); }
            #ifdef PARALLEL
			else if( cpRivals::collect ) 
				MPI::COMM_WORLD.Send(msg, (int)strlen(msg)+1, MPI::CHAR, root, cpRivals::tagInfo);
            #endif
			delete [] msg;
			if( Hold_P ) delete [] Hold_P;
			//throw;
		}
	}
	// Remove an agent from the queue, with checking.
	void removeQueue(Agent* agent) {
		if( agent == NULL ) return;
      if( agent != PQueue.top() ) {
         char* msg = new char[MSGLEN];
         sprintf(msg, "[%04d] Only top agent can be removed from the queue!\n", cpRivals::myid);
			if( cpRivals::myid == 0 ) { fprintf(stderr, "%s", msg); fflush(stderr); }
            #ifdef PARALLEL
			else if( cpRivals::collect ) 
				MPI::COMM_WORLD.Send(msg, (int)strlen(msg)+1, MPI::CHAR, root, cpRivals::tagInfo);
            #endif
			delete [] msg;
			if( Hold_P ) delete [] Hold_P;
      }
      PQueue.pop();
		Quelen--;
	}
	// Return true if the sequence from begin to end is not occupied.
	#ifndef CIRCULAR
	bool IsFreeRange(int begin, int end) {
		if( begin < 0 || begin > end || end >= cpRivals::task->SeqLength ) return false; // argument error
		int i;
		for( i = begin; i <= end; i++ )
			if( Hold[i] ) break;
		return (i > end) ? true : false;
	}
	#else
	bool IsFreeRange(int begin, int end) {		// Here, begin > end is allowed
		if(cpRivals::task->Circular) {	// circular modify if needed
			if(begin < 0) begin += cpRivals::task->SeqLength;
			else if(begin >= cpRivals::task->SeqLength) begin -= cpRivals::task->SeqLength;
			if(end < 0) end += cpRivals::task->SeqLength;
			else if(end >= cpRivals::task->SeqLength) end -= cpRivals::task->SeqLength;
		}
		if( begin < 0 || end >= cpRivals::task->SeqLength || 
			cpRivals::task->Circular == 0 && begin > end ) {		// argument error
				// return false;
				char errtxt[] = "Margin violated in IsFreeRange";
				throw errtxt;
		}
		if(begin <= end) {
			for(int i = begin; i <= end; i++)
				if( Hold[i] ) return false;
			return true;
		}
		else {
			for(int i = begin; i < cpRivals::task->SeqLength; i++)
				if( Hold[i] ) return false;
			for(int i = 0; i <= end; i++)
				if( Hold[i] ) return false;
			return true;
		}
	}
	#endif
	// Occupy the sequence range with an agent.
	#ifndef CIRCULAR
	void OccupyRange(int begin, int end, Agent* agent) {
		if( begin < 0 || begin > end || end >= cpRivals::task->SeqLength || agent == NULL ) return; // argument error
		for(int i=begin; i<=end; i++)
			Hold[i] = agent;
	}
	#else
	void OccupyRange(int begin, int end, Agent* agent) {		// Here, begin > end is allowed
		if(cpRivals::task->Circular) {	// circular modify if needed
			if(begin < 0) begin += cpRivals::task->SeqLength;
			else if(begin >= cpRivals::task->SeqLength) begin -= cpRivals::task->SeqLength;
			if(end < 0) end += cpRivals::task->SeqLength;
			else if(end >= cpRivals::task->SeqLength) end -= cpRivals::task->SeqLength;
		}
		if( begin < 0 || end >= cpRivals::task->SeqLength || 
			cpRivals::task->Circular == 0 && begin > end ) {	 // argument error
				// return;
				char errtxt[] = "Margin violated in OccupyRange";
				throw errtxt;
		}
		if(begin <= end) {
			for(int i=begin; i<=end; i++)
				Hold[i] = agent;
		}
		else {
			for(int i = begin; i < cpRivals::task->SeqLength; i++)
				Hold[i] = agent;
			for(int i = 0; i <= end; i++)
				Hold[i] = agent;
		}
	}
	#endif
	// Free the sequence range.
	#ifndef CIRCULAR
	void FreeRange(int begin, int end) {
		if( begin < 0 || begin > end || end >= cpRivals::task->SeqLength ) return; // argument error
		for(int i=begin; i<=end; i++)
			Hold[i] = NULL;
	}
	#else
	void FreeRange(int begin, int end) {
		if(cpRivals::task->Circular) {	// circular modify if needed
			if(begin < 0) begin += cpRivals::task->SeqLength;
			else if(begin >= cpRivals::task->SeqLength) begin -= cpRivals::task->SeqLength;
			if(end < 0) end += cpRivals::task->SeqLength;
			else if(end >= cpRivals::task->SeqLength) end -= cpRivals::task->SeqLength;
		}
		if( begin < 0 || end >= cpRivals::task->SeqLength || 
			cpRivals::task->Circular == 0 && begin > end ) {	 // argument error
				// return;
				char errtxt[] = "Margin violated in FreeRange";
				throw errtxt;
		}
		if(begin <= end) {
			for(int i=begin; i<=end; i++)
				Hold[i] = NULL;
		}
		else {
			for(int i = begin; i < cpRivals::task->SeqLength; i++)
				Hold[i] = NULL;
			for(int i = 0; i <= end; i++)
				Hold[i] = NULL;
		}
	}
	#endif
	// Initialize all sources of agents and form the initial queue
private: void InitializeQueue(void) {
		int n = cpRivals::task->NumAgents;
		for( int i=0; i<n; i++ ) {			// Collect and set TouchTime for all relevant agents
			Agent* agent = cpRivals::task->getAgent(i);
			if( ! agent->Enabled ) continue;
         if( agent->Type == TypeGene ) { 
            if(agent->Begin > agent->End) {
               if(agent->Strand) GeneWrapM = true;
               else GeneWrapC = true;
            }
            continue;
         }
			if( agent->Type == TypeTerm )
				HasTerm = true;
			agent->Touch();
			addQueue(agent);
		}
						// Add dummy agents according to dynamic table
		for( int numdyn=0; numdyn<MAXDYNAM && Dyn[numdyn].agent; numdyn++ ) {
			Dynparam *dyn = Dyn + numdyn;
			for( int i=0; dyn->modtime[i]>=0; i++ ) {
				Dynam* dynam = new Dynam(dyn, i);
				dynam->Touch();
				addQueue(dynam);
			}
		}
	}
	Agent**		Hold_P;
};

int	ParseArguments(int argc, char** argv);			// 0: OK, -1: arg error, 1: help requested
void	ShowHelp(void);
bool	LoadConfiguration(char* filename);				// true: OK, false: errors
int	CountJob(char* filename);							// Number of jobs to do, -1: errors
long	LoadRunJob(char* filename, long *offset);		// Offset of the next job, 0: EOF, -1: errors
bool	MarkJobDone(char* filename, long offset);		// true: errors, false: OK
void	TrimExtension(char* filename);
bool	LoadTask(char* filename);							// true: OK, false: errors
void	OutCSVHeader(FILE* wcsv);
void	OutCSVResult(FILE* wcsv, int inttime);
void	OutLogHeader(FILE* wlog);
int	CountRunsDone(FILE* wcsv0);						// Number of executed runs, -1: errors
bool	CopyFile(FILE* from, FILE* to);					// true: errors, false: OK
int	RunTrajectory(void);									// 0: OK, 1: Canceled, -1: errors
bool	CheckFilter(void);									// true: terminate, false: continue
bool	CheckLogging(void);									// true: log record, false: not log
#ifdef LOGGING
char* CheckGene(Agent* poly, int circle);											// ptr: result, NULL: error
char* MoveHolo(Holo* holo, int ToPosition, int circle);						// ptr: result, NULL: error
char* MoveKor(Kor* kor, int FromPosition, int ToPosition, int circle );	// ptr: result, NULL: error
char* MoveRpo(Rpo* rpo, int FromPosition, int ToPosition, int circle );	// ptr: result, NULL: error
#else
void CheckGene(Agent* poly, int circle);								
void MoveHolo(Holo* holo, int ToPosition, int circle);			
void MoveKor(Kor* kor, int FromPosition, int ToPosition, int circle );	
void MoveRpo(Rpo* rpo, int FromPosition, int ToPosition, int circle );	
#endif
Agent* CheckTerm(Agent *, int circle);
bool	SetCurrentParameters(double *varvalue);		// true: errors, false: OK
}
using namespace cpRivals;
#ifdef PARALLEL
using namespace MPI;
#endif
#endif
