//	super3GL:  A program for the phylogenetic supertree construction, v.1.X.X
//	The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/super3gl]
//	(C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
// E-mail: rubanov{at}iitp.ru
//	This program is free software: you can redistribute it and/or modify
//	it under the terms of the GNU General Public License as published by
//	the Free Software Foundation, either version 3 of the License, or
//	(at your option) any later version.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details.
//
//	You should have received a copy of the GNU General Public License
//	along with this program.  If not, see <http://www.gnu.org/licenses/>.

#include <sstream>
#include <string>
#include <stack>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <limits>
#include <stdlib.h>
#include "super3gl.h"
#include "config.h"
#include "forest.h"

using namespace std;

// Normalizes node name as per Newick format
string Tree::normalName(const string& name) {
	ostringstream normal;
	string blank(cfg->BLANK);
	bool quoted = (name.find_first_of(cfg->MUSTQ) != string::npos);
	if(quoted)
		normal << cfg->QUOTE;
	for(int i=0; i < (signed)name.size(); i++) {
			// substitute '_' for entire blank series if not at the end
		if(blank.find_first_of(name[i]) != string::npos) {		
			for( ; i < (signed)name.size(); i++)
				if(blank.find_first_of(name[i]) == string::npos)
					break;
			if(i < (signed)name.size())
				normal << cfg->UND;
			else
				break;
		};
			// double the quotes if any
		if(name[i] == cfg->QUOTE)
			normal << cfg->QUOTE << cfg->QUOTE;
			// just copy other characters
		normal << name[i];
	}
	if(quoted)
		normal << cfg->QUOTE;
	return normal.str();
};

// Inserts node name if needed
string Tree::insertName(PNode node, int mode) {
	ostringstream oss;
	if(! node)
		return "";
	if(node->IsLeaf()) {
		oss << normalName(node->GetName());
		if(mode & Config::LeafIndex)
			oss << "_" << node->GetIndex();
	}
	else if(mode & Config::InnerIndex) 
		oss << node->GetIndex();
	else if((mode & Config::InnerName) || ! node->HasParent() && (mode & Config::RootNameLen) ) 
		oss << normalName(node->GetName());
	if(node->IsLeaf() && (mode & Config::LeafLength) || ! node->IsLeaf() && (mode & Config::InnerLength) 
		|| ! node->HasParent() && (mode & Config::RootNameLen) )
		oss << cfg->LENPR << node->GetLength();
	return oss.str();
};

// Builds the tree description in Newick format
string Tree::Write(int mode) {
	if(mode < 0)		// use default combination of options
		mode = cfg->TreeWriteMode;
	ostringstream oss;
	oss << writeTree(Root, mode) << cfg->EOT;
	return oss.str();
};

// Private recoursive routine for building Newick
string Tree::writeTree(PNode node, int mode) {
	ostringstream oss;
	if(node && !node->GetChild()) {		// This is a leaf
		oss << insertName(node,mode);
	}
	else if(node) {
		PNode child = node->GetChild();
		oss << cfg->LPAR << writeTree(child,mode);
		while(child->GetSibling()) {
			child = child->GetSibling();
			oss << cfg->COMMA << writeTree(child,mode);
		}
		oss << cfg->RPAR << insertName(node,mode);
	}
	return oss.str();
};

// Parses tree description in Newick format
// Existing tree data are lost
bool Tree::Read(const std::string& s) {
	if(s.empty())
		return false;
	int dummygene = 1;
	int len = (int)s.length();
	if(Root || Current || InnerCount + LeafCount > 0) {	// Clear current tree
		DeleteNodeTraverse(Root);
		Root = Current = NULL;
		Name = "";
		Rooted = false;
		InnerCount = LeafCount = MaxDepth = 0;
		MaxIndex = 0;
		MinDegree = numeric_limits<int>::max();
		MaxDegree = 0;
		Inners.clear();
		Leaves.clear();
	}
	SetRoot(AddInnerNode());	// Current = Root
	stack <PNode> curpar;		// Stack of current parents
	const string Blank(cfg->BLANK);
	const string Deltok(cfg->DLTOK);
	bool	foundEOT = false;
		// parse string loop
	for(int i = 0; i < len; i++) {
		// skip comments
		if(s[i] == cfg->BCOM) {
			for( ; i < len; i++)
				if(s[i] == cfg->ECOM)
					break;
			if(i < len)
				continue;				// after end of comment
			#ifdef SUPER3MPI
			if(cfg->super3_mpi && cfg->rank_mpi)
				return false;
			#endif
			cerr TSTAMP << "Tree::Read - Comment not closed at position " << i+1 << "." << endl;
			cfg->clog TSTAMP << "Tree::Read - Comment not closed at position " << i+1 << "." << endl;
			return false;
		}
		// skip blanks
		for( ; i < len; i++)	{
			if(Blank.find_first_of(s[i]) == string::npos)
				break;					// first non-blank found					
		}
		// significant character
		if(s[i] == cfg->EOT) {				// ';' encountered
			foundEOT = true;
			break;
		}
		else if(s[i] == cfg->LPAR) {		// '(' encountered
			curpar.push(GetCurrent());
			AddInnerChild();
		}
		else if(s[i] == cfg->RPAR) {		// ')' encountered
			SetCurrent(curpar.top());
			curpar.pop();
		}
		else if(s[i] == cfg->COMMA) {		// ',' encountered
			AddInnerSibling();
		}
		else {									// token encountered
			string token;
			bool quoted = false;
			if(s[i] == cfg->QUOTE) {
				i++;
				quoted = true;
			}
			// gather token
			for( ; i < len; i++) {
				if(quoted) {
					if(s[i] == cfg->QUOTE && i<len-1 && s[i+1] == cfg->QUOTE)
						i++;
					else if(s[i] == cfg->QUOTE) {
						quoted = false;
						continue;
					}
				}
				else if(Deltok.find_first_of(s[i]) != string::npos) {
					i--;
					break;
				}
				token += s[i];
			}
			// separate length from token
			string::size_type colonpos = token.find_last_of(cfg->LENPR);
			if(colonpos != string::npos) {
				istringstream iss;
				iss.str(token.substr(colonpos + 1));
				float len;
				iss >> len;
				Current->SetLength(len);
				token.erase(colonpos);
			}
         // clear token starting from any of StopLabel characters
         if(!cfg->StopLabel.empty()) {
            string::size_type stop = token.find_first_of(cfg->StopLabel);
            if(stop != string::npos)
               token.erase(stop);
         }
			// parse/cut token according to node type
			if(Current->GetDegree() == 0) {		// Leaf
				string species;
				string::size_type undpos = 0;
				int partnum;
				for(partnum = 0; partnum < cfg->SpecLabelParts; partnum++) {
					undpos = token.find_first_of(cfg->UND, undpos == 0 ? 0 : undpos + 1);
					if(undpos == string::npos)
						break;
				}
				if(partnum < cfg->SpecLabelParts) {
					if(cfg->StrictLabelControl) {
						#ifdef SUPER3MPI
						if(cfg->super3_mpi && cfg->rank_mpi)
							return false;
						#endif
						cerr TSTAMP << "Tree::Read - Insufficient segments in \'" << token << "\'." << endl;
						cfg->clog TSTAMP << "Tree::Read - Insufficient segments in \'" << token << "\'." << endl;
						return false;
					}
					species = token;
				}
				else 
					species = token.substr(0, undpos);
				if( !cfg->StrictLabelControl && GetLeaf(token)) {	// append dummy gene name if needed
					ostringstream oss;
					oss << token << "_" << setfill('0') << setw(4) << dummygene++;
					token = oss.str();
				}
				// Check species map and store species as number in the leaf
				int specnum = SpecCode2Number(species);
				if(specnum == 0) {
					if(cfg->SpecTableGiven && cfg->StrictLabelControl) {
						#ifdef SUPER3MPI
						if(!cfg->super3_mpi || cfg->rank_mpi == 0)
						#endif
						{
							cerr TSTAMP << "Tree::Read - Unknown species code \'" << species << "\' found." << endl;
							cfg->clog TSTAMP << "Tree::Read - Unknown species code \'" << species << "\' found." << endl;
						}
					}
					specnum = AddSpecies(species);
					if(specnum == 0) {
						#ifdef SUPER3MPI
						if(cfg->super3_mpi && cfg->rank_mpi)
							return false;
						#endif
						cerr TSTAMP << "Tree::Read - Cannot insert species code \'" << species << "\'." << endl;
						cfg->clog TSTAMP << "Tree::Read - Cannot insert species code \'" << species << "\'." << endl;
						return false;
					}
				}
				Current->SetSpecies(specnum);
				if(! Inner2Leaf(token)) {
					#ifdef SUPER3MPI
					if(cfg->super3_mpi && cfg->rank_mpi)
						return false;
					#endif
					cerr TSTAMP << "TreeRead: Duplicated leaf name \'" << token << "\'." << endl;
					cfg->clog TSTAMP << "TreeRead: Duplicated leaf name \'" << token << "\'." << endl;
					return false;
				}
			}
			else			// Inner node 
				Current->SetName(token);
			// current child is now finished
		}
	}
	if(! foundEOT) {
		#ifdef SUPER3MPI
		if(cfg->super3_mpi && cfg->rank_mpi)
			return false;
		#endif
		cerr TSTAMP << "TreeRead: End of tree character \'" << cfg->EOT << "\' is not found." << endl;
		cfg->clog TSTAMP << "TreeRead: End of tree character \'" << cfg->EOT << "\' is not found." << endl;
		return false;
	}
	if(! curpar.empty()) {
		#ifdef SUPER3MPI
		if(cfg->super3_mpi && cfg->rank_mpi)
			return false;
		#endif
		cerr TSTAMP << "TreeRead: Unbalanced parentheses." << endl;
		cfg->clog TSTAMP << "TreeRead: Unbalanced parentheses." << endl;
		return false;
	}
	MinMaxDegree(NULL);
	UpdateLite(Root);
	if(!Root->GetParent() && Root->GetDegree() == 2 /*&& MinDegree == 2 && MaxDegree == 2*/)
		Rooted = true;		// Only in standard case of binary rooted tree, otherwise remains unrooted
	return true;
};

// Writes all basis trees to a file with the name preset.
// Tree cost and weight are written in the root node.
void WriteBasisTrees() {
	if(cfg->BasisName.empty())
		throw("WriteBasisTrees: No filename given.");
	ofstream btr;
	string filename = cfg->WorkingDirectory + cfg->BasisName;
	btr.open(filename.c_str());
	if(btr.fail()) {
		string msg = "WriteBasisTrees: Can't create file \'" + filename + "\'.";
		throw(msg);
	}
	PSetMapIter pit;
	for(pit = cfg->PSet.begin(); pit != cfg->PSet.end(); pit++) {
		if( ! pit->second.Basis )
			continue;
		PTree btree = pit->second.BasTree;
		if( ! btree )
			continue;
		PNode root = btree->GetRoot();
		#ifdef BTREEWEIGHT
		root->SetLength(pit->second.Weight);
		#endif
		ostringstream oss;
		oss << pit->second.Cost;
		root->SetName(oss.str());
		btr << btree->Write(Config::RootNameLen) << endl;
	}
	btr.close();
};

// Reads all basis trees from a previously written file.
void ReadBasisTrees() {
	if(cfg->BasisName.empty())
		throw("ReadBasisTrees: No filename given.");
	if( ! cfg->PSet.empty())
		throw("ReadBasisTrees: PSet isn't empty, can't use basis trees.");
	int numleaves = 0, maxleaves = 0;
	ifstream btr;
	string filename = cfg->WorkingDirectory + cfg->BasisName;
	btr.open(filename.c_str());
	if(btr.fail()) {
		string msg = "ReadBasisTrees: Can't open file \'" + filename + "\'.";
		throw(msg);
	}
	int linenum = 0, n = 0;
	string line;
	string treestr;
	bool CommentStarted = false;
	while( ! btr.eof()) {
		getline(btr, line, '\n');
		linenum++;
		if(line.size() <= 3 && treestr.empty())
			continue;
		treestr.append(line);
		string::size_type lastBCOM;
		string::size_type lastECOM;
		if( ! CommentStarted ) {			// No comment yet
			lastBCOM = treestr.find_last_of(cfg->BCOM);
			if(lastBCOM != string::npos) {		// Comment begins
				lastECOM = treestr.find_last_of(cfg->ECOM);
				if(lastECOM == string::npos || lastECOM < lastBCOM) {	// intra-comment line break
					CommentStarted = true;
					continue;
				}
			}
		}
		else {	// Comment started in a previous line
			lastECOM = treestr.find_last_of(cfg->ECOM);
			if(lastECOM != string::npos) {		// Comment ends
				lastBCOM = treestr.find_last_of(cfg->BCOM);
				if(lastBCOM == string::npos || lastBCOM < lastECOM)	
					CommentStarted = false;
			}
			else
				continue;
		}
		string::size_type lastEOT = treestr.find_last_of(cfg->EOT);
		PTree t = NULL;
		if(lastEOT != string::npos) {
			if((t = AddBasisTree(treestr)) == NULL) {
				ostringstream oss;
				oss << "Error in basis tree file \'" << filename << "\' (line " << linenum << ")." << endl;
				throw(oss.str());
			}
			treestr.erase();
			// Milestones
			if(cfg->Milestones && (n++ & cfg->Milestones) == 0) 
				cerr << "BT " << n-1 << "      \r" << flush;
		}
		int leaves = t->GetLeafCount();
		numleaves += leaves;
		if(leaves > maxleaves)
			maxleaves = leaves;
	}
	#ifdef SUPER3MPI
	if(!cfg->super3_mpi || cfg->rank_mpi == 0)
	#endif
	{
		cerr TSTAMP << "Basis tree read: " << cfg->PSet.size() << ", total leaves=" << numleaves 
			<< " (max=" << maxleaves << ")." << endl;
		cfg->clog TSTAMP << "Basis tree read: " << cfg->PSet.size() << ", total leaves=" << numleaves 
			<< " (max=" << maxleaves << ")." << endl;
	}
	int specused;						// calculate the number of relevant species
	if( !cfg->SpecTableGiven )
		specused = cfg->SpecNum;
	else {
		for(int sp = 1; sp <= cfg->SpecNum; sp++)
			cfg->SpeciesData[sp].Enable = false;
		PSetMapIter pit;
		for(pit = cfg->PSet.begin(); pit != cfg->PSet.end(); pit++) {
			PTree t = pit->second.BasTree;
			PNode leaf = t->GetLeafFirst();
			while(leaf) {
				int sp = leaf->GetSpecies();
				cfg->SpeciesData[sp].Enable = true;
				// cfg->Species.insert(SpecMap::value_type(cfg->SpeciesData[sp].Code, sp);		is it needed?
				leaf = t->GetLeafNext();
			}
		}
		specused = 0;
		for(int sp = 1; sp <= cfg->SpecNum; sp++) {
			if(cfg->SpeciesData[sp].Enable)
				specused++;
			else {
				cfg->Species.erase(cfg->SpeciesData[sp].Code);
			}
		}
	}
	#ifdef SUPER3MPI
	if(!cfg->super3_mpi || cfg->rank_mpi == 0)
	#endif
	{
		cerr TSTAMP << "Overall species found: " << specused << "." << endl;
		cfg->clog TSTAMP << "Overall species found: " << specused << "." << endl;
	}
};

// Inserts a basis tree specified in the given string to the PSet.
// Returns the tree pointer (OK) or NULL (errors).
PTree AddBasisTree(const string& treestr) {
	VData vdata;
	vdata.Basis = true;
	vdata.BasTree = new Tree;
	int oldmax = cfg->MaxSpecies;
	if( ! vdata.BasTree->Read(treestr)) {
		delete vdata.BasTree;
		return NULL;
	}
	if(cfg->MaxSpecies > oldmax) {	// myset's maxitem has been increased
		throw("Can't AddBasisTree, provide either species table or greater limit.");
	}
	PNode root = vdata.BasTree->GetRoot();
	vdata.Cost = (float)atof(root->GetName().c_str());
	#ifdef BTREEWEIGHT
	vdata.Weight = root->GetLength();
	#endif
	MakeClades(vdata.BasTree);
	myset clade = *(root->GetClade());
	PSetMapIter hint = cfg->PSet.empty() ? cfg->PSet.end() : --(cfg->PSet.end());
	PSetMapIter itr = cfg->PSet.insert(hint, PSetMapPair(clade,vdata));
	if(itr == cfg->PSet.end()) {
		delete vdata.BasTree;
		return NULL;
	}
	return vdata.BasTree;
};
