//	super3GL:  A program for the phylogenetic supertree construction, v.1.X.X
//	The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/super3gl]
//	(C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
// E-mail: rubanov{at}iitp.ru
//	This program is free software: you can redistribute it and/or modify
//	it under the terms of the GNU General Public License as published by
//	the Free Software Foundation, either version 3 of the License, or
//	(at your option) any later version.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details.
//
//	You should have received a copy of the GNU General Public License
//	along with this program.  If not, see <http://www.gnu.org/licenses/>.

#include <iostream>
#include <iomanip>
#include <complex>
#include <limits>
#include "super3gl.h"
#include "forest.h"
#include "config.h"

using namespace std;

// Shared variables
PSetMapIter	itv;
PSetMapIter pit, pit1, pit2;
PTree			tree;

// Finds good edges/nodes over all trees for each element of P set
void FindGoodEdges(void) {
	int v = 0;
	int mingood = numeric_limits<int>::max(), maxgood = 0; 
	double sum = 0.0, sqsum = 0.0, sumR = 0.0;
   int numgood;
	// Loop over elements of P
	for(itv = cfg->PSet.begin(); itv != cfg->PSet.end(); itv++) {
		// Milestones
		if(cfg->Milestones && (v++ & cfg->Milestones) == 0) 
			cerr << "V " << setfill(' ') << setw(5) << v - 1 << " [" << sum << "]      \r" << flush;
		// Loop over trees
		for(int t = 0; t < cfg->TreeNum; t++) {
			tree = cfg->GTree[t];
			if( !tree )		// removed tree
				continue;
         if((!cfg->Polytomy || tree->GetMaxDegree() <= 2) && 	   // binary case
            checkGood(tree->GetRoot())) {
               tree->IncrementGoodCount();
               (*itv).second.GoodEdge++;
         }
         else if(tree->GetMaxDegree() > 2) {                      // polytomous case 
            clearNodeFlag(tree->GetRoot());
            if(checkGoodPoly(tree->GetRoot())) {
               tree->IncrementGoodCount();
               (*itv).second.GoodEdge++;
            }
            countRV(tree->GetRoot());
            if(tree->GetRoot()->GetFlag())
			      (*itv).second.GoodNum++;      // for superroot
         }
		}
		sumR += (int)(*itv).second.GoodNum;
      numgood = (*itv).second.GoodEdge;
		if(numgood < mingood)
			mingood = numgood;
		if(numgood > maxgood)
			maxgood = numgood;
		sum += numgood;
		sqsum += (double)numgood * numgood;
	}
	#ifdef SUPER3MPI
	if(!cfg->super3_mpi || cfg->rank_mpi == 0)
	#endif
	{
		// Compute statistic data of good edges/nodes over elements of PSet
		int nelem = (int)cfg->PSet.size();
		double m = sum / nelem;
		double d = sqsum / nelem;
		d -= m * m;
		d = sqrt(d * nelem / (nelem - 1));
		cerr TSTAMP << "Good edges in total: " << fixed << setprecision(0) << sum << ", |R(V)|=" << sumR << endl; 
		cfg->clog TSTAMP << "Good edges in total: " << fixed << setprecision(0) << sum << ", |R(V)|=" << sumR << endl;
		cerr TSTAMP << "Per clade: min=" << mingood << ", max=" << maxgood << ", average=" 
			<< fixed << setprecision(0) << m << ", stdev=" << d << "." << endl;
		cfg->clog TSTAMP << "Per clade: min=" << mingood << ", max=" << maxgood << ", average=" 
			<< fixed << setprecision(0) << m << ", stdev=" << d << "." << endl;
		// Compute statistic data of good edges/nodes over trees
		mingood = numeric_limits<int>::max(); 
		maxgood = 0;
		sum = sqsum = 0.;
		for(int t = 0; t < cfg->TreeNum; t++) {
			// Milestones
			if(cfg->Milestones && (t & cfg->Milestones) == 0)
				cerr << "T " << setfill(' ') << setw(4) << t << "      \r" << flush;
			tree = cfg->GTree[t];
			if(tree == NULL)
				continue;
			int numgood = tree->GetGoodCount();
			if(numgood < mingood)
				mingood = numgood;
			if(numgood > maxgood)
				maxgood = numgood;
			sum += numgood;
			sqsum += (double)numgood * numgood;
		}
		int numtree = cfg->TreeNum - cfg->TreePruned;
		m = sum / numtree;
		d = sqsum / numtree;
		d -= m * m;
		d = sqrt(d * numtree / (numtree - 1)); 
		cerr TSTAMP << "Per tree: min=" << mingood << ", max=" << maxgood << ", average=" 
			<< fixed << setprecision(0) << m << ", stdev=" << d << "." << endl;
		cfg->clog TSTAMP << "Per tree: min=" << mingood << ", max=" << maxgood << ", average=" 
			<< fixed << setprecision(0) << m << ", stdev=" << d << "." << endl;
	}
};

// Checks if given node is the child of a good edge, and increments itv.GoodNum if so
bool checkGood(PNode node) {
	if(node->IsLeaf()) {
		if(IsContained((*itv).first, node->GetSpecies())) {
			(*itv).second.GoodNum++;
			return true;
		}
	}
	else {
		if(IsContained((*itv).first, *node->GetClade())) {
			(*itv).second.GoodNum++;
			return true;
		}
	}
	PNode child = node->GetChild();
	while(child) {
      if(checkGood(child)) {
			tree->IncrementGoodCount();
         (*itv).second.GoodEdge++;
      }
		child = child->GetSibling();
	}
	return false;
};

// Checks if given node of polytomous tree is the child of a good edge, and sets its flag
bool checkGoodPoly(PNode node) {
	if(node->IsLeaf()) {
		if(IsContained((*itv).first, node->GetSpecies())) {
         node->SetFlag();
			return true;
		}
	}
	else {
		if(IsContained((*itv).first, *node->GetClade())) {
         node->SetFlag();
			return true;
		}
	}
	PNode child = node->GetChild();
	while(child) {
      if(checkGoodPoly(child)) {
			tree->IncrementGoodCount();
         (*itv).second.GoodEdge++;
      }
		child = child->GetSibling();
	}
   node->SetFlag(false);
	return false;
}

// Uses node flags to calculate R(V) and increment itv.GoodNum
void countRV(PNode node) {
   if(node->IsLeaf())
      return;
   PNode child = node->GetChild();
	bool any = false;
   while(child) {
      countRV(child);
      if(child->GetFlag())
			any = true;
		child = child->GetSibling();
	}
   if(any)
      (*itv).second.GoodNum++;
};

// Clear flags from this node downwards
void clearNodeFlag(PNode node) {
   node->SetFlag(false);
   PNode child = node->GetChild();
   while(child) {
      clearNodeFlag(child);
		child = child->GetSibling();
   }
};

// Checks if given set contains a particular element
bool IsContained(const myset& Where, int What) {
	return Where.test(What);
};

// Checks if given set contains a particular subset
bool IsContained(const myset& Where, const myset& What) {
	if(What.count() > Where.count())
		return false;
	myset temp(Where);
	temp.intersect(What);
	return (temp == What);
};

// Returns |r(V1,V2)| for given V, V1, V2 and tree
int CountRV1V2(const PSetMapIter & V, const PSetMapIter & V1, const PSetMapIter & V2, PTree t) {
	pit = V; pit1 = V1; pit2 = V2;
	tree = t;
	//return cfg->Polytomy ? checkPolyRnode(tree->GetRoot()) : checkRnode(tree->GetRoot());
   return tree->GetMaxDegree() > 2 ? checkPolyRnode(tree->GetRoot()) : checkRnode(tree->GetRoot());
	//return checkPolyRnode(tree->GetRoot());
};

// Recursively checks if a binary tree node is to be counted in |r(V1,V2)|
int checkRnode(PNode node) {
	if(!node || node->IsLeaf())
		return 0;
	int result = 0;
	bool any1 = false;
	bool any2 = false;
	PNode left = node->GetChild();
	PNode right = left->GetSibling();
	myset *clade, *lclade, *rclade;
	clade = node->GetClade();
	if(IsContained(pit->first, *clade) && 						// detailed check of the node
		!IsContained(pit1->first, *clade) && !IsContained(pit2->first, *clade)) {
		if(!left->IsLeaf()) { 
			lclade = left->GetClade();
			if(IsContained(pit1->first, *lclade)) 
				any1 = true;
			else if(IsContained(pit2->first, *lclade)) 
				any2 = true;
		}
		else {
			int sp = left->GetSpecies();
			if(IsContained(pit1->first, sp))
				any1 = true;
			else if(IsContained(pit2->first, sp))
				any2 = true;
		}
		if(!right->IsLeaf()) {				
			rclade = right->GetClade();
			if(IsContained(pit1->first, *rclade))
				any1 = true;
			else if(IsContained(pit2->first, *rclade))
				any2 = true;
		}
		else {								
			int sp = right->GetSpecies();
			if(IsContained(pit1->first, sp))
				any1 = true;
			else if(IsContained(pit2->first, sp))
				any2 = true;
		}
		if(any1 && any2)
			result++;
	}
	return result + checkRnode(left) + checkRnode(right);
};

// Recursively checks if a polytomous tree node is to be counted in |r(V1,V2)|
int checkPolyRnode(PNode node) {
	if(!node || node->IsLeaf())
		return 0;
	int result = 0;
	bool any1 = false;
	bool any2 = false;
	PNode child = node->GetChild();
	myset *clade, *clade1;
	clade = node->GetClade();
	while(child) {
		if(!child->IsLeaf()) {
			clade1 = child->GetClade();
			if(IsContained(pit1->first, *clade1)) 
				any1 = true;
			else if(IsContained(pit2->first, *clade1)) 
				any2 = true;
		}
		else {
			int sp = child->GetSpecies();
			if(IsContained(pit1->first, sp))
				any1 = true;
			else if(IsContained(pit2->first, sp))
				any2 = true;
		}
		result += checkPolyRnode(child);
		child = child->GetSibling();
	}
	if(any1 && any2)
		result++;
	return result;
};

#ifdef SUPER3MPI
// Finds good edges over all trees for each element of P set in parallel
void ParaFindGoodEdges(void) {
	int v = 0;
	int mingood = numeric_limits<int>::max(), maxgood = 0; 
	double sum = 0., sqsum = 0., sumR = 0.;
   int numgood;
	int *goods = new int [2*cfg->size_mpi];   // array of (GoodEdge,GoodNum) pairs from each rank
	int sendgood[2];                          // (GoodEdge,GoodNum) pair of P element
	PSetMapIter *iters = new PSetMapIter [cfg->size_mpi];
	itv = cfg->PSet.begin();
	// Loop over elements of P in parallel
	while(itv != cfg->PSet.end()) {
		CheckAbort();
		for(int rank = 0; rank < cfg->size_mpi; rank++) {
			iters[rank] = itv;
			if(itv != cfg->PSet.end()) {
				// Milestones
				if(cfg->Milestones && (v++ & cfg->Milestones) == 0) 
					cerr << "V " << setfill(' ') << setw(5) << v - 1 << " [" << sum << "]      \r" << flush;
				if(rank == cfg->rank_mpi) {
					// Loop over trees
					for(int t = 0; t < cfg->TreeNum; t++) {
						tree = cfg->GTree[t];
						if( !tree )		// removed tree
							continue;
                  if((!cfg->Polytomy || tree->GetMaxDegree() <= 2) && 	   // binary case
                     checkGood(tree->GetRoot())) {
                        tree->IncrementGoodCount();
                        (*itv).second.GoodEdge++;
                  }
                  else if(tree->GetMaxDegree() > 2) {                      // polytomous case 
                     clearNodeFlag(tree->GetRoot());
                     if(checkGoodPoly(tree->GetRoot())) {
                        tree->IncrementGoodCount();
                        (*itv).second.GoodEdge++;
                     }
                     countRV(tree->GetRoot());
                     if(tree->GetRoot()->GetFlag())
			               (*itv).second.GoodNum++;      // for superroot
                  }
					}
					sendgood[0] = itv->second.GoodEdge;
					sendgood[1] = itv->second.GoodNum;
				}
				itv++;
			}
			else {
            if(rank == cfg->rank_mpi) {
					sendgood[0] = -1;    // means no data exist for the rank
               sendgood[1] = -1;
            }
				break;
			}
		}
//		MPI::COMM_WORLD.Barrier();
		MPI::COMM_WORLD.Allgather(sendgood, 2, MPI::INT, goods, 2, MPI::INT);
		for(int rank = 0; rank < cfg->size_mpi; rank++) {
			if(iters[rank] == cfg->PSet.end())
				break;
         if(rank != cfg->rank_mpi) {
				iters[rank]->second.GoodEdge = goods[2*rank];
				iters[rank]->second.GoodNum = goods[2*rank+1];
         }
         sumR += iters[rank]->second.GoodNum;
			numgood = iters[rank]->second.GoodEdge;
			if(cfg->rank_mpi == 0) {
				if(numgood < mingood)
					mingood = numgood;
				if(numgood > maxgood)
					maxgood = numgood;
				sum += numgood;
				sqsum += (double)numgood * numgood;
			}
		}
	}
	CheckAbort();
	delete [] iters;
	delete [] goods;
	if(cfg->rank_mpi == 0) {
		// Compute statistic data of good edges/nodes over elements of PSet
		int nelem = (int)cfg->PSet.size();
		double m = sum / nelem;
		double d = sqsum / nelem;
		d -= m * m;
		d = sqrt(d * nelem / (nelem - 1));
		cerr TSTAMP << "Good edges in total: " << fixed << setprecision(0) << sum << ", |R(V)|=" << sumR << endl; 
		cfg->clog TSTAMP << "Good edges in total: " << fixed << setprecision(0) << sum << ", |R(V)|=" << sumR << endl;
		cerr TSTAMP << "Per clade: min=" << mingood << ", max=" << maxgood << ", average=" 
			<< fixed << setprecision(0) << m << ", stdev=" << d << "." << endl;
		cfg->clog TSTAMP << "Per clade: min=" << mingood << ", max=" << maxgood << ", average=" 
			<< fixed << setprecision(0) << m << ", stdev=" << d << "." << endl;
	}
	MPI::COMM_WORLD.Barrier();
	int sendtree;
	int recvtree;
	mingood = numeric_limits<int>::max(); 
	maxgood = 0;
	sum = sqsum = 0.;
	// Aggregate GoodCount in trees from all branches
	for(int t = 0; t < cfg->TreeNum; t++) {
		// Milestones
		if(cfg->Milestones && (t & cfg->Milestones) == 0)
			cerr << "T " << setfill(' ') << setw(4) << t << "      \r" << flush;
		tree = cfg->GTree[t];
		if(!tree)
			continue;
		sendtree = tree->GetGoodCount();
		MPI::COMM_WORLD.Barrier();
		MPI::COMM_WORLD.Allreduce(&sendtree, &recvtree, 1, MPI::INT, MPI::SUM);
		tree->SetGoodCount(recvtree);
		if(recvtree < mingood)
			mingood = recvtree;
		if(recvtree > maxgood)
			maxgood = recvtree;
		sum += recvtree;
		sqsum += (double)recvtree * recvtree;
	}
	if(cfg->rank_mpi == 0) {
		// Print statistic data of good edges over trees
		int numtree = cfg->TreeNum - cfg->TreePruned;
		double m = sum / numtree;
		double d = sqsum / numtree;
		d -= m * m;
		d = sqrt(d * numtree / (numtree - 1)); 
		cerr TSTAMP << "Per tree: min=" << mingood << ", max=" << maxgood << ", average=" 
			<< fixed << setprecision(0) << m << ", stdev=" << d << "." << endl;
		cfg->clog TSTAMP << "Per tree: min=" << mingood << ", max=" << maxgood << ", average=" 
			<< fixed << setprecision(0) << m << ", stdev=" << d << "." << endl;
	}
};
#endif
