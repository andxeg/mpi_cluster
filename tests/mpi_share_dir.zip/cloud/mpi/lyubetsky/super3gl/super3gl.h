//	super3GL:  A program for the phylogenetic supertree construction, v.1.X.X
//	The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/super3gl]
//	(C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
//	E-mail: rubanov{at}iitp.ru
//	This program is free software: you can redistribute it and/or modify
//	it under the terms of the GNU General Public License as published by
//	the Free Software Foundation, either version 3 of the License, or
//	(at your option) any later version.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details.
//
//	You should have received a copy of the GNU General Public License
//	along with this program.  If not, see <http://www.gnu.org/licenses/>.
	
#ifndef SUPER3GL_H
#define SUPER3GL_H

#include <ctime>		// Doesn't comply with ISO/ANSI C++ standard, use -Wno-deprecated flag if needed

#define	VERSION	"1.4.5"
#define	TSTAMP  << setfill(' ') << setw(4) << ElapsedMin() << "m "
#define	EPS	1.0e-6
#define  TRUNC	0.499

// Control of optional parts of the program code
#define BTREEWEIGHT		// Include code for optional use of weighted base trees
//#define PROFILING			// Include code for the program profiling
//#define TOPO3VAR2			// Use another version of TripleTopology
//#define CHECKSIZE			// Include code to check equal size of mysets
//#define LOG2TREES        // Log two-species basis trees among others [nompi]
//#define LOGPCHOICE       // Logging choice of best partitioning [mpi]
#ifndef NOMPI           // To be defined in IDE configuration or makefile (-DNOMPI)
#define SUPER3MPI			// Include code for parallelization
#endif
#ifdef SUPER3MPI
#define PARAIDBSET		// Use parallel variant of IdentifyBasisSets()
#endif

#ifdef SUPER3MPI
#include "mpi.h"
#endif

#ifdef PROFILING
void			TimerReset(int n);
void			TimerStart(int n);
void			TimerStop(int n);
clock_t		Timer(int n);
int			TimerSec(int n);
float			TimerMin(int n);
#endif

#endif
