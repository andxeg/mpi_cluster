//	super3GL:  A program for the phylogenetic supertree construction, v.1.X.X
//	The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/super3gl]
//	(C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
// E-mail: rubanov{at}iitp.ru
//	This program is free software: you can redistribute it and/or modify
//	it under the terms of the GNU General Public License as published by
//	the Free Software Foundation, either version 3 of the License, or
//	(at your option) any later version.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details.
//
//	You should have received a copy of the GNU General Public License
//	along with this program.  If not, see <http://www.gnu.org/licenses/>.

#include <fstream>
#include <iostream>
#include <iomanip>
#include <map>
#include <string>
#include <locale>
#include <memory>
#include <stdlib.h>
#include <string.h>
#include "super3gl.h"
#include "config.h"

using namespace std;

// Reads CSV file of <abbr>\t<full>\n records into both map & array
// First SkipLines lines assumed to contain field labels (skipped)
// Returns true(OK) or false(errors)
bool ReadSpeciesTable(string filename) {
	if(filename.empty())
		return false;
	ifstream csv;
	filename = cfg->WorkingDirectory + filename;
	csv.open(filename.c_str());
	if(csv.fail()) {
		#ifdef SUPER3MPI
		if(cfg->super3_mpi && cfg->rank_mpi)
			return false;
		#endif
		cerr TSTAMP << "ReadSpeciesTable: Cannot open \'" << filename << "\'." << endl;
		cfg->clog TSTAMP << "ReadSpeciesTable: Cannot open \'" << filename << "\'." << endl;
		return false;
	}
	if( !cfg->SpeciesData ) {
		cfg->SpeciesData = new SData [cfg->MaxSpecies];
		for(int k = 0; k < cfg->MaxSpecies; k++)
			cfg->SpeciesData[k].Enable = false;
		cfg->SpecNum = 0;
	}
	// Read by lines after skipping 'SkipLines'
	string line;
	int linenum;
	for(linenum = 1; linenum <= cfg->SkipLines; linenum++) {
		getline(csv, line, '\n');
		if(csv.eof() || csv.fail())
			return false;
	}
	while(!csv.eof()) {
		getline(csv, line, '\n');
		linenum++;
		if(line.size() < 3)
			break;
		//if(csv.eof())
		//	break;
		string::size_type tabpos = line.find(cfg->CSVdelimiter);
		if(tabpos == string::npos) {
			#ifdef SUPER3MPI
			if(cfg->super3_mpi && cfg->rank_mpi)
				return false;
			#endif
			cerr TSTAMP << "ReadSpeciesTable: No delimiter in line " << linenum << "." << endl;
			cfg->clog TSTAMP << "ReadSpeciesTable: No delimiter in line " << linenum << "." << endl;
			return false;
		}
		string code = line.substr(0,tabpos);
		// Insert into map
		if(AddSpecies(code, line.substr(tabpos + 1, line.size())) == 0) {
			#ifdef SUPER3MPI
			if(cfg->super3_mpi && cfg->rank_mpi)
				return false;
			#endif
			cerr TSTAMP << "ReadSpeciesTable: Duplicated name \'" << code <<
				"\' in line " << linenum << "." << endl;
			cfg->clog TSTAMP << "ReadSpeciesTable: Duplicated name \'" << code <<
				"\' in line " << linenum << "." << endl;
			return false;
		}
		// Milestones
		if(cfg->Milestones && (cfg->SpecNum & cfg->Milestones) == 0)
			cerr << "S " << setfill(' ') << setw(4) << cfg->SpecNum << "      \r" << flush;
	}
	return true;
};

// Adds species code along with optional full name into the map & array of species
// Returns new spec number (1...) if okay, or 0 if cannot add
int AddSpecies(const string& code, const string& name) {
	SpecMapInsertResult smir = cfg->Species.insert(SpecMap::value_type(code,++(cfg->SpecNum)));
	if(! smir.second) 
		return 0;
	// Check if array has enough size and increase as appropriate
	if( ! cfg->SpeciesData ) {
		cfg->SpeciesData = new SData [cfg->MaxSpecies];
		for(int k = 0; k < cfg->MaxSpecies; k++) {
			cfg->SpeciesData[k].Enable = false;
			cfg->SpeciesData[k].Included = false;
		}
		cfg->SpecNum = 1;
	}
	if(cfg->SpecNum >= cfg->MaxSpecies) {
		SData *NewSpeciesData = new SData [2 * cfg->MaxSpecies];
		for(int i = 1; i < cfg->MaxSpecies; i++) {
			NewSpeciesData[i].Code = cfg->SpeciesData[i].Code;
			NewSpeciesData[i].Enable = cfg->SpeciesData[i].Enable;
         NewSpeciesData[i].Included = cfg->SpeciesData[i].Included;
			NewSpeciesData[i].Meet = cfg->SpeciesData[i].Meet;
			NewSpeciesData[i].Name = cfg->SpeciesData[i].Name;
		}
		for(int k = cfg->MaxSpecies; k < 2 * cfg->MaxSpecies; k++) {
			NewSpeciesData[k].Enable = false;
			NewSpeciesData[k].Included = false;
		}
		delete [] cfg->SpeciesData;
		cfg->SpeciesData = NewSpeciesData;
		cfg->MaxSpecies *= 2;
	}
	SData *SpData = & cfg->SpeciesData[cfg->SpecNum];
	SpData->Code = code;
	SpData->Enable = true;
	SpData->Included = false;
	SpData->Meet = 0;
	SpData->Name = name;
	return cfg->SpecNum;
};

// Checks if given species code is already known
// Returns its number (1...) if okay, or 0 if the code isn't in the map
int SpecCode2Number(const string& code) {
	SpecMap::iterator SpeciesIterator = cfg->Species.find(code);
	if(SpeciesIterator == cfg->Species.end())
		return 0;
	else
		return (*SpeciesIterator).second;
};

// Finds species code from its number
// Returns the code string, or empty string if not exists or disbled
string SpecNumber2Code(int specnum) {
	if(specnum <= 0 || specnum > cfg->SpecNum || ! cfg->SpeciesData[specnum].Enable)
		return "";
	else 
		return cfg->SpeciesData[specnum].Code;
};

// Early processing of some command line arguments
// Returns 0 unless Help (1) or Licence (2) output was requested
int EarlyCommandLine(int argc, char *argv[]) {
	int retcode = 0;
	for(int i = 1; i < argc; i++) {
		if(argv[i][0] != '-' && argv[i][0] != '/')
			continue;
		string option = ToLower(argv[i] + 1);
		if(option.compare("w") == 0 || option.compare("wd") == 0 || option.compare("dir") == 0
			|| option.compare("wdir") == 0) {
			cfg->WorkingDirectory.assign(argv[i+1]);
			continue;
		}
	}
	for(int i = 1; i < argc; i++) {
		if(argv[i][0] != '-' && argv[i][0] != '/')
			continue;
		string option = ToLower(argv[i] + 1);
		if(option.compare("g") == 0 || option.compare("log") == 0) {
			if(argv[i+1][0] != '\"')
				cfg->LogFileName.assign(argv[i+1]);
			else
				cfg->LogFileName.assign(argv[i+1] + 1, strlen(argv[i+1]) - 2);
			continue;
		}
		else if(option.compare("r") == 0 || option.compare("br") == 0 || option.compare("resume") == 0
			|| option.compare("basread") == 0 || option.compare("basisread") == 0) {
				cfg->ResumeGiven = true;
				cfg->Resume = true;
				continue;
		}
		#ifdef SUPER3MPI
		else if(option.compare("nompi") == 0) {
			cfg->super3_mpi = false;
			cfg->rank_mpi = 0;
			continue;
		}
		else if(option.compare("mpi") == 0) {
			cfg->super3_mpi = true;
			continue;
		}
      #else
      else if(option.compare("nompi") == 0 || option.compare("mpi") == 0) {
         continue;
      }
		#endif
		else if(option.compare("h") == 0 || option.compare("?") == 0 || option.compare("help") == 0) {
			retcode = 1;
		}
		else if(option.compare("lic") == 0 || option.compare("gpl") == 0 || option.compare("gnu") == 0) {
			retcode = 2;
		}
	}
	for(int i = 1; i < argc; i++) {
		if(argv[i][0] != '-' && argv[i][0] != '/')
			continue;
		if(argv[i][1] != '-' && argv[i][1] != '/')
			continue;
		string option = ToLower(argv[i] + 2);
		if(option.compare("g") == 0 || option.compare("log") == 0) {
			cfg->LogFileName.clear();
			break;
		}
		else if(option.compare("r") == 0 || option.compare("br") == 0 || option.compare("resume") == 0
			|| option.compare("basread") == 0 || option.compare("basisread") == 0) {
				cfg->ResumeGiven = true;
				cfg->Resume = false;
				continue;
		}
		#ifdef SUPER3MPI
		else if(option.compare("mpi") == 0) {
			cfg->super3_mpi = false;
			cfg->rank_mpi = 0;
			continue;
		}
      #else
      else if(option.compare("mpi") == 0)
         continue;
		#endif
	}
	return retcode;
};

// Parses command line arguments setting appropriate flags & variables
// Returns true=OK of false=Errors (or throws an exception)
bool ParseCommandLine(int argc, char *argv[]) {
	// process other options sequentially
	for(int i = 1; i < argc; i+=2 ) {
		if(argv[i][0] != '-' && argv[i][0] != '/')
			throw("Every command line option must start with '-' or '/'.");
		string option = ToLower(argv[i] + 1);
		if(option.compare("w") == 0 || option.compare("wd") == 0 || option.compare("dir") == 0
			|| option.compare("wdir") == 0) {			// preprocessed
			continue;
		}
		if(option.compare("c") == 0 || option.compare("conf") == 0 || option.compare("config") == 0) {
			cfg->ConfigFileNameGiven = true;
			if(argv[i+1][0] != '\"')
				cfg->ConfigFileName.assign(argv[i+1]);
			else
				cfg->ConfigFileName.assign(argv[i+1] + 1, strlen(argv[i+1]) - 2);
			if( ! ReadConfig() ) 		// Read configuration with given name
				throw("Error found in the configuration file.");
			continue;
		}
		if(option.compare("s") == 0 || option.compare("spec") == 0 || option.compare("species") == 0) {
			cfg->SpecTableGiven = true;
			cfg->SpecTableOverride = false;
			if(argv[i+1][0] != '\"')
				cfg->SpeciesTableName.assign(argv[i+1]);
			else
				cfg->SpeciesTableName.assign(argv[i+1] + 1, strlen(argv[i+1]) - 2);
			if( ! ReadSpeciesTable(cfg->SpeciesTableName))
				throw("Error found in specified table of species.");
			continue;
		}
		if(option.compare("o") == 0 || option.compare("output") == 0 || option.compare("super3") == 0 
			|| option.compare("supertree") == 0) {
			cfg->Super3NameGiven = true;
			if(argv[i+1][0] != '\"')
				cfg->Super3Name.assign(argv[i+1]);
			else
				cfg->Super3Name.assign(argv[i+1] + 1, strlen(argv[i+1]) - 2);
			continue;
		}
		if(option.compare("b") == 0 || option.compare("basis") == 0 || option.compare("btree") == 0
			|| option.compare("bastree") == 0) {
			cfg->BasisNameGiven = true;
			if(argv[i+1][0] != '\"')
				cfg->BasisName.assign(argv[i+1]);
			else
				cfg->BasisName.assign(argv[i+1] + 1, strlen(argv[i+1]) - 2);
			continue;
		}
		if(option.compare("r") == 0 || option.compare("br") == 0 || option.compare("resume") == 0 
			|| option.compare("basread") == 0 || option.compare("basisread") == 0) {	// preprocessed
			i--; continue;
		}
		if(option.compare("g") == 0 || option.compare("log") == 0) {		// preprocessed 
			continue;
		}
		if(option.compare("t") == 0 || option.compare("gt") == 0 || option.compare("tree") == 0 
			|| option.compare("genetree") == 0) {
			cfg->TreeListOverride = false;
			string filename;
			if(argv[i+1][0] != '\"')
				filename.assign(argv[i+1]);
			else
				filename.assign(argv[i+1] + 1, strlen(argv[i+1]) - 2);
			if( ! AddGeneTreeFile(filename))
				throw("Error found in specified tree file.");
			continue;
		}
		if(option.compare("l") == 0 || option.compare("loss") == 0 || option.compare("cl") == 0
			|| option.compare("closs") == 0) {
			cfg->CLossGiven = true;
			cfg->CLoss = (float)atof(argv[i+1]);
			continue;
		}
		if(option.compare("d") == 0 || option.compare("dup") == 0 || option.compare("cd") == 0
			|| option.compare("cdup") == 0) {
			cfg->CDuplicationGiven = true;
			cfg->CDuplication = (float)atof(argv[i+1]);
			continue;
		}
		if(option.compare("p") == 0 || option.compare("minocc") == 0 || option.compare("threshold") == 0) {
			cfg->ThresholdGiven = true;
			cfg->Threshold = atoi(argv[i+1]);
			cfg->TreePruningMode = (cfg->Threshold != 0);
			continue;
		}
		#ifdef BTREEWEIGHT
		if(option.compare("f") == 0 || option.compare("factor") == 0 || option.compare("sf") == 0 
			|| option.compare("scalefactor") == 0) {
			cfg->ScaleFactorGiven = true;
			cfg->ScaleFactor = (float)atof(argv[i+1]);
			continue;
		}
		#endif
		if(option.compare("u") == 0 || option.compare("uncertain") == 0 || option.compare("uncertainty") == 0) {
			cfg->UncertaintyGiven = true;
			cfg->Uncertainty = (float)atof(argv[i+1]);
			continue;
		}
		if(option.compare("v") == 0 || option.compare("zerovalue") == 0 || option.compare("value0") == 0) {
			cfg->ZeroValueGiven = true;
			cfg->ZeroValue = (float)atof(argv[i+1]);
			continue;
		}
		if(option.compare("e") == 0 || option.compare("each") == 0 || option.compare("eachstep") == 0) {
			cfg->EachStepReliabilityGiven = true;
			cfg->EachStepReliability = true;
			i--; continue;
		}
		if(option.compare("m") == 0 || option.compare("milestones") == 0 || option.compare("stamp") == 0) {
			cfg->MilestonesGiven = true;
			if((cfg->Milestones = atoi(argv[i+1])) > 0)
				cfg->Milestones = (1 << cfg->Milestones) - 1;
			continue;
		}
		if(option.compare("nompi") == 0 || option.compare("mpi") == 0)	{  // preprocessed
			i--; continue;
		}
		if(option.compare("x") == 0 || option.compare("dim") == 0) {
			cfg->SpecArrayDimGiven = true;
			cfg->SpecArrayDim = atoi(argv[i+1]);
			if(cfg->SpecArrayDim < 0 || cfg->SpecArrayDim > 3)
				throw("Invalid dimension specified by -x|-dim option.");
			continue;
		}
      if(option.compare("y") == 0 || option.compare("para") == 0) {
         cfg->ParalogyPenaltyGiven = true;
         cfg->ParalogyPenalty = (float)atof(argv[i+1]);
         continue;
      }
      if(option.compare("z") == 0 || option.compare("shift") == 0) {
         cfg->RShiftGiven = true;
         cfg->RShift = (float)atof(argv[i+1]);
         continue;
      }
		if(option.compare("a") == 0 || option.compare("add") == 0) {
			cfg->ExtendPsetGiven = true;
			cfg->ExtendPset = true;
			i--; continue;
		}
		//TODO	append other -options here
		if(option[0] == '-' || option[0] == '/') {
			option = option.substr(1);
			if(option.compare("s") == 0 || option.compare("spec") == 0 || option.compare("species") == 0) {
				cfg->SpecTableGiven = true;
				cfg->SpecTableOverride = true;
				if(cfg->SpecNum) {		// Erase existing table
					delete [] cfg->SpeciesData;
					cfg->SpeciesData = NULL;
					SpecMap::iterator begin = cfg->Species.begin();
					SpecMap::iterator end = cfg->Species.end();
					cfg->Species.erase(begin, end);
					cfg->SpecNum = 0;
				}
				if(argv[i+1][0] == '-' || argv[i+1][0] == '/') {	// just --s
					cfg->SpecTableGiven = false;
					i--; continue;
				}
				else if(argv[i+1][0] != '\"') {
					cfg->SpeciesTableName.assign(argv[i+1]);
				}
				else {
					cfg->SpeciesTableName.assign(argv[i+1] + 1, strlen(argv[i+1]) - 2);
				}
				if( ! ReadSpeciesTable(cfg->SpeciesTableName)) {
					throw("Error found in specified table of species.");
				}
				continue;
			}
			if(option.compare("t") == 0 || option.compare("gt") == 0 || option.compare("tree") == 0 
				|| option.compare("genetree") == 0) {
				cfg->TreeListOverride = true;
				if(cfg->TreeNum) {		// Erase existing trees
					for(int i = 0; i < cfg->TreeNum; i++) {
						delete cfg->GTree[i];
						cfg->GTree[i] = NULL;
					}
					cfg->TreeNum = 0;
				}
				string filename;
				if(argv[i+1][0] == '-' || argv[i+1][0] == '/') {	// just --t
					i--; continue;
				}
				else if(argv[i+1][0] != '\"')
					filename.assign(argv[i+1]);
				else
					filename.assign(argv[i+1] + 1, strlen(argv[i+1]) - 2);
				if( !filename.empty() && ! AddGeneTreeFile(filename))
					throw("Error found in specified tree file.");
				continue;
			}
			if(option.compare("r") == 0 || option.compare("br") == 0 || option.compare("resume") == 0 
				|| option.compare("basread") == 0 || option.compare("basisread") == 0) {	// preprocessed
				i--; continue;
			}
			if(option.compare("g") == 0 || option.compare("log") == 0) {		// preprocessed 
				i--; continue;
			}
			if(option.compare("m") == 0 || option.compare("milestones") == 0 || option.compare("stamp") == 0) {
				cfg->MilestonesGiven = true;
				cfg->Milestones = 0;
				i--; continue;
			}
			if(option.compare("p") == 0 || option.compare("minocc") == 0 || option.compare("threshold") == 0) {
				cfg->ThresholdGiven = true;
				cfg->Threshold = 1;
				cfg->TreePruningMode = true;
				i--; continue;
			}
			if(option.compare("e") == 0 || option.compare("each") == 0 || option.compare("eachstep") == 0) {
				cfg->EachStepReliabilityGiven = true;
				cfg->EachStepReliability = false;
				i--; continue;
			}
			if(option.compare("mpi") == 0)	{				// preprocessed
				i--; continue;
			}
			if(option.compare("a") == 0 || option.compare("add") == 0) {
				cfg->ExtendPsetGiven = true;
				cfg->ExtendPset = false;
				i--; continue;
			}
			//TODO	append other --options here
		}
		string msg = "Invalid command line option \'";
		msg.append(argv[i]);
		msg.append("\'.");
		throw(msg);
	}
	return true;
};

// Returns result of given string conversion to lower case string
string ToLower(const string& s) {
	const char *sz = s.c_str();
	return ToLower(sz);
};

// Returns result of given C-string conversion to lower case string
#if _MSC_VER > 1300
#pragma warning( disable:4996 )
#endif
string ToLower(const char *sz) {
	int len = (int)strlen(sz);
	char *buf = (char*)malloc(len + 1);
	std::uninitialized_copy(sz, sz+len+1, buf);
	locale loc = locale::classic();
	use_facet<ctype<char> > (loc).tolower(buf, buf+len);
	string result(buf);
	free(buf);
	return result;
	#if _MSC_VER > 1300
	#pragma warning( default:4996 )
	#endif
};

// Reads configuration from the file with stored name
// Returns true=OK of false=Errors (or throws an exception)
bool ReadConfig(void) {
	ifstream in;
	string filename = cfg->WorkingDirectory + cfg->ConfigFileName;
	in.open(filename.c_str());
	if(in.fail()) {
		if(cfg->ConfigFileNameGiven) {
			#ifdef SUPER3MPI
			if(cfg->super3_mpi && cfg->rank_mpi)
				return false;
			#endif
			cerr TSTAMP << "Cannot open configuration file \'" << cfg->ConfigFileName << "\'." << endl;
			cfg->mem TSTAMP << "Cannot open configuration file \'" << cfg->ConfigFileName << "\'." << endl;
			return false;
		}
		#ifdef SUPER3MPI
		else if(!cfg->super3_mpi || cfg->rank_mpi == 0) {
		#else
		else {
		#endif
			cerr TSTAMP << "Configuration file not found - using defaults." << endl;
			cfg->mem TSTAMP << "Configuration file not found - using defaults." << endl;
		}
	}
	else {
		int linenum = 0;
		string line;
		string key;
		string *values = new string [cfg->MaxValues];
		while( ! in.eof()) {
			getline(in, line, '\n');
			linenum++;
			// Remove leading blanks & skip comments
			string::size_type pos = line.find_first_not_of(cfg->CBLANK);
			if(pos == string::npos)
				continue;					// skip empty lines
			string::size_type rem = line.find_first_of(cfg->CREM, pos);
			if(rem == pos)
				continue;					// skip comment lines
			// Identify & normalize key
			string::size_type end = line.find_first_of(cfg->CDELIM, pos);
			string::size_type count = (end == string::npos) ? end : end - pos;
			key = ToLower(line.substr(pos, count));
			// Collect value(s)
			int valuenum;
			for(valuenum = 0; ; valuenum++) {
				pos = line.find_first_not_of(cfg->CDELIM, end);
            rem = line.find_first_of(cfg->CREM, pos);    // since 1.1.8 for rem char inside string value
				if(pos == string::npos || pos == rem)
					break;
				if(valuenum >= cfg->MaxValues) {
					#ifdef SUPER3MPI
					if(cfg->super3_mpi && cfg->rank_mpi)
						return false;
					#endif
					cerr TSTAMP << "Too many values (" << valuenum << ") in configuration line " 
                  << linenum << "." << endl;
					cfg->mem TSTAMP << "Too many values (" << valuenum << ") in configuration line " 
                  << linenum << "." << endl;
					return false;
				}
				if(line[pos] == cfg->CQUOTE) { 
					end = line.find(cfg->CQUOTE, ++pos);
					count = (end == string::npos) ? end : end - pos;
					values[valuenum++] = line.substr(pos, count);
					end = line.find_first_of(cfg->CDELIM, ++end);
				}
				else {
					end = line.find_first_of(cfg->CDELIM, pos);
					count = (end == string::npos) ? end : end - pos;
					values[valuenum++] = line.substr(pos, count);
				}
			}
			// Parse option
			if(key == ToLower("MaxValues")) {
				int val;
				if(valuenum && (val = atoi(values[0].c_str())) > 0)
					cfg->MaxValues = val;
			}
			else if(key == ToLower("WorkingDirectory")) {
				if(cfg->WorkingDirectory.empty())			// only if wasn't specified in cmd line
					cfg->WorkingDirectory = values[0];
			}
			else if(key == ToLower("Milestones")) {
				if( ! cfg->MilestonesGiven ) {
					int val = atoi(values[0].c_str());
					if(val > 0) 
						cfg->Milestones = (1 << val) - 1;
					else
						cfg->Milestones = val;
				}
			}
			else if(key == ToLower("Resume")) {
				if( !cfg->ResumeGiven) 
					CheckBool("Resume", cfg->Resume, values[0]);
			}
			else if(key == ToLower("SpeciesTableName")) {
				if( ! cfg->SpecTableOverride) {
					cfg->SpeciesTableName = values[0];
					if( ! ReadSpeciesTable(cfg->SpeciesTableName)) {
						#ifdef SUPER3MPI
						if(cfg->super3_mpi && cfg->rank_mpi)
							return false;
						#endif
						cerr TSTAMP << "Error found in configured table of species." << endl;
						cfg->mem TSTAMP << "Error found in configured table of species." << endl;
						return false;
					}
					cfg->SpecTableGiven = true;
				}
			}
			else if(key == ToLower("MaxSpecies")) {
				int val;
				if(valuenum && (val = atoi(values[0].c_str())) > 0)
					cfg->MaxSpecies = val;
			}
			else if(key == ToLower("CSVdelimiter")) {
				if(ToLower(values[0]) == ToLower("Tab"))
					cfg->CSVdelimiter = '\t';
				else if(ToLower(values[0]) == ToLower("Blank"))
					cfg->CSVdelimiter = ' ';
				else
					cfg->CSVdelimiter = values[0][0];
			}
			else if(key == ToLower("SkipLines")) {
				int val;
				if(valuenum && (val = atoi(values[0].c_str())) >= 0)
					cfg->SkipLines = val;
			}
			else if(key == ToLower("MaxTrees")) {
				int val;
				if(valuenum && (val = atoi(values[0].c_str())) > 0) {
					if(cfg->MaxTrees < val) {		// Only increase table of gene trees if needed
						PTree *tmp = new PTree [val];
						for(int i = 0; i < cfg->TreeNum; i++)
							tmp[i] = cfg->GTree[i];
						delete [] cfg->GTree;
						cfg->GTree = tmp;
						cfg->MaxTrees = val;
					}
				}
			}
			else if(key == ToLower("SpecLabelParts")) {
				int val;
				if(valuenum && (val = atoi(values[0].c_str())) > 0) 
					cfg->SpecLabelParts = val;
				#ifdef SUPER3MPI
				else if(!cfg->super3_mpi || cfg->rank_mpi == 0) {
				#else
				else {
				#endif
					cerr TSTAMP << "Invalid configuration value of SpecLabelParts ignored." << endl;
					cfg->mem TSTAMP << "Invalid configuration value of SpecLabelParts ignored." << endl;
				}
			}
         else if(key == ToLower("StopLabel")) {
            cfg->StopLabel = values[0];
         }
			else if(key == ToLower("StrictLabelControl")) 
				CheckBool("StrictLabelControl", cfg->StrictLabelControl, values[0]);
			else if(key == ToLower("GeneTreeName")) {
				#ifdef SUPER3MPI
				if(cfg->Resume && (!cfg->super3_mpi || cfg->rank_mpi == 0)) {
				#else
				if(cfg->Resume) {
				#endif
					cerr TSTAMP << "Resume mode - gene tree file \'" << values[0] << "\' ignored." << endl; 
					cfg->mem TSTAMP << "Resume mode - gene tree file \'" << values[0] << "\' ignored." << endl; 
				}
            else {
               if(!cfg->TreeListOverride)
					   AddGeneTreeFile(values[0]);
            }
			}
			else if(key == ToLower("GeneTree")) {
				#ifdef SUPER3MPI
				if(cfg->Resume && (!cfg->super3_mpi || cfg->rank_mpi == 0)) {
				#else
				if(cfg->Resume) {
				#endif
					cerr TSTAMP << "Resume mode - gene tree ignored." << endl; 
					cfg->mem TSTAMP << "Resume mode - gene tree ignored." << endl; 
				}
            else {
               if(!cfg->TreeListOverride)
					   AddGeneTree(values[0]);
            }
			}
			else if(key == ToLower("TreeWriteMode")) {
				int val;
				if(valuenum && (val = atoi(values[0].c_str())) >= 0)
					cfg->TreeWriteMode = val;
			}
			else if(key == ToLower("Super3Name")) {
				if( ! cfg->Super3NameGiven) {
					cfg->Super3Name = values[0];
					cfg->Super3NameGiven = true;
				}
			}
			else if(key == ToLower("Super3Sequence")) 
				CheckBool("Super3Sequence", cfg->Super3Sequence, values[0]);
			else if(key == ToLower("Super3Quality")) 
				CheckBool("Super3Quality", cfg->Super3Quality, values[0]);
			else if(key == ToLower("BasisName")) {
				if( ! cfg->BasisNameGiven) { 
					cfg->BasisName = values[0];
					cfg->BasisNameGiven = true;
				}
			}
			else if(key == ToLower("Threshold")) {
				if( ! cfg->ThresholdGiven && valuenum) 
					cfg->Threshold = atoi(values[0].c_str());
			}
			else if(key == ToLower("CostOfLoss")) {
				if( ! cfg->CLossGiven && valuenum)
					cfg->CLoss = (float)atof(values[0].c_str());
			}
			else if(key == ToLower("CostOfDuplication")) {
				if( ! cfg->CDuplicationGiven && valuenum)
					cfg->CDuplication = (float)atof(values[0].c_str());
			}
			else if(key == ToLower("TreePruningMode"))
				CheckBool("TreePruningMode", cfg->TreePruningMode, values[0]);
			else if(key == ToLower("ExtendPset")) {
				if( ! cfg->ExtendPsetGiven && valuenum)
					CheckBool("ExtendPset", cfg->ExtendPset, values[0]);
			}
			else if(key == ToLower("BasisTreeWeight")) {
				#ifdef BTREEWEIGHT
				CheckBool("BasisTreeWeight", cfg->BasisTreeWeight, values[0]);
				#else
				#ifdef SUPER3MPI
				if(!cfg->super3_mpi || cfg->rank_mpi == 0)
				#endif
				{
				cerr TSTAMP << "BasisTreeWeight option is not available in this program version." << endl;
				cfg->mem TSTAMP << "BasisTreeWeight option is not available in this program version." << endl;
				}
				#endif
			}
			#ifdef BTREEWEIGHT
			else if(key == ToLower("ScaleFactor")) {
				if( !cfg->ScaleFactorGiven )
					cfg->ScaleFactor = (float)atof(values[0].c_str()); 
			}
			else if(key == ToLower("MinWeight")) {
				cfg->MinWeight = (float)atof(values[0].c_str());
			}
			#endif
			else if(key == ToLower("Uncertainty")) {
				if( !cfg->UncertaintyGiven )
					cfg->Uncertainty = (float)atof(values[0].c_str());
			}
			else if(key == ToLower("ZeroValue")) {
				if( !cfg->ZeroValueGiven )
					cfg->ZeroValue = (float)atof(values[0].c_str());
			}
			else if(key == ToLower("EachStepReliability")) {
				if( !cfg->EachStepReliabilityGiven )
					CheckBool("EachStepReliability", cfg->EachStepReliability, values[0]);
			}
			else if(key == ToLower("SpecArrayDim")) {
				if(!cfg->SpecArrayDimGiven) {
					int val;
					if(valuenum && (val = atoi(values[0].c_str())) >= 0 && val <=3)
						cfg->SpecArrayDim = val;
					#ifdef SUPER3MPI
					else if(!cfg->super3_mpi || cfg->rank_mpi == 0) {
					#else
					else {
					#endif
						cerr TSTAMP << "Invalid configuration value of SpecArrayDim ignored." << endl;
						cfg->mem TSTAMP << "Invalid configuration value of SpecArrayDim ignored." << endl;
					}
				}
			}
         else if(key == ToLower("ParalogyPenalty")) {
            if(valuenum && !cfg->ParalogyPenaltyGiven)
               cfg->ParalogyPenalty = (float)atof(values[0].c_str());
         }
         else if(key == ToLower("RShift")) {
            if(valuenum && !cfg->RShiftGiven)
               cfg->RShift = (float)atof(values[0].c_str());
         }
			else if(key == ToLower("SpeciesLength"))
            CheckBool("SpeciesLength", cfg->SpeciesLength, values[0]);
         else if(key == ToLower("SkipAmbiguous"))
            CheckBool("SkipAmbiguous", cfg->SkipAmbiguous, values[0]);
			else if(key == ToLower("TreeLogMode")) {
				int val;
				if(valuenum && (val = atoi(values[0].c_str())) >= 0)
					cfg->TreeLogMode = val;
			}
			else if(key == ToLower("LogActualTrees"))
				CheckBool("LogActualTrees", cfg->LogActualTrees, values[0]);
			else if(key == ToLower("LogActualSpecies"))
				CheckBool("LogActualSpecies", cfg->LogActualSpecies, values[0]);
			else if(key == ToLower("LogEntirePset"))
				CheckBool("LogEntirePset", cfg->LogEntirePset, values[0]);
			else if(key == ToLower("LogBasisSets"))
				CheckBool("LogBasisSets", cfg->LogBasisSets, values[0]);
			else if(key == ToLower("LogBasisTrees"))
				CheckBool("LogBasisTrees", cfg->LogBasisTrees, values[0]);
			else if(key == ToLower("LogTopology3"))
				CheckBool("LogTopology3", cfg->LogTopology3, values[0]);
			else if(key == ToLower("LogSuper3"))
				CheckBool("LogSuper3", cfg->LogSuper3, values[0]);
			else if(key == ToLower("LogChoice3"))
				CheckBool("LogChoice3", cfg->LogChoice3, values[0]);
			//TODO	continue with config statements here
			else {
				#ifdef SUPER3MPI
				if(cfg->super3_mpi && cfg->rank_mpi)
					return false;
				#endif
				cerr TSTAMP << "Invalid key in configuration line " << linenum << "." << endl;
				cfg->mem TSTAMP << "Invalid key in configuration line " << linenum << "." << endl;
				return false;
			}
		}
	}
	// Config postprocessing
	if( ! cfg->SpeciesData ) {
		cfg->SpeciesData = new SData [cfg->MaxSpecies];
		for(int k = 0; k < cfg->MaxSpecies; k++)
			cfg->SpeciesData[k].Enable = false;
		cfg->SpecNum = 0;
	}
	return true;
};

// Parses given tree file and appends tree pointer(s) to GTree table
// Increases TreeNum and reallocates the table if necessary
// Returns true=OK or false(Errors)
bool AddGeneTreeFile(string filename) {
	ifstream in;
	filename = cfg->WorkingDirectory + filename;
	in.open(filename.c_str());
	if(in.fail()) {
		#ifdef SUPER3MPI
		if(cfg->super3_mpi && cfg->rank_mpi)
			return false;
		#endif
		cerr TSTAMP << "Cannot open tree file \'" << filename << "\'." << endl;
		cfg->clog TSTAMP << "Cannot open tree file \'" << filename << "\'." << endl;
		return false;
	}
	int linenum = 0;
	string line;
	string tree;
	bool CommentStarted = false;
	while( ! in.eof()) {
		getline(in, line, '\n');
		linenum++;
		//if(in.eof())
		//	break;
		tree.append(line);
		string::size_type lastBCOM;
		string::size_type lastECOM;
		if( ! CommentStarted ) {		// No comment yet
			lastBCOM = tree.find_last_of(cfg->BCOM);
			if(lastBCOM != string::npos) {		// Comment begins
				lastECOM = tree.find_last_of(cfg->ECOM);
				if(lastECOM == string::npos || lastECOM < lastBCOM) {	// intra-comment line break
					CommentStarted = true;
					continue;
				}
			}
		}
		else {	// Comment started in a previous line
			lastECOM = tree.find_last_of(cfg->ECOM);
			if(lastECOM != string::npos) {		// Comment ends
				lastBCOM = tree.find_last_of(cfg->BCOM);
				if(lastBCOM == string::npos || lastBCOM < lastECOM)	
					CommentStarted = false;
			}
			else
				continue;
		}
		string::size_type lastEOT = tree.find_last_of(cfg->EOT);
		if(lastEOT != string::npos) {
			if( ! AddGeneTree(tree)) {
				#ifdef SUPER3MPI
				if(cfg->super3_mpi && cfg->rank_mpi)
					return false;
				#endif
				cerr TSTAMP << "Error in tree file \'" << filename << "\' (line " << linenum << ")." << endl;
				cfg->clog TSTAMP << "Error in tree file \'" << filename << "\' (line " << linenum << ")." << endl;
				return false;
			}
			tree.erase();
		}
	}
	return true;
};

// Parses given tree string and appends the tree pointer to GTree table
// Increases TreeNum and reallocates the table if necessary
// Returns true=OK or false(Errors)
bool AddGeneTree(const string& tree) {
	PTree t = new Tree;
	if( ! t->Read(tree)) {
		delete t;
		return false;
	}
	if(cfg->TreeNum >= cfg->MaxTrees) {		// Increase GTree table
		PTree *tmp = new PTree [2 * cfg->MaxTrees];
		for(int i = 0; i < cfg->MaxTrees; i++)
			tmp[i] = cfg->GTree[i];
		delete [] cfg->GTree;
		cfg->GTree = tmp;
		cfg->MaxTrees *= 2;
	}
	cfg->GTree[cfg->TreeNum++] = t;
	// Milestones
	if(cfg->Milestones && (cfg->TreeNum & cfg->Milestones) == 0)
		cerr << "T " << setfill(' ') << setw(4) << cfg->TreeNum << "      \r" << flush;
	return true;
};

// Checks and sets the given boolean parameter according to a string value
void CheckBool(const string& name, bool& param, const string& value) {
	string low = ToLower(value);
	if(value[0] == 0 || low == "false" || low == "disable" || low == "no" || low == "not" || low == "off")
		param = false;
	else if(value[0] == 1 || low == "true" || low == "enable" || low == "yes" || low == "on")
		param = true;
	#ifdef SUPER3MPI
	else if(!cfg->super3_mpi || cfg->rank_mpi == 0) {
	#else
	else {
	#endif
		cerr TSTAMP << "Invalid configuration value \'" << value << "\' of " << name << " ignored." << endl;
		cfg->mem TSTAMP << "Invalid configuration value \'" << value << "\' of " << name << " ignored." << endl;
	}
};
