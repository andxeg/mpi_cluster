//	super3GL:  A program for the phylogenetic supertree construction, v.1.X.X
//	The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/super3gl]
//	(C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
// E-mail: rubanov{at}iitp.ru
//	This program is free software: you can redistribute it and/or modify
//	it under the terms of the GNU General Public License as published by
//	the Free Software Foundation, either version 3 of the License, or
//	(at your option) any later version.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details.
//
//	You should have received a copy of the GNU General Public License
//	along with this program.  If not, see <http://www.gnu.org/licenses/>.

#include <fstream>
#include <iostream>
#include <iomanip>
#include <strstream>
#include <limits>
#include <complex>
#include <queue>
#include <vector>
#include "super3gl.h"
#include "forest.h"
#include "config.h"

using namespace std;

class Sp2Add {
public:
   double   criterion;  // comparison criterion
   int      species;    // species number
   int      nodeno;     // best node no. in nodes[]
   double   best;       // best quality value
   PNode    bestnode;   // best quality node to unsert over
   double   good;       // good quality value
   PNode    goodnode;   // good quality node to unsert over
   double   R;          // reliability of insertion
};
// This class defines a comparison function for MyQueue
class MyQueueLess {
public:
   bool operator() (Sp2Add* sp1, Sp2Add* sp2) const {
      if(sp1->criterion == sp2->criterion) {
         if(sp1->best == sp2->best)
            return (sp1->R < sp2->R);
         return (sp1->best < sp2->best);
      }
      return (sp1->criterion < sp2->criterion);
   }
};
typedef priority_queue <Sp2Add*, vector<Sp2Add* >, MyQueueLess > MyQueue;

// Incremental building of the species tree (all variants)
void BuildSpeciesTree(int spin) {
	if(cfg->LogSuper3)
		cfg->clog << "\nBuilding of the supertree:" << endl;
	#ifdef PROFILING
	TimerReset(0);
	TimerStart(0);
	TimerReset(1);
	TimerReset(2);
	TimerReset(3);
	TimerReset(4);
	TimerReset(5);
	TimerReset(6);
	TimerReset(7);
	TimerReset(8);
	#endif
	// Main loop of the species addition
	int addedsp = 0;			// id (number) of added species
	double R = 0;				// reliability of such addition
   double Criterion;       // current greater Q*(R+1) product  
	PTree BestTree = NULL, GoodTree = NULL;
	double BestQ = -1;
   int skipped = 0;
   MyQueue queue;
	for( ; ; spin++) {
      while( !queue.empty() ) {  // to ensure that it's empty
         Sp2Add* specdata = queue.top();
         queue.pop();
         delete specdata;
      }
      Criterion = -1;
		if(cfg->EachStepReliability || spin == (int)cfg->Species.size()) {
			MakeClades(cfg->STree);
			switch(cfg->SpecArrayDim) {					
				case 0:	ReliabilityCalc0(); break;
				case 1:	ReliabilityCalc1(); break;
				case 2:	ReliabilityCalc2(); break;
				case 3:	ReliabilityCalc3(); break;
			}
		}
      // Output in the species tree file or cout
		if(cfg->Super3NameGiven) { 
			if(!cfg->Super3Sequence)
				cfg->super3.seekp(0);
			if(cfg->Super3Quality) {
				cfg->super3 << "[" TSTAMP << " N=" << spin;
				if(addedsp)
					cfg->super3 << " (" << cfg->SpeciesData[addedsp].Code << " added)";
				cfg->super3 << "  TotalQ=" << fixed << setprecision(2) << cfg->TotalQ;
				if(addedsp)
					cfg->super3 << "  Q=" << fixed << setprecision(2) << BestQ 
                  << "  R=" << fixed << setprecision(6) << R;
            if(skipped)
               cfg->super3 << " (" << skipped << " species skipped)";
				cfg->super3 << " ]" << endl;
			}
			cfg->super3 << cfg->STree->Write(cfg->TreeWriteMode) << endl;
		}
		else {
			if(cfg->Super3Quality) {
				cout TSTAMP << " N=" << spin;
				if(addedsp)
					cout << " (" << cfg->SpeciesData[addedsp].Code << " added)";
				cout << " TotalQ=" << fixed << setprecision(0) << cfg->TotalQ;
				if(addedsp)
					cout << " R=" << fixed << setprecision(4) << R;
            if(skipped)
               cout << " (" << skipped << " species skipped)";
				cout << endl;
			}
			cout << cfg->STree->Write(cfg->TreeWriteMode) << endl;
		}
		// Optional logging
		if(cfg->LogSuper3) {    // Logging supertree construction with additional data
			cfg->clog TSTAMP << "  N=" << spin;
			if(addedsp)
				cfg->clog << " (" << cfg->SpeciesData[addedsp].Code << " added)";
			cfg->clog << "  TotalQ=" << fixed << setprecision(2) << cfg->TotalQ;
			if(addedsp)
				cfg->clog << "  Q=" << fixed << setprecision(2) << BestQ 
               << "  R=" << fixed << setprecision(6) << R;
         if(skipped)
            cfg->clog << " (" << skipped << " species skipped)";
         int stmode = cfg->TreeLogMode;
         if(cfg->LogChoice3) stmode |= Config::InnerIndex;
			cfg->clog << endl << cfg->STree->Write(stmode) << endl;
		}
		#ifdef PROFILING
		TimerStop(0);
		cout << Timer(0) << "\t" << Timer(1) << "\t" << Timer(2) << "\t" << Timer(3) << "\t"
			<< Timer(4) << "\t" << Timer(5) << "\t" << Timer(6) << "\t" << Timer(7) << "\t"
			<< Timer(8) << endl;
		TimerReset(0);		// Overhead
		TimerStart(0);
		TimerReset(1);		// TryNextLeaf
		TimerReset(2);		// TreeQuality
		TimerReset(3);		// TryNextInner
		TimerReset(4);		// TripleQuality
		TimerReset(5);		
		TimerReset(6);		
		TimerReset(7);		
		TimerReset(8);		
		#endif
		// Loop over species which are not included yet
      skipped = 0;
		for(int sp = 1; sp <= cfg->SpecNum; sp++) {
			if( !cfg->SpeciesData[sp].Enable || cfg->SpeciesData[sp].Included)
				continue;
			// Milestones
			if(cfg->Milestones && (sp & cfg->Milestones) == 0)
				cerr TSTAMP << " ST " << setfill(' ') << setw(4) << spin << setw(5) << sp 
					<< " TotalQ=" << setprecision(0) << fixed << cfg->TotalQ + BestQ << "      \r" << flush;
			// Loop over all nodes of the current tree: leaves, inners
			string newname = cfg->SpeciesData[sp].Code;
			PTree tree = cfg->STree;		
			double best = -1, good = -1;
         PNode bestnode = 0, goodnode = 0;
			#ifdef PROFILING
			TimerStop(0);
			TimerStart(1);
			#endif
			PNode node = tree->GetLeafFirst();
			while(node) {											// over leaves
				// try branch above here, check, undo
				PNode upnode = tree->InsertParent(node);
				PNode newnode = tree->AddLeafChild(newname, upnode);
				newnode->SetSpecies(sp);
				tree->UpdateLite(tree->GetRoot());
				#ifdef PROFILING
				TimerStop(1);
				TimerStart(2);
				#endif
				#ifdef TOPO3VAR2
				MakeClades(tree);
				#endif
				double Q;
				switch(cfg->SpecArrayDim) {
					case 0:	Q = Tree0Quality(tree, newname); break;
					case 1:	Q = Tree1Quality(tree, newname); break;
					case 2:	Q = Tree2Quality(tree, newname); break;
					case 3:	Q = Tree3Quality(tree, newname); break;
				}
				#ifdef PROFILING
				TimerStop(2);
				TimerStart(1);
				#endif
				if(Q > best) {
					good = best;
               goodnode = bestnode;
					best = Q;
               bestnode = node;
				}
            else if(Q > good) {
					good = Q;
               goodnode = node;
            }
				tree->RemoveNode(newnode);
				tree->RemoveNode(upnode);
				tree->UpdateLite(tree->GetRoot());
				node = tree->GetLeafNext();
			}
			node = tree->GetInnerFirst();
			#ifdef PROFILING
			TimerStop(1);
			TimerStart(3);
			#endif
			while(node) {											// over inners
				// try branch above here, check, undo
				PNode upnode = tree->InsertParent(node);
				PNode newnode = tree->AddLeafChild(newname, upnode);
				newnode->SetSpecies(sp);
				tree->UpdateLite(tree->GetRoot());
				#ifdef PROFILING
				TimerStop(3);
				TimerStart(2);
				#endif
				#ifdef TOPO3VAR2
				MakeClades(tree);
				#endif
				double Q;
				switch(cfg->SpecArrayDim) {
					case 0:	Q = Tree0Quality(tree, newname); break;
					case 1:	Q = Tree1Quality(tree, newname); break;
					case 2:	Q = Tree2Quality(tree, newname); break;
					case 3:	Q = Tree3Quality(tree, newname); break;
				}
				#ifdef PROFILING
				TimerStop(2);
				TimerStart(3);
				#endif
				if(Q > best) {
					good     = best;
               goodnode = bestnode;
					best     = Q;
               bestnode = node;
				}
            else if(Q > good) {
					good     = Q;
               goodnode = node;
            }
				tree->RemoveNode(newnode);
				tree->RemoveNode(upnode);
				tree->UpdateLite(tree->GetRoot());
				node = tree->GetInnerNext();
			}
			#ifdef PROFILING
			TimerStop(3);
			TimerStart(0);
			#endif
         R = best > 0 ? (best - good) / best : 0;
         double c = best * (R + cfg->RShift);

         // push best node to the queue
         Sp2Add* specdata     = new Sp2Add;
         specdata->species    = sp;
         specdata->nodeno     = -1;    // not used if no mpi
         specdata->best       = best;
         specdata->bestnode   = bestnode;
         specdata->good       = good;
         specdata->goodnode   = goodnode;
         specdata->R          = R;
         specdata->criterion  = c;
         queue.push(specdata);
		}
      if( !queue.empty() ) {
         Sp2Add* specdata = 0;

         if(cfg->LogSuper3 && cfg->LogChoice3) {   // Log entire queue
            MyQueue tq(queue);
            cfg->clog << "\nCandidates for species insertion over nodes:" << endl;
            while( !tq.empty() ) {
               specdata = tq.top();
               cfg->clog << "  " << cfg->SpeciesData[specdata->species].Code << ": ";
               PNode node = specdata->bestnode;
               if(node->IsLeaf()) 
                  cfg->clog << node->GetName();
               else 
                  cfg->clog << node->GetIndex(); 
               cfg->clog << "->(" << fixed << setprecision(2) << specdata->best << 
                  " " << fixed << setprecision(6) << specdata->R << ")";
               tq.pop();
            }
			   cfg->clog << endl << endl;
         }

         if( cfg->SkipAmbiguous ) {
            for(skipped = 0; !queue.empty(); skipped++) {
               specdata = queue.top();
               if(specdata->R != 0) break;
               queue.pop();
            }
            if(queue.empty()) break;
         }
         else 
            specdata = queue.top();

         addedsp  = specdata->species;
         R        = specdata->R;
         BestQ    = specdata->best;

         PNode upnode   = cfg->STree->InsertParent(specdata->bestnode);
         string newname = cfg->SpeciesData[addedsp].Code;
         PNode newnode  = cfg->STree->AddLeafChild(newname, upnode);
         newnode->SetSpecies(addedsp);
         cfg->STree->UpdateLite(cfg->STree->GetRoot());
         cfg->TotalQ += BestQ;
			cfg->SpeciesData[addedsp].Included = true;
         if(cfg->SpeciesLength) {
            double len = R < EPS ? cfg->ZeroValue : R + 2 * cfg->ZeroValue;
            newnode->SetLength((float)len);
         }
      }
      else {
			break;
      }
	}
   if(skipped) {
      cfg->clog TSTAMP << "  Cannot insert " << skipped << " species:" << endl;
		for(int sp = 1; sp <= cfg->SpecNum; sp++) 
			if( cfg->SpeciesData[sp].Enable && !cfg->SpeciesData[sp].Included)
            cfg->clog << setfill(' ') << setw(6) << sp << ": " << 
               cfg->SpeciesData[sp].Code << endl;
      cfg->clog << endl;
   }
};

// Creates and fills PSetEntry array of entries into PSet
void CreatePSetCatalog(void) {
  	cfg->PSetEntry = new PSetMapIter [cfg->SpecNum + 1];
	PSetMapIter PSetIter = cfg->PSet.begin();
	PSetMapIter NotInPSet = cfg->PSet.end();
	for(int k = 0; k <= cfg->SpecNum; k++)
		cfg->PSetEntry[k] = NotInPSet;
	for( ; PSetIter != NotInPSet; PSetIter++ ) {
		PSetMapPair p = *PSetIter;
		size_t size = p.first.count();
		if(cfg->PSetEntry[size] == NotInPSet) 
			cfg->PSetEntry[size] = PSetIter;
	}
};

// Identifies basis sets in PSet by induction
void IdentifyBasisSets(void) {
	int numbas = 0;
	int numpart = 0;
	size_t maxpart = 1;
	PSetMapIter none = cfg->PSet.end();
	PSetMapIter pit = cfg->PSetEntry[1];

	// Mark each set of the size=1 as basis set 
	for( ; pit->first.count() == 1; pit++) {
		pit->second.Basis = true;
		pit->second.V1V2.clear();
		numbas++;
		numpart++;
	}

	// Process greater sizes in turn
	myset join;
	for(int size = 2; size <= cfg->SpecNum; size++) {
		if(cfg->PSetEntry[size] == none)
			continue;
		PSetMapIter pit1; 
		PSetMapIter pit2;
		for(int s1 = 1; s1 <= (size >> 1); s1++) {
			int s2 = size - s1;
			if((pit1 = cfg->PSetEntry[s1]) == none || (pit2 = cfg->PSetEntry[s2]) == none)
				continue;
			for( ; pit1 != none && pit1->first.count() == s1; pit1++) {
				if( ! pit1->second.Basis )
					continue;
				if(s1 != s2)
					pit2 = cfg->PSetEntry[s2];
				else {
					pit2 = pit1;
					pit2++;
				}
				for( ; pit2 != none && pit2->first.count() == s2; pit2++) {
					if( ! pit2->second.Basis )
						continue;
					join.assign(pit1->first);
					join.join(pit2->first);
					if(join.count() != size)
						continue;
					// find such set in PSet and make it basis if exists
					pit = cfg->PSet.find(join);
					if(pit == none)
						continue;
					if( ! pit->second.Basis ) {
						pit->second.Basis = true;
						numbas++;
					}
					V1V2Pair v1v2(pit1->first, pit2->first);
					pit->second.V1V2.insert(v1v2);
					numpart++;
					if(cfg->Milestones && (numpart & cfg->Milestones) == 0)
						cerr << "B " << setfill(' ') << setw(4) << size << " [" << numpart << "]      \r" << flush;
					if(pit->second.V1V2.size() > maxpart)
						maxpart = pit->second.V1V2.size();
				}
			}
		}
	}
	#ifdef SUPER3MPI
	if(!cfg->super3_mpi || cfg->rank_mpi == 0)
	#endif
	{
		cerr TSTAMP << "Basis sets selected: " << numbas << ", partitions=" << numpart 
			<< " (max=" << maxpart << ")." << endl;
		cfg->clog TSTAMP << "Basis sets selected: " << numbas << ", partitions=" << numpart 
			<< " (max=" << maxpart << ")." << endl;
	}
};

// Builds basis trees by induction
void BuildBasisTrees(void) {
	// First building one-element trees
	int serial = 1;
	if(cfg->LogBasisSets) {						// Logging basis sets
		cfg->clog << "\nBasis sets & partitions:" << endl
			<< "    #  |V|{V}  |V1+V2| Partition:|r(V1,V2)|[,penalty]..." << endl; 
	}
	PSetMapIter none = cfg->PSet.end();
	PSetMapIter pit = cfg->PSet.begin();
	for( ; pit != none; pit++) {
		if( ! pit->second.Basis )
			continue;
		if(pit->first.count() > 1)
			break;
		if(cfg->LogBasisSets) {
			pit->second.serial = serial++;
			myset clade = pit->first;
			set<V1V2Pair> &v1v2 = pit->second.V1V2;
			cfg->clog << setfill(' ') << setw(5) << pit->second.serial << "  [" << clade.count() << "] " 
				<< clade.Write() << "  [" << v1v2.size() << "]" << endl;
		}
		int sp = pit->first.first();
		PTree tree = new Tree();
		PNode leaf = tree->AddLeafNode(cfg->SpeciesData[sp].Code);
		leaf->SetSpecies(sp);
		tree->SetRoot(leaf);
		tree->SetRooted();
		pit->second.BasTree = tree;
		#ifdef BTREEWEIGHT
		pit->second.Weight = 1;
		#endif
	}
	// Then proceeding from two-element basis sets
	int innerbase = 1;
	int n = 0;
	for( ; pit != none; pit++) {
		if( ! pit->second.Basis )
			continue;
		if(cfg->LogBasisSets) {
			pit->second.serial = serial++;
			myset clade = pit->first;
			set<V1V2Pair> &v1v2 = pit->second.V1V2;
			cfg->clog << setfill(' ') << setw(5) << pit->second.serial << "  [" << clade.count() << "] " 
				<< clade.Write() << "  [" << v1v2.size() << "]";
		}
		int size = pit->first.count();
		// Milestones
		if(cfg->Milestones && (n++ & cfg->Milestones) == 0)
			cerr << "BT " << setfill(' ') << setw(4) << size << " [" << n-1 << "]      \r" << flush;
		// Loop over all variants of partitioning
		set<V1V2Pair>::iterator bestvar;
		float bestcost = numeric_limits<float>::max();
		#ifdef BTREEWEIGHT
		float bestcost2 = numeric_limits<float>::max();
		#endif
		set<V1V2Pair>::iterator partvar = pit->second.V1V2.begin();
		for( ; partvar != pit->second.V1V2.end(); partvar++) {
			if(cfg->LogBasisSets) {
				cfg->clog << " " << cfg->PSet.find(partvar->first)->second.serial
					<< "+" << cfg->PSet.find(partvar->second)->second.serial << ":";
			}
			float cost = PartitionCost(pit, partvar);
			if(cost < bestcost) {
				#ifdef BTREEWEIGHT
				if(cfg->BasisTreeWeight)
					bestcost2 = bestcost;
				#endif
				bestvar = partvar;
				bestcost = cost;
			}
			#ifdef BTREEWEIGHT
			else if(cfg->BasisTreeWeight && cost < bestcost2)
				bestcost2 = cost;
			#endif
		}
		if(cfg->LogBasisSets)
			cfg->clog << endl;
		// Building best basis tree
		PTree tree = new Tree(innerbase++);
		PNode root = tree->AddInnerNode();
		tree->SetRoot(root);
		tree->SetRooted();
		root->SetDepth(0);
		PSetMapIter pit1 = cfg->PSet.find(bestvar->first);
		PSetMapIter pit2 = cfg->PSet.find(bestvar->second);
		if(pit1 == cfg->PSet.end() || pit2 == cfg->PSet.end())
			throw("Internal error: Partition constituent not found.");
		tree->Clone(pit1->second.BasTree->GetRoot(), root);
		tree->Clone(pit2->second.BasTree->GetRoot(), root);
		tree->UpdateLite(root);
		pit->second.Cost = bestcost;
		pit->second.BasTree = tree;
		#ifdef BTREEWEIGHT
		if(cfg->BasisTreeWeight) {
			float tmp = (float)tree->GetLeafCount()/cfg->Species.size();
			pit->second.Weight = (bestcost2 - bestcost) / 
            bestcost2 * (float)(1 + cfg->ScaleFactor * tmp * tmp);
		}
		else
			pit->second.Weight = 1.0F;
		#endif
	}
	#ifdef BTREEWEIGHT
	float wmax = 0;
	float wmin = numeric_limits<float>::max();
	double wsum = 0;
	double wsqsum = 0;
	#endif
   #ifdef LOG2TREES
	   #ifdef SUPER3MPI
	   if(!cfg->super3_mpi || cfg->rank_mpi == 0)
	   #endif
	   {
		   if(cfg->LogBasisTrees) 		// Log also two-species trees
			   cfg->clog << "\nCost of two-species trees:" << endl;
	   }
   #endif
	// Final cut of basis trees
	int btreenum = 0, numleaves = 0, maxleaves = 0;
	for(pit = cfg->PSet.begin(); pit != none; /*pit++*/) {
		if( ! pit->second.Basis ) {
			pit++;
			continue;
		}
		int leaves = pit->second.BasTree->GetLeafCount();
      #ifdef LOG2TREES
		   #ifdef SUPER3MPI
		   if(!cfg->super3_mpi || cfg->rank_mpi == 0)
		   #endif
		   {
			   if(cfg->LogBasisTrees && leaves == 2) {		// Log also two-species trees
				   //set<V1V2Pair>::iterator v1v2 = pit->second.V1V2.begin();
				   //int v1 = v1v2->first.first();
				   //int v2 = v1v2->second.first();
				   //cfg->clog << cfg->SpeciesData[v1].Code << " + " << cfg->SpeciesData[v2].Code << " = "
				   //	<< pit->second.Cost << endl; 
				   ostringstream oss;
				   oss << pit->second.Cost;
				   pit->second.BasTree->GetRoot()->SetName(oss.str());
				   cfg->clog << pit->second.BasTree->Write(Config::InnerName) << endl;
			   }
		   }
      #endif
		#ifdef BTREEWEIGHT
		if(leaves < 3 || pit->second.Weight < cfg->MinWeight) { 
		#else
		if(leaves < 3) { 
		#endif
			pit->second.Basis = false;
			pit->second.V1V2.clear();
			delete pit->second.BasTree;
			PSetMapIter toerase = pit++;
			cfg->PSet.erase(toerase);
		}
		else {
			MakeClades(pit->second.BasTree);
			btreenum ++;
			#ifdef BTREEWEIGHT
			if(cfg->BasisTreeWeight) {
				float w = pit->second.Weight;
				if(w > wmax)
					wmax = w;
				if(w < wmin)
					wmin = w;
				wsum += (double)w;
				wsqsum += (double)w * w;
			}
			#endif
			numleaves += leaves;
			if(leaves > maxleaves)
				maxleaves = leaves;
			pit++;
		}
	}
	#ifdef SUPER3MPI
	if(!cfg->super3_mpi || cfg->rank_mpi == 0)
	#endif
	{
      if(cfg->LogBasisSets)
			cfg->clog << endl;
		cerr TSTAMP << "Basis trees constructed: " << btreenum << ", total leaves=" << numleaves
			<< " (max=" << maxleaves << ")." << endl;
		cfg->clog TSTAMP << "Basis trees constructed: " << btreenum << ", total leaves=" << numleaves
			<< " (max=" << maxleaves << ")." << endl;
	}
	#ifdef BTREEWEIGHT
	#ifdef SUPER3MPI
	if(!cfg->super3_mpi || cfg->rank_mpi == 0)
	#endif
	{
		if(cfg->BasisTreeWeight) {
			double m = wsum / btreenum;
			double d = wsqsum / btreenum - m * m;
			d = sqrt(d * btreenum / (btreenum - 1));
			cerr TSTAMP << "BT weight: min=" << fixed << setprecision(5) << wmin << ", max="
				<< setprecision(2) << wmax << ", average=" << m << ", stdev=" << d << "." << endl;
			cfg->clog TSTAMP << "BT weight: min=" << fixed << setprecision(5) << wmin << ", max="
				<< setprecision(5) << wmax << ", average=" << m << ", stdev=" << d << "." << endl;
		}
	}
	#endif
};

// Calculates cost of given partition by the formula c(v1,v2)=c(v1)+c(v2)+a
float PartitionCost(PSetMapIter pit, const set<V1V2Pair>::iterator partvar) {
	PSetMapIter pit1 = cfg->PSet.find(partvar->first);
	PSetMapIter pit2 = cfg->PSet.find(partvar->second);
	float a = 0.;
	int rv1 = pit1->second.GoodNum;		// |R(V1)|
	int rv2 = pit2->second.GoodNum;		// |R(V2)|
	// Counting |r(V1,V2)| in a loop over trees
	int rv1v2 = 0;
   int penaltysum = 0;
	for(int t = 0; t < cfg->TreeNum; t++) {
		PTree tree = cfg->GTree[t];
		if(!tree)
			continue;
		// Check from the root downward whether a node is to be counted in rv1v2
      int r = CountRV1V2(pit, pit1, pit2, tree);
		rv1v2 += r;
      if(r > 1)
         penaltysum += r - 1;
	}
   if(cfg->LogBasisSets) {
		cfg->clog << rv1v2;
      if(penaltysum)
         cfg->clog << "," << penaltysum;
   }
	a = cfg->CLoss * (rv1 + rv2 - 2 * rv1v2) +
		cfg->CDuplication * (rv1 + rv2 - pit->second.GoodNum - rv1v2);
   return pit1->second.Cost + pit2->second.Cost + a + 
      (int)(cfg->ParalogyPenalty * penaltysum);
};

// Fills a map of triples with nonzero quality from all basis trees (3d map)
void FillTriple0Map(void) {
	PSetMapIter pit = cfg->PSet.begin();
	// Count meetings in the loop over basis trees
	int tn = 0;
	for( ; pit != cfg->PSet.end(); pit++) {
		if( ! pit->second.Basis )					// to be on safe side
			continue;
		// Milestones
		if(cfg->Milestones && (tn++ & cfg->Milestones) == 0)
			cerr << "BT " << setfill(' ') << setw(4) << tn-1 << "      \r" << flush;
		PTree tree = pit->second.BasTree;
		#ifdef BTREEWEIGHT
		float weight = cfg->BasisTreeWeight ? pit->second.Weight : 1;
		#endif
		// Loop for triple leaves
		Leaf3 leaf3;
		bool exist = tree->GetLeaf3First(leaf3);
		while(exist) {
			// Inserts/modifies an entry in the meeting map (Trim)
			Triple0 triple;
			triple.a = leaf3.a->GetSpecies();
			int spb = leaf3.b->GetSpecies();
			int spc = leaf3.c->GetSpecies();
			if(spb < spc) {
				triple.b = spb;
				triple.c = spc;
			}
			else {
				triple.b = spc;
				triple.c = spb;
			}
			Triple0MapPair new3;
			new3.first = triple;
			#ifndef BTREEWEIGHT
			new3.second = 1;
			#else
			new3.second = weight;
			#endif
			Triple0MapResult res3 = cfg->Triq0.insert(new3);
			if( ! res3.second ) 		// already exists
				#ifndef BTREEWEIGHT
				(*(res3.first)).second += 1;			
				#else
				(*(res3.first)).second += weight;
				#endif
			// try next triple
			exist = tree->GetLeaf3Next(leaf3);
		}
	}
	// Recalculate number of a triple meetings into the quality
	Triple0MapIter tita, titb, titc;		
	Triple0MapIter end = cfg->Triq0.end();
	Triple0 tra, trb, trc;
	int spa, spb, spc;
	float ma, mb, mc;
	for(spa = 1; spa < cfg->SpecNum; spa++) {
		if(!cfg->SpeciesData[spa].Enable)
			continue;
		tra.a = trb.b = trc.b = spa;
		for(spb = spa + 1; spb < cfg->SpecNum; spb++) {
			if(!cfg->SpeciesData[spb].Enable)
				continue;
			tra.b = trb.a = trc.c = spb;
			for(spc = spb + 1; spc < cfg->SpecNum; spc++) {
				if(!cfg->SpeciesData[spc].Enable)
					continue;
				tra.c = trb.c = trc.a = spc;
				tita = cfg->Triq0.find(tra);
				ma = (tita == end) ? 0 : tita->second;
				titb = cfg->Triq0.find(trb);
				mb = (titb == end) ? 0 : titb->second;
				titc = cfg->Triq0.find(trc);
				mc = (titc == end) ? 0 : titc->second;
				if(ma != 0)
					tita->second = ma / (mb + mc + 1);
				if(mb != 0)
					titb->second = mb / (ma + mc + 1);
				if(mc != 0)
					titc->second = mc / (ma + mb + 1);
			}
		}
	}
	// Calculate statistics
	int n = (int)cfg->Triq0.size();
	float qmin = numeric_limits<float>::max();
	float qmax = 0;
	float qmax2 = 0;
	double sum = 0;
	double sqsum = 0;
	Triple0MapIter tit = cfg->Triq0.begin();
	for( ; tit != cfg->Triq0.end(); tit++) {
		float q = tit->second;
		if(q < qmin)
			qmin = q;
		if(q > qmax) {
			qmax2 = qmax;
			qmax = q;
			cfg->BestTriple = tit;
		}
		else if(q > qmax2) 
			qmax2 = q;
		sum += (double)q;
		sqsum += (double)q * q;
	}
	#ifdef SUPER3MPI
	if(!cfg->super3_mpi || cfg->rank_mpi == 0)
	#endif
	{
		double m = sum / n;
		double d = sqsum / n - m * m;
		d = sqrt(d * n / (n - 1));
		cerr TSTAMP << "Triple topologies with nonzero quality in the basis trees: " << n << "." << endl
			TSTAMP << "Quality:  min=" << fixed << setprecision(3) << qmin << ", max=" << setprecision(0)
			<< qmax << ", max2=" << qmax2 << ", average=" << m << ", stdev=" << d << "." << endl;
		cfg->clog TSTAMP << "Triple topologies with nonzero quality in the basis trees: " << n << "." << endl
			TSTAMP << "Quality:  min=" << fixed << setprecision(6) << qmin << ", max=" << setprecision(3) 
			<< qmax << ", max2=" << qmax2 << ", average=" << m << ", stdev=" << d << "." << endl;
	}
};

// Fills a map of triples with nonzero quality from all basis trees (1d array of 2d maps)
void FillTriple1Map(void) {
	PSetMapIter pit = cfg->PSet.begin();
	cfg->Triq1 = new PTriple1Map [cfg->SpecNum + 1];
	for(int i = 0; i <= cfg->SpecNum; i++)
		cfg->Triq1[i] = new Triple1Map;
	// Count meetings in the loop over basis trees
	int tn = 0;
	for( ; pit != cfg->PSet.end(); pit++) {
		if( ! pit->second.Basis )					// to be on safe side
			continue;
		// Milestones
		if(cfg->Milestones && (tn++ & cfg->Milestones) == 0)
			cerr << "BT " << setfill(' ') << setw(4) << tn-1 << "      \r" << flush;
		PTree tree = pit->second.BasTree;
		#ifdef BTREEWEIGHT
		float weight = cfg->BasisTreeWeight ? pit->second.Weight : 1;
		#endif
		// Loop for triple leaves
		Leaf3 leaf3;
		bool exist = tree->GetLeaf3First(leaf3);
		while(exist) {
			// Inserts/modifies an entry in the meeting map (Trim)
			Triple1 triple;
			int spa = leaf3.a->GetSpecies();
			int spb = leaf3.b->GetSpecies();
			int spc = leaf3.c->GetSpecies();
			if(spb < spc) {
				triple.b = spb;
				triple.c = spc;
			}
			else {
				triple.b = spc;
				triple.c = spb;
			}
			Triple1MapPair new3;
			new3.first = triple;
			#ifndef BTREEWEIGHT
			new3.second = 1;
			#else
			new3.second = weight;
			#endif
			Triple1MapResult res3 = cfg->Triq1[spa]->insert(new3);
			if( ! res3.second ) 		// already exists
				#ifndef BTREEWEIGHT
				(*(res3.first)).second += 1;			
				#else
				(*(res3.first)).second += weight;
				#endif
			// try next triple
			exist = tree->GetLeaf3Next(leaf3);
		}
	}
	// Recalculate number of a triple meetings into the quality
	Triple1MapIter tita, titb, titc;		
	Triple1 tra, trb, trc;
	int spa, spb, spc;
	float ma, mb, mc;
	for(spa = 1; spa <= cfg->SpecNum; spa++) {
		if(!cfg->SpeciesData[spa].Enable)
			continue;
		Triple1MapIter enda = cfg->Triq1[spa]->end();
		trb.b = trc.b = spa;
		for(spb = spa + 1; spb < cfg->SpecNum; spb++) {
			if(!cfg->SpeciesData[spb].Enable)
				continue;
			tra.b = trc.c = spb;
			Triple1MapIter endb = cfg->Triq1[spb]->end();
			for(spc = spb + 1; spc < cfg->SpecNum; spc++) {
				if(!cfg->SpeciesData[spc].Enable)
					continue;
				tra.c = trb.c = spc;
				Triple1MapIter endc = cfg->Triq1[spc]->end();
				tita = cfg->Triq1[spa]->find(tra);
				ma = (tita == enda) ? 0 : tita->second;
				titb = cfg->Triq1[spb]->find(trb);
				mb = (titb == endb) ? 0 : titb->second;
				titc = cfg->Triq1[spc]->find(trc);
				mc = (titc == endc) ? 0 : titc->second;
				if(ma != 0)
					tita->second = ma / (mb + mc + 1);
				if(mb != 0)
					titb->second = mb / (ma + mc + 1);
				if(mc != 0)
					titc->second = mc / (ma + mb + 1);
			}
		}
	}
	// Calculate statistics
	int n = 0;
	float qmin = numeric_limits<float>::max();
	float qmax = 0;
	float qmax2 = 0;
	double sum = 0;
	double sqsum = 0;
	int numsize = 0; 
	int minsize = numeric_limits<int>::max();
	int maxsize = 0;
	double sumsize = 0, sqsumsize = 0;
	for(int sp = 1; sp <= cfg->SpecNum; sp++) {
		if(!cfg->SpeciesData[sp].Enable)
			continue;
		int sz = (int)cfg->Triq1[sp]->size();
		if(sz) {
			numsize++;
			if(sz < minsize)
				minsize = sz;
			if(sz > maxsize)
				maxsize = sz;
			sumsize += sz;
			sqsumsize += (double)sz * sz;
			n += sz;
			Triple1MapIter tit = cfg->Triq1[sp]->begin();
			for( ; tit != cfg->Triq1[sp]->end(); tit++) {
				float q = tit->second;
				if(q < qmin)
					qmin = q;
				if(q > qmax) {
					qmax2 = qmax;
					qmax = q;
					cfg->BestTripleA = sp;
					cfg->BestTriple1 = tit;
				}
				else if(q > qmax2) 
					qmax2 = q;
				sum += (double)q;
				sqsum += (double)q * q;
			}
		}
	}
	#ifdef SUPER3MPI
	if(!cfg->super3_mpi || cfg->rank_mpi == 0)
	#endif
	{
		double m = sum / n;
		double d = sqsum / n - m * m;
		d = sqrt(d * n / (n - 1));
		cerr TSTAMP << "Triple topologies with nonzero quality in the basis trees: " << n << "." << endl
			TSTAMP << "Quality:  min=" << fixed << setprecision(3) << qmin << ", max=" << setprecision(0)
			<< qmax << ", max2=" << qmax2 << ", average=" << m << ", stdev=" << d << "." << endl;
		cfg->clog TSTAMP << "Triple topologies with nonzero quality in the basis trees: " << n << "." << endl
			TSTAMP << "Quality:  min=" << fixed << setprecision(6) << qmin << ", max=" << setprecision(3) 
			<< qmax << ", max2=" << qmax2 << ", average=" << m << ", stdev=" << d << "." << endl;
		m = sumsize / numsize;
		d = sqsumsize / numsize - m * m;
		d = sqrt(d * numsize / (numsize - 1));
		cerr TSTAMP << "Total 2d maps: " << numsize << ". Size: min=" << minsize << ", max=" << maxsize
			<< ", average=" << fixed << setprecision(0) << m << ", stdev=" << d << "." << endl;
		cfg->clog TSTAMP << "Total 2d maps: " << numsize << ". Size: min=" << minsize << ", max=" << maxsize
			<< ", average=" << fixed << setprecision(2) << m << ", stdev=" << d << "." << endl;
	}
};

// Fills a map of triples with nonzero quality from all basis trees (2d array of 1d maps)
void FillTriple2Map(void) {
	PSetMapIter pit = cfg->PSet.begin();
	cfg->Triq2 = new PTriple2Map* [cfg->SpecNum + 1];
	for(int i = 1; i <= cfg->SpecNum; i++) {
		cfg->Triq2[i] = new PTriple2Map [cfg->SpecNum + 1];
		for(int j = 1; j <= cfg->SpecNum; j++)
			cfg->Triq2[i][j] = new Triple2Map;
	}
	// Count meetings in the loop over basis trees
	int tn = 0;
	for( ; pit != cfg->PSet.end(); pit++) {
		if( ! pit->second.Basis )					// to be on safe side
			continue;
		// Milestones
		if(cfg->Milestones && (tn++ & cfg->Milestones) == 0)
			cerr << "BT " << setfill(' ') << setw(4) << tn-1 << "      \r" << flush;
		PTree tree = pit->second.BasTree;
		#ifdef BTREEWEIGHT
		float weight = cfg->BasisTreeWeight ? pit->second.Weight : 1;
		#endif
		// Loop for triple leaves
		Leaf3 leaf3;
		bool exist = tree->GetLeaf3First(leaf3);
		while(exist) {
			// Inserts/modifies an entry in the meeting map (Triq)
			int spa = leaf3.a->GetSpecies();
			int spb = leaf3.b->GetSpecies();
			int spc = leaf3.c->GetSpecies();
			if(spb > spc) {
				int tmp = spb;
				spb = spc;
				spc = tmp;
			}
			Triple2MapPair new3;
			new3.first = spc;
			#ifndef BTREEWEIGHT
			new3.second = 1;
			#else
			new3.second = weight;
			#endif
			Triple2MapResult res3 = cfg->Triq2[spa][spb]->insert(new3);
			if( ! res3.second ) 		// already exists
				#ifndef BTREEWEIGHT
				(*(res3.first)).second += 1;			
				#else
				(*(res3.first)).second += weight;
				#endif
			// try next triple
			exist = tree->GetLeaf3Next(leaf3);
		}
	}
	// Recalculate number of a triple meetings into the quality
	Triple2MapIter tita, titb, titc;		
	int spa, spb, spc;
	float ma, mb, mc;
	for(spa = 1; spa <= cfg->SpecNum; spa++) {
		if(!cfg->SpeciesData[spa].Enable)
			continue;
		for(spb = spa + 1; spb < cfg->SpecNum; spb++) {
			if(!cfg->SpeciesData[spb].Enable)
				continue;
			for(spc = spb + 1; spc < cfg->SpecNum; spc++) {
				if(!cfg->SpeciesData[spc].Enable)
					continue;
				tita = cfg->Triq2[spa][spb]->find(spc);
				ma = (tita == cfg->Triq2[spa][spb]->end()) ? 0 : tita->second;
				titb = cfg->Triq2[spb][spa]->find(spc);
				mb = (titb == cfg->Triq2[spb][spa]->end()) ? 0 : titb->second;
				titc = cfg->Triq2[spc][spa]->find(spb);
				mc = (titc == cfg->Triq2[spc][spa]->end()) ? 0 : titc->second;
				if(ma != 0)
					tita->second = ma / (mb + mc + 1);
				if(mb != 0)
					titb->second = mb / (ma + mc + 1);
				if(mc != 0)
					titc->second = mc / (ma + mb + 1);
			}
		}
	}
	// Calculate statistics
	int n = 0;
	float qmin = numeric_limits<float>::max();
	float qmax = 0;
	float qmax2 = 0;
	double sum = 0;
	double sqsum = 0;
	int numsize = 0; 
	int minsize = numeric_limits<int>::max();
	int maxsize = 0;
	double sumsize = 0, sqsumsize = 0;
	for(spa = 1; spa <= cfg->SpecNum; spa++) {
		if(!cfg->SpeciesData[spa].Enable)
			continue;
		for(spb = 1; spb <= cfg->SpecNum; spb++) {
			if(spb == spa || !cfg->SpeciesData[spb].Enable)
				continue;
			int sz = (int)cfg->Triq2[spa][spb]->size();
			if(sz) {
				numsize++;
				if(sz < minsize)
					minsize = sz;
				if(sz > maxsize)
					maxsize = sz;
				sumsize += sz;
				sqsumsize += (double)sz * sz;
				n += sz;
				Triple2MapIter tit = cfg->Triq2[spa][spb]->begin();
				for( ; tit != cfg->Triq2[spa][spb]->end(); tit++) {
					float q = tit->second;
					if(q < qmin)
						qmin = q;
					if(q > qmax) {
						qmax2 = qmax;
						qmax = q;
						cfg->BestTripleA = spa;
						cfg->BestTripleB = spb;
						cfg->BestTriple2 = tit;
					}
					else if(q > qmax2) 
						qmax2 = q;
					sum += (double)q;
					sqsum += (double)q * q;
				}
			}
		}
	}
	#ifdef SUPER3MPI
	if(!cfg->super3_mpi || cfg->rank_mpi == 0)
	#endif
	{
		double m = sum / n;
		double d = sqsum / n - m * m;
		d = sqrt(d * n / (n - 1));
		cerr TSTAMP << "Triple topologies with nonzero quality in the basis trees: " << n << "." << endl
			TSTAMP << "Quality:  min=" << fixed << setprecision(3) << qmin << ", max=" << setprecision(0)
			<< qmax << ", max2=" << qmax2 << ", average=" << m << ", stdev=" << d << "." << endl;
		cfg->clog TSTAMP << "Triple topologies with nonzero quality in the basis trees: " << n << "." << endl
			TSTAMP << "Quality:  min=" << fixed << setprecision(6) << qmin << ", max=" << setprecision(3) 
			<< qmax << ", max2=" << qmax2 << ", average=" << m << ", stdev=" << d << "." << endl;
		m = sumsize / numsize;
		d = sqsumsize / numsize - m * m;
		d = sqrt(d * numsize / (numsize - 1));
		cerr TSTAMP << "Total 1d maps: " << numsize << ". Size: min=" << minsize << ", max=" << maxsize
			<< ", average=" << fixed << setprecision(0) << m << ", stdev=" << d << "." << endl;
		cfg->clog TSTAMP << "Total 1d maps: " << numsize << ". Size: min=" << minsize << ", max=" << maxsize
			<< ", average=" << fixed << setprecision(2) << m << ", stdev=" << d << "." << endl;
	}
};

// Fills a map of triples with nonzero quality from all basis trees (3d array)
void FillTriple3Map(void) {
	PSetMapIter pit = cfg->PSet.begin();
	cfg->Triq3 = new float** [cfg->SpecNum + 1];
	for(int i = 1; i <= cfg->SpecNum; i++) {
		cfg->Triq3[i] = new float* [cfg->SpecNum + 1];
		for(int j = 1; j <= cfg->SpecNum; j++) {
			cfg->Triq3[i][j] = new float [cfg->SpecNum + 1];
			for(int k = 1; k <= cfg->SpecNum; k++)
				cfg->Triq3[i][j][k] = 0;
		}
	}
	// Count meetings in the loop over basis trees
	int tn = 0;
	for( ; pit != cfg->PSet.end(); pit++) {
		if( ! pit->second.Basis )					// to be on safe side
			continue;
		// Milestones
		if(cfg->Milestones && (tn++ & cfg->Milestones) == 0)
			cerr << "BT " << setfill(' ') << setw(4) << tn-1 << "      \r" << flush;
		PTree tree = pit->second.BasTree;
		#ifdef BTREEWEIGHT
		float weight = cfg->BasisTreeWeight ? pit->second.Weight : 1;
		#endif
		// Loop for triple leaves
		Leaf3 leaf3;
		bool exist = tree->GetLeaf3First(leaf3);
		while(exist) {
			// Inserts/modifies an entry in the meeting map (Triq)
			int spa = leaf3.a->GetSpecies();
			int spb = leaf3.b->GetSpecies();
			int spc = leaf3.c->GetSpecies();
			if(spb > spc) {
				int tmp = spb;
				spb = spc;
				spc = tmp;
			}
			#ifndef BTREEWEIGHT
			cfg->Triq3[spa][spb][spc] += 1;
			#else
			cfg->Triq3[spa][spb][spc] += weight;
			#endif
			// try next triple
			exist = tree->GetLeaf3Next(leaf3);
		}
	}
	// Recalculate number of a triple meetings into the quality
	int spa, spb, spc;
	float ma, mb, mc;
	for(spa = 1; spa <= cfg->SpecNum; spa++) {
		if(!cfg->SpeciesData[spa].Enable)
			continue;
		for(spb = spa + 1; spb < cfg->SpecNum; spb++) {
			if(!cfg->SpeciesData[spb].Enable)
				continue;
			for(spc = spb + 1; spc < cfg->SpecNum; spc++) {
				if(!cfg->SpeciesData[spc].Enable)
					continue;
				ma = cfg->Triq3[spa][spb][spc];
				mb = cfg->Triq3[spb][spa][spc];
				mc = cfg->Triq3[spc][spa][spb];
				if(ma != 0)
					cfg->Triq3[spa][spb][spc] = ma / (mb + mc + 1);
				if(mb != 0)
					cfg->Triq3[spb][spa][spc] = mb / (ma + mc + 1);
				if(mc != 0)
					cfg->Triq3[spc][spa][spb] = mc / (ma + mb + 1);
			}
		}
	}
	// Calculate statistics
	int n = 0;
	float q;
	float qmin = numeric_limits<float>::max();
	float qmax = 0;
	float qmax2 = 0;
	double sum = 0;
	double sqsum = 0;
	for(spa = 1; spa <= cfg->SpecNum; spa++) {
		if(!cfg->SpeciesData[spa].Enable)
			continue;
		for(spb = 1; spb <= cfg->SpecNum; spb++) {
			if(spb == spa || !cfg->SpeciesData[spb].Enable)
				continue;
			for(spc = 1; spc <= cfg->SpecNum; spc++) {
				if(spc == spa || spc == spb || !cfg->SpeciesData[spc].Enable
					|| (q = cfg->Triq3[spa][spb][spc]) == 0)
					continue;
				n++;
				if(q < qmin)
					qmin = q;
				if(q > qmax) {
					qmax2 = qmax;
					qmax = q;
					cfg->BestTripleA = spa;
					cfg->BestTripleB = spb;
					cfg->BestTripleC = spc;
				}
				else if(q > qmax2) 
					qmax2 = q;
				sum += (double)q;
				sqsum += (double)q * q;
			}
		}
	}
	#ifdef SUPER3MPI
	if(!cfg->super3_mpi || cfg->rank_mpi == 0)
	#endif
	{
		double m = sum / n;
		double d = sqsum / n - m * m;
		d = sqrt(d * n / (n - 1));
		cerr TSTAMP << "Triple topologies with nonzero quality in the basis trees: " << n << "." << endl
			TSTAMP << "Quality:  min=" << fixed << setprecision(3) << qmin << ", max=" << setprecision(0)
			<< qmax << ", max2=" << qmax2 << ", average=" << m << ", stdev=" << d << "." << endl;
		cfg->clog TSTAMP << "Triple topologies with nonzero quality in the basis trees: " << n << "." << endl
			TSTAMP << "Quality:  min=" << fixed << setprecision(6) << qmin << ", max=" << setprecision(3) 
			<< qmax << ", max2=" << qmax2 << ", average=" << m << ", stdev=" << d << "." << endl;
	}
};

// Recalculate total quality of given species tree
double TreeQuality(PTree tree) {								// All *d versions of a map
	double Q = 0;
	Leaf3 leaf3;
	bool flag = tree->GetLeaf3First(leaf3);
	while(flag) {
		int spa = leaf3.a->GetSpecies();
		int spb = leaf3.b->GetSpecies();
		int spc = leaf3.c->GetSpecies();
		if(spb > spc) {
			int tmp = spb;
			spb = spc;
			spc = tmp;
		}
		switch(cfg->SpecArrayDim) {
			case 0: {
				Triple0 triple = {spa, spb, spc};
				Triple0MapIter tit = cfg->Triq0.find(triple);
				if(tit != cfg->Triq0.end())
					Q += tit->second;
					  } break;
			case 1: {
				Triple1 triple = {spb, spc};
				Triple1MapIter tit = cfg->Triq1[spa]->find(triple);
				if(tit != cfg->Triq1[spa]->end())
					Q += tit->second;
					  } break;
			case 2: {
				Triple2MapIter tit = cfg->Triq2[spa][spb]->find(spc);
				if(tit != cfg->Triq2[spa][spb]->end())
					Q += tit->second;
					  } break;
			case 3:
				Q += cfg->Triq3[spa][spb][spc];
				break;
		}
		flag = tree->GetLeaf3Next(leaf3);
	}
	return Q;
};

// Calculates quality increment of given species tree with regard to a specified node
double Tree0Quality(PTree tree, const string& newname) {					// 3d map
	double Q = 0;
	Leaf3 leaf3;
	#ifdef PROFILING
	TimerStop(0);
	TimerStart(7);
	#endif
	bool flag = tree->GetLeaf3First(leaf3, newname);
	// Loop for each triple of leaves
	#ifdef PROFILING
	TimerStart(0);
	#endif
	while(flag) {
		Triple0 triple;
		int spa = triple.a = leaf3.a->GetSpecies();
		int spb = leaf3.b->GetSpecies();
		int spc = leaf3.c->GetSpecies();
		if(spb < spc) {
			triple.b = spb;
			triple.c = spc;
		}
		else {
			triple.b = spc;
			triple.c = spb;
		}
		#ifdef PROFILING
		TimerStop(0);
		TimerStart(5);
		#endif
		Triple0MapIter tit = cfg->Triq0.find(triple);
		if(tit != cfg->Triq0.end())
			Q += tit->second;
		#ifdef PROFILING
		TimerStop(5);
		TimerStart(7);
		#endif
		flag = tree->GetLeaf3NextFA(leaf3);
		#ifdef PROFILING
		TimerStart(0);
		#endif
	}
	return Q;
};

// Calculates quality increment of given species tree with regard to a specified node
double Tree1Quality(PTree tree, const string& newname) {			// 1d array of 2d maps
	double Q = 0;
	Leaf3 leaf3;
	bool flag = tree->GetLeaf3First(leaf3, newname);
	// Loop for each triple of leaves
	while(flag) {
		Triple1 triple;
		int spa = leaf3.a->GetSpecies();
		int spb = leaf3.b->GetSpecies();
		int spc = leaf3.c->GetSpecies();
		if(spb < spc) {
			triple.b = spb;
			triple.c = spc;
		}
		else {
			triple.b = spc;
			triple.c = spb;
		}
		#ifdef PROFILING
		TimerStop(2);
		TimerStart(4);
		#endif
		Triple1MapIter tit = cfg->Triq1[spa]->find(triple);
		if(tit != cfg->Triq1[spa]->end())
			Q += tit->second;
		#ifdef PROFILING
		TimerStop(4);
		TimerStart(2);
		#endif
		flag = tree->GetLeaf3NextFA(leaf3);
	}
	return Q;
};

// Calculates quality increment of given species tree with regard to a specified node
double Tree2Quality(PTree tree, const string& newname) {			// 2d array of 1d maps
	double Q = 0;
	Leaf3 leaf3;
	bool flag = tree->GetLeaf3First(leaf3, newname);
	// Loop for each triple of leaves
	while(flag) {
		int spa = leaf3.a->GetSpecies();
		int spb = leaf3.b->GetSpecies();
		int spc = leaf3.c->GetSpecies();
		if(spb > spc) {
			int tmp = spb;
			spb = spc;
			spc = tmp;
		}
		#ifdef PROFILING
		TimerStop(2);
		TimerStart(4);
		#endif
		Triple2MapIter tit = cfg->Triq2[spa][spb]->find(spc);
		if(tit != cfg->Triq2[spa][spb]->end())
			Q += tit->second;
		#ifdef PROFILING
		TimerStop(4);
		TimerStart(2);
		#endif
		flag = tree->GetLeaf3NextFA(leaf3);
	}
	return Q;
};

// Calculates quality increment of given species tree with regard to a specified node
double Tree3Quality(PTree tree, const string& newname) {			// 3d array of floats
	double Q = 0;
	Leaf3 leaf3;
	bool flag = tree->GetLeaf3First(leaf3, newname);
	// Loop for each triple of leaves
	while(flag) {
		int spa = leaf3.a->GetSpecies();
		int spb = leaf3.b->GetSpecies();
		int spc = leaf3.c->GetSpecies();
		if(spb > spc) {
			int tmp = spb;
			spb = spc;
			spc = tmp;
		}
		#ifdef PROFILING
		TimerStop(2);
		TimerStart(4);
		#endif
		Q += cfg->Triq3[spa][spb][spc];
		#ifdef PROFILING
		TimerStop(4);
		TimerStart(2);
		#endif
		flag = tree->GetLeaf3NextFA(leaf3);
	}
	return Q;
};

// Builds initial state of the species tree (best triple or ready state)
// Also creates future supertree and a file for it
// Returns number of species currently included in the tree
int InitSpeciesTree() {
	PNode lfa, lfb, lfc, node;
	string filename;
	ios::openmode mode;
	if(cfg->STree)
		delete cfg->STree;
	cfg->STree = new Tree;			// future supertree
	if(cfg->Super3NameGiven && !cfg->Super3Name.empty()) {
		filename = cfg->WorkingDirectory + cfg->Super3Name;
		if(cfg->Resume) {
			mode = ios_base::in;
			cfg->super3.open(filename.c_str(), mode);
			if(!cfg->super3.fail()) {			// supertree file exists
				string line, lasttree;
				int spin = 0;
				while(!cfg->super3.fail()) {
					getline(cfg->super3, line, '\n');
					string::size_type begin = line.find_first_not_of(" \t\n\r");
					if(begin == string::npos || line[begin] != cfg->LPAR)
						continue;
					string::size_type end = line.find_last_not_of(" \t\n\r");
					if(end == string::npos || line[end] != cfg->EOT)
						continue;
					lasttree = line.substr(begin, end - begin + 1);
				}
				// Read last line into STree, calc 'spin' & cfg->TotalQ for BuildSpeciesXTree
				if(!lasttree.empty() && cfg->STree->Read(lasttree)) {
					PNode leaf = cfg->STree->GetLeafFirst();
					while(leaf) {
						cfg->SpeciesData[leaf->GetSpecies()].Included = true;
						leaf = cfg->STree->GetLeafNext();
					}
					for(int i = 1; i <= cfg->SpecNum; i++)
						if(cfg->SpeciesData[i].Enable && cfg->SpeciesData[i].Included)
							spin++;
					cfg->TotalQ = TreeQuality(cfg->STree);
				}
				cfg->super3.close();

				#ifdef SUPER3MPI
				if(cfg->super3_mpi && cfg->size_mpi > 1)
					MPI::COMM_WORLD.Barrier();
				#endif

				#ifdef SUPER3MPI
				if(!cfg->super3_mpi || cfg->rank_mpi == 0)
				#endif
				{
					mode = (cfg->Super3Sequence) ? (ios_base::app | ios_base::out) 
														  : (ios_base::out | ios_base::trunc);
					cfg->super3.open(filename.c_str(), mode);
					if(cfg->super3.bad()) {
						ostrstream msg;
						msg << "BuildSpeciesTree: Cannot write/append to \'" << filename << "\' ("
							<< cfg->super3.rdstate() << ").";
						throw(msg.str());
					}
					else cfg->super3.clear();
				}
				if(spin >= 3)
					return spin;	// return spin if the last tree was okay
			}
			cfg->super3.clear();
			cfg->super3.close();
		}
		#ifdef SUPER3MPI
		if(cfg->super3_mpi && cfg->size_mpi > 1)
			MPI::COMM_WORLD.Barrier();
		if(!cfg->super3_mpi || cfg->rank_mpi == 0)
		#endif
		{
			// Not Resume or bad supertree file
			mode = ios_base::out | ios_base::trunc;
			cfg->super3.open(filename.c_str(), mode);
			if(cfg->super3.bad()) {
				ostrstream msg;
				msg << "BuildSpeciesTree: Cannot create \'" << filename << "\' ("
					<< cfg->super3.rdstate() << ").";
				throw(msg.str());
			}
			else cfg->super3.clear();
		}
	}
	else
		cfg->Super3NameGiven = false;
	PNode root = cfg->STree->AddInnerNode();
	cfg->STree->SetRoot(root);
	cfg->STree->SetRooted();
	root->SetDepth(0);
	switch(cfg->SpecArrayDim) {
		case 0:
			lfa = cfg->STree->AddLeafChild(cfg->SpeciesData[cfg->BestTriple->first.a].Code, root);
			lfa->SetSpecies(cfg->BestTriple->first.a);
			cfg->SpeciesData[cfg->BestTriple->first.a].Included = true;
			node = cfg->STree->AddInnerChild(root);
			lfb = cfg->STree->AddLeafChild(cfg->SpeciesData[cfg->BestTriple->first.b].Code, node);
			lfb->SetSpecies(cfg->BestTriple->first.b);
			cfg->SpeciesData[cfg->BestTriple->first.b].Included = true;
			lfc = cfg->STree->AddLeafChild(cfg->SpeciesData[cfg->BestTriple->first.c].Code, node);
			lfc->SetSpecies(cfg->BestTriple->first.c);
			cfg->SpeciesData[cfg->BestTriple->first.c].Included = true;
			cfg->TotalQ = cfg->BestTriple->second;
			break;
		case 1:
			lfa = cfg->STree->AddLeafChild(cfg->SpeciesData[cfg->BestTripleA].Code, root);
			lfa->SetSpecies(cfg->BestTripleA);
			cfg->SpeciesData[cfg->BestTripleA].Included = true;
			node = cfg->STree->AddInnerChild(root);
			lfb = cfg->STree->AddLeafChild(cfg->SpeciesData[cfg->BestTriple1->first.b].Code, node);
			lfb->SetSpecies(cfg->BestTriple1->first.b);
			cfg->SpeciesData[cfg->BestTriple1->first.b].Included = true;
			lfc = cfg->STree->AddLeafChild(cfg->SpeciesData[cfg->BestTriple1->first.c].Code, node);
			lfc->SetSpecies(cfg->BestTriple1->first.c);
			cfg->SpeciesData[cfg->BestTriple1->first.c].Included = true;
			cfg->TotalQ = cfg->BestTriple1->second;
			break;
		case 2:
			lfa = cfg->STree->AddLeafChild(cfg->SpeciesData[cfg->BestTripleA].Code, root);
			lfa->SetSpecies(cfg->BestTripleA);
			cfg->SpeciesData[cfg->BestTripleA].Included = true;
			node = cfg->STree->AddInnerChild(root);
			lfb = cfg->STree->AddLeafChild(cfg->SpeciesData[cfg->BestTripleB].Code, node);
			lfb->SetSpecies(cfg->BestTripleB);
			cfg->SpeciesData[cfg->BestTripleB].Included = true;
			lfc = cfg->STree->AddLeafChild(cfg->SpeciesData[cfg->BestTriple2->first].Code, node);
			lfc->SetSpecies(cfg->BestTriple2->first);
			cfg->SpeciesData[cfg->BestTriple2->first].Included = true;
			cfg->TotalQ = cfg->BestTriple2->second;
			break;
		case 3:
			lfa = cfg->STree->AddLeafChild(cfg->SpeciesData[cfg->BestTripleA].Code, root);
			lfa->SetSpecies(cfg->BestTripleA);
			cfg->SpeciesData[cfg->BestTripleA].Included = true;
			node = cfg->STree->AddInnerChild(root);
			lfb = cfg->STree->AddLeafChild(cfg->SpeciesData[cfg->BestTripleB].Code, node);
			lfb->SetSpecies(cfg->BestTripleB);
			cfg->SpeciesData[cfg->BestTripleB].Included = true;
			lfc = cfg->STree->AddLeafChild(cfg->SpeciesData[cfg->BestTripleC].Code, node);
			lfc->SetSpecies(cfg->BestTripleC);
			cfg->SpeciesData[cfg->BestTripleC].Included = true;
			cfg->TotalQ = cfg->Triq3[cfg->BestTripleA][cfg->BestTripleB][cfg->BestTripleC];
			break;
	}
	cfg->STree->UpdateLite(root);
	return 3;		// Because initial tree consists of three leaves
};

// Calculates reliablity for all inner nodes but root of the current STree
void ReliabilityCalc0(void) {									// 3d map
	// Loop over all inner nodes but root
	PNode root = cfg->STree->GetRoot();
	myset *allspec = root->GetClade();
	PNode node = cfg->STree->GetInnerFirst();
	Triple0 triple;
	while(node) {
		if(node != root) {
			myset *clade = node->GetClade();
			float numerator = 0, denominator = 0;
			for(int spb = 1; spb <= cfg->SpecNum; spb++) {
				if(!(*clade)[spb])
					continue;
				for(int spc = spb + 1; spc <= cfg->SpecNum; spc++) {
					if(!(*clade)[spc])
						continue;
					for(int spa = 1; spa <= cfg->SpecNum; spa++) {
						if(spa == spb || spa == spc || (*clade)[spa] || !(*allspec)[spa])
							continue;
						triple.a = spa;
						triple.b = spb;
						triple.c = spc;
						Triple0MapIter tit = cfg->Triq0.find(triple);
						if(tit != cfg->Triq0.end()) {
							numerator += tit->second;
							denominator += tit->second;
						}
						triple.a = spb;
						if(spc < spa) {
							triple.b = spc;
							triple.c = spa;
						}
						else {
							triple.b = spa;
							triple.c = spc;
						}
						tit = cfg->Triq0.find(triple);
						if(tit != cfg->Triq0.end())
							denominator += tit->second;
						triple.a = spc;
						if(spb < spa) {
							triple.b = spb;
							triple.c = spa;
						}
						else {
							triple.b = spa;
							triple.c = spb;
						}
						tit = cfg->Triq0.find(triple);
						if(tit != cfg->Triq0.end())
							denominator += tit->second;
					}
				}
			}
			node->SetLength((denominator < EPS ? cfg->Uncertainty : 
            (numerator  < EPS ? cfg->ZeroValue : numerator / denominator)));
		}
		node = cfg->STree->GetInnerNext();
	}
};

// Calculates reliablity for all inner nodes but root of the current STree
void ReliabilityCalc1(void) {									// 1d array of 2d maps
	// Loop over all inner nodes but root
	PNode root = cfg->STree->GetRoot();
	myset *allspec = root->GetClade();
	PNode node = cfg->STree->GetInnerFirst();
	Triple1 triple;
	while(node) {
		if(node != root) {
			myset *clade = node->GetClade();
			float numerator = 0, denominator = 0;
			for(int spb = 1; spb <= cfg->SpecNum; spb++) {
				if(!(*clade)[spb])
					continue;
				for(int spc = spb + 1; spc <= cfg->SpecNum; spc++) {
					if(!(*clade)[spc])
						continue;
					for(int spa = 1; spa <= cfg->SpecNum; spa++) {
						if(spa == spb || spa == spc || (*clade)[spa] || !(*allspec)[spa])
							continue;
						triple.b = spb;
						triple.c = spc;
						Triple1MapIter tit = cfg->Triq1[spa]->find(triple);
						if(tit != cfg->Triq1[spa]->end()) {
							numerator += tit->second;
							denominator += tit->second;
						}
						if(spc < spa) {
							triple.b = spc;
							triple.c = spa;
						}
						else {
							triple.b = spa;
							triple.c = spc;
						}
						tit = cfg->Triq1[spb]->find(triple);
						if(tit != cfg->Triq1[spb]->end())
							denominator += tit->second;
						if(spb < spa) {
							triple.b = spb;
							triple.c = spa;
						}
						else {
							triple.b = spa;
							triple.c = spb;
						}
						tit = cfg->Triq1[spc]->find(triple);
						if(tit != cfg->Triq1[spc]->end())
							denominator += tit->second;
					}
				}
			}
			node->SetLength((denominator < EPS ? cfg->Uncertainty : 
            (numerator < EPS ? cfg->ZeroValue : numerator / denominator)));
		}
		
		node = cfg->STree->GetInnerNext();
	}
};

// Calculates reliablity for all inner nodes but root of the current STree
void ReliabilityCalc2(void) {									// 2d array of 1d maps
	// Loop over all inner nodes but root
	PNode root = cfg->STree->GetRoot();
	myset *allspec = root->GetClade();
	PNode node = cfg->STree->GetInnerFirst();
	while(node) {
		if(node != root) {
			myset *clade = node->GetClade();
			float numerator = 0, denominator = 0;
			for(int spb = 1; spb <= cfg->SpecNum; spb++) {
				if(!(*clade)[spb])
					continue;
				for(int spc = spb + 1; spc <= cfg->SpecNum; spc++) {
					if(!(*clade)[spc])
						continue;
					for(int spa = 1; spa <= cfg->SpecNum; spa++) {
						if(spa == spb || spa == spc || (*clade)[spa] || !(*allspec)[spa])
							continue;
						Triple2MapIter tit = cfg->Triq2[spa][spb]->find(spc);
						if(tit != cfg->Triq2[spa][spb]->end()) {
							numerator += tit->second;
							denominator += tit->second;
						}
						if(spc < spa) {
							tit = cfg->Triq2[spb][spc]->find(spa);
							if(tit != cfg->Triq2[spb][spc]->end())
								denominator += tit->second;
						}
						else {
							tit = cfg->Triq2[spb][spa]->find(spc);
							if(tit != cfg->Triq2[spb][spa]->end())
								denominator += tit->second;
						}
						if(spb < spa) {
							tit = cfg->Triq2[spc][spb]->find(spa);
							if(tit != cfg->Triq2[spc][spb]->end())
								denominator += tit->second;
						}
						else {
							tit = cfg->Triq2[spc][spa]->find(spb);
							if(tit != cfg->Triq2[spc][spa]->end())
								denominator += tit->second;
						}
					}
				}
			}
			node->SetLength((denominator < EPS ? cfg->Uncertainty : 
            (numerator < EPS ? cfg->ZeroValue : numerator / denominator)));
		}
		node = cfg->STree->GetInnerNext();
	}
};

// Calculates reliablity for all inner nodes but root of the current STree
void ReliabilityCalc3(void) {									// 3d array
	// Loop over all inner nodes but root
	PNode root = cfg->STree->GetRoot();
	myset *allspec = root->GetClade();
	PNode node = cfg->STree->GetInnerFirst();
	while(node) {
		if(node != root) {
			myset *clade = node->GetClade();
			float numerator = 0, denominator = 0;
			for(int spb = 1; spb <= cfg->SpecNum; spb++) {
				if(!(*clade)[spb])
					continue;
				for(int spc = spb + 1; spc <= cfg->SpecNum; spc++) {
					if(!(*clade)[spc])
						continue;
					for(int spa = 1; spa <= cfg->SpecNum; spa++) {
						if(spa == spb || spa == spc || (*clade)[spa] || !(*allspec)[spa])
							continue;
						numerator += cfg->Triq3[spa][spb][spc];
						denominator += cfg->Triq3[spa][spb][spc];
						denominator += spc < spa ? cfg->Triq3[spb][spc][spa] : cfg->Triq3[spb][spa][spc];
						denominator += spb < spa ? cfg->Triq3[spc][spb][spa] : cfg->Triq3[spc][spa][spb];
					}
				}
			}
			node->SetLength((denominator < EPS ? cfg->Uncertainty : 
            (numerator < EPS ? cfg->ZeroValue : numerator / denominator)));
		}
		node = cfg->STree->GetInnerNext();
	}
};

#ifdef SUPER3MPI
// Parallel incremental building of the species tree (all variants)
// This function is performed by each (rank_mpi)-th CPU
void ParaBuildSpeciesTree(int spin) {
	if(cfg->LogSuper3)
		cfg->clog << "\nBuilding of the supertree:" << endl;
	// Main loop of the species addition
	int addedsp = 0;			// id (number) of added species
	double R = 0;				// reliability of last addition
   double Criterion;       // current greater Q*(R+1) product  
	double **quality = 0;	// [nodecount][speccount] variants quality matrix
	PTree BestTree = NULL, GoodTree = NULL;
	double BestQ = -1;
   int skipped = 0;
   MyQueue queue;          // used only in root branch
	for( ; ; spin++) {	
      Criterion = -1;
      // Fixing last step result by root branch only
		if(cfg->rank_mpi == 0) {
         while( !queue.empty() ) {  // to ensure that it's empty
            Sp2Add* specdata = queue.top();
            queue.pop();
            delete specdata;
         }
			// Calculate reliability (optional)
			if(cfg->EachStepReliability || spin == (int)cfg->Species.size()) {
				MakeClades(cfg->STree);
				switch(cfg->SpecArrayDim) {					
					case 0:	ReliabilityCalc0(); break;
					case 1:	ReliabilityCalc1(); break;
					case 2:	ReliabilityCalc2(); break;
					case 3:	ReliabilityCalc3(); break;
				}
			}
			// Output in the species tree file or cout
			if(cfg->Super3NameGiven) { 
				if(!cfg->Super3Sequence)
					cfg->super3.seekp(0);
				if(cfg->Super3Quality) {
					cfg->super3 << "[" TSTAMP << " N=" << spin;
					if(addedsp)
						cfg->super3 << " (" << cfg->SpeciesData[addedsp].Code << " added)";
					cfg->super3 << "  TotalQ=" << fixed << setprecision(2) << cfg->TotalQ;
					if(addedsp)
					   cfg->super3 << "  Q=" << fixed << setprecision(2) << BestQ 
                     << "  R=" << fixed << setprecision(6) << R;
               if(skipped)
                  cfg->super3 << " (" << skipped << " species skipped)";
					cfg->super3 << " ]" << endl;
				}
				cfg->super3 << cfg->STree->Write(cfg->TreeWriteMode) << endl;
			}
			else {
				if(cfg->Super3Quality) {
					cout TSTAMP << " N=" << spin;
					if(addedsp)
						cout << " (" << cfg->SpeciesData[addedsp].Code << " added)";
					cout << " TotalQ=" << fixed << setprecision(0) << cfg->TotalQ;
					if(addedsp)
						cout << "  R=" << fixed << setprecision(4) << R;
               if(skipped)
                  cout << " (" << skipped << " species skipped)";
					cout << endl;
				}
				cout << cfg->STree->Write(cfg->TreeWriteMode) << endl;
			}
			// Optional logging
			if(cfg->LogSuper3) {						// Logging supertree construction with add. data
				cfg->clog TSTAMP << "  N=" << spin;
				if(addedsp)
					cfg->clog << " (" << cfg->SpeciesData[addedsp].Code << " added)";
				cfg->clog << "  TotalQ=" << fixed << setprecision(2) << cfg->TotalQ;
				if(addedsp)
				   cfg->clog << "  Q=" << fixed << setprecision(2) << BestQ 
                  << "  R=" << fixed << setprecision(6) << R;
            if(skipped)
               cfg->clog << " (" << skipped << " species skipped)";
            int stmode = cfg->TreeLogMode;
            if(cfg->LogChoice3) stmode |= Config::InnerIndex;
				cfg->clog << endl << cfg->STree->Write(stmode) << endl;
			}
		}
      // Gather all remaining species in spnums[speccount]
		int speccount = (int)cfg->Species.size() - spin;
		if(speccount == 0)	// nothing to do
			break;
		int *spnums = new int [speccount];
		int spn = 0;
		for(int sp = 1; sp <= cfg->SpecNum; sp++) {
			if(cfg->SpeciesData[sp].Enable && !cfg->SpeciesData[sp].Included)
				spnums[spn++] = sp;
		}
		if(spn != speccount) {
			ostringstream oss;
			oss << "ParaBuildSpeciesTree: Species counts mismatch: " << spn << " vs. " << speccount;
			throw(oss.str());
		}
		// Gather all nodes of the current STree in nodes[nodecount]
		PTree tree = cfg->STree;
		int nodecount = tree->GetInnerCount() + tree->GetLeafCount();
		PNode *nodes = new PNode [nodecount];	   // i = index - 1
		PNode inner = tree->GetInnerFirst();
		while(inner) {
			nodes[inner->GetIndex() - 1] = inner;
			inner = tree->GetInnerNext();
		}
		PNode leaf = tree->GetLeafFirst();
		while(leaf) {
			nodes[leaf->GetIndex() - 1] = leaf;
			leaf = tree->GetLeafNext();
		}
      skipped = 0;
		// Initialize quality table to choose from
		if(cfg->rank_mpi == 0) {
			quality = new double* [nodecount];
			for(int i = 0; i < nodecount; i++) {
				quality[i] = new double [speccount];
				for(int j = 0; j < speccount; j++)
					quality[i][j] = -1;
			}
		}
      double report[3];    // Q, i=node, j=species
      int needed = speccount * nodecount;
		// Each nonzero rank contributes to the quality matrix for assigned node
      if(cfg->rank_mpi != 0) {
		   for(int i = cfg->rank_mpi - 1; i < nodecount; i += cfg->size_mpi - 1) {
			   PNode node = nodes[i];
			   PNode upnode = tree->InsertParent(node);
			   PNode newnode;
            // Try all remaining species in turn
			   for(int j = 0; j < speccount; j++) {
				   int sp = spnums[j];
				   string newname = cfg->SpeciesData[sp].Code;
				   if(j == 0) {		// begin run over species for this node
					   newnode = tree->AddLeafChild(newname, upnode);
					   newnode->SetSpecies(sp);
					   tree->UpdateLite(tree->GetRoot());
				   }
				   else {				// continue last run
					   tree->ChangeLeaf(newnode, newname, sp);
				   }
				   #ifdef TOPO3VAR2
				   MakeClades(tree);
				   #endif
				   double Q;
				   switch(cfg->SpecArrayDim) {
					   case 0:	Q = Tree0Quality(tree, newname); break;
					   case 1:	Q = Tree1Quality(tree, newname); break;
					   case 2:	Q = Tree2Quality(tree, newname); break;
					   case 3:	Q = Tree3Quality(tree, newname); break;
				   }

				   // Report <Q, i, j> to the root 
				   report[0] = Q;
				   report[1] = (double)i;
				   report[2] = (double)j;
				   MPI::COMM_WORLD.Send(report, 3, MPI::DOUBLE, 0, Config::tagQIJ);

			   }  // next remaining species

			   tree->RemoveNode(newnode);
			   tree->RemoveNode(upnode);
			   tree->UpdateLite(tree->GetRoot());

		   }  // assign next node to this rank
      }
      else {   // The root collects reports from other ranks
		   while(cfg->rank_mpi == 0 && needed) {
			   MPI::Status status;
			   MPI::COMM_WORLD.Recv(report, 3, MPI::DOUBLE, MPI::ANY_SOURCE, Config::tagQIJ, status);
			   int i1 = (int)(report[1] + TRUNC);
			   int j1 = (int)(report[2] + TRUNC);
			   quality[i1][j1] = report[0];
			   needed--;
		   }

         // Debug logging of the matrix
         //cfg->clog << "Quality matrix\n     ";
         //for (int j = 0; j < speccount; j++)
         //   cfg->clog << setw(8) << cfg->SpeciesData[spnums[j]].Code;
         //cfg->clog << endl;
         //for (int i = 0; i < nodecount; i++) {
         //   if (nodes[i]->IsLeaf())
         //      cfg->clog << setw(2) << nodes[i]->GetName() << ":  ";
         //   else
         //      cfg->clog << setw(2) << nodes[i]->GetIndex() << ":  ";
         //   for (int j = 0; j < speccount; j++)
         //      cfg->clog << setprecision(2) << setw(8) << quality[i][j];
         //   cfg->clog << endl;
         //}
      }

		MPI::COMM_WORLD.Barrier();
		// Find & accept the best candidate
		BestQ       = -1;
		int ibest   = -1;
      addedsp     = 0;

		if(cfg->rank_mpi == 0) {

         //  Fill queue by the matrix
         for(int j = 0; j < speccount; j++) {   // loop over species
			   double best = -1, good = -1;
            PNode bestnode = 0, goodnode = 0;

            for(int i = 0; i < nodecount; i++) {   // loop over nodes
               double Q = quality[i][j];
				   if(Q > best) {
					   good     = best;
                  goodnode = bestnode;
					   best     = Q;
                  bestnode = nodes[i];
                  ibest    = i;
				   }
               else if(Q > good) {
					   good     = Q;
                  goodnode = nodes[i];
               }
            }

            R = best > 0 ? (best - good) / best : 0;
            double c = best * (R + cfg->RShift);

            // push best node to the queue
            Sp2Add* specdata     = new Sp2Add;
            specdata->species    = spnums[j];
            specdata->nodeno     = ibest;
            specdata->best       = best;
            specdata->bestnode   = bestnode;
            specdata->good       = good;
            specdata->goodnode   = goodnode;
            specdata->R          = R;
            specdata->criterion  = c;
            queue.push(specdata);
         }

		   // Free quality matrix after the step done
		   for(int i = 0; i < nodecount; i++) 
			   delete [] quality[i];
		   delete [] quality;

         if( !queue.empty() ) {
            // Make choice with logging
            Sp2Add* specdata = 0;

            if(cfg->LogSuper3 && cfg->LogChoice3) {   // Log entire queue
               MyQueue tq(queue);
               cfg->clog << "\nCandidates for species insertion over nodes:" << endl;
               while( !tq.empty() ) {
                  specdata = tq.top();
                  cfg->clog << "  " << cfg->SpeciesData[specdata->species].Code << ": ";
                  PNode node = specdata->bestnode;
                  if(node->IsLeaf()) 
                     cfg->clog << node->GetName();
                  else 
                     cfg->clog << node->GetIndex(); 
                  cfg->clog << "->(" << fixed << setprecision(2) << specdata->best << 
                     " " << fixed << setprecision(6) << specdata->R << ")";
                  tq.pop();
				   }
				   cfg->clog << endl << endl;
			   }

            if( cfg->SkipAmbiguous ) {
               for(skipped = 0; !queue.empty(); skipped++) {
                  specdata = queue.top();
                  if(specdata->R != 0) break;
                  queue.pop();
               }
            }
            else 
               specdata = queue.top();

            if( !queue.empty() ) {
               addedsp  = specdata->species;
               R        = specdata->R;
               BestQ    = specdata->best;
               ibest    = specdata->nodeno;

			      report[0]   = BestQ;
			      report[1]   = (double)ibest;     // node no. in 
			      report[2]   = (double)addedsp;   // instead of indirect jbest
            }
         }
         if (queue.empty()) {
            cerr TSTAMP << "Cannot add more species after " << spin << "th one." << endl;
            report[0]   = -1;
         }
		}

		MPI::COMM_WORLD.Bcast(report, 3, MPI::DOUBLE, 0);
      if(report[0] >= 0) {
		   if(cfg->rank_mpi != 0) {
			   BestQ    = report[0];
			   ibest    = (int)(report[1] + TRUNC);
			   addedsp  = (int)(report[2] + TRUNC);
		   }

         //cfg->clog << "rank=" << cfg->rank_mpi << ": BestQ=" << BestQ << 
         //             " ibest=" << ibest << " addedsp=" << addedsp << endl;

		   // Make best move everywhere
		   PNode bestnode = nodes[ibest];
		   string newname = cfg->SpeciesData[addedsp].Code;
		   PNode upnode   = tree->InsertParent(bestnode);
		   PNode newnode  = tree->AddLeafChild(newname, upnode);
		   newnode->SetSpecies(addedsp);
		   tree->UpdateLite(tree->GetRoot());
		   cfg->TotalQ += BestQ;
		   cfg->SpeciesData[addedsp].Included = true;
         if(cfg->SpeciesLength) {
            double len = R < EPS ? cfg->ZeroValue : R + 2 * cfg->ZeroValue;
            newnode->SetLength((float)len);
         }
		   delete [] spnums;
		   delete [] nodes;
      }
      else {
         break;
      }
	}     // increment spin
   if(skipped && cfg->rank_mpi == 0) {
      cfg->clog TSTAMP << "  Cannot insert " << skipped << " species:" << endl;
		for(int sp = 1; sp <= cfg->SpecNum; sp++) 
			if( cfg->SpeciesData[sp].Enable && !cfg->SpeciesData[sp].Included)
            cfg->clog << setfill(' ') << setw(6) << sp << ": " << 
               cfg->SpeciesData[sp].Code << endl;
      cfg->clog << endl;
   }
};

// Parallel building of basis trees by induction over size
void ParaBuildBasisTrees(void) {
	// First building one-element trees
	PSetMapIter none = cfg->PSet.end();
	PSetMapIter pit = cfg->PSet.begin();
	for( ; pit != none; pit++) {
		if( ! pit->second.Basis )
			continue;
		if(pit->first.count() > 1)
			break;
		int sp = pit->first.first();
		PTree tree = new Tree();
		PNode leaf = tree->AddLeafNode(cfg->SpeciesData[sp].Code);
		leaf->SetSpecies(sp);
		tree->SetRoot(leaf);
		tree->SetRooted();
		pit->second.BasTree = tree;
		#ifdef BTREEWEIGHT
		pit->second.Weight = 1;
		#endif
	}
	MPI::COMM_WORLD.Barrier();
	int wordcount = pit->first.wordcount();
	int portion = wordcount * 2 + 2;       // ending two: bestcost, bestcost2 
	WORD *buf = new WORD [cfg->size_mpi * portion];		// Buffers for MPI collective communication
	WORD *sendbuf = new WORD [portion];
	WORD *w1 = sendbuf;												// key of V1 for "this" processor
	WORD *w2 = w1 + wordcount;										// key of V2
	float *f1 = (float*)(w2 + wordcount);						// bestcost (assume sizeof(float)==sizeof(WORD))
	float *f2 = f1 + 1;												// bestcost2
	PSetMapIter *pits = new PSetMapIter [cfg->size_mpi];
	myset ms;
   // To suppress basis set logging in PartitionCost
   bool cfgLogBasisSets = cfg->LogBasisSets;
   cfg->LogBasisSets = false;
	// Then proceed in parallel starting from two-element basis sets
	for(int size = 2; size <= cfg->SpecNum; size++) {
		CheckAbort();
		if((pit = cfg->PSetEntry[size]) == none)
			continue;
		int innerbase = 1;
		int n = 0;
		PSetMapIter nextpit;
      // loop in parallel within current size
		for( ; pit != none && pit->first.count() == size; pit++) {
			CheckAbort();
			if( ! pit->second.Basis )
				continue;
			for(int rank = 0; rank < cfg->size_mpi; ) {
				pits[rank] = pit;
				// Milestones
				if(cfg->Milestones && (n++ & cfg->Milestones) == 0)
					cerr << "BT " << setfill(' ') << setw(4) << size << " [" << n-1 << "]      \r" << flush;
				set<V1V2Pair>::iterator bestvar;
				float bestcost = numeric_limits<float>::max();
				#ifdef BTREEWEIGHT
				float bestcost2 = numeric_limits<float>::max();
				#endif
				if(rank++ == cfg->rank_mpi) {	   // pertinent to this rank (=cpu)
               // Loop over all variants of partitioning
					set<V1V2Pair>::iterator partvar = pit->second.V1V2.begin();
					for( ; partvar != pit->second.V1V2.end(); partvar++) {
						float cost = PartitionCost(pit, partvar);
						if(cost < bestcost) {
							#ifdef BTREEWEIGHT
							if(cfg->BasisTreeWeight)
								bestcost2 = bestcost;
							#endif
							bestvar = partvar;
							bestcost = cost;
						}
						#ifdef BTREEWEIGHT
						else if(cfg->BasisTreeWeight && cost < bestcost2)
							bestcost2 = cost;
						#endif
					}
					ms = bestvar->first;
					ms.getwords(w1);
					ms = bestvar->second;
					ms.getwords(w2);
					*f1 = bestcost;
					#ifdef BTREEWEIGHT
					*f2 = bestcost2;
					#endif
				}
				nextpit = pit;							// find next relevant pit
				for( ++nextpit; nextpit != none && nextpit->first.count() == size; nextpit++) {
					if(!nextpit->second.Basis)
						continue;
					pit = nextpit;
					break;
				}
				if(pit == nextpit) 					// next pit found
					continue;
				if(rank == cfg->rank_mpi)			// no more pit for this size
					*f1 = *f2 = -1;
				break;
			}
			pit = --nextpit;

			// Exchange best variants among all processors
	//		MPI::COMM_WORLD.Barrier();
			MPI::COMM_WORLD.Allgather(sendbuf, portion, MPI::UNSIGNED, buf, portion, MPI::UNSIGNED);

			// Building best basis trees at each CPU
			WORD *v1 = buf;
			WORD *v2 = v1 + wordcount;
			float *g1 = (float*)(v2 + wordcount);
			float *g2 = g1 + 1;
         #ifdef LOGPCHOICE			
         if(cfg->rank_mpi == 0 && cfg->LogBasisTrees) 
				cfg->clog << "size=" << setfill(' ') << setw(3) << size;
         #endif				
			for(int k = 0; k < cfg->size_mpi; k++) {
            #ifdef LOGPCHOICE			
				if(cfg->rank_mpi == 0 && cfg->LogBasisTrees) { 
					cfg->clog << setw(4) << k << ": ";
					if(*g1 < 0)
						cfg->clog << "*** & *** " << *g1 << endl;
				}
            #endif
				if(*g1 < 0)
					break;
				PTree tree = new Tree(innerbase++);
				PNode root = tree->AddInnerNode();
				tree->SetRoot(root);
				tree->SetRooted();
				root->SetDepth(0);
				PSetMapIter pit1, pit2;
				myset tmp(v1);
				pit1 = cfg->PSet.find(tmp);
            #ifdef LOGPCHOICE			
            int n1 = tmp.count();
            #endif
				tmp.setwords(v2);
				pit2 = cfg->PSet.find(tmp);
            #ifdef LOGPCHOICE			
            int n2 = tmp.count();
				if(cfg->rank_mpi == 0 && cfg->LogBasisTrees) 
					cfg->clog << setfill('0') << setw(3) << n1 << " & " << setw(3) << n2 << setfill(' ')
						<< fixed << setw(8) << setprecision(1) << *g1 << " ";
            #endif
				if(pit1 == none || pit2 == none)
					throw("Internal error: Partition constituent not found.");
				if(!pit1->second.BasTree || !pit2->second.BasTree)
					throw("Internal error: Partition constituent has no tree.");
				tree->Clone(pit1->second.BasTree->GetRoot(), root);
				tree->Clone(pit2->second.BasTree->GetRoot(), root);
				tree->UpdateLite(root);
				pits[k]->second.Cost = *g1;		// bestcost;
				pits[k]->second.BasTree = tree;
				#ifdef BTREEWEIGHT
				if(cfg->BasisTreeWeight) {
					float tmp = (float)tree->GetLeafCount()/cfg->Species.size();
					pits[k]->second.Weight = (*g2 - *g1) / *g2		// (bestcost2 - bestcost) / bestcost2 
						* (float)(1 + cfg->ScaleFactor * tmp * tmp);
				}
				else
					pits[k]->second.Weight = 1;
				#endif
				v1 += portion;
				v2 += portion;
				g1 += portion;
				g2 += portion;
			}
         #ifdef LOGPCHOICE			
			if(cfg->rank_mpi == 0 && cfg->LogBasisTrees) 
				cfg->clog << endl;
         #endif
		}
		MPI::COMM_WORLD.Barrier();
	}
   cfg->LogBasisSets = cfgLogBasisSets;   // restore logging flag
	delete [] pits;
	delete [] sendbuf;
	delete [] buf;
	#ifdef BTREEWEIGHT
	float wmax = 0;
	float wmin = numeric_limits<float>::max();
	double wsum = 0;
	double wsqsum = 0;
	#endif
	// Final cut of basis trees
	int btreenum = 0, numleaves = 0, maxleaves = 0;
	for(pit = cfg->PSet.begin(); pit != none; /*pit++*/) {
		if( ! pit->second.Basis ) {
			pit++;
			continue;
		}
		int leaves = pit->second.BasTree->GetLeafCount();
		#ifdef BTREEWEIGHT
		if(leaves < 3 || pit->second.Weight < cfg->MinWeight) { 
		#else
		if(leaves < 3) { 
		#endif
			pit->second.Basis = false;
			pit->second.V1V2.clear();
			delete pit->second.BasTree;
			PSetMapIter toerase = pit++;
			cfg->PSet.erase(toerase);
		}
		else {
			MakeClades(pit->second.BasTree);
			btreenum ++;
			#ifdef BTREEWEIGHT
			if(cfg->BasisTreeWeight) {
				float w = pit->second.Weight;
				if(w > wmax)
					wmax = w;
				if(w < wmin)
					wmin = w;
				wsum += (double)w;
				wsqsum += (double)w * w;
			}
			#endif
			numleaves += leaves;
			if(leaves > maxleaves)
				maxleaves = leaves;
			pit++;
		}
	}
	if(!cfg->super3_mpi || cfg->rank_mpi == 0) {
		cerr TSTAMP << "Basis trees constructed: " << btreenum << ", total leaves=" << numleaves
			<< " (max=" << maxleaves << ")." << endl;
		cfg->clog TSTAMP << "Basis trees constructed: " << btreenum << ", total leaves=" << numleaves
			<< " (max=" << maxleaves << ")." << endl;
	}
	#ifdef BTREEWEIGHT
	if(!cfg->super3_mpi || cfg->rank_mpi == 0) {
		if(cfg->BasisTreeWeight) {
			double m = wsum / btreenum;
			double d = wsqsum / btreenum - m * m;
			d = sqrt(d * btreenum / (btreenum - 1));
			cerr TSTAMP << "BT weight: min=" << fixed << setprecision(5) << wmin << ", max="
				<< setprecision(2) << wmax << ", average=" << m << ", stdev=" << d << "." << endl;
			cfg->clog TSTAMP << "BT weight: min=" << fixed << setprecision(5) << wmin << ", max="
				<< setprecision(5) << wmax << ", average=" << m << ", stdev=" << d << "." << endl;
		}
	}
	#endif
};

// Identifies basis sets in PSet in parallel by induction over size
void ParaIdentifyBasisSets(void) {
	int numbas = 0;
	int numpart = 0;
	size_t maxpart = 1;
	PSetMapIter none = cfg->PSet.end();
	PSetMapIter pit = cfg->PSetEntry[1];

   // Preparing for set exchanges
	int maxword = pit->first.wordcount();
	int sendcount = 1 + maxword * 2;    // [0]: is partition
	WORD *sendbuf = new WORD [sendcount];
	WORD *w1 = sendbuf + 1;
	WORD *w2 = w1 + maxword;
	int recvcount = sendcount * cfg->size_mpi;
	WORD *buf = new WORD [recvcount];

	// Mark each set of the size=1 as basis set
	for( ; pit->first.count() == 1; pit++) {
		pit->second.Basis = true;
		pit->second.V1V2.clear();
		numbas++;
		numpart++;
	}

	// Process greater sizes in turn
	myset join;
	for(int size = 2; size <= cfg->SpecNum; size++) {
		MPI::COMM_WORLD.Barrier();
		if(cfg->PSetEntry[size] == none)
			continue;
		int rank = 0;
		PSetMapIter pit1; 
		PSetMapIter pit2;
		for(int s1 = 1; s1 <= (size >> 1); s1++) {
			int s2 = size - s1;
			if((pit1 = cfg->PSetEntry[s1]) == none || (pit2 = cfg->PSetEntry[s2]) == none)
				continue;
			for( ; pit1 != none && pit1->first.count() == s1; pit1++) {
				if( ! pit1->second.Basis )
					continue;
				if(s1 != s2)
					pit2 = cfg->PSetEntry[s2];
				else {
					pit2 = pit1;
					pit2++;
				}
				for( ; pit2 != none && pit2->first.count() == s2; pit2++) {
					if( ! pit2->second.Basis )
						continue;
					if(rank == cfg->size_mpi)
						rank = 0;
					if(rank++ == cfg->rank_mpi) {
						join.assign(pit1->first);
						join.join(pit2->first);
						if(join.count() != size)
							continue;
						// find such set in PSet and make it basis if exists
						pit = cfg->PSet.find(join);
						if(pit == none)
							continue;
						pit->second.Basis = true;
						V1V2Pair v1v2(pit1->first, pit2->first);
						pit->second.V1V2.insert(v1v2);
					}
				}
			}
		}
		MPI::COMM_WORLD.Barrier();
		// Merge results of all branches
		pit = cfg->PSetEntry[size];
		V1V2Pair vvp; 
		for( ; pit != none && pit->first.count() == size; pit++) {
			set<V1V2Pair>::iterator partit = pit->second.V1V2.begin();
			while(1) {
				if(partit != pit->second.V1V2.end()) {
					sendbuf[0] = 1;
					partit->first.getwords(w1);
					partit->second.getwords(w2);
					partit++;
				}
				else {
					for(int i = 0; i < sendcount; i++)
						sendbuf[i] = 0;
				}
				MPI::COMM_WORLD.Allgather(sendbuf, sendcount, MPI::UNSIGNED, buf, sendcount, MPI::UNSIGNED);
				WORD flag = 0;
				WORD *recv = buf;
				for(int rank = 0; rank < cfg->size_mpi; rank++) {
					flag |= *recv;
					if(*recv) {
						vvp.first.setwords(recv + 1);
						vvp.second.setwords(recv + maxword + 1);
						pit->second.Basis = true;
						pit->second.V1V2.insert(vvp);
					}
					recv += sendcount;
				}
				if(flag == 0)
					break;
			}
			MPI::COMM_WORLD.Barrier();
			if(pit->second.Basis)
				numbas++;
			numpart += (int)pit->second.V1V2.size();
			if(pit->second.V1V2.size() > maxpart)
				maxpart = pit->second.V1V2.size();
		}
		if(cfg->Milestones)
			cerr << "B " << setfill(' ') << setw(4) << size << " [" << numpart << "]      \r" << flush;
	}
	delete [] buf;
	delete [] sendbuf;
	if(!cfg->super3_mpi || cfg->rank_mpi == 0) {
		cerr TSTAMP << "Basis sets selected: " << numbas << ", partitions=" << numpart 
			<< " (max=" << maxpart << ")." << endl;
		cfg->clog TSTAMP << "Basis sets selected: " << numbas << ", partitions=" << numpart 
			<< " (max=" << maxpart << ")." << endl;
      if(cfg->LogBasisSets) {
		   cfg->clog << "\nBasis sets & partitions:" << endl
			   << "    #  |V|{V}  |V1+V2| Partition:|r(V1,V2)|[,penalty]..." << endl; 
	      int serial = 1;
	      for(pit = cfg->PSet.begin(); pit != none; pit++) {
            if( !pit->second.Basis )
               continue;
			   pit->second.serial = serial++;
			   myset clade = pit->first;
			   set<V1V2Pair> &v1v2 = pit->second.V1V2;
			   cfg->clog << setfill(' ') << setw(5) << pit->second.serial << "  [" << clade.count() << "] " 
				   << clade.Write() << "  [" << v1v2.size() << "]";
		      set<V1V2Pair>::iterator partvar = pit->second.V1V2.begin();
		      for( ; partvar != pit->second.V1V2.end(); partvar++) {
			      cfg->clog << " " << cfg->PSet.find(partvar->first)->second.serial
				      << "+" << cfg->PSet.find(partvar->second)->second.serial << ":";
               float cost = PartitionCost(pit, partvar);
		      }
			   cfg->clog << endl;
         }
		   cfg->clog << endl;
      }
	}
};
#endif
