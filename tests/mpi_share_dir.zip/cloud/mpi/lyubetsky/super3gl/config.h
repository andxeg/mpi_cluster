//	super3GL:  A program for the phylogenetic supertree construction, v.1.X.X
//	The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/super3gl]
//	(C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
// E-mail: rubanov{at}iitp.ru
//	This program is free software: you can redistribute it and/or modify
//	it under the terms of the GNU General Public License as published by
//	the Free Software Foundation, either version 3 of the License, or
//	(at your option) any later version.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details.
//
//	You should have received a copy of the GNU General Public License
//	along with this program.  If not, see <http://www.gnu.org/licenses/>.

#ifndef CONFIG_H
#define CONFIG_H

#include <string>
#include <map>
#include <set>
#include <functional>
#include <fstream>
#include <sstream>
#include "super3gl.h"
#include "forest.h"
#include "myset.h"

using namespace std;
typedef string *Pstr;
typedef map<string, int, less<string> > SpecMap;
typedef pair<SpecMap::iterator, bool> SpecMapInsertResult;

struct PSetFunctor {		// Arranging set of mysets
	bool operator() (myset elem1, myset elem2) const {
		return (elem1 < elem2);
	}
};

typedef pair<myset, myset> V1V2Pair;
struct VData {			// Clade data
	bool				Basis;
	PTree				BasTree;
	float				Cost;
	#ifdef BTREEWEIGHT
	float				Weight;
	#endif
	set<V1V2Pair>	V1V2;
	int				GoodNum;    // |r(V)| or equivalent in polytomous case
   int            GoodEdge;   // only number of good edges irrespective of polytomy
	int				serial;
};

typedef map<myset, VData, PSetFunctor> PSetMap;
typedef pair<myset, VData> PSetMapPair;
typedef PSetMap::iterator PSetMapIter;
typedef pair<PSetMapIter, bool> PSetMapResult;

struct Triple0 {		// 0-th = singular, others sorted (1st < 2nd)
	int a, b, c;
};
struct Triple0Functor {		// Arranging triples
	bool operator() (Triple0 elem1, Triple0 elem2) const {
		if(elem1.a < elem2.a)
			return true;
		if(elem1.a > elem2.a)
			return false;
		if(elem1.b < elem2.b)
			return true;
		if(elem1.b > elem2.b)
			return false;
		if(elem1.c < elem2.c)
			return true;
		return false;
	}
};
typedef map<Triple0, float, Triple0Functor> Triple0Map;
typedef pair<Triple0, float> Triple0MapPair;
typedef Triple0Map::iterator Triple0MapIter;
typedef pair<Triple0MapIter, bool> Triple0MapResult;

struct Triple1 {		// 1st < 2nd
	int b, c;
};
struct Triple1Functor {		// Arranging triples
	bool operator() (Triple1 elem1, Triple1 elem2) const {
		if(elem1.b < elem2.b)
			return true;
		if(elem1.b > elem2.b)
			return false;
		if(elem1.c < elem2.c)
			return true;
		return false;
	}
};
typedef map<Triple1, float, Triple1Functor> Triple1Map;
typedef pair<Triple1, float> Triple1MapPair;
typedef Triple1Map::iterator Triple1MapIter;
typedef pair<Triple1MapIter, bool> Triple1MapResult;
typedef Triple1Map* PTriple1Map;

typedef map<int, float, less<int> > Triple2Map;
typedef pair<int, float> Triple2MapPair;
typedef Triple2Map::iterator Triple2MapIter;
typedef pair<Triple2MapIter, bool> Triple2MapResult;
typedef Triple2Map* PTriple2Map;

struct SData {			// Species data
	bool			Enable;
	bool			Included;
	string		Code;
	string		Name;
	int			Meet;
};

struct Config {
	Config() {
		// Default program options
		WorkingDirectory = "";
		ConfigFileName = "super3GL.ini";
		ConfigFileNameGiven = false;
		SpecLabelParts = 1;
      StopLabel = "";
		StrictLabelControl = false;
		SpeciesTableName = "";
		SpecTableGiven = false;
		SpecTableOverride = false;
		TreeListOverride = false;
		TreeWriteMode = 0;
		Super3Name = "";
		Super3NameGiven = false;
		Super3Sequence = true;
		Super3Quality = false;
		BasisName = "";
		BasisNameGiven = false;
		MilestonesGiven = false;
		Milestones = 6;
		LogFileName = "super3GL.log";
		LogFileNameGiven = false;
		TreeLogMode = 0;
		LogActualTrees = false;
		LogActualSpecies = false;
		LogEntirePset = false;
		LogBasisSets = false;
		LogBasisTrees = false;
		LogTopology3 = false;
		LogSuper3 = true;
		LogChoice3 = false;
		memlog = true;
		Polytomy = false;
		// Elements of the configuration
		MaxValues = 3;
		CREM = "#;/*";
		CBLANK = " \t\n\r";
		CDELIM = " \t\n\r=:,";
		CQUOTE = '\"';
		// Elements of the Newick format
		EOT = ';';
		LPAR = '(';
		RPAR = ')';
		COMMA = ',';
		LENPR = ':';
		QUOTE = '\'';
		UND = '_';
		BCOM = '[';
		ECOM = ']';
		// Elementary groups
		DLTOK = ";(),[]";
		BLANK = " \t\n\r";
		MUSTQ = "()[],\':;";
		// CSV species table
		CSVdelimiter = '\t';
		SkipLines = 0;
		SpecNum = 0;
		SpeciesData = NULL;
		MaxSpecies = 32;
		// Table of gene trees
		TreeNum = 0;
		MaxTrees = 16;
		GTree = new PTree [MaxTrees];
		TreePruned = 0;
		// Algorithm parameters
		CLossGiven = false;
		CLoss = 2.;
		CDuplicationGiven = false;
		CDuplication = 3.;
		ThresholdGiven = false;
		Threshold = 1;
		TreePruningMode = false;
		ExtendPsetGiven = false;
		ExtendPset = false;
		#ifdef BTREEWEIGHT
		BasisTreeWeight = true;
		ScaleFactorGiven = false;
		ScaleFactor = 10;
		MinWeight = 0;
		#endif
		// Miscellanea
		STree = NULL;
		TotalQ = 0;
		SpecArrayDimGiven = false;
		SpecArrayDim = 3;
		UncertaintyGiven = false;
		Uncertainty = -1;
      ZeroValueGiven = false;
      ZeroValue = 0.1F;
		ResumeGiven = false;
		Resume = true;
		EachStepReliabilityGiven = false;
		EachStepReliability = false;
      ParalogyPenaltyGiven = false;
      ParalogyPenalty = 1.0;
      RShiftGiven = false;
      RShift = 0.5;
      SpeciesLength = true;
      SkipAmbiguous = true;
		#ifdef SUPER3MPI
		super3_mpi = true;
		size_mpi = 1;
		rank_mpi = 0;
		#endif
	};
	~Config() {
		delete [] SpeciesData;
	};
	enum TreeWriteOption {				// Enumeration to control tree output
					InnerIndex	= 1,
					InnerName	= 2,			// InnerIndex has precedence
					InnerLength = 4,
					LeafLength	= 8,
					LeafIndex	= 16,			// Print as name_index
					RootNameLen	= 32
	};
									// Configuration format elements
	int			MaxValues;			// Max number of values for a key
	const char	*CREM;				// Comment indicators
	const char	*CBLANK;				// Whitespace characters
	const char	*CDELIM;				// Delimiter characters
	char			CQUOTE;				// Value quotation mark
									// Tree format elements
	char			EOT;					// End of tree
	char			LPAR;					// Begin children list
	char			RPAR;					// End children list
	char			COMMA;				// Children delimiter
	char			LENPR;				// Length prefix
	char			QUOTE;				// Name quotation mark
	char			UND;					// Blank substitute in names
	char			BCOM;					// Begin comment
	char			ECOM;					// End comment
	const char	*DLTOK;				// Tree token delimiters
	const char	*BLANK;				// Whitespace characters
	const char	*MUSTQ;				// Characters that require name to be quoted
									// Program options
	bool			Resume;				// If true, the program tries to continue interrupted work
	bool			ResumeGiven;		// True if Resume was given in the command line
	string		WorkingDirectory;	// Path to prepend to all filenames, empty by default
	string		ConfigFileName;	// Configuration file pathname
	bool			ConfigFileNameGiven;		// True if config file is provided
	int			SpecLabelParts;	// Fixed/max depending on StrictLabelControl
   string      StopLabel;        // Any character of the string terminates a label
	bool			StrictLabelControl;		// True if "SpecParts_Gene" label format is required.
	string		SpeciesTableName;	// Species table pathname
	bool			SpecTableGiven;	// True if list of species is somehow provided
	bool			SpecTableOverride;		// True to ignore table of species in the configuration
	bool			TreeListOverride;	// True to ignore tree(s) in the configuration
	int			TreeWriteMode;		// Composed of TreeWriteOption enum
	string		Super3Name;			// Sought-for species tree filename
	bool			Super3NameGiven;	// True if Super3Name was given somewhere
	bool			Super3Sequence;	// True = intermediate supertree output, False = final only
	bool			Super3Quality;		// True = output time/quality comment before the tree
	string		BasisName;			// Basis trees filename
	bool			BasisNameGiven;	// True if BasisName was given in the config or command line
	bool			MilestonesGiven;	// True if Milestones value was given in the command line
	int			Milestones;			// Intermediate output step
	#ifdef SUPER3MPI
	double		StartTime;			// Program start time
	#else
	clock_t		StartTime;			// Program start time
	#endif
	string		LogFileName;		// Filename for a copy of the program console log
	bool			LogFileNameGiven;	// True if log file name was given in the command line
	fstream		super3;				// File stream for species tree to write in/read from
	ofstream		clog;					// File stream to duplicate the console log
	bool			memlog;				// While true, logging is performed to mem
	bool			Polytomy;			// True if there is at least one polytomous node
	ostringstream	mem;				// Temporary log before log file is open
									// CSV table of species related data
	char			CSVdelimiter;		// Character used to delimit CSV fields
	int			SkipLines;			// Number of initial lines to skip
	int			SpecNum;				// Number of last species (starts from 1 to avoid zero code)
	int			MaxSpecies;			// Max number of species (to double if necessary)
	SpecMap		Species;				// <Code,number> map of species
	SData			*SpeciesData;		// Array of specied data (by the same number)
									// Gene tree(s) related data
	int			TreeNum;				// Current number of trees (zero based)
	int			MaxTrees;			// Max number of tree (to double if necessary)
	PTree			*GTree;				// Array of gene tree pointers (may include NULLs)
	int			TreePruned;			// Number of trees removed by pruning
									// Algorithm parameters
	bool			CLossGiven;			// True if CLoss was given in command line
	float			CLoss;				// Cost of gene loss
	bool			CDuplicationGiven;		// True if CDuplication was given in command line
	float			CDuplication;		// Cost of gene duplication
	bool			ThresholdGiven;
	int			Threshold;			// Min allowed number of species meetings to consider
	bool			TreePruningMode;	// If true, eliminate rare species and non-informative trees
	bool			ExtendPsetGiven;	// True, if ExtendPset was given in the command line
	bool			ExtendPset;			// If true, insert additional clade differences in P set
	#ifdef BTREEWEIGHT
	bool			BasisTreeWeight;	// If true, calculate and use the weigth of a basis tree
	bool			ScaleFactorGiven;	// True, if ScaleFactor was given in the command line
	float			ScaleFactor;		// To multiply (leaves/species)^2 ratio
	float			MinWeight;			// Minimum weight to consider a tree 
	#endif
	bool			UncertaintyGiven;	// True, if Uncertainty was given in the command line
	float			Uncertainty;		// Value to represent 0/0 uncertain reliability
	bool			ZeroValueGiven;	// True, if ZeroValue was given in the command line
	float			ZeroValue;		   // Value to represent zero reliability
	bool			EachStepReliabilityGiven;	// True, if EachStepReliability was given in the command line
	bool			EachStepReliability;	// If false, calculate reliability only for final tree
	bool			SpecArrayDimGiven;	// True, if SpecArrayDim was given in the command line
	int			SpecArrayDim;		// Dimension of the species array for topology data
   bool        ParalogyPenaltyGiven;   // True, if ParalogyPenalty was given in the command line
   float       ParalogyPenalty;        // Paralogy penalty factor (1 by default)
   bool        RShiftGiven;            // True, if RShift was given in the command line
   float       RShift;                 // Species reliability shift (1 by default)
   bool        SpeciesLength;    // True: Represent species insertion reliability as the edge length
									// Algorithm working data
	PSetMap		PSet;					// Set P of sets of species: map<myset, VData, PFunctor >
	PSetMapIter *PSetEntry;			// Array of PSet iterators pointing to 1st element of given set size
	Triple0Map	Triq0;				// Map: meeting/quality of triples with respect to the basis trees
	PTriple1Map	*Triq1;				// [SpecNum+1] array of ptr->map: meeting/quality of triples
	PTriple2Map	**Triq2;				// [SpecNum+1][SpecNum+1] array of ptr->map: meeting/quality of triples
	float			***Triq3;			// [SpecNum+1]^3 array of floats: meeting/quality of triples
	int			BestTripleA;		// 1st member of a triple, now separated
	int			BestTripleB;		// 2nd member of a triple, now separated
	int			BestTripleC;		// 3rd member of a triple, now separated
	Triple0MapIter BestTriple;		// First triple with the best quality in all basis trees
	Triple1MapIter BestTriple1;	// First "2-triple" with the best quality in all basis trees
	Triple2MapIter BestTriple2;	// First "1-triple" with the best quality in all basis trees
	PTree			STree;				// Sought-for species tree
	double		TotalQ;				// Current quality of the species tree
   bool        SkipAmbiguous;    // True: don't include species if R=0
									// MPI related data
	#ifdef SUPER3MPI
	bool			super3_mpi;			// True if the program operates in MPI environment
	int			size_mpi;			// Number of CPUs involved
	int			rank_mpi;			// "This" CPU number
	char			name_mpi[MPI_MAX_PROCESSOR_NAME];	// "This" CPU name
	enum			tag_mpi {		// MPI message tags:
		tagQIJ = 10,					// Result: quality[i][j]
		tagAbort							// Report exception message to the root
	};
	#endif

									// Logging options
	int			TreeLogMode;
	bool			LogActualTrees;
	bool			LogActualSpecies;
	bool			LogEntirePset;
	bool			LogBasisSets;
	bool			LogBasisTrees;
	bool			LogTopology3;
	bool			LogSuper3;
	bool			LogChoice3;
	#ifdef PROFILING
	#define MAXTIMER 10
	clock_t		timer[MAXTIMER];
	clock_t		start[MAXTIMER];
	#endif
};

extern Config *cfg;

string		ToLower(const string& s);
string		ToLower(const char *sz);
bool			ReadSpeciesTable(string filename);
int			AddSpecies(const string& code, const string& name="");
int			SpecCode2Number(const string& code);
string		SpecNumber2Code(int specnum);
bool			ParseCommandLine(int argc, char *argv[]);
bool			ReadConfig(void);
bool			AddGeneTreeFile(string filename);
bool			AddGeneTree(const string& tree);
void			MakeClades(PTree tree);
void			makeClade(PNode node);
void			AnalyzeTrees(void);
void			PruneTrees(void);
void			calcMeeting(PNode node);
void			BuildPSetOfSetOfSpecies(void);
void			FindGoodEdges(void);
bool			checkGood(PNode node);
bool			checkGoodPoly(PNode node);
void        countRV(PNode node);
void        clearNodeFlag(PNode node);
bool			IsContained(const myset& Where, int What);
bool			IsContained(const myset& Where, const myset& What);
int			Elapsed(void);
int			ElapsedMin(void);
void			CreatePSetCatalog(void);
void			IdentifyBasisSets(void);
void			BuildBasisTrees(void);
float			PartitionCost(PSetMapIter pit, const set<V1V2Pair>::iterator partvar);
void			FillTriple0Map(void);
void			FillTriple1Map(void);
void			FillTriple2Map(void);
void			FillTriple3Map(void);
int			InitSpeciesTree();
void			BuildSpeciesTree(int spin);
double		TreeQuality(PTree tree);
double		Tree0Quality(PTree tree, const string& newname);
double		Tree1Quality(PTree tree, const string& newname);
double		Tree2Quality(PTree tree, const string& newname);
double		Tree3Quality(PTree tree, const string& newname);
void			WriteBasisTrees();						// newick.cpp
void			ReadBasisTrees();							// newick.cpp
PTree			AddBasisTree(const string& tree);	// newick.cpp
int			EarlyCommandLine(int argc, char *argv[]);
int			CountRV1V2(const PSetMapIter& pit, const PSetMapIter& pit1, const PSetMapIter& pit2, PTree tree);
int			checkRnode(PNode node);
int			checkPolyRnode(PNode node);
void			CheckBool(const string& name, bool& param, const string& value);
void			ReliabilityCalc0(void);
void			ReliabilityCalc1(void);
void			ReliabilityCalc2(void);
void			ReliabilityCalc3(void);
void			PrintHelp(void);
void			PrintGPL3(void);
void			OpenLogFile(bool flag = true);
#ifdef SUPER3MPI
void			ParaFindGoodEdges(void);
void			ParaIdentifyBasisSets(void);
void			ParaBuildSpeciesTree(int spin);
void			ParaBuildBasisTrees(void);
void			CheckAbort(void);
#endif

#endif
