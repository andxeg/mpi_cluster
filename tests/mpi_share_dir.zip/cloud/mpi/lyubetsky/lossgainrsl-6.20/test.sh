#!/bin/bash
cd example
../bin/lossgainRSL config1.ini result1.txt
../bin/lossgainRSL config2.ini result2.txt
../bin/lossgainRSL config3.ini result3.txt
../bin/lossgainRSL config4.ini result4.txt
cmp result1.txt result1.ref
if [ $? -ne 0 ]
then
  echo "Test 1 failed."
else
  cmp result2.txt result2.ref
  if [ $? -ne 0 ]
  then
    echo "Test 2 failed."
  else
    cmp result3.txt result3.ref
    if [ $? -ne 0 ]
    then
      echo "Test 3 failed."
    else
      cmp result4.txt result4.ref
      if [ $? -ne 0 ]
      then
        echo "Test 4 failed."
      else
        echo " "
        echo "Example completed OK."
      fi  
    fi  
  fi  
fi
echo " "
cd ..
