#!/bin/bash
cd example
mpirun -np 5 -hosts slave1,master ../bin/lossgainRSL config4.ini result.txt
echo " "
cd ..
