// synteny : main file
#define  SYNTENY_MAIN
#include "synteny.h"

using namespace std;

int main(int argc, char** argv) {
    double start, finish;

#ifdef SYNTENY_MPI
    try {
        MPI_Init(&argc, &argv);
        MPI_Comm_size(MPI_COMM_WORLD, &global.size);
        MPI_Comm_rank(MPI_COMM_WORLD, &global.rank);
        int flag;
        MPI_Initialized(&flag);
        if (!flag)
            throw 1;
        else if (global.size < 2) {
            MPI_Finalize();
            throw 2;
        }

        // Print hello message
        char processor_name[MPI_MAX_PROCESSOR_NAME];
        int name_len;
        MPI_Get_processor_name(processor_name, &name_len);
        printf("Hello from processor %s, rank %d out of %d processors\n",
               processor_name, global.rank, global.size);
    }
    catch (...) {
        global.size = 1;
        global.rank = 0;
    }
    MPI_File fh;   // use instead of out at global.size>1
#endif  // defined SYNTENY_MPI

    if (argc > 1 && (argv[1][0] == '?' || 
        (argv[1][0] == '-' || argv[1][0] == '/') &&
        (argv[1][1] == 'H' || argv[1][1] == 'h' || argv[1][1] == '?'))) {
        string pgm(argv[0]);
        try {
            string::size_type pos = pgm.find_last_of(".");
            pgm.erase(pos);
            pos = pgm.find_last_of("\\/");
            if (pos != string::npos)
                pgm.erase(0, pos+1);
        }
        catch(...) { }
        if (global.rank == 0) {
            cerr << "\nUsage (v " << version;
            if (global.size > 1) cerr << " MPI*" << global.size;
            cerr << "): " << pgm << " [-X|--X] [-Q|-QQ] [-G" << outgenestep 
                << "] [-N] [%param=value] [config] [outfile]\n" << endl;
        }
        exit(0);
    }

    start = getTimer();
    int nopt;
    for (nopt = 1; nopt < argc; nopt++) {
        char c = argv[nopt][0];
        if (c != '-' && c != '/' && c != '%') 
            break;
        if (c != '%') 
            c = argv[nopt][1];
        string str(argv[nopt]+2);
        istringstream iss(str);
        int cgsi = -1;
        double ddf;
        char postfix;
        string par(argv[nopt]);
        string::size_type eq = par.find_first_of('=');
        istringstream isp(par.substr(eq+1));
        switch (c) {
            case 'X': case 'x':
                global.mode_extract = true;
                global.cmd_extract = true;
                global.log_separate = false;
                global.log_tail = false;
                break;
            //case 'R': case 'r':
            //    postfix = 0;
            //    iss >> ddf >> postfix;
            //    if (postfix == 'K' || postfix == 'k')
            //        currentdefrange = (int)(ddf * 1000.0);
            //    else if (postfix == 'M' || postfix == 'm')
            //        currentdefrange = (int)(ddf * 1000000.0);
            //    else 
            //        currentdefrange = (int)ddf;
            //    global.terms.front().range = currentdefrange;
            //    break;
            case 'Q': case 'q':
                global.quiet = true;
                if (str[0] == 'Q' || str[0] == 'q')
                    global.qquiet = true;
                break;
            case 'G': case 'g':
                iss >> cgsi;
                if (cgsi >= 0) global.currentgenestep = cgsi;
                break;
            case 'N': case 'n':
                global.size = 1;
                global.rank = 0;
                break;
            case '-':
                c = argv[nopt][2];
                switch (c) {
                    case 'X': case 'x':
                        global.mode_extract = false;
                        global.cmd_extract = true;
                        global.log_separate = true;
                        global.log_tail = true;
                        break;
                    default:
                        if (global.rank == 0)
                            cerr << "Invalid command line option: --" << c << endl;
                        exit(1);
                }
                break;
            case '%':
                if (eq == string::npos) {
                    cerr << "Invalid command line parameter: " << par << endl;
                    exit(1);
                }
                postfix = 0;
                isp >> ddf >> postfix;
                if (postfix == 'K' || postfix == 'k')       ddf *= 1000.0;
                else if (postfix == 'M' || postfix == 'm')  ddf *= 1000000.0;
                global.parameter.insert(pair<string,double>(par.substr(0,eq), ddf));
                break;
            default:
                if (global.rank == 0)
                    cerr << "Invalid command line option: -" << c << endl;
                exit(1);
        }
    }
    const char *confile = argc > nopt ? argv[nopt] : def_config.c_str(); 
    const char *outfile = argc > ++nopt ? argv[nopt] : defaultout.c_str(); 

    if (!ReadConfig(confile)) {
        if (global.rank == 0)
            cerr << "Config file error." << endl;
        exit(2);
    }
    
    if (global.size == 1) {
        global.out.open(outfile);
        if(!global.out || global.out.bad()) {
            if (global.rank == 0)
                cerr << "Can't open " << outfile << endl;
            exit(3);
        }
    }
#ifdef SYNTENY_MPI
    else {
        string myfile(outfile);
        myfile.append(1, '\0');
        int TRUE = 1;
        int amode = MPI_MODE_WRONLY | MPI_MODE_CREATE | MPI_MODE_SEQUENTIAL;
        MPI_File_delete(&myfile[0], MPI_INFO_NULL);
        MPI_File_open(MPI_COMM_WORLD, &myfile[0], amode, MPI_INFO_NULL, &fh);
        MPI_File_set_atomicity(fh, TRUE);
    }
#endif  // defined SYNTENY_MPI

    if (global.rank == 0) {
        cout << "\nSynteny analysis utility (version " << version << ")\n\n" 
            << "Taxa: " << global.taxa.size() << "  Species: " 
            << global.nAnimals << "  Mode: " << global.progmode;
        if (global.size > 1) cout << "  MPI: " << global.size;
        cout << endl;

        if (!global.taxa.empty() && !global.quiet) {
            vector <Taxon>::iterator tit = global.taxa.begin();
            for ( ; tit != global.taxa.end(); tit++) {
                Taxon &t = *tit;
                cout << t.name << "[" << t.nspec << "]:";
                for (int i=0; i<t.nspec; i++)
                    cout << " " << global.Animals[t.specno[i]].name;
                cout << endl;
            }
        }

        if (!global.quiet) {
            cout << "\nThe predicate (scenario) consists of " 
                << global.terms.size() << " terms:" << endl;
            for (int n = 0; n < (int)global.terms.size(); n++) {
                Term & t = global.terms[n];
                cout << setw(3) << n << "  " << TermOper[t.oper] << " \t";
                if (t.sp == unknown_species)
                    cout << setw(16) << " ";
                else if (t.sp >= 0 && t.sp < global.nAnimals)
                    cout << left << setw(16) << global.Animals[t.sp].name;
                else if (t.sp < 0 && t.sp > -(int)global.taxa.size())
                    cout << left << setw(16) << global.taxa[-t.sp].name;
                else 
                    cout << left << setw(16) << "????????";

                if (t.yes == YES)
                    cout << right << setw(4) << label_yes;
                else if (t.yes == NO)
                    cout << right << setw(4) << label_no;
                else 
                    cout << right << setw(4) << t.yes;

                if (t.no == t.yes)
                    cout << setw(4) << " ";
                else if (t.no == YES)
                    cout << right << setw(4) << label_yes;
                else if (t.no == NO)
                    cout << right << setw(4) << label_no;
                else
                    cout << right << setw(4) << t.no;

                if (t.oper==SET || t.oper==IN || t.oper==IN2 || t.oper==OVER) {
                    cout << "  " << right << setw(2) << t.nwit << " " << t.range
                        << setw(3) << t.BBH << setw(3) << t.uselast0 << setw(3) 
                        << t.uselast1 << scientific << setprecision(1) << setw(9) 
                        << t.E;
                }
                else if (t.oper==EOR || t.oper==EAND) {
                    cout << "  " << right << setw(2) << t.nwit;
                }
                else if (t.oper==ADD) {
                    cout << "   Fields:";
                    bool first = true;
                    for (int fo = 1; fo <= maxfield; fo++) {
                        int my = 0;
                        for ( ; my < maxfield; my++)
                            if (t.forder[my] == fo) {
                                cout << (first? ' ': ',') << global.myfields[my];
                                first = false;
                                break;
                            }
                        if (my >= maxfield) break;
                    }
                }
                if (!global.quiet) cout << endl;
            }
        }
    }

    // Calculate max set of terms per line
    vector <int> curtpl(1,0);   // num of ADDs after last branch
    vector <int> curnos;   
    stack <int> track;          // remaining opno at branches
    int tn = 1;         // because 0th term contains default parameters
    for (int loopno = 0; loopno < maxloop; loopno++) {
        if (tn == NO || tn == YES || tn >= (int)global.terms.size()) {
            // Store current longest set of terms
            if (tn != NO && (int)curnos.size() > global.maxtpl) {
                global.maxtpl = (int)curnos.size();
                global.termnos.clear(); 
                vector<int>::iterator tit = curnos.begin();
                for (; tit != curnos.end(); tit++) 
                    global.termnos.push_back(*tit);
            }
            // Revert last branch
            for (int i=0; i<curtpl.back(); i++)
                curnos.pop_back();
            curtpl.back() = 0;
            if (track.empty()) break;
            tn = track.top();
            if (tn != 0)
                track.top() = 0;
            else {
                track.pop();
                curtpl.pop_back();
            }
        }
        else {
            Term & t = global.terms[tn];
            if (t.oper == ADD) {
                curtpl.back() ++;
                curnos.push_back(tn);
            }
            int next;
            if (t.no != t.yes) {
                curtpl.push_back(0);
                track.push(t.no);
                next = t.yes;
            }
            else if (t.oper == NEXT) {
                //next = global.terms[next].no;
                //while (track.top() != next) {
                //    track.pop();
                //}
                //track.top() = 0;
                next = tn + 1;
            }
            else next = t.yes;
            tn = next;
        }

        // Preprocess next term number
        while (tn == 0) {      
            for (int i=0; i<curtpl.back(); i++)
                curnos.pop_back();
            curtpl.pop_back();
            if (track.empty()) break;
            track.pop();
            if (track.empty()) break;
            tn = track.top();
        }
        if (tn == 0 && track.empty()) break;
    }

    int maxtpl = global.maxtpl;
    if (global.mode_extract) {
        for (int i=1; i<global.maxtpl; i++)     // exclude repeats of base species
            if (global.terms[global.termnos[i]].sp == 0)
                maxtpl--;
    }

    if (global.rank == 0 && !global.quiet) {
        cout << "\nMaximum " << maxtpl << " gene(s) per line:";
        for (int i=0; i<global.maxtpl; i++) {
            Term & t = global.terms[global.termnos[i]];
            if (t.sp == 0) {
                if (i > 0 && global.mode_extract) continue;
                cout << " " << global.Animals[t.sp].name;
            }
            else if (t.sp > 0)
                cout << " " << global.Animals[t.sp].name;
            else
                cout << " " << global.taxa[-t.sp].name;
        }
        cout << "\n" << endl;
    }

    // Select relevant data per species
    global.Animals[0].need = true;      // base species always
    global.Animals[0].needmatrix = true;
    int paraflag = ORTX | ORTY | ORTZ;
    vector <Term>::iterator tit = global.terms.begin();
    for (++tit; tit != global.terms.end(); tit++) {
        Term & t = *tit;
        if (t.oper == OVER) {
            if (t.sp >= 0) {
                global.Animals[t.sp].need = true;
                global.Animals[t.sp].needmatrix = true;
                if (global.mode_homology && global.mode_info && (t.BBH&paraflag) != paraflag)
                    global.Animals[t.sp].needself = true;
            }
            else {
                Taxon & taxon = global.taxa[-t.sp];
                for (int i = 0; i < taxon.nspec; i++) {
                    int spno = taxon.specno[i];
                    global.Animals[spno].need = true;
                    global.Animals[spno].needmatrix = true;
                    if (global.mode_homology && global.mode_info && (t.BBH&paraflag) != paraflag)
                        global.Animals[spno].needself = true;
                }
            }
        }
        else if (t.oper == IN || t.oper == IN2) {
            if (t.sp >= 0) {
                global.Animals[t.sp].need = true;
                if (global.mode_homology && global.mode_info) {
                }   // hold default false value of needmatrix
                else if (t.BBH & (BBHX | BBHY | BBHZ | IBHX | IBHY | IBHZ))
                    global.Animals[t.sp].needmatrix = true;
                if (global.mode_homology && global.mode_info && (t.BBH&paraflag) != paraflag)
                    global.Animals[t.sp].needself = true;
            }
            else {
                Taxon & taxon = global.taxa[-t.sp];
                for (int i = 0; i < taxon.nspec; i++) {
                    int spno = taxon.specno[i];
                    global.Animals[spno].need = true;
                    if (global.mode_homology && global.mode_info) {
                    }   // hold default false value of needmatrix
                    else if (t.BBH & (BBHX | BBHY | BBHZ | IBHX | IBHY | IBHZ))
                        global.Animals[spno].needmatrix = true;
                    if (global.mode_homology && global.mode_info && (t.BBH&paraflag) != paraflag)
                        global.Animals[spno].needself = true;
                }
            }
        }
    }
    // detect & print unneeded species
    int nextra = 0;      // number of unneeded spp
    ostringstream oex;
    for (int i = 0; i < (int)global.nAnimals; i++) {     // over species
        Species & spec = global.Animals[i];
        if (!spec.need) {
            nextra++;
            oex << " " << spec.name;
        }
    }
    if (nextra > 0 && global.rank == 0 && !global.quiet) {
        cout << nextra << " unneeded species removed:" << oex.str() << endl;
    }

    //return 0;       // stop before reading data

    // Read source data
    if (global.mode_info) {             // Read all genes information
        for (int i = 0; i < global.nAnimals; i++) {
            Species & spec = global.Animals[i];
            if (spec.need) {
                string filename = global.info_path + spec.name + global.info_ext;
                if (global.rank == 0 && !global.qquiet)
                    cout << "Reading gene info file " << filename << " ..." << endl;

                if (!ReadGeneInfo(i)) {
                    if (global.rank == 0)
                        cerr << "Gene info file error: " << filename << endl;
                    exit(2);
                }
            }
        }
    }

    // Set log/debug flags of gene/protein/contig(s)
    if (global.size > 1) {              // Eliminate logging in parallel mode
        global.log_verbose  = false;
        global.log_gene     = false;
        global.log_protein  = false;
        global.log_contig   = false;
        global.log_span1    = false;
        global.log_span2    = false;
        global.log_synteny  = false;
        global.log_contigno = -1;
        global.log_geneno   = -1;
    }
    else if (global.log_gene || global.log_protein || global.log_contig || global.log_contigno>=0) {
        vector <string>::iterator idit = global.logID.begin();
        for ( ; idit != global.logID.end(); idit++) {
            string & ID = *idit;
            if (global.log_contigno >= 0) { 
                istringstream iss(ID);
                int c_no = -1;
                int x_no = -1;
                char c;
                iss >> c_no >> c >> x_no;
                Citer cit = global.Animals[0].contigs.begin();   
                // skip num contigs
                for (int i=0; i<c_no && cit!=global.Animals[0].contigs.end(); i++,cit++) ;
                if (cit!=global.Animals[0].contigs.end()) {
                    global.log_contigno = c_no;
                    global.log_geneno = x_no;
                    cit->second.log = true;             // set flag in (num)-th contig
                    cerr << "Logging contig #" << c_no;
                    if (x_no >= 0) cerr << " gene #" << x_no;
                    cerr << endl;
                    Giter git = cit->second.genes.begin();
                    for (int j = 0; git != cit->second.genes.end(); j++,git++) {
                        if (x_no == j || x_no < 0) {
                            git->second.log = true;
                            cerr << "Logging gene " << git->first << endl;
                        }
                    }
                }
            }
            if (global.log_contig) {
                Citer cit = global.Animals[0].contigs.find(ID);
                if (cit != global.Animals[0].contigs.end()) {
                    cit->second.log = true;
                    cerr << "Logging contig " << cit->second.name << endl;
                    Giter git = cit->second.genes.begin();
                    for ( ; git != cit->second.genes.end(); git++) {
                        git->second.log = true;
                        cerr << "Logging gene " << git->first << endl;
                    }
                }
            }
            if (global.log_gene || global.log_protein) {
                Piter pit = global.stableid.find(ID);
                if (pit != global.stableid.end()) {
                    pit->second->log = true;
                    cerr << "Logging protein/gene " << ID;
                    if (pit->second->name != ID)
                        cerr << "/" << pit->second->name;
                    cerr << endl;
                }
                else cerr << "Cannot find protein/gene " << ID << endl;
            }
        }
    }

    if (global.mode_cluster) {          // Read cluster file
        vector <string>::const_iterator cfit = global.cluster_files.begin();
        for ( ; cfit != global.cluster_files.end(); cfit++) {
            string filename(*cfit);
            if (global.rank == 0 && !global.qquiet)
                cout << "\nReading clusters from " << filename << " ..." << endl;

            if (!ReadClusterData(filename.c_str())) {
                if (global.rank == 0)
                    cerr << "Data file error: " << filename << endl;
                exit(2);
            }
        }
    }
    else if (global.mode_ogroup) {     // Read orthogroup file
        vector <string>::const_iterator cfit = global.cluster_files.begin();
        for ( ; cfit != global.cluster_files.end(); cfit++) {
            string filename(*cfit);
            if (global.rank == 0 && !global.qquiet)
                cout << "\nReading orthogroups from " << filename << " ..." << endl;

            if (!ReadOgroupData(filename.c_str())) {
                if (global.rank == 0)
                    cerr << "Data file error: " << filename << endl;
                exit(2);
            }
        }
    }
    else if (global.mode_matrix) {      // Read relevant matrix file(s)
        for (int i = 0; i < global.nAnimals; i++) {
            Species & spec = global.Animals[i];
            if (spec.need && spec.needmatrix) {
                string filename = global.matrix_path + spec.name + global.matrix_ext;
                if (global.rank == 0 && !global.qquiet)
                    cout << "Reading gene likeness matrix " << filename << " ..." << setw(9) << " "; 

                if (!ReadMatrix(i)) {
                    if (global.rank == 0)
                        cerr << "Error in matrix file: " << filename << endl;
                    exit(2);
                }
                if (global.rank == 0 && !global.qquiet)
                    cout << endl;
            }
        }
    }
    else if (global.mode_homology && !global.mode_info) {   // Read long homology files (obsolete)
        for (int i = 0; i < global.nAnimals; i++) {
            Species & spec1 = global.Animals[i];
            if (!spec1.need || !spec1.needmatrix) continue;
            for (int j = 0; j < global.nAnimals; j++) {
                Species & spec2 = global.Animals[j];
                if (j==i || !spec2.need) continue;
                string filename = spec1.name + pairsep + spec2.name;
                if (global.rank == 0 && !global.qquiet)
                    cout << "Reading " << filename << " ..." << endl;

                if (!ReadData(i, j)) {
                    if (global.rank == 0)
                        cerr << "Data file error: " << filename << endl;
                    exit(2);
                }
            }
        }
    }
    else if (global.mode_homology) {        // Read short homology files
        for (int i = 0; i < global.nAnimals; i++) {
            Species & spec = global.Animals[i];
            if (!spec.need) continue;
            if (spec.needmatrix) {
                string filename = global.homology_path + spec.name + global.homology_ext;
                if (global.rank == 0 && !global.qquiet) {
                    string ht = global.mode_single ? "homologs" : "orthologs";
                    cout << "Reading " << ht << " from " << filename << " ..." << setw(9) << " "; 
                }

                if (!ReadShortData(i)) {
                    if (global.rank == 0)
                        cerr << "Data file error: " << filename << endl;
                    exit(2);
                }
                if (global.rank == 0 && !global.qquiet)
                    cout << endl;
            }
            if (spec.needself && (i > 0 || !global.mode_single) ||
                spec.neednumpar && (i > 0 || !global.mode_single)) {
                string filename = global.paralogs_path + spec.name + global.paralogs_ext;
                if (global.rank == 0 && !global.qquiet)
                    cout << "Reading paralogs from " << filename << " ..." << setw(9) << " "; 

                if (!ReadShortData(i, true)) {      // 
                    if (global.rank == 0)
                        cerr << "Data file error: " << filename << endl;
                    exit(2);
                }
                if (global.rank == 0 && !global.qquiet) cout << endl;
            }
        }
    }

    // Fill virtual # fields as needed
    for (int i = 0; i < global.nAnimals; i++) {
        Species & spec = global.Animals[i];
        if (!spec.need || !spec.neednumpar) continue;
        int j = spec.myfields[global.fnumpara];    // field no. for count
        Citer cit = spec.contigs.begin();
        for ( ; cit != spec.contigs.end(); cit++) {
            Contig& contig = cit->second;
            Giter git = contig.genes.begin();
            for ( ; git != contig.genes.end(); git++) {
                Gene& gene = git->second;
                int count = (int)gene.homologs[i].size();
                if (count > 0) {
                    ostringstream oss;
                    oss << count;
                    gene.fields[j] = oss.str();
                }
            }
        }
    }

    // Print heading
    if (global.rank == 0) {
        string o;
        bool first = true;
        vector <int>::const_iterator nit = global.termnos.begin();
        if (global.heading.empty()) {
            for ( ; nit != global.termnos.end(); nit++) {
                Term & t = global.terms[*nit];
                int sp = (t.sp>=0 ? t.sp : global.taxa[-t.sp].specno[0]);
                if (sp==0 && global.mode_extract && nit!=global.termnos.begin())
                    continue;   // not repeat 0th spec in autohead X mode
                Species& spec = global.Animals[sp];

                for (int fo = 1; fo <= maxfield; fo++) {
                    int my = 0;
                    for ( ; my < maxfield; my++) {
                        if (t.forder[my] == fo) {
                            if (!first) o += '\t';
                            o += spec.fields[spec.myfields[my]];
                            first = false;
                        }
                    }
                }
            /*
                vector <string>::const_iterator fit = spec.fields.begin();
                vector <int>::const_iterator rit = spec.required.begin();
                for ( ; fit != spec.fields.end(); fit++,rit++) {
                    if (*rit < 0) continue;
                    unsigned int mask = 1 << *rit;
                    if (t.fmask & mask) {
                        if (!first) o += '\t';
                        o += *fit;
                        first = false;
                    }
                }
            */
            }
        }
        else o = global.heading;

        if (global.log_tail) o += "\tID\t#";
        if (global.size > 1) o += "\trank";
        o += '\n';

        if (global.size < 2) {
            global.out << o;
            global.out.flush();
        }
        #ifdef SYNTENY_MPI
        else {
            MPI_Status status;
            MPI_File_write_shared(fh, &o[0], (int)o.size(), MPI_CHAR, &status);
        }
        #endif  // defined SYNTENY_MPI
    }   // global.rank == 0
#ifdef SYNTENY_MPI
    if (global.size > 1) {   // Wait for heading written
        MPI_Barrier(MPI_COMM_WORLD);
    }
#endif

    Species & species1 = global.Animals[0];
    Citer cit1, cit2;
    Giter git1;
    int total = 0;
    int contig_m = 0;
    int total_m = 0;

    for (cit1 = species1.contigs.begin(); cit1 != species1.contigs.end(); cit1++) {
        if (cit1->second.genes.size() > 1) {
            contig_m ++;
            total_m += (int)cit1->second.genes.size();
        }
        total += (int)cit1->second.genes.size();
    }
    if (global.rank == 0) {
        cout << "\n" << species1.name << " in total: " << species1.contigs.size() 
            << " contigs, " << total << " genes." << endl;
        cout << "With several genes: " << contig_m << " contigs, " << total_m 
            << " genes." << endl; 
    }

    int gene_no = 0;    // current serial number of the species1 gene
    int good_no = 0;    // current number of good species1 genes
    bool logging = global.log_verbose || global.log_gene || global.log_protein ||
        global.log_contig || global.log_contigno >= 0;
    if (global.size > 1) {
        logging = 0;
        //global.currentgenestep = 0;
    }

    // *****   Main loop over all genes of the reference species #0.
    global.c_no = 0;        // current number of species1 contig
    int branch = 0;
    cit1 = species1.contigs.begin();
#ifdef SYNTENY_MPI
    ostringstream ossr;
    ossr << '\t' << global.rank;
    string rankstr = ossr.str();
    vector <Citer> vcits;
    for ( ; cit1 != species1.contigs.end(); cit1++) 
        vcits.push_back(cit1);
    if (global.size > 1)    // balancing
        sort(vcits.begin(), vcits.end(), GreaterGenes);
    vector <Citer>::iterator vcit = vcits.begin();
    for ( ; vcit != vcits.end(); vcit++, global.c_no++) {
        cit1 = *vcit;
#else
    for ( ; cit1 != species1.contigs.end(); cit1++, global.c_no++) {
#endif      // ifdef SYNTENY_MPI

        // Skip contigs without genes
        if (cit1->second.genes.size() < 1) continue;

        // Select gene X
        Giter xit = cit1->second.genes.begin();
        global.x_no = 0;       // current number of a gene in the current contig
        for ( ; xit != cit1->second.genes.end(); xit++, global.x_no++, branch++) {
        #ifdef SYNTENY_MPI
            if (global.size > 1 && branch % global.size != global.rank)
                continue;
        #endif
            Gene & x = xit->second;
            vector <Group> groups;

            // Milestones 
            if (global.rank == 0 && global.currentgenestep && global.x_no % global.currentgenestep == 0) {
                ostringstream oss;
                oss << left << "c" << setw(5) << global.c_no << "x" 
                    << setw(6) << global.x_no /*<< setw(30)*/ << " \t\t\r";
                //cout << oss.str();
                if (logging)    cout << oss.str();
                else            cerr << oss.str();
            }

            // Check predicate & print good genes
            if (Predicate(x, groups)) {
                good_no ++;

                // Output good group sequence data
                if (global.mode_extract) {          // Print only gene X data
                    string o;
                    bool first = true;
                    vector <Group>::iterator git = groups.begin();
                    for (int k = 0; k < global.maxtpl; k++) {
                        Term & t = global.terms[global.termnos[k]];
                        if (git != groups.end()) {
                            PGene pg = git->pgene[0];
                            if (pg == 0) {
                                for (int fno = 0; fno < maxfield; fno++) {
                                    if (t.forder[fno] != 0) {
                                        if (!first) o += '\t';
                                        first = false;
                                    }
                                }
                                /*
                                int sp = (t.sp>=0 ? t.sp : global.taxa[-t.sp].specno[0]);
                                unsigned int mask = 1;
                                for (int j = 0; j < (int)global.Animals[sp].fields.size(); j++,mask<<=1)
                                    if (t.fmask & mask) {
                                        if (!first) o += '\t';
                                        first = false;
                                    }
                                */
                            }
                            else {
                                Species & spec = global.Animals[pg->sp];
                                for (int fo = 1; fo < maxfield; fo++) {
                                    int my = 0;
                                    for ( ; my < maxfield; my++) {
                                        if (t.forder[my] == fo) {
                                            if (!first) o += '\t';
                                            o += pg->fields[spec.myfields[my]];
                                            first = false;
                                        }
                                    }
                                }
                                /*
                                vector <string>::const_iterator fit = pg->fields.begin();
                                vector <int>::const_iterator rit = spec.required.begin();
                                for ( ; fit != pg->fields.end(); fit++,rit++) {
                                    if (*rit < 0) continue;
                                    unsigned int mask = 1 << *rit;
                                    if (t.fmask & mask) {
                                        if (!first) o += '\t';
                                        o += *fit;
                                        first = false;
                                    }
                                }
                                */
                            }
                            git++;
                        }
                        else {
                            for (int fno = 0; fno < maxfield; fno++) {
                                if (t.forder[fno] != 0) {
                                    if (!first) o += '\t';
                                    first = false;
                                }
                            }
                            /*
                            int sp = (t.sp>=0 ? t.sp : global.taxa[-t.sp].specno[0]);
                            unsigned int mask = 1;
                            for (int j = 0; j < (int)global.Animals[sp].fields.size(); j++,mask<<=1)
                                if (t.fmask & mask) {
                                    if (!first) o += '\t';
                                    first = false;
                                }
                            */
                        }
                    }
                    
                    #ifdef SYNTENY_MPI
                    if (global.size > 1) o += rankstr;
                    #endif  // ifdef SYNTENY_MPI
                    o += '\n';
                    if (global.size < 2) {
                        global.out << o;
                        global.out.flush();
                    }
                    #ifdef SYNTENY_MPI
                    else {
                        MPI_Status status;
                        MPI_File_write_shared(fh, &o[0], (int)o.size(), MPI_CHAR, &status);
                    }
                    #endif  // ifdef SYNTENY_MPI
                }
                else {                              // Print entire group data
                    int gsize = 0;
                    vector <Group>::iterator git = groups.begin();
                    for (; git != groups.end(); git++)
                        if ((*git).gsize > gsize)
                            gsize = (*git).gsize;

                    vector <string> o(gsize);       // data lines
                    string sepline;                 // separator line
                    vector <bool> first(gsize+1, true);

                    git = groups.begin();
                    for (int k = 0; k < global.maxtpl; k++) {
                        Term & t = global.terms[global.termnos[k]];
                        if (git != groups.end()) {
                            for (int gno = 0; gno < gsize; gno++) {
                                PGene pg = git->pgene[gno];
                                if (pg == 0) {
                                    for (int fno = 0; fno < maxfield; fno++) {
                                        if (t.forder[fno] != 0) {
                                            if (!first[gno]) o[gno] += '\t';
                                            first[gno] = false;
                                            if (gno == 0) {
                                                if (!first[gsize]) sepline += '\t';
                                                first[gsize] = false;
                                            }
                                        }
                                    }
                                    /*
                                    int sp = (t.sp>=0 ? t.sp : global.taxa[-t.sp].specno[0]);
                                    unsigned int mask = 1;
                                    for (int j = 0; j < (int)global.Animals[sp].fields.size(); j++,mask<<=1)
                                        if (t.fmask & mask) { 
                                            if (!first[gno]) o[gno] += '\t';
                                            first[gno] = false;
                                            if (gno == 0) {
                                                if (!first[gsize]) sepline += '\t';
                                                first[gsize] = false;
                                            }
                                        }
                                    */
                                }
                                else {
                                    Species & spec = global.Animals[pg->sp];
                                    for (int fo = 1; fo < maxfield; fo++) {
                                        int my = 0;
                                        for ( ; my < maxfield; my++) {
                                            if (t.forder[my] == fo) {
                                                if (!first[gno]) o[gno] += '\t';
                                                o[gno] += pg->fields[spec.myfields[my]];
                                                first[gno] = false;
                                                if (gno == 0) {
                                                    if (!first[gsize]) sepline += '\t'; 
                                                    first[gsize] = false;
                                                }
                                            }
                                        }
                                    }
                                    /*
                                    vector <string>::const_iterator fit = pg->fields.begin();
                                    vector <int>::const_iterator rit = spec.required.begin();
                                    for ( ; fit != pg->fields.end(); fit++,rit++) {
                                        if (*rit < 0) continue;
                                        unsigned int mask = 1 << *rit;
                                        if (t.fmask & mask) { 
                                            if (!first[gno]) o[gno] += '\t'; 
                                            o[gno] += *fit; 
                                            first[gno] = false;
                                            if (gno == 0) {
                                                if (!first[gsize]) sepline += '\t'; 
                                                first[gsize] = false;
                                            }
                                        }
                                    }
                                    */
                                }
                            }
                            git++;
                        }
                        else {
                            for (int fno = 0; fno < maxfield; fno++) {
                                if (t.forder[fno] != 0) {
                                    for (int gno = 0; gno < gsize; gno++) {
                                        if (!first[gno]) o[gno] += '\t';
                                        first[gno] = false;
                                    }
                                    if (!first[gsize]) sepline += '\t';
                                    first[gsize] = false;
                                }
                            }
                            /*
                            int sp = (t.sp>=0 ? t.sp : global.taxa[-t.sp].specno[0]);
                            unsigned int mask = 1;
                            for (int j = 0; j < (int)global.Animals[sp].fields.size(); j++,mask<<=1)
                                for (int gno = 0; gno < gsize; gno++)
                                    if (t.fmask & mask) { 
                                        if (!first[gno]) o[gno] += '\t'; 
                                        first[gno] = false;
                                        if (gno == 0) {
                                            if (!first[gsize]) sepline += '\t'; 
                                            first[gsize] = false;
                                        }
                                    }
                            */
                        }
                    }

                    ostringstream oo;
                    for (int gno = 0; gno < gsize; gno++) {
                        oo << o[gno];
                        if (global.log_tail)
                            oo << '\t' << x.name << '\t' << gno;
                        if (global.size < 2)
                            oo << '\n';
                        #ifdef SYNTENY_MPI
                        else
                            oo << rankstr << '\n';
                        #endif  // ifdef SYNTENY_MPI
                    }
                    if (global.log_separate) {
                        if (global.log_tail)
                            oo << sepline << '\t' << x.name << '\t' << gsize;
                        if (global.size < 2)
                            oo << '\n';
                        #ifdef SYNTENY_MPI
                        else
                            oo << rankstr << '\n';
                        #endif  // ifdef SYNTENY_MPI
                    }

                    if (global.size < 2) {
                        global.out << oo.str();
                        global.out.flush();
                    }
                    #ifdef SYNTENY_MPI
                    else {
                        string oos = oo.str();
                        MPI_Status status;
                        MPI_File_write_shared(fh, &oos[0], (int)oos.size(), MPI_CHAR, &status);
                    }
                    #endif  // ifdef SYNTENY_MPI
                }
            }     // if Predicate()
        }     // next X
    }     // next contig

#ifdef SYNTENY_MPI
    if (global.size > 1) {
        int sendbuf = good_no;
        MPI_Reduce(&sendbuf, &good_no, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
        MPI_File_close(&fh);
    }
#endif

    finish = getTimer();

    if (global.rank == 0) {
        cout << "                                  \n" << global.Animals[0].name 
            << " candidate genes selected: " << good_no << endl;

        double elapsed = (int)(finish - start);
        if (elapsed > 300) {
            int minutes = (int)(elapsed / 60.0);
            cout << "\n" << minutes << "m";
        }
        else {
            int seconds = (int)elapsed;
            cout << "\n" << seconds << "s";
        }
        cout << ": Completed OK." << endl;
    }

#ifdef SYNTENY_MPI
    if (global.size > 1)
        MPI_Finalize();
#endif
}
