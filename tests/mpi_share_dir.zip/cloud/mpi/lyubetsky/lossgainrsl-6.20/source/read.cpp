// synteny : data read functions
#include "synteny.h"

using namespace std;

typedef map <string, int> StrInt;
typedef pair <string, int> StrIntPair;

void    ParseExtension (const string& str, string& path, string &ext) {
    string::size_type pos = str.find_last_of('*');
    if (pos == string::npos) {
        path.clear();
        ext = str;
    }
    else {
        ext = str.substr(++pos);
        pos = str.find_first_of('*');
        path = str.substr(0, pos);
    }
}

bool    IsComment (const char* c) {
    while (*c != 0 && *c == ' ')
        c++;
    return (*c != 0 && (*c == ';' || *c == '/' && *(c+1) == '/'));
}

bool    IsComment (string & s) {
    string::size_type pos = s.find_first_not_of(' ');
    return (pos != string::npos && (s[pos]==';' || s.substr(pos,2)=="//"));
}

// Return current token of the string str starting from offset.
// Modify the offset so that it points to the next token.
// Skip multiple tabs unless strict=true
// In non-strict mode, provide for a comment instead of the next token.
string  GetToken (const string & str, string::size_type & offset, bool strict = false) {
    static string token;
    string::size_type pos, pos2;
    while (true) {
        pos = str.find_first_of('\t', offset);
        if (pos == string::npos) {          // no more tabs
            if (offset < str.size()) {
                pos2 = str.find_first_not_of(' ', offset);
                if (pos2 != string::npos)
                    token = str.substr(pos2);
                else
                    token.clear();
            }
            else
                token.clear();
            offset = str.size();
            break;
        }
        else {                              // found tab at pos position
            pos2 = str.find_first_not_of(' ', offset);

            if (strict && pos2 == pos) {        // empty or blank token
                offset = pos+1;
                token.clear();
                return token;
            }
            else if (pos2 < pos) {              // nonempty token
                offset = pos2;
                token = str.substr(offset, pos-offset);
                offset = pos+1;
                break;
            }
            else offset = pos+1;                // skip repeating tabs
        }
    }
    if (!strict && token.length()>1 && token.substr(0,2)=="//") 
        token.clear();      // ignore comments
    return token;
}

// Return Term_Oper value for the string or -1 if unknown
int     FindOper (const string &s) {
    for (int i=0; i<EOLIST; i++)
        if (TermOper[i] == s) return i;
    return -1;
}

// Substitute tabs for commas in the given string and append tab
void    Comma2Tab (string &s) {
    string::size_type pos = s.find_first_of(',');
    while (pos != string::npos) {
        s[pos++] = '\t';
        pos = s.find_first_of(',', pos);
    }
}

// Read and parse whole config (job) file
bool    ReadConfig (const char* filename) {
    int lineno = 0;
    char buf[buflen];
    ifstream jf;
    jf.open(filename, ios_base::binary);
    if (!jf || jf.bad()) {
        if (global.rank == 0)
            cerr << "Can't open " << filename << endl;
        return false;
    }

    while (!jf.eof()) {         // prior to 1st section
        jf.getline(buf, buflen);
        lineno++;
        if (jf.bad()) return false;
        if (jf.eof()) return false;
        if (IsComment(buf)) continue;
        if (*buf == '[') break;
        if (global.rank == 0)
            cerr << "Invalid configuration line " << lineno << endl;
        return false;
    }

    bool haveMode = false;
    bool haveData = false;
    bool haveFields = false;
    bool haveSpecies = false;
    bool havePredicate = false;

    while (!jf.eof()) {         // read sections
        string section(buf+1);
        if (*(section.end()-1) == '\r') section.erase(section.end()-1);
        string::size_type pos = section.find_last_of(']');
        if (pos == string::npos) {
            if (global.rank == 0)
                cerr << "Invalid section '" << section << "' in line " << lineno << endl;
            return false;
        }
        section.erase(pos);

        if (!haveMode && section == "mode") {
            while (!jf.eof()) {         // [mode]
                jf.getline(buf, buflen);
                lineno++;
                if (jf.bad()) return false;             // IO error
                if (jf.eof()) break;                    // EOF
                if (IsComment(buf)) continue;           // Comment
                if (*buf == '[') break;              

                if (haveMode) {             // 2nd etc. line(s) of this section
                    if (!global.log_gene && !global.log_protein && 
                        !global.log_contig && global.log_contigno<0) 
                        continue;               // skip debug lines
                    string list(buf);
                    if (*(list.end()-1) == '\r') list.erase(list.end()-1);
                    string::size_type off = 0;
                    while (true) {
                        string token = GetToken(list, off);
                        if (token.empty()) break;
                        global.logID.push_back(token);
                    }
                    continue;
                }
                haveMode = true;
                global.progmode.assign(buf);
                if (*(global.progmode.end()-1) == '\r') 
                    global.progmode.erase(global.progmode.end()-1);

                // Remove a comment from the command line if any.
                string::size_type soc = global.progmode.find_first_of("//");
                if (soc != string::npos)
                    global.progmode.erase(soc);

                // General mode
                if (global.progmode.find(Mode_Homology) != string::npos) {
                    global.mode_homology = true;
                    global.mode_cluster = false;
                    global.mode_ogroup = false;
                    global.mode_matrix = false;
                    global.mode_info = true;
                }
                else if (global.progmode.find(Mode_Cluster) != string::npos) {
                    global.mode_homology = false;
                    global.mode_cluster = true;
                    global.mode_ogroup = false;
                    global.mode_matrix = false;
                    global.mode_info = true;    // for new format, C with I
                }
                else if (global.progmode.find(Mode_Ogroup) != string::npos) {
                    global.mode_homology = false;
                    global.mode_cluster = false;
                    global.mode_ogroup = true;
                    global.mode_matrix = false;
                    global.mode_info = false;    // for old format, G w/o I
                }
                else if (global.progmode.find(Mode_Matrix) != string::npos) {
                    global.mode_homology = false;
                    global.mode_cluster = false;
                    global.mode_ogroup = false;
                    global.mode_matrix = true;
                    global.mode_info = true;
                }
                else if (!global.mode_homology && !global.mode_cluster && 
                    !global.mode_ogroup && !global.mode_matrix) {
                    global.mode_homology = true;
                    global.mode_cluster = false;
                    global.mode_ogroup = false;
                    global.mode_matrix = false;
                    global.mode_info = false;
                }

                // X: refine extraction mode
                string::size_type pos = global.progmode.find(Mode_Extract);
                if (pos != string::npos) {
                    if (global.cmd_extract && !global.mode_extract)
                        global.progmode.erase(pos, 1);
                    else
                        global.mode_extract = true;
                }
                else if (global.cmd_extract && global.mode_extract) {
                    global.progmode += " X";
                }

                // I, J: refine separate & tail log modes
                pos = global.progmode.find(Log_Separate);
                if (pos != string::npos) {
                    if (global.cmd_extract && global.mode_extract)
                        global.progmode.erase(pos, 1);
                    else
                        global.log_separate = true;
                }
                else if (global.cmd_extract && !global.mode_extract) {
                    global.progmode += " I";
                }
                pos = global.progmode.find(Log_Tail);
                if (pos != string::npos) {
                    if (global.cmd_extract && global.mode_extract)
                        global.progmode.erase(pos, 1);
                    else
                        global.log_tail = true;
                }
                else if (global.cmd_extract && !global.mode_extract) {
                    global.progmode += " J";
                }

                // Synteny option
                if (global.progmode.find(Mode_Order) != string::npos)
                    global.mode_order = true;
                if (global.progmode.find(Mode_Direct) != string::npos)
                    global.mode_direct = true;
                if (global.progmode.find(Mode_Mirror) != string::npos)
                    global.mode_mirror = true;

                // Span option
                if (global.progmode.find(Span_Center) != string::npos) {
                    global.span_center = true;
                    global.span_inner = false;
                    global.span_outer = false;
                }
                else if (global.progmode.find(Span_Inner) != string::npos) {
                    global.span_center = false;
                    global.span_inner = true;
                    global.span_outer = false;
                }
                else if (global.progmode.find(Span_Outer) != string::npos) {
                    global.span_center = false;
                    global.span_inner = false;
                    global.span_outer = true;
                }

                // Log options
                if (global.progmode.find(Log_Separate) != string::npos && !global.cmd_extract)
                    global.log_separate = true;
                if (global.progmode.find(Log_Tail) != string::npos && !global.cmd_extract)
                    global.log_tail = true;
                if (global.progmode.find(Log_Gene) != string::npos)
                    global.log_gene = true;
                if (global.progmode.find(Log_Protein) != string::npos)
                    global.log_protein = true;
                if (global.progmode.find(Log_Verbose) != string::npos)
                    global.log_verbose = true;
                if (global.progmode.find(Log_Contig) != string::npos)
                    global.log_contig = true;
                if (global.progmode.find(Log_ContigN) != string::npos)
                    global.log_contigno = 0;
                if (global.progmode.find(Log_Span1) != string::npos)
                    global.log_span1 = true;
                if (global.progmode.find(Log_Span2) != string::npos)
                    global.log_span2 = true;
                if (global.progmode.find(Log_Synteny) != string::npos)
                    global.log_synteny = true;
                if (global.progmode.find(Log_Union) != string::npos)
                    global.log_union = true;
            }       // next [mode] line
            continue;
        }       // next section

        if (!haveData && section == "data") {
            if (!haveMode) {
                if (global.rank == 0)
                    cerr << "No [mode] section in line " << lineno << endl;
                return false;
            }

            while (!jf.eof()) {         // [data]
                jf.getline(buf, buflen);
                lineno++;
                if (jf.bad()) return false;             // IO error
                if (jf.eof()) break;                    // EOF
                if (IsComment(buf)) continue;           // Comment
                if (*buf == '[') break;

                haveData = true;
                string str(buf);
                if (*(str.end()-1) == '\r') str.erase(str.end()-1);
                string::size_type off = 0;
                string intype = GetToken(str, off);
                string inname = GetToken(str, off);

                switch (intype[0]) {
                    case 'H': case 'h':
                        global.mode_single = true;
                        // fall through
                    case 'O': case 'o':
                        if (!global.homology_ext.empty()) {
                            if (global.rank == 0)
                                cerr << "Multiple homology lines in the config file are not allowed." << endl;
                            return false;
                        }
                        ParseExtension(inname, global.homology_path, global.homology_ext);
                        break;
                    case 'P': case 'p':
                        if (!global.paralogs_ext.empty()) {
                            if (global.rank == 0)
                                cerr << "Multiple paralog lines in the config file are not allowed." << endl;
                            return false;
                        }
                        ParseExtension(inname, global.paralogs_path, global.paralogs_ext);
                        break;
                    case 'C': case 'c':
                        if (global.mode_cluster)
                            global.cluster_files.push_back(inname);
                        break;
                    case 'Q': case 'q':
                        if (global.mode_ogroup)
                            global.cluster_files.push_back(inname);
                        break;
                    case 'A': case 'a':
                        if (!global.matrix_ext.empty()) {
                            if (global.rank == 0)
                                cerr << "Multiple matrix lines in the config file are not allowed." << endl;
                            return false;
                        }
                        ParseExtension(inname, global.matrix_path, global.matrix_ext);
                        break;
                    case 'I': case 'i':
                        if (!global.info_ext.empty()) {
                            if (global.rank == 0)
                                cerr << "Multiple info_file lines in the config file are not allowed." << endl;
                            return false;
                        }
                        ParseExtension(inname, global.info_path, global.info_ext);
                        break;
                }
            }       // next [data] line

            if (global.mode_homology && global.homology_ext.empty()) {
                if (global.rank == 0)
                    cerr << "Homology file directory not specified." << endl;
                return false;
            }
            if (global.mode_matrix && global.matrix_ext.empty()) {
                if (global.rank == 0)
                    cerr << "Matrix file directory not specified." << endl;
                return false;
            }
            if (global.mode_info && global.info_ext.empty()) {
                if (global.rank == 0)
                    cerr << "Gene info file directory not specified." << endl;
                return false;
            }
            if (global.mode_cluster && global.cluster_files.empty()) {
                if (global.rank == 0)
                    cerr << "Cluster file name(s) not specified." << endl;
                return false;
            }
            if (global.mode_ogroup && global.cluster_files.empty()) {
                if (global.rank == 0)
                    cerr << "Orthogroup file name(s) not specified." << endl;
                return false;
            }
            continue;
        }       // next section

        if (!haveFields && section == "fields") {
            if (!haveMode) {
                if (global.rank == 0)
                    cerr << "No [mode] section in line " << lineno << endl;
                return false;
            }

            if (!haveData) {
                if (global.rank == 0)
                    cerr << "No [data] section in line " << lineno << endl;
                return false;
            }

            while (!jf.eof()) {         // [fields]
                jf.getline(buf, buflen);
                lineno++;
                if (jf.bad()) return false;             // IO error
                if (jf.eof()) break;                    // EOF
                if (IsComment(buf)) continue;           // Comment
                if (*buf == '[') break;

                haveFields = true;
                string s(buf);
                if (*(s.end()-1) == '\r') s.erase(s.end()-1);
                string::size_type off = 0;
                string f = GetToken(s, off);
                if (f == paracount)                 // store '#' field no.
                    global.fnumpara = (int)global.myfields.size();
                global.myfields.push_back(f);
                string a = GetToken(s, off);        // optional alias
                if (a.empty()) a = f;               // use primary name if omitted
                global.aliases.push_back(a);
            }       // next [fields] line
            continue;
        }       // next section

        if (!haveSpecies && section == "species") {
            if (!haveMode) {
                if (global.rank == 0)
                    cerr << "No [mode] section in line " << lineno << endl;
                return false;
            }

            if (!haveData) {
                if (global.rank == 0)
                    cerr << "No [data] section in line " << lineno << endl;
                return false;
            }

            if (!haveFields) {
                if (global.rank == 0)
                    cerr << "No [fields] section in line " << lineno << endl;
                return false;
            }

            Taxon taxon(startax);
            while (!jf.eof()) {         // [species]
                jf.getline(buf, buflen);
                lineno++;
                if (jf.bad()) return false;             // IO error
                if (jf.eof()) break;                    // EOF
                if (IsComment(buf)) continue;           // Comment
                if (*buf == '[') break;

                haveSpecies = true;
                string line(buf); 
                if (*(line.end()-1) == '\r') line.erase(line.end()-1);
                string::size_type off = 0;
                string name = GetToken(line, off);
                if (name[0] == startax) {           // taxon name found
                    if (!taxon.specno.empty()) {          // finish last taxon
                        taxon.nspec = (int)taxon.specno.size();
                        global.taxa.push_back(taxon);
                    }
                    taxon.name = name;                  // start new taxon
                    taxon.nspec = 0;
                    taxon.specno.clear();
                    continue;
                }
                //if (!taxon.name.empty())
                taxon.specno.push_back(global.nAnimals);
                Species sp(name);
                global.Animals.push_back(sp);
                global.nAnimals++;
            }       // next [species] line

            if (!taxon.specno.empty()) {          // finish last taxon
                taxon.nspec = (int)taxon.specno.size();
                global.taxa.push_back(taxon);
            }
            // Construct myfields for each animal
            global.nColumns = (int)global.myfields.size();
            for (int k=0; k<global.nAnimals; k++)
                for (int i=0; i < global.nColumns; i++)
                    global.Animals[k].myfields.push_back(-1);
            continue;
        }       // next section

        if (!havePredicate && section == "predicate") {  
            if (!haveMode) {
                if (global.rank == 0)
                    cerr << "No [mode] section in line " << lineno << endl;
                return false;
            }

            if (!haveData) {
                if (global.rank == 0)
                    cerr << "No [data] section in line " << lineno << endl;
                return false;
            }

            if (!haveFields) {
                if (global.rank == 0)
                    cerr << "No [fields] section in line " << lineno << endl;
                return false;
            }

            if (!haveSpecies) {
                if (global.rank == 0)
                    cerr << "No [species] section in line " << lineno << endl;
                return false;
            }

            map <string, int> labels;      // User's label IDs start from -3
            labels.insert(StrIntPair(label_no, NO));
            labels.insert(StrIntPair(label_yes, YES));
            const int offlabel = YES-1;
            Term term, parminit;
            int opno = 0;
            int lastsp = 0;         // last species in selection loop
            int loophead = -1;      // means loop not began
            int orhead   = -1;      // means OR not began
            int andhead  = -1;      // meand AND not began

            while (!jf.eof()) {         // [predicate]
                jf.getline(buf, buflen);
                lineno++;
                if (jf.bad()) return false;             // IO error
                if (jf.eof()) break;                    // EOF
                if (IsComment(buf)) continue;           // Comment
                if (*buf == '[') break;

                havePredicate = true;
                string str(buf);
                if (*(str.end()-1) == '\r') str.erase(str.end()-1);
                string::size_type offset = 0;
                string oper = GetToken(str, offset);

                if (oper[0] == ':') {               // Label found
                    string label = oper.substr(1);
                    StrInt::iterator lit = labels.find(label);
                    if (lit == labels.end())        // unreferenced label 
                        labels.insert(StrIntPair(label, opno));
                    else {                          // modify old references
                        int oldno = lit->second;
                        lit->second = opno;
                        vector <Term>::iterator tit = global.terms.begin();
                        for (++tit; tit != global.terms.end(); tit++) {
                            if (tit->yes == oldno)  tit->yes = opno;
                            if (tit->no == oldno)   tit->no  = opno;
                        }
                    }
                    continue;
                }

                // Parse predicate type and optional parameters
                string::size_type off = 0;
                string::size_type next;
                next = oper.find_first_of(subdelim, off);
                term.oper = FindOper(oper.substr(off, next-off));   // term operation
                if (term.oper < 0) {
                    if (global.rank == 0)
                        cerr << "Unknown operation '" << oper << "' in line " << lineno << endl;
                    return false;
                }
                if (opno == 0 && term.oper != SET) {
                    if (global.rank == 0)
                        cerr << "The predicate must begin with SET." << endl;
                    return false;
                }
                Term & gt0  = global.terms[0];
                term.sp     = unknown_species;
                term.nwit   = term.oper==EOR? 1:    // use as number of positives in OR 
                    term.oper==EAND? 0: gt0.nwit;   // use as number of negatives in AND
                term.E      = gt0.E;
                term.range  = gt0.range;
                term.uselast0 = gt0.uselast0;
                term.uselast1 = gt0.uselast1;
                term.BBH    = gt0.BBH;
                //term.fmask  = 0xffffffff;
                for (int my = 0; my < maxfield; my++)
                    term.forder[my] = 0;

                if (next != string::npos) {         // parse optional parameters
                    off = next+1;
                    next = oper.find_first_of(subdelim, off);   // number of witnesses
                    if (next != off) {
                        string par = oper.substr(off, next-off);
                        if (par[0] != '%') {
                            istringstream nwit(par);
                            nwit >> term.nwit;
                        }
                        else {
                            map<string, double>::iterator pk = global.parameter.find(par);
                            if (pk == global.parameter.end()) {
                                if (global.rank == 0)
                                    cerr << "Unknown parameter '" << par << "' in line " << lineno << endl;
                                return false;
                            }
                            term.nwit = (int)(pk->second);
                        }
                    }
                    if (next != string::npos) {
                        off = next+1;
                        next = oper.find_first_of(subdelim, off);   // range
                        if (next != off) {
                            double setrange;
                            char postfix;
                            string par = oper.substr(off, next-off);
                            if (par[0] != '%') {
                                istringstream range(par);
                                range >> setrange >> postfix;
                                if (postfix=='M' || postfix=='m') setrange *= 1.0e6;
                                else if (postfix=='K' || postfix=='k') setrange *= 1.0e3;
                            }
                            else {
                                map<string, double>::iterator pk = global.parameter.find(par);
                                if (pk == global.parameter.end()) {
                                    if (global.rank == 0)
                                        cerr << "Unknown parameter '" << par << "' in line " << lineno << endl;
                                    return false;
                                }
                                setrange = pk->second;
                            }
                            term.range = opno==0 && currentdefrange>0 ? currentdefrange : (int)setrange;
                        }
                        if (next != string::npos) {
                            off = next+1;
                            next = oper.find_first_of(subdelim, off);   // BBH
                            if (next != off) {
                                string par = oper.substr(off, next-off);
                                if (par[0] != '%') {
                                    istringstream BBH(par);
                                    BBH >> term.BBH;
                                }
                                else {
                                    map<string, double>::iterator pk = global.parameter.find(par);
                                    if (pk == global.parameter.end()) {
                                        if (global.rank == 0)
                                            cerr << "Unknown parameter '" << par << "' in line " 
                                            << lineno << endl;
                                        return false;
                                    }
                                    term.BBH = (int)(pk->second);
                                }
                                // Fix superfluous flags
                                if ((term.BBH & IBHX)&&(term.BBH & OBHX)) term.BBH |= BBHX;
                                if ((term.BBH & IBHY)&&(term.BBH & OBHY)) term.BBH |= BBHY;
                                if ((term.BBH & IBHZ)&&(term.BBH & OBHZ)) term.BBH |= BBHZ;
                                if (term.BBH & BBHX) term.BBH &= ~(OBHX | IBHX);
                                if (term.BBH & BBHY) term.BBH &= ~(OBHY | IBHY);
                                if (term.BBH & BBHZ) term.BBH &= ~(OBHZ | IBHZ);
                            }
                            if (next != string::npos) {
                                off = next+1;
                                next = oper.find_first_of(subdelim, off);   // uselast0
                                if (next != off) {
                                    string par = oper.substr(off, next-off);
                                    if (par[0] != '%') {
                                        istringstream uselast0(par);
                                        uselast0 >> term.uselast0;
                                    }
                                    else {
                                        map<string, double>::iterator pk = global.parameter.find(par);
                                        if (pk == global.parameter.end()) {
                                            if (global.rank == 0)
                                                cerr << "Unknown parameter '" << par << "' in line " 
                                                << lineno << endl;
                                            return false;
                                        }
                                        term.uselast0 = (int)(pk->second);
                                    }
                                }
                                if (next != string::npos) {
                                    off = next+1;
                                    next = oper.find_first_of(subdelim, off);   // uselast1
                                    if (next != off) {
                                        string par = oper.substr(off, next-off);
                                        if (par[0] != '%') {
                                            istringstream uselast1(par);
                                            uselast1 >> term.uselast1;
                                        }
                                        else {
                                            map<string, double>::iterator pk = global.parameter.find(par);
                                            if (pk == global.parameter.end()) {
                                                if (global.rank == 0)
                                                    cerr << "Unknown parameter '" << par << "' in line " 
                                                    << lineno << endl;
                                                return false;
                                            }
                                            term.uselast1 = (int)(pk->second);
                                        }
                                    }
                                    if (next != string::npos) {
                                        off = next + 1;
                                        next = oper.find_first_of(subdelim, off);   // E-value
                                        if (next != off) {
                                            string par = oper.substr(off, next-off);
                                            if (par[0] != '%') {
                                                istringstream evalue(par);
                                                evalue >> term.E;
                                            }
                                            else {
                                                map<string, double>::iterator pk = global.parameter.find(par);
                                                if (pk == global.parameter.end()) {
                                                    if (global.rank == 0)
                                                        cerr << "Unknown parameter '" << par << "' in line " 
                                                        << lineno << endl;
                                                    return false;
                                                }
                                                term.E = pk->second;
                                            }
                                            if (term.E > global.Elimit)
                                                global.Elimit = term.E;
                                        }
                                        // more optional parameters
                                    }
                                }
                            }
                        }
                    }
                }
                if (term.oper == NOP || term.oper == GOTO) {    // NOPs & unconditional branches
                    string label = GetToken(str, offset);
                    if (!label.empty() && !IsComment(label.c_str())) {
                        if (label[0]==noprefix) label.erase(0,1);
                        StrInt::iterator lit = labels.find(label);
                        int lblno;
                        if (lit == labels.end()) {   // unknown label
                            lblno = -(int)labels.size()-1;
                            labels.insert(StrIntPair(label, lblno));
                        }
                        else lblno = lit->second;
                        opno++;
                        term.yes = lblno; term.no = lblno;
                        global.terms.push_back(term);       // store term only if label present
                    }
                    continue;
                }
                else if (term.oper == SET) {                // set new parameters
                    gt0.nwit    = term.nwit;
                    gt0.E       = term.E;
                    if (term.E > global.Elimit)
                        global.Elimit = term.E;
                    gt0.range   = term.range;
                    gt0.uselast0 = term.uselast0;
                    gt0.uselast1 = term.uselast1;
                    gt0.BBH     = term.BBH;
                    // Check optional tokens in SET operator
                    string option = GetToken(str, offset);
                    while (!option.empty() && !IsComment(option)) {
                        off = 0;
                        next = option.find_first_of(eqsign, off);
                        int opt = FindOper(option.substr(off, next-off));   // option type
                        if (next != string::npos) {
                            string par = option.substr(next+1);
                            istringstream vals(par);
                            switch (opt) {
                                case WIT: case WITNESS:
                                    if (par[0] == '%') {
                                        map<string, double>::iterator pk = global.parameter.find(par);
                                        if (pk == global.parameter.end()) {
                                            if (global.rank == 0)
                                                cerr << "Unknown parameter '" << par << "' in line " 
                                                    << lineno << endl;
                                            return false;
                                        }
                                        term.nwit = (int)(pk->second);
                                    }
                                    else vals >> term.nwit;
                                    gt0.nwit = term.nwit;
                                    break;
                                case EVAL:
                                    if (par[0] == '%') {
                                        map<string, double>::iterator pk = global.parameter.find(par);
                                        if (pk == global.parameter.end()) {
                                            if (global.rank == 0)
                                                cerr << "Unknown parameter '" << par << "' in line " 
                                                    << lineno << endl;
                                            return false;
                                        }
                                        term.E = pk->second;
                                    }
                                    else vals >> term.E;
                                    gt0.E = term.E;
                                    if (term.E > global.Elimit)
                                        global.Elimit = term.E;
                                    break;
                                case RANGE:
                                    if (par[0] == '%') {
                                        map<string, double>::iterator pk = global.parameter.find(par);
                                        if (pk == global.parameter.end()) {
                                            if (global.rank == 0)
                                                cerr << "Unknown parameter '" << par << "' in line " 
                                                    << lineno << endl;
                                            return false;
                                        }
                                        term.range = (int)(pk->second);
                                    }
                                    else vals >> term.range;
                                    gt0.range = term.range;
                                    break;
                                case HOLD1:
                                    if (par[0] == '%') {
                                        map<string, double>::iterator pk = global.parameter.find(par);
                                        if (pk == global.parameter.end()) {
                                            if (global.rank == 0)
                                                cerr << "Unknown parameter '" << par << "' in line " 
                                                    << lineno << endl;
                                            return false;
                                        }
                                        term.uselast0 = (int)(pk->second);
                                    }
                                    else vals >> term.uselast0;
                                    gt0.uselast0 = term.uselast0;
                                    break;
                                case HOLD2:
                                    if (par[0] == '%') {
                                        map<string, double>::iterator pk = global.parameter.find(par);
                                        if (pk == global.parameter.end()) {
                                            if (global.rank == 0)
                                                cerr << "Unknown parameter '" << par << "' in line " 
                                                    << lineno << endl;
                                            return false;
                                        }
                                        term.uselast1 = (int)(pk->second);
                                    }
                                    else vals >> term.uselast1;
                                    gt0.uselast1 = term.uselast1;
                                    break;
                                case BBH:
                                    if (par[0] == '%') {
                                        map<string, double>::iterator pk = global.parameter.find(par);
                                        if (pk == global.parameter.end()) {
                                            if (global.rank == 0)
                                                cerr << "Unknown parameter '" << par << "' in line " 
                                                    << lineno << endl;
                                            return false;
                                        }
                                        term.BBH = (int)(pk->second);
                                    }
                                    else vals >> term.BBH;
                                    gt0.BBH = term.BBH;
                                    break;
                                case HEAD: case HEADING:
                                    global.heading = vals.str();
                                    Comma2Tab(global.heading);
                                    break;
                                default:
                                    if (global.rank == 0)
                                        cerr << "Unknown SET option '" << option << "' in line " << lineno << endl;
                                    return false;
                            }
                        }
                        else {
                            if (global.rank == 0)
                                cerr << "No value of SET option '" << option << "' in line " << lineno << endl;
                            return false;
                        }
                        option = GetToken(str, offset);     // get next option
                    }
                    opno++;
                    term.yes = opno; term.no = opno;
                    if (opno > 1)
                        global.terms.push_back(term);
                    else        // store initial parameters
                        parminit = term;
                    continue;
                }
                else if (term.oper == WIT || term.oper == WITNESS) {
                    term.oper = SET;
                    string value = GetToken(str, offset);
                    istringstream vals(value);
                    if (value[0] == '%') {
                        map<string, double>::iterator pk = global.parameter.find(value);
                        if (pk == global.parameter.end()) {
                            if (global.rank == 0)
                                cerr << "Unknown parameter '" << value << "' in line " 
                                    << lineno << endl;
                            return false;
                        }
                        term.nwit = (int)(pk->second);
                    }
                    else vals >> term.nwit;
                    gt0.nwit = term.nwit;
                    opno++;
                    term.yes = opno; term.no = opno;
                    global.terms.push_back(term);
                    continue;
                }
                else if (term.oper == EVAL) {
                    term.oper = SET;
                    string value = GetToken(str, offset);
                    istringstream vals(value);
                    if (value[0] == '%') {
                        map<string, double>::iterator pk = global.parameter.find(value);
                        if (pk == global.parameter.end()) {
                            if (global.rank == 0)
                                cerr << "Unknown parameter '" << value << "' in line " 
                                    << lineno << endl;
                            return false;
                        }
                        term.E = pk->second;
                    }
                    else vals >> term.E;
                    gt0.E = term.E;
                    opno++;
                    term.yes = opno; term.no = opno;
                    global.terms.push_back(term);
                    continue;
                }
                else if (term.oper == RANGE) {
                    term.oper = SET;
                    string value = GetToken(str, offset);
                    istringstream vals(value);
                    if (value[0] == '%') {
                        map<string, double>::iterator pk = global.parameter.find(value);
                        if (pk == global.parameter.end()) {
                            if (global.rank == 0)
                                cerr << "Unknown parameter '" << value << "' in line " 
                                    << lineno << endl;
                            return false;
                        }
                        term.range = (int)(pk->second);
                    }
                    else {
                        char suffix = 0;
                        vals >> term.range >> suffix;
                        if (suffix=='M' || suffix=='m') term.range *= 1000000;
                        else if (suffix=='K' || suffix=='k') term.range *= 1000;
                    }
                    gt0.range = term.range;
                    opno++;
                    term.yes = opno; term.no = opno;
                    global.terms.push_back(term);
                    continue;
                }
                else if (term.oper == HOLD1) {
                    term.oper = SET;
                    string value = GetToken(str, offset);
                    istringstream vals(value);
                    if (value[0] == '%') {
                        map<string, double>::iterator pk = global.parameter.find(value);
                        if (pk == global.parameter.end()) {
                            if (global.rank == 0)
                                cerr << "Unknown parameter '" << value << "' in line " 
                                    << lineno << endl;
                            return false;
                        }
                        term.uselast0 = (int)(pk->second);
                    }
                    else vals >> term.uselast0;
                    gt0.uselast0 = term.uselast0;
                    opno++;
                    term.yes = opno; term.no = opno;
                    global.terms.push_back(term);
                    continue;
                }
                else if (term.oper == HOLD2) {
                    term.oper = SET;
                    string value = GetToken(str, offset);
                    istringstream vals(value);
                    if (value[0] == '%') {
                        map<string, double>::iterator pk = global.parameter.find(value);
                        if (pk == global.parameter.end()) {
                            if (global.rank == 0)
                                cerr << "Unknown parameter '" << value << "' in line " 
                                    << lineno << endl;
                            return false;
                        }
                        term.uselast1 = (int)(pk->second);
                    }
                    else vals >> term.uselast1;
                    gt0.uselast1 = term.uselast1;
                    opno++;
                    term.yes = opno; term.no = opno;
                    global.terms.push_back(term);
                    continue;
                }
                else if (term.oper == BBH || term.oper == ORTH) {
                    term.oper = SET;
                    string value = GetToken(str, offset);
                    istringstream vals(value);
                    if (value[0] == '%') {
                        map<string, double>::iterator pk = global.parameter.find(value);
                        if (pk == global.parameter.end()) {
                            if (global.rank == 0)
                                cerr << "Unknown parameter '" << value << "' in line " 
                                    << lineno << endl;
                            return false;
                        }
                        term.BBH = (int)(pk->second);
                    }
                    else vals >> term.BBH;
                    gt0.BBH = term.BBH;
                    opno++;
                    term.yes = opno; term.no = opno;
                    global.terms.push_back(term);
                    continue;
                }
                else if (term.oper == HEAD || term.oper == HEADING) {
                    global.heading = GetToken(str, offset);
                    Comma2Tab(global.heading);
                    continue;
                }
                else if (term.oper == ADD) {                // store genes found
                    string spec = GetToken(str, offset);
                    int sp = FindSpecno(spec);
                    term.sp = (sp == unknown_species ? lastsp : sp);
                    opno ++;
                    term.no = opno; term.yes = opno;

                    // Read optional list of fields
                    string flist = GetToken(str, offset);
                    if (!flist.empty() && !IsComment(flist.c_str())) {
                        int forder = 1;     // current field order

                        if (flist[0] == '-') {  // all but given fields in natural order
                            flist.erase(0, 1);

                            for (int fno = 0; fno < global.nColumns; fno++) {
                                // check if this field is listed
                                string fname;
                                off = 0;
                                next = 0;
                                while (next != string::npos) {
                                    next = flist.find_first_of(subdelim, off);
                                    fname = flist.substr(off, next-off);
                                    if (fname == global.myfields[fno] || fname == global.aliases[fno])
                                        break;
                                    off = next + 1;
                                }
                                if (fname.empty() || next == string::npos)
                                    term.forder[fno] = forder++;
                            }
                        }
                        else {                  // only given fields in specified order
                            off = 0;
                            next = 0;
                            while (next != string::npos) {
                                next = flist.find_first_of(subdelim, off);
                                string fname = flist.substr(off, next-off);
                                if (!fname.empty()) {
                                    int fno;        // determine the field no.

                                    for (fno = 0; fno < (int)global.myfields.size(); fno++) {
                                        if (global.myfields[fno] == fname) break;
                                        if (global.aliases[fno] == fname) break;
                                    }

                                    if (fno >= (int)global.myfields.size()) {
                                        if (global.rank == 0)
                                            cout << "Predicate error: unknown field '" << fname 
                                                 << "' ignored in line " << lineno << endl;
                                    }
                                    else term.forder[fno] = forder++;
                                }
                                off = next+1;
                            }       // get next field
                        }
                /*
                        if (flist[0] == '-') {
                            flist.erase(0, 1);
                            term.fmask = -1;    // some fields to remove later
                        }
                        else
                            term.fmask = 0;     // some fields to add later
                        off = 0;
                        next = 0;
                        while (next != string::npos) {
                            next = flist.find_first_of(subdelim, off);
                            string fname = flist.substr(off, next-off);
                            if (!fname.empty()) {
                                int fno;        // determine the field no.
                                for (fno = 0; fno < (int)global.myfields.size(); fno++)
                                    if (global.myfields[fno] == fname) break;
                                if (fno >= (int)global.myfields.size()) {
                                    for (fno = 0; fno < (int)global.aliases.size(); fno++)
                                        if (global.aliases[fno] == fname) break;
                                }
                                if (fno >= (int)global.myfields.size() || fno >= (int)global.aliases.size()) {
                                    if (global.rank == 0)
                                        cout << "Predicate error: unknown field '" << fname 
                                             << "' ignored in line " << lineno << endl;
                                }
                                else
                                    term.fmask ^= (1U<<fno);     // both inclusion and exclusion
                            }
                            off = next+1;
                        }
                */
                    }
                    else {      // empty list, all fields are added
                        int forder = 1;
                        for (int my = 0; my < global.nColumns; my++)
                            term.forder[my] = forder++;
                    }
                    // set 'paralogs count' flag if needed
                    if (term.sp >= 0) {
                        global.Animals[term.sp].neednumpar = 
                            (global.fnumpara >= 0 && term.forder[global.fnumpara] != 0);
                            //((term.fmask &(1U<<global.fnumpara))!= 0);
                    }
                    else {
                        Taxon& taxon = global.taxa[-term.sp];
                        for (int s = 0; s < taxon.nspec; s++) {
                            global.Animals[taxon.specno[s]].neednumpar = 
                                (global.fnumpara >= 0 && term.forder[global.fnumpara] != 0);
                                //((term.fmask &(1U<<global.fnumpara))!= 0);
                        }
                    }
                    global.terms.push_back(term);
                    continue;
                }
                else if (term.oper == NEXT) {               // looping bound
                    if (loophead < 0) {
                        if (global.rank == 0)
                            cerr << "Predicate error: NEXT without OVER in line " << lineno << endl;
                        return false;
                    }
                    opno++;
                    term.no = loophead; term.yes = loophead;
                    if (global.terms[loophead].no == 0) 
                        global.terms[loophead].no = opno;
                    loophead = -1;
                    global.terms.push_back(term);
                    continue;
                }
                else if (term.oper == BOR) {                // begin nonexclusive OR
                    if (orhead >= 0) {
                        if (global.rank == 0)
                            cerr << "Predicate error: nested OR not allowed in line " << lineno << endl;
                        return false;
                    }
                    if (andhead >= 0) {
                        if (global.rank == 0)
                            cerr << "Predicate error: overlapped OR/AND not allowed in line " << lineno << endl;
                        return false;
                    }
                    orhead = opno++;
                    term.no = opno; term.yes = opno;
                    global.terms.push_back(term);
                    continue;
                }
                else if (term.oper == BAND) {               // begin noninclusive AND
                    if (andhead >= 0) {
                        if (global.rank == 0)
                            cerr << "Predicate error: nested AND not allowed in line " << lineno << endl;
                        return false;
                    }
                    if (orhead >= 0) {
                        if (global.rank == 0)
                            cerr << "Predicate error: overlapped AND/OR not allowed in line " << lineno << endl;
                        return false;
                    }
                    andhead = opno++;
                    term.no = opno; term.yes = opno;
                    global.terms.push_back(term);
                    continue;
                }
                else {          // INx, OVER, EOR, EAND
                    if (term.oper != EOR && term.oper != EAND) {    // parse species/taxa
                        string spec = GetToken(str, offset);
                        int sp = FindSpecno(spec);
                        if (sp == unknown_species) {
                            if (global.rank == 0)
                                cerr << "Predicate error: invalid or missing species in line " << lineno << endl;
                            return false;
                        }
                        else 
                            term.sp = sp;
                        if (term.oper == OVER) {
                            if (loophead >= 0) {
                                if (global.rank == 0)
                                    cerr << "Predicate error: nested OVER/NEXT not allowed in line" << lineno << endl;
                                return false;
                            }
                            loophead = opno;
                            lastsp = term.sp;
                        }
                    }
                    else if (term.oper == EOR) {    // EOR
                        if (orhead < 0) {
                            if (global.rank == 0)
                                cerr << "Predicate error: EOR without BOR encountered in line " 
                                    << lineno << endl;
                            return false;
                        }
                        orhead = -1;
                    }
                    else {                          // EAND
                        if (andhead < 0) {
                            if (global.rank == 0)
                                cerr << "Predicate error: EAND without BAND encountered in line " 
                                    << lineno << endl;
                            return false;
                        }
                        andhead = -1;
                    }
                    // parse and check label
                    string label = GetToken(str, offset);
                    bool neg = false;
                    if (!label.empty() && !IsComment(label.c_str())) {
                        if (label[0]==noprefix) {
                            neg = true;
                            label.erase(0,1);
                        }

                        StrInt::iterator lit = labels.find(label);
                        int lblno;
                        if (lit == labels.end()) {   // unknown label
                            lblno = -(int)labels.size()-1;
                            labels.insert(StrIntPair(label, lblno));
                        }
                        else lblno = lit->second;

                        opno++;
                        term.yes = (neg ? opno : lblno);
                        term.no = (neg ? lblno : opno);
                    }
                    else if (term.oper == EOR) {
                        term.nwit = 0;  // default number of positives at no label
                        opno++;
                        term.yes = opno; term.no = opno;
                    }
                    else if (term.oper == EAND) {
                        term.nwit = -1; // default number of negatives at no label
                        opno++;
                        term.yes = opno; term.no = opno;
                    }
                    else if (term.oper == OVER) {       // OVER w/o label
                        opno++;
                        term.yes = opno;
                        term.no = 0;        // "process by NEXT" indicator 
                    }
                    else if (term.oper == IN || term.oper == IN2) {     // INx w/o label
                        opno++;
                        term.yes = opno; term.no = opno;
                    }
                    global.terms.push_back(term);
                }

            }       // next [predicate] line

            // Final YES, check labels resolved
            int nterms = (int)global.terms.size()-1;
            for (int i=1; i <= nterms; i++) {
                Term & t = global.terms[i];
                if (t.yes == nterms+1)  t.yes = YES;
                else if (t.yes!=YES && t.yes!=NO && (t.yes<=0 || t.yes>nterms)) {
                    if (global.rank == 0)
                        cerr << "Predicate error: unresolved Yes-label in operator #" << i << endl;
                    return false;
                }
                if (t.no == nterms+1)  t.no = YES;
                else if (t.no!=YES && t.no!=NO && (t.no<=0 || t.no>nterms)) {
                    if (global.rank == 0)
                        cerr << "Predicate error: unresolved No-label in operator #" << i << endl;
                    return false;
                }
            }
            global.terms[0] = parminit;     // restore initial parameters (eg for X range)
            continue;
        }

        // skip extra section if any
        while (!jf.eof()) {
            jf.getline(buf, buflen);
            lineno++;
            if (jf.bad()) return false;             // IO error
            if (jf.eof()) break;                    // EOF
            if (IsComment(buf)) continue;           // Comment
            if (*buf == '[') break;              
        }
    }
  
    jf.close();
    return true;
}

bool    ReadData (int spec1, int spec2) {
    int sp1 = spec1;
    int sp2 = spec2;
    char buf[buflen];
    string filename = global.homology_path + global.Animals[sp1].name 
        + pairsep + global.Animals[sp2].name + global.homology_ext;
    fstream df;
    df.open(filename.c_str(), ios_base::in | ios_base::binary);
    if (!df || df.bad()) {
        df.clear();
        filename = global.homology_path + global.Animals[sp2].name 
            + pairsep + global.Animals[sp1].name + global.homology_ext;
        df.open(filename.c_str(), ios_base::in | ios_base::binary);
        if (!df || df.bad()) {
            if (global.rank == 0)
                cout << "Can't open " << filename << endl;
            return false;
        }
        sp1 = spec2; sp2 = spec1;
    }

    df.getline(buf, buflen);      // Check heading line
    string str(buf);
    if (*(str.end()-1) == '\r') str.erase(str.end()-1);
    string::size_type offset = 0;

    int field_no;
    string name;

    if (global.Animals[sp1].contigs.size() == 0) {     // First appearance of sp1 - fill in

        for (field_no = 0; ; field_no++) {     // 1st species columns
            name = GetToken(str, offset, true);
            if (name.empty()) {
                if (global.rank == 0)
                    cout << "Invalid heading in " << filename << endl;
                return false;
            }
            else {
                if (name == global.myfields[0]) {    // Protein ID found
                    if (global.Animals[sp1].myfields[0] >= 0)
                        break;      // Protein ID appears 2nd time - switch to 2nd species
                    global.Animals[sp1].myfields[0] = field_no;
                    global.Animals[sp1].required.push_back(0);
                }
                else {
                    int j;
                    for (j = 1; j < global.nColumns; j++) {
                        if (name == global.myfields[j]) {
                            global.Animals[sp1].myfields[j] = field_no;
                            global.Animals[sp1].required.push_back(j);
                            break;
                        }
                    }
                    if (j >= global.nColumns)
                        global.Animals[sp1].required.push_back(-1);
                }
            }
            global.Animals[sp1].fields.push_back(name);
        }
        // Check that all required sp1 fields present
        for (int j = 0; j < ncol; j++) {
            if (global.Animals[sp1].myfields[j] < 0) {
                if (global.rank == 0)
                    cout << "Required field '" << global.myfields[j] << "' of " 
                         << global.Animals[sp1].name << " is absent from " << filename << endl;
                return false;
            }
        }
    }
    else {                                             // Next appearance of sp1 - check
        for (field_no = 0; field_no < (int)global.Animals[sp1].fields.size(); field_no++) {
            name = GetToken(str, offset, true);
            if (name.empty()) {
                if (global.rank == 0)
                    cout << "Invalid heading in " << filename << endl;
                return false;
            }
            else {
                if (name != global.Animals[sp1].fields[field_no]) {
                    if (global.rank == 0)
                        cout << "Inconsistent " << global.Animals[0].name << " field "
                            << field_no << " in " << filename << endl;
                    return false;
                }
            }
        }
        name = GetToken(str, offset);
    }

    field_no = 0;
    global.Animals[sp2].myfields[0] = field_no;
    global.Animals[sp2].required.push_back(0);
    global.Animals[sp2].fields.push_back(name);

    for (++field_no; ; field_no++) {                   // 2nd species columns
        name = GetToken(str, offset, true);
        if (name.empty()) break;
        int j;
        for (j = 1; j < global.nColumns; j++) {
            if (name == global.myfields[j]) {
                global.Animals[sp2].myfields[j] = field_no;
                global.Animals[sp2].required.push_back(j);
                break;
            }
        }
        if (j >= global.nColumns)
            global.Animals[sp2].required.push_back(-1);

        global.Animals[sp2].fields.push_back(name);
    }
    // Check that all required sp2 fields present
    for (int j = 0; j < ncol; j++) {
        if (global.Animals[sp2].myfields[j] < 0) {
            if (global.rank == 0)
                cout << "Required field '" << global.myfields[j] << "' of " 
                     << global.Animals[sp2].name << " is absent in " << filename << endl;
            exit(3);
        }
    }

    Species& species1 = global.Animals[sp1];
    Species& species2 = global.Animals[sp2];
    Contig   contig1, contig2;
    Gene     gene1, gene2;
    Citer    cit1, cit2;
    Giter    git1, git2;
    int line = 2;
    bool logging = global.log_contig || global.log_contigno>=0 || global.log_gene ||
        global.log_protein || global.log_verbose;

    for ( ; !df.eof(); line++) {
        gene1.fields.clear();
        gene2.fields.clear();
        df.getline(buf, buflen);
        if (df.bad())
            return false;               // IO error
        if (df.eof() && *buf == 0)
            break;                      // EOF or empty line

        // Read & parse current pair
        str.assign(buf);
        if (*(str.end()-1) == '\r') str.erase(str.end()-1);
        offset = 0;

        // 1st animal data
        for (field_no = 0; field_no < (int)species1.fields.size(); field_no++) { 
            int reqno = species1.required[field_no];
            name = GetToken(str, offset, true);
            if (name.empty() && reqno == field_protein) break;  // skip genes w/o protein
            if (name.empty() && reqno >= 0 && reqno < ncol) {
                if (global.rank == 0)
                    cout << "Line " << line << " format error: " << species1.name << endl;
                return false;
            }
            istringstream ss(name);

            switch (reqno) {
                case field_gene:
                    gene1.name = name;      // Gene1
                    break;
                case field_contig:
                    contig1.name = name;    // Contig1
                    break;
                case field_begin:
                    ss >> gene1.begin;      // Begin1
                    break;
                case field_end:
                    ss >> gene1.end;        // End1
                    break;
                case field_strand:
                    ss >> gene1.strand;     // Strand1
                    break;
            }

            gene1.fields.push_back(name);    // Original field
        }
        if (field_no < (int)species1.fields.size()) continue;  // skip genes w/o protein

        gene1.sp = sp1;                  // Species - back reference

        cit1 = species1.contigs.find(contig1.name);
        if (cit1 == species1.contigs.end())
            cit1 = species1.contigs.insert( cit1, Cpair(contig1.name, contig1) );
        gene1.cit = cit1;                // Contig - back reference

        git1 = cit1->second.genes.find(gene1.name);
        if (git1 == cit1->second.genes.end()) {
            git1 = cit1->second.genes.insert( git1, Gpair(gene1.name, gene1) );
            PGene pgene1 = (Gene*)&git1->second;
            global.stableid.insert( Ppair(gene1.name, pgene1) );
        }

        // Check uniqueness of the gene
        if (global.rank == 0 && (git1->second.begin != gene1.begin || 
            git1->second.end != gene1.end || git1->second.strand != gene1.strand)) {
            cout << species1.name << "[" << contig1.name << "] gene " << gene1.name 
                 << " conflict in line " << line << ":\n" << "\t" << git1->second.begin 
                 << " " << git1->second.end << " " << git1->second.strand << "\n"
                 << "\t" << gene1.begin << " " << gene1.end << " " << gene1.strand << endl;
        }

        // 2nd animal data
        for (field_no = 0; field_no < (int)species2.fields.size(); field_no++) {
            int reqno = species2.required[field_no];
            name = GetToken(str, offset, true);
            if (name.empty() && reqno == field_protein) break;  // skip genes w/o protein
            if (name.empty() && reqno >= 0 && reqno < ncol) {
                if (global.rank == 0)
                    cout << "Line " << line << " format error: " << species2.name << endl;
                return false;
            }
            istringstream ss(name);

            switch (reqno) {
                case field_gene:
                    gene2.name = name;      // Gene2
                    break;
                case field_contig:
                    contig2.name = name;    // Contig2
                    break;
                case field_begin:
                    ss >> gene2.begin;      // Begin2
                    break;
                case field_end:
                    ss >> gene2.end;        // End2
                    break;
                case field_strand:
                    ss >> gene2.strand;     // Strand2
                    break;
            }

            gene2.fields.push_back(name);    // Original field
        }
        if (field_no < (int)species2.fields.size()) continue;  // skip genes w/o protein

        gene2.sp = sp2;                     // Species - back reference

        cit2 = species2.contigs.find(contig2.name);
        if (cit2 == species2.contigs.end())
            cit2 = species2.contigs.insert( cit2, Cpair(contig2.name, contig2) );
        gene2.cit = cit2;                   // Contig - back reference

        git2 = cit2->second.genes.find(gene2.name);
        if (git2 == cit2->second.genes.end()) {
            git2 = cit2->second.genes.insert( git2, Gpair(gene2.name, gene2) );
            PGene pgene2 = (Gene*)&git2->second;
            global.stableid.insert( Ppair(gene2.name, pgene2) );
        }

        // Check uniqueness of the gene
        if (global.rank == 0 && (git2->second.begin != gene2.begin || 
            git2->second.end != gene2.end || git2->second.strand != gene2.strand)) {
            cout << species2.name << "[" << contig2.name << "] gene " << gene2.name 
                 << " conflict in line " << line << ":\n" << "\t" << git2->second.begin 
                 << " " << git2->second.end << " " << git2->second.strand << "\n"
                 << "\t" << gene2.begin << " " << gene2.end << " " << gene2.strand << endl;
        }

        // Store pairing in both genes
        PGene pg2 = (Gene*)&git2->second;
        PGene pg1 = (Gene*)&git1->second;
        if (IsNewPair(pg1, pg2)) {
            git1->second.homologs[sp2].push_back( Homolog(pg2,0,0x7FFFFFFF) );
            git2->second.homologs[sp1].push_back( Homolog(pg1,0,0x7FFFFFFF) );
        }

        // Log submatrix element
        if (logging && ((pg1->log && pg2->log) || (global.log_union && (pg1->log || pg2->log)))) {
            cerr << global.Animals[sp1].name << tab << pg1->name << tab 
                 << global.Animals[sp2].name << tab << pg2->name << tab << endl;
        }

        if (global.rank == 0 && !global.qquiet 
            && inrecordstep && line % inrecordstep == 0) {
            if (logging)                cout << line << "    \r";
            else if (global.size > 1)   cout << line << "    \r";
            else                        cerr << line << "    \r";
        }
    }
    df.close();

    if (global.rank == 0 && !global.qquiet) 
        cout << "Homologous pairs read: " << line-2 << endl;

    int total = 0;
    int contig_m = 0;
    int total_m = 0;

    for (cit2 = species2.contigs.begin(); cit2 != species2.contigs.end(); cit2++) {
        if (cit2->second.genes.size() > 1) {
            contig_m ++;
            total_m += (int)cit2->second.genes.size();
        }
        total += (int)cit2->second.genes.size();
    }

    if (global.rank == 0 && !global.qquiet) {
        cout << species2.name << " in total: " << species2.contigs.size() << " contigs, " 
            << total << " genes." << endl;
        cout << "With enough genes: " << contig_m << " contigs, " << total_m << " genes." << endl;
    }

    return true;
}

bool    ReadShortData (int spec, bool paralogs) {
    int npairs = 0;
    int sp1 = spec;
    char buf[buflen];
    bool logging = global.log_contig || global.log_contigno>=0 || global.log_gene ||
        global.log_protein || global.log_verbose;
    string filename = paralogs ? global.paralogs_path + global.Animals[sp1].name + global.paralogs_ext
                               : global.homology_path + global.Animals[sp1].name + global.homology_ext;
    string str;
    string::size_type offset = 0;
    fstream df;
    df.open(filename.c_str(), ios_base::in | ios_base::binary);
    if (!df || df.bad()) {
        if (global.rank == 0)
            cout << "Can't open " << filename << endl;
        return false;
    }

    Species& species1 = global.Animals[sp1];

    for (int line = 1; !df.eof(); line++) {
        df.getline(buf, buflen);
        if (df.bad())
            return false;               // IO error
        if (df.eof() && *buf == 0)
            break;                      // EOF or empty line

        // Read & parse current pair
        str.assign(buf);
        if (*(str.end()-1) == '\r') str.erase(str.end()-1);
        offset = 0;
        string name1 = GetToken(str, offset, true);
        string name2 = GetToken(str, offset, true);
        if (name1.empty() || name2.empty())
            continue;

        Piter piter = global.stableid.find(name1);
        if (piter == global.stableid.end())
            continue;
        PGene pg1 = piter->second;

        piter = global.stableid.find(name2);
        if (piter == global.stableid.end())
            continue;
        PGene pg2 = piter->second;

        // Log submatrix element
        if (logging && ((pg1->log && pg2->log) || (global.log_union && (pg1->log || pg2->log)))) {
            cerr << global.Animals[pg1->sp].name << tab << pg1->name << tab 
                 << global.Animals[pg2->sp].name << tab << pg2->name << endl;
        }

        // Store pairing in both genes (only if new)
        if (pg1 != pg2 && IsNewPair(pg1, pg2)) {
            pg1->homologs[pg2->sp].push_back( Homolog(pg2,0,0x7FFFFFFF) );
            pg2->homologs[pg1->sp].push_back( Homolog(pg1,0,0x7FFFFFFF) );
            npairs++;
        }

        if (global.rank == 0 && !global.qquiet 
            && inmatrixstep && line % inmatrixstep == 0) {
            if (logging)                cout << back9 << setw(9) << line;
            else if (global.size > 1)   cout << back9 << setw(9) << line;
            else                        cerr << back9 << setw(9) << line;
        }
    }
    if (global.rank == 0 && !global.qquiet)
        cout << back9 << setw(9) << npairs;
    return true;
}

bool    ReadClusterData (const char* filename) {
    char buf[buflen];
    int homolog_count = 0;
    bool logging = global.log_contig || global.log_contigno>=0 || global.log_gene ||
        global.log_protein || global.log_verbose;
    fstream df;
    df.open(filename, ios_base::in | ios_base::binary);
    if (!df || df.bad()) {
        if (global.rank == 0)
            cout << "Can't open " << filename << endl;
        return false;
    }

    df.getline(buf, buflen);      // Read heading line
    string str(buf);
    if (*(str.end()-1) == '\r') str.erase(str.end()-1);
    string::size_type offset = 0;

    int field_no;
    string name;

    // Just find ProteinID field
    for (field_no = 0; ; field_no++) {        

        name = GetToken(str, offset, true);
        if (name.empty()) {
            if (global.rank == 0)
                cout << "Can't find " << global.myfields[field_protein] 
                     << " field in " << filename << endl;
            return false;
        }
        // Remove quotes if present
        if (name[0] == '\"' && name[name.length()-1] == '\"')
            name = name.substr(1, name.length()-2);

        if (name == global.myfields[field_protein])
            break;
    }

    int cl_read = 0;        // Cluster read count
    int cl_proc = 0;        // Cluster processed count
    int xgene_proc = 0;     // Reference's gene count
    int line = 1;           // First line of current cluster

    while (!df.eof()) {
        df.getline(buf, buflen);
        line++;
        if (df.bad()) return false;             // IO error
        if (df.eof() && *buf == 0) continue;    // EOF or empty line

        // Collect cluster proteins
        vector <string> clust;

        do {
            string str(buf);
            if (*(str.end()-1) == '\r') str.erase(str.end()-1);
            string protein;
            offset = 0;
            int i;
            for (i = 0; i <= field_no; i++) {
                protein = GetToken(str, offset, true);
                if (protein.empty()) break;
            }
            if (i <= field_no) break;
            if (!protein.empty())       // skip gene w/o protein
                clust.push_back(protein);

            df.getline(buf, buflen);
            if (df.bad()) return false;         // IO error
            if (df.eof() && *buf == 0) break;
        } while (true);

        // Process the cluster
        bool processed = false;
        PGene pg1, pg2;

        for (int i = 0; i < (int)clust.size(); i++) {   // Loop over 1st genes
            Piter piter = global.stableid.find(clust[i]);
            if (piter != global.stableid.end())
                pg1 = piter->second;
            else continue;

            if (pg1->sp > 0 && pg1->sp < global.nAnimals 
                && global.Animals[pg1->sp].need) {

                for (int j = i + 1; j < (int)clust.size(); j++) {   // Loop over 2nd genes
                    piter = global.stableid.find(clust[j]);
                    if (piter != global.stableid.end())
                        pg2 = piter->second;
                    else continue;

                    if (pg2->sp > 0 && pg2->sp < global.nAnimals                    // Fill homologous pair
                        && global.Animals[pg2->sp].need && IsNewPair(pg1, pg2)) { 
                        processed = true;
                        // Store pairing in both genes
                        pg1->homologs[pg2->sp].push_back( Homolog(pg2,0,0x7FFFFFFF) );
                        pg2->homologs[pg1->sp].push_back( Homolog(pg1,0,0x7FFFFFFF) );

                        // Log submatrix element
                        if (logging && ((pg1->log && pg2->log) || (global.log_union 
                            && (pg1->log || pg2->log)))) {
                            cerr << global.Animals[pg1->sp].name << tab << pg1->name << tab << clust[i] << tab 
                                 << global.Animals[pg2->sp].name << tab << pg2->name << tab << clust[j] << endl;
                        }

                        if (global.rank == 0 && !global.qquiet 
                            && inogroupstep && homolog_count % inogroupstep == 0) {
                            if (logging)                cout << homolog_count << "    \r";
                            else if (global.size > 1)   cout << homolog_count << "    \r";
                            else                        cerr << homolog_count << "    \r";
                        }
                        homolog_count++;
                    }
                }       // next j
            }
        }       // next i

        line += (int)clust.size() + 1;
        cl_read++;
        if (processed)
            cl_proc++;
        clust.clear();
    }
    df.close();

    if (global.rank == 0 && !global.qquiet) {
        cout << "Clusters read: " << cl_read << ", processed: " << cl_proc << endl;
        cout << "Orthologous pair read: " << homolog_count << endl;
        cout << "Contigs, genes and pairs collected per species:" << endl;
    }

    // Calculate genes & pairs
    for (int k = 0; k < global.nAnimals; k++) {
        Species& species = global.Animals[k];
        if (!species.need) continue;
        Citer cit;
        Giter git;
        int nGenes = 0;
        int nGenes_m = 0;
        int nContigs = (int)species.contigs.size();
        int nContigs_m = 0;
        int nPairs = 0;
        int nPairs_m = 0;

        cit = species.contigs.begin();
        for ( ; cit != species.contigs.end(); cit++) {
            int count = (int)cit->second.genes.size();
            nGenes += count;
            if (count > 1) {
                nContigs_m++;
                nGenes_m += count;
            }

            git = cit->second.genes.begin();
            for ( ; git != cit->second.genes.end(); git++) {
                int pp = 0;
                if (k == 0) {
                    for (int j = 1; j < global.nAnimals; j++)
                        if (global.Animals[j].need)
                            pp += (int)git->second.homologs[j].size();
                }
                else
                    pp = (int)git->second.homologs[0].size();
                nPairs += pp;
                if (count > 1)
                    nPairs_m += pp;
            }
        }

        if (global.rank == 0 && !global.qquiet) {
            cout << "c:" << setw(4) << right << nContigs_m << "/" << setw(4) << left << nContigs
                 << " g:" << setw(6) << right << nGenes_m << "/" << setw(6) << left << nGenes
                 << " p:" << setw(6) << right << nPairs_m << "/" << setw(6) << left << nPairs 
                 << "  " << species.name << endl;
        }
    }

    return true;
}

bool    ReadOgroupData (const char* filename) {
    char buf[buflen];
    int homolog_count = 0;
    bool logging = global.log_contig || global.log_contigno>=0 || global.log_gene ||
        global.log_protein || global.log_verbose;

    fstream df;
    df.open(filename, ios_base::in | ios_base::binary);
    if (!df || df.bad()) {
        if (global.rank == 0)
            cout << "Can't open " << filename << endl;
        return false;
    }

    df.getline(buf, buflen);      // Read heading line
    string str(buf);
    if (*(str.end()-1) == '\r') str.erase(str.end()-1);
    string::size_type offset = 0;

    int field_no;
    string name;
    Species species;                // a virtual species
    for (int i = 0; i < global.nColumns; i++)
        species.myfields.push_back(-1);

    for (field_no = 0; ; field_no++) {      // columns of this ogroup file
        name = GetToken(str, offset, true);
        if (name.empty()) break;

        int j;
        for (j = 0; j < global.nColumns; j++) {
            if (name == global.myfields[j]) {
                species.myfields[j] = field_no;
                species.required.push_back(j);
                break;
            }
        }
        if (j >= global.nColumns)
            species.required.push_back(-1);

        species.fields.push_back(name);
    }
    // Check that all required sp fields present
    for (int j = 0; j < ncol; j++) {
        if (species.myfields[j] < 0) {
            if (global.rank == 0)
                cout << "Required field '" << global.myfields[j] << "' of " 
                     << species.name << " is absent in " << filename << endl;
            return false;
        }
    }
    // Add virtual field with paralog count
    if (species.neednumpar) {
        species.myfields[global.fnumpara] = (int)species.fields.size();
        species.fields.push_back(paracount);
        species.required.push_back(global.fnumpara);
    }
    // now apply equally to all species and build map of species names
    map <string, int> spid2no;
    for (int k = 0; k < global.nAnimals; k++) {
        Species& s = global.Animals[k];
        if (!s.need) continue;
        spid2no.insert( pair <string, int> (s.name, k) );

        for (int i = 0; i < (int)species.fields.size(); i++) {
            s.fields.push_back(species.fields[i]);
            s.required.push_back(species.required[i]);
        }
        for (int i = 0; i < (int)species.myfields.size(); i++)
            s.myfields[i] = species.myfields[i];
    }

    int og_count = 0;       // Orthogroup processed count
    int orth_count = 0;     // Orthologous pairs count
    int line = 1;           // First line of current cluster

    while (!df.eof()) {
        df.getline(buf, buflen);
        line++;
        if (df.bad()) return false;             // IO error
        if (df.eof() && *buf == 0) continue;    // EOF or empty line

        // Collect cluster genes
        vector <PGene> pgenes;

        while (!df.eof()) {
            string str(buf);
            if (*(str.end()-1) == '\r') str.erase(str.end()-1);

            // Read and parse gene lines
            string  spid;       // species id  
            Contig  contig;
            Gene    gene;
            Citer   cit;
            Giter   git;
            string::size_type offset = 0;

            for (field_no = 0; field_no < (int)species.fields.size(); field_no++) {
                name = GetToken(str, offset, true);
                istringstream ss(name);

                switch (species.required[field_no]) {
                    case field_protein:
                        species.name = name;        // used for Species in this mode
                        break;
                    case field_gene:
                        gene.name = name;       // Gene
                        break;
                    case field_contig:
                        contig.name = name;     // Contig
                        break;
                    case field_begin:
                        ss >> gene.begin;       // Begin
                        break;
                    case field_end:
                        ss >> gene.end;         // End
                        break;
                    case field_strand:
                        ss >> gene.strand;      // Strand
                        break;
                }
                gene.fields.push_back(name);
            }

            // find species no.
            if (species.name.empty()) break;    // finish this cluster
            map <string, int>::iterator sit = spid2no.find(species.name);
            if (sit != spid2no.end()) {
                int sp = sit->second;
                Species& spec = global.Animals[sp];

                gene.sp = sp;           // Species - back reference

                if (!gene.name.empty() && !contig.name.empty()) {
                    cit = spec.contigs.find(contig.name);
                    if (cit == spec.contigs.end())
                        cit = spec.contigs.insert(cit, Cpair(contig.name, contig));
                    gene.cit = cit;     // Contig - back reference

                    git = cit->second.genes.find(gene.name);
                    if (git == cit->second.genes.end())
                        git = cit->second.genes.insert(git, Gpair(gene.name, gene));

                    PGene pgene = (Gene*)&git->second;

                    Piter piter = global.stableid.find(gene.name);
                    if (piter == global.stableid.end()) {
                        global.stableid.insert( Ppair(gene.name, pgene) );
                        pgenes.push_back(pgene);
                    }
                    else {
                        int i = 0;
                        for ( ; i < (int)pgenes.size(); i++) {
                            if (pgenes[i] == piter->second)
                                break;
                        }
                        if (i >= (int)pgenes.size() && global.rank == 0) {
                            // allow for genes belonging to other orthogroup
                            pgenes.push_back(pgene);
                            //if (!global.qquiet)
                            //  cout << "Duplicate gene " << gene.name << " in line " << line << endl;
                        }
                    }
                }
            }
            df.getline(buf, buflen);
            line++;
            if (df.bad()) return false;             // IO error
            if (df.eof() && *buf == 0) break;       // EOF or empty line
        }

        // write homologs from this cluster data
        if (!pgenes.empty()) {
            PGene pg1, pg2;
            for (int i = 0; i < (int)pgenes.size(); i++) {  // loop over 1st genes
                pg1 = pgenes[i];
                if (pg1->sp < 0 || pg1->sp >= global.nAnimals
                    || !global.Animals[pg1->sp].need) continue;

                for (int j = i + 1; j < (int)pgenes.size(); j++) {    // loop over 2nd gene
                    pg2 = pgenes[j];
                    if (pg2->sp < 0 || pg2->sp >= global.nAnimals
                        || !global.Animals[pg2->sp].need) continue;

                    if (IsNewPair(pg1, pg2)) {      // Fill orthologous pair
                        // Store pairing in both genes
                        pg1->homologs[pg2->sp].push_back( Homolog(pg2,0,0x7FFFFFFF) );
                        pg2->homologs[pg1->sp].push_back( Homolog(pg1,0,0x7FFFFFFF) );

                        // Log submatrix element
                        if (logging && ((pg1->log && pg2->log) || (global.log_union 
                            && (pg1->log || pg2->log)))) {
                            cerr << global.Animals[pg1->sp].name << tab << pg1->name << tab 
                                 << global.Animals[pg2->sp].name << tab << pg2->name << endl;
                        }

                        if (global.rank == 0 && !global.qquiet 
                            && inogroupstep && orth_count % inogroupstep == 0) {
                            if (logging)                cout << orth_count << "    \r";
                            else if (global.size > 1)   cout << orth_count << "    \r";
                            else                        cerr << orth_count << "    \r";
                        }
                        orth_count++;
                    }
                }
            }
        }
        else continue;

        pgenes.clear();
        og_count++;
    }
    df.close();

    if (global.rank == 0 && !global.qquiet) {
        cout << "Orthogroups processed: " << og_count
            << "  Orthologous pairs written: " << orth_count << endl;
        cout << "Contigs, genes and pairs collected per species:" << endl;
    }

    // Calculate genes & pairs
    for (int k = 0; k < global.nAnimals; k++) {
        Species& species = global.Animals[k];
        if (!species.need) continue;
        Citer cit;
        Giter git;
        int nGenes = 0;
        int nGenes_m = 0;
        int nContigs = (int)species.contigs.size();
        int nContigs_m = 0;
        int nPairs = 0;
        int nPairs_m = 0;

        cit = species.contigs.begin();
        for ( ; cit != species.contigs.end(); cit++) {
            int count = (int)cit->second.genes.size();
            nGenes += count;
            if (count > 1) {
                nContigs_m++;
                nGenes_m += count;
            }

            git = cit->second.genes.begin();
            for ( ; git != cit->second.genes.end(); git++) {
                int pp = 0;
                if (k == 0) {
                    for (int j = 1; j < global.nAnimals; j++)
                        if (global.Animals[j].need)
                            pp += (int)git->second.homologs[j].size();
                }
                else
                    pp = (int)git->second.homologs[0].size();
                nPairs += pp;
                if (count > 1)
                    nPairs_m += pp;
            }
        }

        if (global.rank == 0 && !global.qquiet) {
            cout << "c:" << setw(4) << right << nContigs_m << "/" << setw(4) << left << nContigs
                 << " g:" << setw(6) << right << nGenes_m << "/" << setw(6) << left << nGenes
                 << " p:" << setw(6) << right << nPairs_m << "/" << setw(6) << left << nPairs 
                 << "  " << species.name << endl;
        }
    }

    return true;
}

bool    ReadGeneInfo (int sp) {
    Species& species = global.Animals[sp];
    string filename = global.info_path + species.name + global.info_ext;
    char buf[buflen];
    bool logging = global.log_contig || global.log_contigno>=0 || global.log_gene || global.log_protein;
    fstream df;
    df.open(filename.c_str(), ios_base::in | ios_base::binary);
    if (!df || df.bad()) {
        if (global.rank == 0)
            cout << "Can't open " << filename << endl;
        return false;
    }

    df.getline(buf, buflen);      // Read and check heading line
    string str(buf);
    if (*(str.end()-1) == '\r') str.erase(str.end()-1);
    string::size_type offset = 0;

    int field_no;
    string name;

    for (field_no = 0; ; field_no++) {     // this species columns
        name = GetToken(str, offset, true);
        if (name.empty()) break;

        int j;
        for (j = 0; j < global.nColumns; j++) {
            if (name == global.myfields[j]) {
                species.myfields[j] = field_no;
                species.required.push_back(j);
                break;
            }
        }
        if (j >= global.nColumns)
            species.required.push_back(-1);

        species.fields.push_back(name);
    }
    // Check that all required sp fields present
    for (int j = 0; j < ncol; j++) {
        if (species.myfields[j] < 0) {
            if (global.rank == 0)
                cout << "Required field '" << global.myfields[j] << "' of " 
                     << species.name << " is absent in " << filename << endl;
            return false;
        }
    }
    // Add virtual field with paralog count
    if (species.neednumpar) {
        species.myfields[global.fnumpara] = (int)species.fields.size();
        species.fields.push_back(paracount);
        species.required.push_back(global.fnumpara);
    }

    // Read and parse protein/gene lines
    string  protein;
    Contig  contig;
    Gene    gene;
    Citer   cit;
    Giter   git;
    int line=1, nprot=0, ngenes=0;

    while (!df.eof()) {
        gene.fields.clear();
        df.getline(buf, buflen);
        line++;
        if (df.bad()) return false;             // IO error
        if (df.eof() && *buf == 0) break;       // EOF or empty line

        // Read current line & store gene information
        str.assign(buf);
        if (*(str.end()-1) == '\r') str.erase(str.end()-1);
        offset = 0;

        for (field_no = 0; field_no < (int)species.fields.size(); field_no++) {                             
            name = GetToken(str, offset, true);
            istringstream ss(name);

            switch (species.required[field_no]) {
                case field_protein:
                    protein = name;         // Protein
                    break;
                case field_gene:
                    gene.name = name;       // Gene
                    break;
                case field_contig:
                    contig.name = name;     // Contig
                    break;
                case field_begin:
                    ss >> gene.begin;       // Begin
                    break;
                case field_end:
                    ss >> gene.end;         // End
                    break;
                case field_strand:
                    ss >> gene.strand;      // Strand
                    break;
            }

            gene.fields.push_back(name);    // Original field
        }

        gene.sp = sp;                  // Species - back reference

        if (protein.empty()) continue;      // skip genes w/o protein
        nprot++;

        if (!gene.name.empty() && !contig.name.empty()) {
            cit = species.contigs.find(contig.name);
            if (cit == species.contigs.end())
                cit = species.contigs.insert( cit, Cpair(contig.name, contig) );
            gene.cit = cit;                // Contig - back reference

            git = cit->second.genes.find(gene.name);
            if (git == cit->second.genes.end()) {
                ngenes++;
                git = cit->second.genes.insert( git, Gpair(gene.name, gene) );
            }

            PGene pgene = (Gene*)&git->second;
            Piter piter = global.stableid.find(gene.name);
            if (piter == global.stableid.end())
                global.stableid.insert( Ppair(gene.name, pgene) );
            piter = global.stableid.find(protein);
            if (piter == global.stableid.end())
                global.stableid.insert( Ppair(protein, pgene) );
            else if (global.rank == 0)
                cout << "Duplicate protein " << protein << " in line " << line << endl;
        }

        if (global.rank == 0 && !global.qquiet 
            && inrecordstep && line % inrecordstep == 0) {
            if (logging)            cout << line << "    \r";
            if (global.size > 1)    cout << line << "    \r";
            else                    cerr << line << "    \r";
        }
    }
    df.close();

    int c1=0, c2=0;
    cit = global.Animals[sp].contigs.begin();
    for ( ; cit != global.Animals[sp].contigs.end(); cit++) {
        Contig &cntg = cit->second;
        if (cntg.genes.size() == 1) c1++;
        if (cntg.genes.size() == 2) c2++;
    }

    if (global.rank == 0 && !global.qquiet) {
        cout << "Lines read: " << line << "  genes: " << ngenes << "  proteins: " 
             << nprot << "  contigs: " << global.Animals[sp].contigs.size() 
             << "  c1: " << c1 << "  c2: " << c2 << endl;
    }

    return true;
}

bool    ReadMatrix (int sp) {
    char buf[buflen];
    int line; 
    double npairs = 0.0;
    string::size_type offset;
    bool logging = global.log_contig || global.log_contigno>=0 || global.log_gene ||
        global.log_protein || global.log_verbose;
    string filename = global.matrix_path + global.Animals[sp].name + global.matrix_ext;

    fstream df;
    df.open(filename.c_str(), ios_base::in | ios_base::binary);
    if (!df || df.bad()) {
        if (global.rank == 0)
            cout << "Can't open " << filename << endl;
        return false;
    }

    string lastprot1;
    Piter pit1;
    for (line=1; !df.eof(); line++) {
        df.getline(buf, buflen);
        if (df.bad()) return false;             // IO error
        if (df.eof() && *buf == 0) break;       // EOF or empty line

        // Read & parse current pair
        string str(buf);
        if (*(str.end()-1) == '\r') str.erase(str.end()-1);
        string prot1, prot2;
        offset = 0;

        prot1 = GetToken(str, offset, true);    // Protein 1
        if (prot1.empty()) {
            if (global.rank == 0)
                cout << "Field 1 error in line " << line << endl;
            continue;
        }
        if (prot1 != lastprot1) {
            pit1 = global.stableid.find(prot1);
            if (pit1 == global.stableid.end())
                continue;
            lastprot1 = prot1;
        }
        PGene pg1 = pit1->second;
        int sp1 = pg1->sp;
        if (sp1 != sp) {
            if (global.rank == 0)
                cout << "Species " << sp1 << " encountered in line " << line << endl;
            continue;
        }

        prot2 = GetToken(str, offset, true);    // Protein 2
        if (prot2.empty()) {
            if (global.rank == 0)
                cout << "Field 2 error in line " << line << endl;
            continue;
        }
        Piter pit2 = global.stableid.find(prot2);
        if (pit2 == global.stableid.end())
            continue;           // skip unknown or alien proteins
        PGene pg2 = pit2->second;
        int sp2 = pg2->sp;

        string rscore = GetToken(str, offset, true);  // Raw score
        int rawscore = -1;
        istringstream rs(rscore);
        rs >> rawscore;
        if (rawscore < 0 || rscore.empty()) {
            if (global.rank == 0)
                cout << "Score invalid or absent from line " << line << endl;
            continue;
        }

        string evalue = GetToken(str, offset, true);  // E-value
        double expect = -1;
        istringstream es(evalue);
        es >> expect;
        if (expect < 0 || evalue.empty()) {
            if (global.rank == 0)
                cout << "E-value invalid or absent from line " << line << endl;
            continue;
        }
        if (expect > global.Elimit)
            continue;       // skip homologs with too great E-value

        // Log submatrix element
        if (logging && ((pg1->log && pg2->log) || (global.log_union && (pg1->log || pg2->log)))) {
            cerr << global.Animals[sp1].name << tab << pg1->name << tab << prot1 << tab 
                 << global.Animals[sp2].name << tab << pg2->name << tab << prot2 << tab
                 << rawscore << tab << expect << endl;
        }

        vector <Homolog> & vhg1 = pg1->homologs[sp2];
        vector <Homolog>::iterator hgit1 = vhg1.begin();
        for ( ; hgit1 != vhg1.end(); hgit1++) {
            if (hgit1->pgene == pg2) {           // modify old pair if needed
                if (hgit1->evalue > expect)  hgit1->evalue = expect;
                if (hgit1->score < rawscore) hgit1->score  = rawscore;
                break;
            }
        }
        vector <Homolog> & vhg2 = pg2->homologs[sp1];
        vector <Homolog>::iterator hgit2 = vhg2.begin();
        for ( ; hgit2 != vhg2.end(); hgit2++) {
            if (hgit2->pgene == pg1) {           // modify old pair if needed
                if (hgit2->evalue > expect)  hgit2->evalue = expect;
                if (hgit2->score < rawscore) hgit2->score  = rawscore;
                break;
            }
        }
        if (hgit1 == vhg1.end() && hgit2 == vhg2.end()) {  // add new pair(s) if needed
            pg1->homologs[sp2].push_back( Homolog(pg2, expect, rawscore) );
            if (pg2 != pg1)
                pg2->homologs[sp1].push_back( Homolog(pg1, expect, rawscore) );
            npairs += 1.0;
        }
        else if (hgit1 == vhg1.end()) {
            pg1->homologs[sp2].push_back( Homolog(pg2, expect, rawscore) );
            npairs += 0.5;
        }
        else if (hgit2 == vhg2.end()) {
            pg2->homologs[sp1].push_back( Homolog(pg1, expect, rawscore) );
            npairs += 0.5;
        }

        if (global.rank == 0 && !global.qquiet 
            && inmatrixstep && line % inmatrixstep == 0) {
            if (logging)                cout << back9 << setw(9) << line;
            else if (global.size > 1)   cout << back9 << setw(9) << line;
            else                        cerr << back9 << setw(9) << line;
        }
    }

    if (global.rank == 0 && !global.qquiet)
        cout << back9 << setw(9) << fixed << setprecision(1) << npairs;

    return true;
}

// Not used for ReadMatrix!
bool    IsNewPair (const PGene pg1, const PGene pg2) {
    static PGene old1 = 0; 
    static PGene old2 = 0;
    if (pg1==old1 && pg2==old2)
        return false;
    else {
        old1=pg1; old2=pg2;
    }
    vector <Homolog>::iterator pgit;
    vector <Homolog> & vpg1 = pg1->homologs[pg2->sp];
    for (pgit = vpg1.begin(); pgit != vpg1.end(); pgit++)
        if (pgit->pgene == pg2) return false;
    vector <Homolog> & vpg2 = pg2->homologs[pg1->sp];
    for (pgit = vpg2.begin(); pgit != vpg2.end(); pgit++)
        if (pgit->pgene == pg1) return false;
    return true;
}

// Return species no. or -1 from Gene/Protein ID 
int     FindOrganism (const string & str) {
    Piter piter = global.stableid.find(str);
    if (piter != global.stableid.end())
        return piter->second->sp;
    else return -1;
}

// Return specno taken from the predicate term: 
// >=0: animal no. | <0: taxon no. | unknown_species 
int     FindSpecno (string & spec) {
    int sp = unknown_species;
    if (!spec.empty() && !IsComment(spec.c_str())) {
        if (spec[0] == startax) {       // taxon
            int ntaxa = (int)global.taxa.size();
            for (sp = 0; sp < ntaxa; sp++)
                if (global.taxa[sp].name == spec) 
                    break;
            sp = (sp >= ntaxa ? unknown_species : -sp);
        }
        else {
            for (sp = 0; sp < global.nAnimals; sp++)
                if (global.Animals[sp].name == spec) 
                    break;
            if (sp >= global.nAnimals)
                sp = unknown_species;
        }
    }
    return sp;
}
