// synteny : checking of the predicate
#include "synteny.h"

using namespace std;

// Return whether 1st contig contains more genes than 2nd contig
bool    GreaterGenes(Citer c1, Citer c2) {
    return c1->second.genes.size() > c2->second.genes.size();
}

bool  ExceedSpan(const Group & grp, const int span) {
    if (grp.gsize == 1) return false;
    else if (grp.gsize == 2 || grp.gsize == 3 && !grp.pgene[2]) {
        if (!grp.pgene[0] || !grp.pgene[1])
            return true;    //false;
        Gene & x = *grp.pgene[0];
        Gene & y = *grp.pgene[1];
        if (grp.pgene[0] == grp.pgene[1])
            return true;   // Skip degenerated pairs
        else if (global.span_outer)
            return __max(x.end, y.end) - __min(x.begin, y.begin) > span;
        else if (global.span_center)
            return abs(x.begin + x.end - y.begin - y.end) > span*2;
        else 
            return (x.begin < y.end ? y.begin - x.end : x.begin - y.end) > span;
    }
    else if (grp.gsize == 3) {
        if (!grp.pgene[0] || !grp.pgene[1])
            return true;    //false;
        Gene & x = *grp.pgene[0];
        Gene & y = *grp.pgene[1];
        Gene & z = *grp.pgene[2];
        if (grp.pgene[0] == grp.pgene[1] || grp.pgene[0] == grp.pgene[2] || 
            ZneY && grp.pgene[1] == grp.pgene[2])
                return true;   // Skip degenerated triplets
        else if (global.span_outer) {
            int rxy = __max(x.end, y.end) - __min(x.begin, y.begin);
            int rxz = __max(x.end, z.end) - __min(x.begin, z.begin);
            return __max(rxy, rxz) > span;
        }
        else if (global.span_center) {
            int rxy = abs(x.begin + x.end - y.begin - y.end);
            int rxz = abs(x.begin + x.end - z.begin - z.end);
            return __max(rxy, rxz) > span*2;
        }
        else {
            int rxy = x.begin < y.end ? y.begin - x.end : x.begin - y.end;
            int rxz = x.begin < z.end ? z.begin - x.end : x.begin - z.end;
            return __max(rxy, rxz) > span;
        }
    }
    return false;
}

bool  InSynteny(const Group & g1, const Group & g2) {

    if (g1.gsize != g2.gsize) return false;

    if (g1.gsize == 1)
        return (g1.pgene[0] != 0 && g2.pgene[0] != 0);

    else if (g1.gsize == 2) {
        if (g1.pgene[0]==0 || g2.pgene[0]==0 || g1.pgene[1]==0 || g2.pgene[1]==0)
            return false;
        Gene & x    = *(g1.pgene[0]);
        Gene & y    = *(g1.pgene[1]);
        Gene & x1   = *(g2.pgene[0]);
        Gene & y1   = *(g2.pgene[1]);

        if (global.mode_direct) {
            if (x.strand == x1.strand && y.strand == y1.strand || 
                global.mode_mirror && x.strand == -x1.strand && y.strand == -y1.strand)
                ;     // fall through
            else
                return false;
        }

        if (global.mode_order && !global.mode_direct) {
            if (x.begin < y.begin && x1.begin < y1.begin || 
                x.begin >= y.begin && x1.begin >= y1.begin ||
                global.mode_mirror && x.begin < y.begin && x1.begin >= y1.begin ||
                global.mode_mirror && x.begin >= y.begin && x1.begin < y1.begin)
                ;     // fall through
            else
                return false;
        }
        else if (global.mode_order) {
            if (x.strand == x1.strand && x.begin < y.begin && x1.begin < y1.begin ||
                x.strand == x1.strand && x.begin >= y.begin && x1.begin >= y1.begin ||
                global.mode_mirror && x.strand != x1.strand && x.begin < y.begin && x1.begin >= y1.begin ||
                global.mode_mirror && x.strand != x1.strand && x.begin >= y.begin && x1.begin < y1.begin)
                ;     // fall through
            else
                return false;
        }

        return true;
    }

    else if (g1.gsize == 3) {
        if (g1.pgene[0]==0 || g1.pgene[1]==0 || g1.pgene[2]==0 || 
            g2.pgene[0]==0 || g2.pgene[1]==0 || g2.pgene[2]==0)
                return false;
        Gene & x    = *(g1.pgene[0]);
        Gene & y    = *(g1.pgene[1]);
        Gene & z    = *(g1.pgene[2]);
        Gene & x1   = *(g2.pgene[0]);
        Gene & y1   = *(g2.pgene[1]);
        Gene & z1   = *(g2.pgene[2]);

        if (global.mode_direct) {
            if (x.strand == x1.strand && y.strand == y1.strand && z.strand == z1.strand || 
                global.mode_mirror && x.strand == -x1.strand && y.strand == -y1.strand && z.strand == -z1.strand)
                ;     // fall through
            else
                return false;
        }

        if (global.mode_order && !global.mode_direct) {
            if (x.begin < y.begin && y.begin < z.begin && x1.begin < y1.begin && y1.begin < z1.begin || 
                x.begin >= y.begin && y.begin >= z.begin && x1.begin >= y1.begin && y1.begin >= z1.begin ||
                x.begin < z.begin && z.begin < y.begin && x1.begin < z1.begin && z1.begin < y1.begin ||
                x.begin >= z.begin && z.begin >= y.begin && x1.begin >= z1.begin && z1.begin >= y1.begin ||
                y.begin < x.begin && x.begin < z.begin && y1.begin < x1.begin && x1.begin < z1.begin ||
                y.begin >= x.begin && x.begin >= z.begin && y1.begin >= x1.begin && x1.begin >= z1.begin ||
                global.mode_mirror && 
                (x.begin < y.begin && y.begin < z.begin && x1.begin >= y1.begin && y1.begin >= z1.begin ||
                x.begin >= y.begin && y.begin >= z.begin && x1.begin < y1.begin && y1.begin < z1.begin ||
                x.begin < z.begin && z.begin < y.begin && x1.begin >= z1.begin && z1.begin >= y1.begin ||
                x.begin >= z.begin && z.begin >= y.begin && x1.begin < z1.begin && z1.begin < y1.begin ||
                y.begin < x.begin && x.begin < z.begin && y1.begin >= x1.begin && x1.begin >= z1.begin ||
                y.begin >= x.begin && x.begin >= z.begin && y1.begin < x1.begin && x1.begin < z1.begin))
                ;     // fall through
            else
                return false;
        }
        else if (global.mode_order) {  // (&& global.mode_direct)
            if (x.strand == x1.strand && 
                (x.begin < y.begin && y.begin < z.begin && x1.begin < y1.begin && y1.begin < z1.begin ||
                x.begin >= y.begin && y.begin >= z.begin && x1.begin >= y1.begin && y1.begin >= z1.begin ||
                x.begin < z.begin && z.begin < y.begin && x1.begin < z1.begin && z1.begin < y1.begin ||
                x.begin >= z.begin && z.begin >= y.begin && x1.begin >= z1.begin && z1.begin >= y1.begin ||
                y.begin < x.begin && x.begin < z.begin && y1.begin < x1.begin && x1.begin < z1.begin ||
                y.begin >= x.begin && x.begin >= z.begin && y1.begin >= x1.begin && x1.begin >= z1.begin) ||
                global.mode_mirror && x.strand == -x1.strand && 
                (x.begin < y.begin && y.begin < z.begin && x1.begin >= y1.begin && y1.begin >= z1.begin ||
                x.begin >= y.begin && y.begin >= z.begin && x1.begin < y1.begin && y1.begin < z1.begin ||
                x.begin < z.begin && z.begin < y.begin && x1.begin >= z1.begin && z1.begin >= y1.begin ||
                x.begin >= z.begin && z.begin >= y.begin && x1.begin < z1.begin && z1.begin < y1.begin ||
                y.begin < x.begin && x.begin < z.begin && y1.begin >= x1.begin && x1.begin >= z1.begin ||
                y.begin >= x.begin && x.begin >= z.begin && y1.begin < x1.begin && x1.begin < z1.begin))
                ;     // fall through
                else
                    return false;
        }

        return true;
    }
    return false;
}

// Return: satisfied/unsatisfied, side effects in groups and detail
bool Predicate(Gene & x, vector<Group> & groups) {
    Group g0(&x), g1, g2, g3;       // groups for current predicate term (two pairs max)
    int sp0=0, sp1, sp2, sp3;       // species/taxa numbers for current predicate term 
    sp1 = unknown_species;
    sp3 = unknown_species;
    Term & gt0 = global.terms[0];
    Term parminit = gt0;
    int range0 = gt0.range, range1;
    int tno = 0;
    int orcount  = -1;  // means no OR entered
    int andcount = -1;  // means no AND entered
    int overloop = 0;   // OVER-loop variables
    Giter oyit, ozit;
    bool exspan = false;
    bool logging = (global.size == 1) && (global.log_verbose || x.log);
    bool logany = global.log_contig || global.log_contigno || global.log_gene ||
        global.log_geneno || global.log_protein || global.log_verbose;
    int y_no = 0;
    if (logging)
        cerr << "\nX=" << x.name << endl;

    while (tno >= 0 && tno < (int)global.terms.size()) {
        Term & t = global.terms[tno];

        if (logging) {
            cerr << "#" << tno << " " << TermOper[t.oper];
            if (t.oper == OVER) 
                cerr << "_" << overloop;
            cerr << " \t";
            if (t.sp == unknown_species)
                cerr << setw(16) << " ";
            else if (t.sp >= 0 && t.sp < global.nAnimals)
                cerr << left << setw(16) << global.Animals[t.sp].name;
            else if (t.sp < 0 && t.sp > -(int)global.taxa.size())
                cerr << left << setw(16) << global.taxa[-t.sp].name;
            else
                cerr << left << setw(16) << "????????";
            if (t.yes == YES)
                cerr << right << setw(4) << label_yes;
            else if (t.yes == NO)
                cerr << right << setw(4) << label_no;
            else
                cerr << right << setw(4) << t.yes;
            if (t.no == t.yes)
                cerr << setw(4) << " ";
            else if (t.no == YES)
                cerr << right << setw(4) << label_yes;
            else if (t.no == NO)
                cerr << right << setw(4) << label_no;
            else
                cerr << right << setw(4) << t.no;
            if (t.oper==SET || t.oper==IN || t.oper==IN2 || t.oper==OVER)
                cerr << "  " << right << setw(2) << t.nwit << scientific 
                    << setprecision(1) << setw(9) << t.E << " " << t.range 
                    << setw(3) << t.uselast0 << setw(3) << t.uselast1 << setw(3) << t.BBH;
            else if (t.oper==ADD) {
                cerr << "   Fields:";
                bool first = true;
                for (int fo = 1; fo <= maxfield; fo++) {
                    int my = 0;
                    for ( ; my < maxfield; my++)
                        if (t.forder[my] == fo) {
                            cerr << (first? ' ': ',') << global.myfields[my];
                            first = false;
                            break;
                        }
                    if (my >= maxfield) break;
                }
                //cerr << "  " << right << setw(2) << t.nwit << "  Fields=" 
                //    << hex << left << t.fmask << dec << right;
            }
            cerr << endl;
        }

        if (t.oper == NOP || t.oper == GOTO || t.oper == NEXT) {
            tno = t.yes;
        }
        else if (t.oper == SET) {
            gt0.nwit    = t.nwit;
            gt0.range   = t.range;
            gt0.E       = t.E;
            gt0.uselast0 = t.uselast0;
            gt0.uselast1 = t.uselast1;
            gt0.BBH     = t.BBH;
            tno = t.yes;
        }
        else if (t.oper == BOR) {
            orcount = 0;
            if (logging) 
                cerr << "OR_count=" << orcount << endl;
            tno = t.yes;
        }
        else if (t.oper == EOR) {
            if (logging) 
                cerr << "OR_count=" << orcount << endl;
            tno = (orcount >= t.nwit ? t.yes : t.no);   // check number of positives
            orcount = -1;
        }
        else if (t.oper == BAND) {
            andcount = 0;
            if (logging) 
                cerr << "AND_count=" << andcount << endl;
            tno = t.yes;
        }
        else if (t.oper == EAND) {
            if (logging) 
                cerr << "AND_count=" << andcount << endl;
            tno = (andcount >= t.nwit ? t.yes : t.no);   // check number of negatives
            andcount = -1;
        }
        else if (t.oper == IN) {
            bool insynt = false;
            int incase = 0;     // synteny case no. for logging
            for (int n=0; n<maxgroup; n++) {
                if ((t.uselast0 & (1<<n)) == 0)
                    g0.pgene[n] = 0;
            }
            g0.gsize = t.nwit + 1;
            g0.pgene[0] = &x;
            g0.goon = 0;
            SetBestHit(g0, 0, t);       // set E & ?BH for X
            if (logging) {
                cerr << "Group0[" << g0.gsize << "]";
                for (int k = 0; k < g0.gsize; k++)
                    cerr << " " << (g0.pgene[k]==0 ? "0" : g0.pgene[k]->name);
                cerr << endl;
            }
            sp1 = t.sp;
            g1.clear();
            g1.gsize = t.nwit + 1;
            // Single loop until satisfied
            if (g0.gsize > 1) {     // Y required
                if (g0.pgene[1] == 0) {     // Select gene Y
                    Giter yit = x.cit->second.genes.begin();
                    for ( ; yit != x.cit->second.genes.end(); yit++) {
                        if (&(yit->second) == g0.pgene[0]) continue;
                        g0.pgene[1] = &(yit->second);
                        exspan = ExceedSpan(g0, range0);    // Check span
                        if (logging && g0.gsize==2 && (global.log_span1 || !exspan)) {
                            cerr << "Span: 0[" << g0.gsize << "," << range0 << "]";
                            for (int k = 0; k < g0.gsize; k++)
                                cerr << " " << (g0.pgene[k]==0 ? "0" : g0.pgene[k]->name);
                            cerr << " - " << (exspan ? "exceeded" : "ok") << endl;
                        }
                        if (exspan) continue;
                        SetBestHit(g0, 1, t);       // set E & ?BH for Y

                        if (g0.gsize > 2) {     // Z required
                            if (g0.pgene[2] == 0) {     // Select gene Z
                                Giter zit = yit;
                                for (++zit; zit != x.cit->second.genes.end(); zit++) {
                                    if (&(zit->second) == g0.pgene[0]) continue;
                                    g0.pgene[2] = &(zit->second);
                                    exspan = ExceedSpan(g0, range0);    // Check span
                                    if (logging && (global.log_span1 || !exspan)) {
                                        cerr << "Span: 0[" << g0.gsize << "," << range0 << "]";
                                        for (int k = 0; k < g0.gsize; k++)
                                            cerr << " " << (g0.pgene[k]==0 ? "0" : g0.pgene[k]->name);
                                        cerr << " - " << (exspan ? "exceeded" : "ok") << endl;
                                    }
                                    if (exspan) continue;
                                    SetBestHit(g0, 2, t);       // set E & ?BH for Z

                                    insynt = HasSynteny(g0, g1, sp1, t.range);
                                    if (logging && (global.log_synteny || insynt)) {
                                        cerr << "Synteny: 0[" << g0.gsize << "]";
                                        for (int k = 0; k < g0.gsize; k++)
                                            cerr << " " << (g0.pgene[k]==0 ? "0" : g0.pgene[k]->name);
                                        cerr << " 1[" << g1.gsize << "," << t.range << "]";
                                        for (int k = 0; k < g1.gsize; k++)
                                            cerr << " " << (g1.pgene[k]==0 ? "0" : g1.pgene[k]->name);
                                        cerr << " - " << (insynt ? "yes" : "no") << endl;
                                    }
                                    if (insynt) { 
                                        incase = 1; break;      // exit Z-loop
                                    }
                                }       // next Z
                                if (!insynt) g0.pgene[2] = 0;
                            }
                            else {                      // Use fixed Z
                                insynt = HasSynteny(g0, g1, sp1, t.range);
                                if (logging && (global.log_synteny || insynt)) {
                                    cerr << "Synteny: 0[" << g0.gsize << "]";
                                    for (int k = 0; k < g0.gsize; k++)
                                        cerr << " " << (g0.pgene[k]==0 ? "0" : g0.pgene[k]->name);
                                    cerr << " 1[" << g1.gsize << "," << t.range << "]";
                                    for (int k = 0; k < g1.gsize; k++)
                                        cerr << " " << (g1.pgene[k]==0 ? "0" : g1.pgene[k]->name);
                                    cerr << " - " << (insynt ? "yes" : "no") << endl;
                                }
                                if (insynt) incase = 2;
                            }
                        }
                        else {                  // only X,Y required
                            g0.pgene[2] = 0;
                            insynt = HasSynteny(g0, g1, sp1, t.range);
                            if (logging && (global.log_synteny || insynt)) {
                                cerr << "Synteny: 0[" << g0.gsize << "]";
                                for (int k = 0; k < g0.gsize; k++)
                                    cerr << " " << (g0.pgene[k]==0 ? "0" : g0.pgene[k]->name);
                                cerr << " 1[" << g1.gsize << "," << t.range << "]";
                                for (int k = 0; k < g1.gsize; k++)
                                    cerr << " " << (g1.pgene[k]==0 ? "0" : g1.pgene[k]->name);
                                cerr << " - " << (insynt ? "yes" : "no") << endl;
                            }
                            if (insynt) incase = 3;
                        }
                        if (insynt) break;  // exit Y-loop
                    }       // next Y
                    if (!insynt) g0.pgene[1] = 0;
                }
                else {                      // Use fixed Y
                    if (g0.gsize > 2) {
                        if (g0.pgene[2] == 0) {     // Select gene Z
                            Giter zit = x.cit->second.genes.begin();
                            for ( ; zit != x.cit->second.genes.end(); zit++) {
                                if (&(zit->second) == g0.pgene[0]) continue;
                                if (&(zit->second) == g0.pgene[1]) continue;
                                g0.pgene[2] = &(zit->second);
                                exspan = ExceedSpan(g0, range0);    // Check span
                                if (logging && (global.log_span1 || !exspan)) {
                                    cerr << "Span: 0[" << g0.gsize << "," << range0 << "]";
                                    for (int k = 0; k < g0.gsize; k++)
                                        cerr << " " << (g0.pgene[k]==0 ? "0" : g0.pgene[k]->name);
                                    cerr << " - " << (exspan ? "exceeded" : "ok") << endl;
                                }
                                if (exspan) continue;
                                SetBestHit(g0, 2, t);       // set E & ?BH for Z

                                insynt = HasSynteny(g0, g1, sp1, t.range);
                                if (logging && (global.log_synteny || insynt)) {
                                    cerr << "Synteny: 0[" << g0.gsize << "]";
                                    for (int k = 0; k < g0.gsize; k++)
                                        cerr << " " << (g0.pgene[k]==0 ? "0" : g0.pgene[k]->name);
                                    cerr << " 1[" << g1.gsize << "," << t.range << "]";
                                    for (int k = 0; k < g1.gsize; k++)
                                        cerr << " " << (g1.pgene[k]==0 ? "0" : g1.pgene[k]->name);
                                    cerr << " - " << (insynt ? "yes" : "no") << endl;
                                }
                                if (insynt) { 
                                    incase = 4; break;      // Z-loop
                                }
                            }       // next Z
                        }
                        else {                      // Use fixed Z 
                            insynt = HasSynteny(g0, g1, sp1, t.range);
                            if (logging && (global.log_synteny || insynt)) {
                                cerr << "Synteny: 0[" << g0.gsize << "]";
                                for (int k = 0; k < g0.gsize; k++)
                                    cerr << " " << (g0.pgene[k]==0 ? "0" : g0.pgene[k]->name);
                                cerr << " 1[" << g1.gsize << "," << t.range << "]";
                                for (int k = 0; k < g1.gsize; k++)
                                    cerr << " " << (g1.pgene[k]==0 ? "0" : g1.pgene[k]->name);
                                cerr << " - " << (insynt ? "yes" : "no") << endl;
                            }
                            if (insynt) incase = 5;
                        }
                    }       // endif (g0.gsize > 2)
                    else {      // only X,Y required
                        g0.pgene[2] = 0;
                        insynt = HasSynteny(g0, g1, sp1, t.range);
                        if (logging && (global.log_synteny || insynt)) {
                            cerr << "Synteny: 0[" << g0.gsize << "]";
                            for (int k = 0; k < g0.gsize; k++)
                                cerr << " " << (g0.pgene[k]==0 ? "0" : g0.pgene[k]->name);
                            cerr << " 1[" << g1.gsize << "," << t.range << "]";
                            for (int k = 0; k < g1.gsize; k++)
                                cerr << " " << (g1.pgene[k]==0 ? "0" : g1.pgene[k]->name);
                            cerr << " - " << (insynt ? "yes" : "no") << endl;
                        }
                        if (insynt) incase = 6;
                    }
                }
            }       // endif (g0.gsize > 1)
            else {      // only X required
                g0.pgene[1] = 0; g0.pgene[2] = 0;
                insynt = HasSynteny(g0, g1, sp1, t.range);
                if (logging && (global.log_synteny || insynt)) {
                    cerr << "Synteny: 0[" << g0.gsize << "]";
                    for (int k = 0; k < g0.gsize; k++)
                        cerr << " " << (g0.pgene[k]==0 ? "0" : g0.pgene[k]->name);
                    cerr << " 1[" << g1.gsize << "," << t.range << "]";
                    for (int k = 0; k < g1.gsize; k++)
                        cerr << " " << (g1.pgene[k]==0 ? "0" : g1.pgene[k]->name);
                    cerr << " - " << (insynt ? "yes" : "no") << endl;
                }
                if (insynt) incase = 7;
            }

            if (logging) {
                if (insynt) {
                    cerr << "+++ Synteny #" << incase << " found: 0[" << g0.gsize << "," << range0 << "]";
                    for (int k = 0; k < g0.gsize; k++)
                        cerr << " " << (g0.pgene[k]==0 ? "0" : g0.pgene[k]->name);
                    cerr << " 1[" << g1.gsize << "," << t.range << "]";
                    for (int k = 0; k < g1.gsize; k++)
                        cerr << " " << (g1.pgene[k]==0 ? "0" : g1.pgene[k]->name);
                    cerr << endl;
                }
                else
                    cerr << "--- No synteny found." << endl;
            }
            if (!insynt) {
                g1.clear(); g1.gsize = g0.gsize;
            }
            tno = insynt ? t.yes : t.no;
            if (orcount >=0 && insynt) {
                orcount++;
                if (logging)
                    cerr << "OR_count=" << orcount << endl;
            }
            if (andcount >=0 && !insynt) {
                andcount++;
                if (logging)
                    cerr << "AND_count=" << andcount << endl;
            }
            incase = 0;
            insynt = false;
        }
        else if (t.oper == OVER) {
            bool insynt = false;
            int incase = 0;     // synteny case no. for logging
            if (overloop == 0) {    // Initialize loop variables
                g0.gsize = t.nwit + 1;
                for (int n=0; n<maxgroup; n++) {
                    if ((t.uselast0 & (1<<n)) == 0) {
                        g0.pgene[n] = 0;
                        g0.goon |= (1<<n);
                    }
                }
                SetBestHit(g0, 0, t);       // set E & ?BH for X
                y_no = 0;
                oyit = x.cit->second.genes.begin();
                ozit = oyit; ozit++;
                g1.clear();
                g1.gsize = t.nwit + 1;
                for (int n=0; n<maxgroup; n++)
                    g1.goon |= (1<<n);
            }
            else {              // Increment loop variables
            }

            // Milestones 
            if (global.rank == 0 && global.currentgenestep && y_no % global.currentgenestep == 0) {
                ostringstream oss;
                oss << left << "c" << setw(5) << global.c_no << "x" << setw(6) 
                    << global.x_no << "o" << setw(6) << overloop << "y" << setw(6) 
                    << y_no << setw(10) << " ";
                if (logany)     cout << oss.str() << "\r";
                else            cerr << oss.str() << "\r";
            }

            overloop++;
            sp1 = t.sp;
            range1 = t.range;
            // Outer loop until end
            if (g0.gsize>1) {     // Y required
                if ((t.uselast0 & 2) == 0) {    // Select gene Y
                    for ( ; oyit != x.cit->second.genes.end(); oyit++,y_no++) {
                        if (&(oyit->second) == g0.pgene[0]) continue;
                        g0.pgene[1] = &(oyit->second);
                        exspan = ExceedSpan(g0, range0);    // Check span
                        if (logging && g0.gsize==2 && (global.log_span1 || !exspan)) {
                            cerr << "Span: 0[" << g0.gsize << "," << range0 << "]";
                            for (int k = 0; k < g0.gsize; k++)
                                cerr << " " << (g0.pgene[k]==0 ? "0" : g0.pgene[k]->name);
                            cerr << " - " << (exspan ? "exceeded" : "ok") << endl;
                        }
                        if (exspan) continue;
                        SetBestHit(g0, 1, t);       // set E & ?BH for Y

                        if (g0.gsize > 2) {     // Z required
                            if ((t.uselast0 & 4) == 0) {    // Select gene Z
                                for ( ; ozit != x.cit->second.genes.end(); ozit++) {
                                    if (&(ozit->second) == g0.pgene[0]) continue;
                                    if (&(ozit->second) == g0.pgene[1]) continue;
                                    g0.pgene[2] = &(ozit->second);
                                    exspan = ExceedSpan(g0, range0);    // Check span
                                    if (logging && (global.log_span1 || !exspan)) {
                                        cerr << "Span: 0[" << g0.gsize << "," << range0 << "]";
                                        for (int k = 0; k < g0.gsize; k++)
                                            cerr << " " << (g0.pgene[k]==0 ? "0" : g0.pgene[k]->name);
                                        cerr << " - " << (exspan ? "exceeded" : "ok") << endl;
                                    }
                                    if (exspan) continue;
                                    SetBestHit(g0, 2, t);       // set E & ?BH for Z

                                    insynt = HasSynteny(g0, g1, sp1, t.range);
                                    if (logging && (global.log_synteny || insynt)) {
                                        cerr << "Synteny: 0[" << g0.gsize << "]";
                                        for (int k = 0; k < g0.gsize; k++)
                                            cerr << " " << (g0.pgene[k]==0 ? "0" : g0.pgene[k]->name);
                                        cerr << " 1[" << g1.gsize << "," << t.range << "]";
                                        for (int k = 0; k < g1.gsize; k++)
                                            cerr << " " << (g1.pgene[k]==0 ? "0" : g1.pgene[k]->name);
                                        cerr << " - " << (insynt ? "yes" : "no") << endl;
                                    }
                                    if (insynt) { 
                                        incase = 1;
                                        break;      // exit Z-loop
                                    }
                                }       // next Z
                                if (!insynt) {
                                    g0.pgene[2] = 0;
                                    ozit = x.cit->second.genes.begin();
                                }
                            }
                            else {              // Use fixed Z 
                                insynt = HasSynteny(g0, g1, sp1, t.range); 
                                if (logging && (global.log_synteny || insynt)) {
                                    cerr << "Synteny: 0[" << g0.gsize << "]";
                                    for (int k = 0; k < g0.gsize; k++)
                                        cerr << " " << (g0.pgene[k]==0 ? "0" : g0.pgene[k]->name);
                                    cerr << " 1[" << g1.gsize << "," << t.range << "]";
                                    for (int k = 0; k < g1.gsize; k++)
                                        cerr << " " << (g1.pgene[k]==0 ? "0" : g1.pgene[k]->name);
                                    cerr << " - " << (insynt ? "yes" : "no") << endl;
                                }
                                if (insynt) incase = 2;
                            }
                        }
                        else {      // only X,Y required
                            insynt = HasSynteny(g0, g1, sp1, t.range);
                            if (logging && (global.log_synteny || insynt)) {
                                cerr << "Synteny: 0[" << g0.gsize << "]";
                                for (int k = 0; k < g0.gsize; k++)
                                    cerr << " " << (g0.pgene[k]==0 ? "0" : g0.pgene[k]->name);
                                cerr << " 1[" << g1.gsize << "," << t.range << "]";
                                for (int k = 0; k < g1.gsize; k++)
                                    cerr << " " << (g1.pgene[k]==0 ? "0" : g1.pgene[k]->name);
                                cerr << " - " << (insynt ? "yes" : "no") << endl;
                            }
                            if (insynt) incase = 3;
                        }
                        if (insynt) break;      // Y-loop
                    }       // next Y
                    if (!insynt) {
                        g0.pgene[1] = 0;
                        oyit = x.cit->second.genes.begin();
                    }
                }
                else {                      // Use fixed Y
                    if (g0.gsize > 2) {
                        if ((t.uselast0 & 4) == 0) {    // Select gene Z
                            for ( ; ozit != x.cit->second.genes.end(); ozit++) {
                                if (&(ozit->second) == g0.pgene[0]) continue;
                                if (&(ozit->second) == g0.pgene[1]) continue;
                                g0.pgene[2] = &(ozit->second);
                                exspan = ExceedSpan(g0, range0);    // Check span
                                if (logging && (global.log_span1 || !exspan)) {
                                    cerr << "Span: 0[" << g0.gsize << "]";
                                    for (int k = 0; k < g0.gsize; k++)
                                        cerr << " " << (g0.pgene[k]==0 ? "0" : g0.pgene[k]->name);
                                    cerr << " - " << (exspan ? "exceeded" : "ok") << endl;
                                }
                                if (exspan) continue;
                                SetBestHit(g0, 2, t);       // set E & ?BH for Z

                                insynt = HasSynteny(g0, g1, sp1, t.range);
                                if (logging && (global.log_synteny || insynt)) {
                                    cerr << "Synteny: 0[" << g0.gsize << "]";
                                    for (int k = 0; k < g0.gsize; k++)
                                        cerr << " " << (g0.pgene[k]==0 ? "0" : g0.pgene[k]->name);
                                    cerr << " 1[" << g1.gsize << "," << t.range << "]";
                                    for (int k = 0; k < g1.gsize; k++)
                                        cerr << " " << (g1.pgene[k]==0 ? "0" : g1.pgene[k]->name);
                                    cerr << " - " << (insynt ? "yes" : "no") << endl;
                                }
                                if (insynt) { 
                                    incase = 4; break;      // Z-loop
                                }
                            }       // next Z
                            if (!insynt) {
                                g0.pgene[2] = 0;
                                ozit = x.cit->second.genes.begin();
                            }
                        }
                        else {                          // Use fixed Z 
                            insynt = HasSynteny(g0, g1, sp1, t.range);
                            if (logging && (global.log_synteny || insynt)) {
                                cerr << "Synteny: 0[" << g0.gsize << "]";
                                for (int k = 0; k < g0.gsize; k++)
                                    cerr << " " << (g0.pgene[k]==0 ? "0" : g0.pgene[k]->name);
                                cerr << " 1[" << g1.gsize << "," << t.range << "]";
                                for (int k = 0; k < g1.gsize; k++)
                                    cerr << " " << (g1.pgene[k]==0 ? "0" : g1.pgene[k]->name);
                                cerr << " - " << (insynt ? "yes" : "no") << endl;
                            }
                            if (insynt) incase = 5;
                        }
                    }       // endif (g0.gsize > 2)
                    else {      // only X,Y required
                        g0.pgene[2] = 0;
                        insynt = HasSynteny(g0, g1, sp1, t.range);
                        if (logging && (global.log_synteny || insynt)) {
                            cerr << "Synteny: 0[" << g0.gsize << "]";
                            for (int k = 0; k < g0.gsize; k++)
                                cerr << " " << (g0.pgene[k]==0 ? "0" : g0.pgene[k]->name);
                            cerr << " 1[" << g1.gsize << "," << t.range << "]";
                            for (int k = 0; k < g1.gsize; k++)
                                cerr << " " << (g1.pgene[k]==0 ? "0" : g1.pgene[k]->name);
                            cerr << " - " << (insynt ? "yes" : "no") << endl;
                        }
                        if (insynt) incase = 6;
                    }
                }
            }       // endif (g0.gsize > 1)
            else {      // only X required
                g0.pgene[1] = 0; g0.pgene[2] = 0;
                insynt = HasSynteny(g0, g1, sp1, t.range); 
                if (logging && (global.log_synteny || insynt)) {
                    cerr << "Synteny: 0[" << g0.gsize << "]";
                    for (int k = 0; k < g0.gsize; k++)
                        cerr << " " << (g0.pgene[k]==0 ? "0" : g0.pgene[k]->name);
                    cerr << " 1[" << g1.gsize << "," << t.range << "]";
                    for (int k = 0; k < g1.gsize; k++)
                        cerr << " " << (g1.pgene[k]==0 ? "0" : g1.pgene[k]->name);
                    cerr << " - " << (insynt ? "yes" : "no") << endl;
                }
                if (insynt) incase = 7;
            }

            if (logging) {
                if (insynt) {
                    cerr << "+++ Synteny #" << incase << " found: 0[" << g0.gsize << "," << range0 << "]";
                    for (int k = 0; k < g0.gsize; k++)
                        cerr << " " << (g0.pgene[k]==0 ? "0" : g0.pgene[k]->name);
                    cerr << " 1[" << g1.gsize << "," << t.range << "]";
                    for (int k = 0; k < g1.gsize; k++)
                        cerr << " " << (g1.pgene[k]==0 ? "0" : g1.pgene[k]->name);
                    cerr << endl;
                }
                else
                    cerr << "--- No synteny found." << endl;
            }
            if (insynt) {
                // Store variables of the loop
                tno = t.yes;
            }
            else {
                if (overloop > 0) {     // End of outer loop
                    overloop = 0;
                    if (orcount >= 0 && insynt) {
                        orcount++;
                        if (logging)
                            cerr << "OR_count=" << orcount << endl;
                    }
                    if (andcount >= 0 && !insynt) {
                        andcount++;
                        if (logging)
                            cerr << "AND_count=" << andcount << endl;
                    }
                }
                tno = t.no;
                g1.clear(); g1.gsize = g0.gsize;
                g0.goon = 0;
            }
            incase = 0;
            insynt = false;
        }
        else if (t.oper == IN2) {
            Gene & x2 = *(g1.pgene[0]);     // g2={X",Y",Z"}
            bool insynt = false;
            int incase = 0;     // synteny case no. for logging
            g2 = g1;
            for (int n=0; n<maxgroup; n++) {    // use only needed witnesses from sp1
                if ((t.uselast1 & (1<<n)) == 0)
                    g2.pgene[n] = 0;
            }
            g2.gsize = t.nwit + 1;
            g2.goon = 0;
            SetBestHit(g2, 0, t);       // set E & ?BH for X
            sp2 = g1.pgene[0]->sp;
            sp3 = t.sp;
            g3.clear();
            g3.gsize = t.nwit + 1;
            // Inner loop until satisfied
            if (g2.gsize > 1) {     // Y" required
                if (g2.pgene[1] == 0) {     // Select gene Y"
                    Giter yit = x2.cit->second.genes.begin();
                    for ( ; yit != x2.cit->second.genes.end(); yit++) {
                        if (&(yit->second) == g2.pgene[0]) continue;
                        g2.pgene[1] = &(yit->second);
                        exspan = ExceedSpan(g2, range1);    // Check span
                        if (logging && g2.gsize==2 && (global.log_span1 || !exspan)) {
                            cerr << "Span: 2[" << g2.gsize << "," << range1 << "]";
                            for (int k = 0; k < g2.gsize; k++)
                                cerr << " " << (g2.pgene[k]==0 ? "0" : g2.pgene[k]->name);
                            cerr << " - " << (exspan ? "exceeded" : "ok") << endl;
                        }
                        if (exspan) continue;
                        SetBestHit(g2, 1, t);       // set E & ?BH for Y"

                        if (g2.gsize > 2) {     // Z" required
                            if (g2.pgene[2] == 0) {     // Select gene Z"
                                Giter zit = yit;
                                for (++zit; zit != x2.cit->second.genes.end(); zit++) {
                                    if (&(zit->second) == g2.pgene[0]) continue;
                                    g2.pgene[2] = &(zit->second);
                                    exspan = ExceedSpan(g2, range1);    // Check span
                                    if (logging && (global.log_span1 || !exspan)) {
                                        cerr << "Span: 2[" << g2.gsize << "," << range1 << "]";
                                        for (int k = 0; k < g2.gsize; k++)
                                            cerr << " " << (g2.pgene[k]==0 ? "0" : g2.pgene[k]->name);
                                        cerr << " - " << (exspan ? "exceeded" : "ok") << endl;
                                    }
                                    if (exspan) continue;
                                    SetBestHit(g2, 2, t);       // set E & ?BH for Z"

                                    insynt = HasSynteny(g2, g3, sp3, t.range);
                                    if (logging && (global.log_synteny || insynt)) {
                                        cerr << "Synteny: 2[" << g2.gsize << "]";
                                        for (int k = 0; k < g2.gsize; k++)
                                            cerr << " " << (g2.pgene[k]==0 ? "0" : g2.pgene[k]->name);
                                        cerr << " 3[" << g3.gsize << "," << t.range << "]";
                                        for (int k = 0; k < g3.gsize; k++)
                                            cerr << " " << (g3.pgene[k]==0 ? "0" : g3.pgene[k]->name);
                                        cerr << " - " << (insynt ? "yes" : "no") << endl;
                                    }
                                    if (insynt) {
                                        incase = 1; break;      // exit Z-loop
                                    }
                                }       // next Z"
                                if (!insynt) g2.pgene[2] = 0;
                            }
                            else {                      // Use fixed Z"
                                insynt = HasSynteny(g2, g3, sp3, t.range);
                                if (logging && (global.log_synteny || insynt)) {
                                    cerr << "Synteny: 2[" << g2.gsize << "]";
                                    for (int k = 0; k < g2.gsize; k++)
                                        cerr << " " << (g2.pgene[k]==0 ? "0" : g2.pgene[k]->name);
                                    cerr << " 3[" << g3.gsize << "," << t.range << "]";
                                    for (int k = 0; k < g3.gsize; k++)
                                        cerr << " " << (g3.pgene[k]==0 ? "0" : g3.pgene[k]->name);
                                    cerr << " - " << (insynt ? "yes" : "no") << endl;
                                }
                                if (insynt) incase = 2;
                            }
                        }
                        else {                  // only X",Y" required
                            g2.pgene[2] = 0;
                            insynt = HasSynteny(g2, g3, sp3, t.range);
                            if (logging && (global.log_synteny || insynt)) {
                                cerr << "Synteny: 2[" << g2.gsize << "]";
                                for (int k = 0; k < g2.gsize; k++)
                                    cerr << " " << (g2.pgene[k]==0 ? "0" : g2.pgene[k]->name);
                                cerr << " 3[" << g3.gsize << "," << t.range << "]";
                                for (int k = 0; k < g3.gsize; k++)
                                    cerr << " " << (g3.pgene[k]==0 ? "0" : g3.pgene[k]->name);
                                cerr << " - " << (insynt ? "yes" : "no") << endl;
                            }
                            if (insynt) incase = 3;
                        }
                        if (insynt) break;  // exit Y"-loop
                    }       // next Y"
                    if (!insynt) g2.pgene[1] = 0;
                }
                else {                      // Use fixed Y"
                    if (g2.gsize > 2) {
                        if (g2.pgene[2] == 0) {     // Select gene Z"
                            Giter zit = x2.cit->second.genes.begin();
                            for ( ; zit != x2.cit->second.genes.end(); zit++) {
                                if (&(zit->second) == g2.pgene[0]) continue;
                                if (&(zit->second) == g2.pgene[1]) continue;
                                g2.pgene[2] = &(zit->second);
                                exspan = ExceedSpan(g2, range1);    // Check span
                                if (logging && (global.log_span1 || !exspan)) {
                                    cerr << "Span: 2[" << g2.gsize << "," << range1 << "]";
                                    for (int k = 0; k < g2.gsize; k++)
                                        cerr << " " << (g2.pgene[k]==0 ? "0" : g2.pgene[k]->name);
                                    cerr << " - " << (exspan ? "exceeded" : "ok") << endl;
                                }
                                if (exspan) continue;
                                SetBestHit(g2, 2, t);       // set E & ?BH for Z"

                                insynt = HasSynteny(g2, g3, sp3, t.range);
                                if (logging && (global.log_synteny || insynt)) {
                                    cerr << "Synteny: 2[" << g2.gsize << "]";
                                    for (int k = 0; k < g2.gsize; k++)
                                        cerr << " " << (g2.pgene[k]==0 ? "0" : g2.pgene[k]->name);
                                    cerr << " 3[" << g3.gsize << "," << t.range << "]";
                                    for (int k = 0; k < g3.gsize; k++)
                                        cerr << " " << (g3.pgene[k]==0 ? "0" : g3.pgene[k]->name);
                                    cerr << " - " << (insynt ? "yes" : "no") << endl;
                                }
                                if (insynt) {
                                    incase = 4; break;
                                }
                            }       // next Z"
                        }
                        else {                      // Use fixed Z"
                            insynt = HasSynteny(g2, g3, sp3, t.range);
                            if (logging && (global.log_synteny || insynt)) {
                                cerr << "Synteny: 2[" << g2.gsize << "]";
                                for (int k = 0; k < g2.gsize; k++)
                                    cerr << " " << (g2.pgene[k]==0 ? "0" : g2.pgene[k]->name);
                                cerr << " 3[" << g3.gsize << "," << t.range << "]";
                                for (int k = 0; k < g3.gsize; k++)
                                    cerr << " " << (g3.pgene[k]==0 ? "0" : g3.pgene[k]->name);
                                cerr << " - " << (insynt ? "yes" : "no") << endl;
                            }
                            if (insynt) incase = 5;
                        }
                    }       // endif (g2.gsixe > 2)
                    else {      // only X",Y" required
                        g2.pgene[2] = 0;
                        insynt = HasSynteny(g2, g3, sp3, t.range);
                        if (logging && (global.log_synteny || insynt)) {
                            cerr << "Synteny: 2[" << g2.gsize << "]";
                            for (int k = 0; k < g2.gsize; k++)
                                cerr << " " << (g2.pgene[k]==0 ? "0" : g2.pgene[k]->name);
                            cerr << " 3[" << g3.gsize << "," << t.range << "]";
                            for (int k = 0; k < g3.gsize; k++)
                                cerr << " " << (g3.pgene[k]==0 ? "0" : g3.pgene[k]->name);
                            cerr << " - " << (insynt ? "yes" : "no") << endl;
                        }
                        if (insynt) incase = 6;
                    }
                }
            }       // endif (g2.gsize > 1)
            else {      // only X" required
                g2.pgene[1] = 0; g2.pgene[2] = 0;
                insynt = HasSynteny(g2, g3, sp3, t.range);
                if (logging && (global.log_synteny || insynt)) {
                    cerr << "Synteny: 2[" << g2.gsize << "]";
                    for (int k = 0; k < g2.gsize; k++)
                        cerr << " " << (g2.pgene[k]==0 ? "0" : g2.pgene[k]->name);
                    cerr << " 3[" << g3.gsize << "," << t.range << "]";
                    for (int k = 0; k < g3.gsize; k++)
                        cerr << " " << (g3.pgene[k]==0 ? "0" : g3.pgene[k]->name);
                    cerr << " - " << (insynt ? "yes" : "no") << endl;
                }
                if (insynt) incase = 7;
            }
            if (logging) {
                if (insynt) {
                    cerr << "+++ Synteny2 #" << incase << " found: 2[" << g2.gsize << "," << range1 << "]";
                    for (int k = 0; k < g2.gsize; k++)
                        cerr << " " << (g2.pgene[k]==0 ? "0" : g2.pgene[k]->name);
                    cerr << " 3[" << g3.gsize << "," << t.range << "]";
                    for (int k = 0; k < g3.gsize; k++)
                        cerr << " " << (g3.pgene[k]==0 ? "0" : g3.pgene[k]->name);
                    cerr << endl;
                }
                else
                    cerr << "--- No synteny2 found." << endl;
            }
            if (!insynt) {
                g3.clear(); g3.gsize = g2.gsize;
            }
            tno = insynt ? t.yes : t.no;
            incase = 0;
            insynt = false;
        }
        else if (t.oper == ADD) {
            if (t.sp == sp0 || t.sp < 0 && global.taxa[-t.sp].specno[0] == sp0) {
                if (logging) 
                    cerr << "Groups[" << groups.size() << "]=Group0" << endl;
                groups.push_back(g0);
            }
            // allow for sp1==sp2 (3 spp predicate)
            else if (t.sp == sp1 && (g1.pgene[0] == 0 || groups.back().pgene[0] == 0 || 
                                     groups.back().pgene[0]->sp != g1.pgene[0]->sp)) {
                if (logging) 
                    cerr << "Groups[" << groups.size() << "]=Group1" << endl;
                groups.push_back(g1);
            }
            else if (t.sp == sp2 || t.sp < 0 && t.sp == sp1) {
                if (logging) 
                    cerr << "Groups[" << groups.size() << "]=Group2" << endl;
                groups.push_back(g2);
            }
            else if (t.sp == sp3) {
                if (logging) 
                    cerr << "Groups[" << groups.size() << "]=Group3" << endl;
                groups.push_back(g3);
            }
            else {
                ostringstream oss;
                if (global.size > 1) oss << "[" << global.rank << "] ";
                oss << "Runtime error: invalid ADD term " << tno;
                cerr << oss.str() << endl;
                return false;
            }
            tno = t.yes;
        }
        else {
            ostringstream oss;
            if (global.size > 1) oss << "[" << global.rank << "] ";
            oss << "Runtime error: invalid term " << tno;
            cerr << oss.str() << endl;
            return false;
        }
    }
    if (logging)
        cerr << "Predicate is " << boolalpha << (tno == YES) << endl;
    gt0 = parminit;         // restore initial parameters
    return (tno == YES);
}

// Return true/false, side effects in g2
bool HasSynteny(Group & g1, Group & g2, int spec2, int span) {
    if (g1.gsize != g2.gsize) return false;
    vector <Homolog>::const_iterator hitx;
    vector <Homolog>::const_iterator hity;
    vector <Homolog>::const_iterator hitz;
    PGene px, py, pz;
    Group grp(g2);
    bool logging = (global.size == 1) && (global.log_verbose || g1.pgene[0]->log);
    bool exspan = false;
    bool insynt = false;
    bool zerop = false;     // zero pointer flag
    int sp1 = g1.pgene[0]->sp;
    int sp2 = unknown_species;

    if (g2.pgene[0] == 0) {         // start search
        if (spec2 >= 0) 
            sp2 = spec2;
        else if (global.taxa[-spec2].nspec > 0)
            sp2 = global.taxa[-spec2].specno[0];
        else
            return false;
    }
    else {                          // continue search
        sp2 = g2.pgene[0]->sp;
    }

    // Do for species sp2 and optionally over taxon -spec2 beyond sp2
    while (sp2 != unknown_species) {
        // Loop over X' ~ X
        int sbx1 = 0;
        vector <Homolog> hvx( g1.pgene[0]->homologs[sp2] );
        if (global.mode_homology && global.mode_info && !(g1.BBH & ORTX)) {
            // add unique paralogs of each ortholog
            vector <Homolog> para;
            vector <Homolog>::iterator xpi = hvx.begin();
            for ( ; xpi != hvx.end(); xpi++) {
                vector <Homolog>& parxp = xpi->pgene->homologs[sp2]; // paralogs of ortholog
                vector <Homolog>::iterator pitxp = parxp.begin();
                for ( ; pitxp != parxp.end(); pitxp++) {
                    vector <Homolog>::iterator herex = hvx.begin();
                    for ( ; herex != hvx.end(); herex++)
                        if (pitxp->pgene == herex->pgene) break;
                    if (herex == hvx.end())
                        para.push_back(*pitxp);  // will be added to the list of orthologs
                }
            }
            vector <Homolog>::iterator pi = para.begin();
            for ( ; pi != para.end(); pi++)
                hvx.push_back(*pi);
        }
        if (global.mode_matrix && (g1.BBH & (BBHX | OBHX)))
            sbx1 = GetBestHit(hvx);     // find OBH value
        hitx = hvx.begin();
        if ((grp.goon & 1) && grp.pgene[0]) {   // continue at last X'
            for ( ; hitx != hvx.end(); hitx++) {
                // Check E-value
                if (hitx->evalue > g1.E) continue;
                // Check best hit conditions
                if (global.mode_matrix && (g1.BBH & (BBHX | OBHX))) {
                    if (hitx->score < sbx1) continue;
                }
                if (global.mode_matrix && (g1.BBH & (BBHX | IBHX))) {
                    PGene pgx = hitx->pgene;
                    vector <Homolog> & hgx = pgx->homologs[sp1];
                    int sbx2 = GetBestHit(hgx);      // find IBH value
                    vector <Homolog>::iterator hgxit = hgx.begin();
                    for ( ; hgxit != hgx.end(); hgxit++)
                        if (hgxit->pgene == g1.pgene[0]) break;
                    if (hgxit == hgx.end() || hgxit->score < sbx2) continue;
                }
                if (hitx->pgene == grp.pgene[0]) break;
            }
            if (hitx == hvx.end()) hitx = hvx.begin();
            else if (g1.gsize == 1) hitx++;         // increment X'
        }
        for ( ; hitx != hvx.end(); hitx++) {
            // Check E-value
            if (hitx->evalue > g1.E) continue;
            // Check best hit conditions
            if (global.mode_matrix && (g1.BBH & (BBHX | OBHX))) {
                if (hitx->score < sbx1) continue;
            }
            if (global.mode_matrix && (g1.BBH & (BBHX | IBHX))) {
                PGene pgx = hitx->pgene;
                vector <Homolog> & hgx = pgx->homologs[sp1];
                int sbx2 = GetBestHit(hgx);      // find IBH value
                vector <Homolog>::iterator hgxit = hgx.begin();
                for ( ; hgxit != hgx.end(); hgxit++)
                    if (hgxit->pgene == g1.pgene[0]) break;
                if (hgxit == hgx.end() || hgxit->score < sbx2) continue;
            }
            px = hitx->pgene;
            grp.pgene[0] = px;

            // Skip contigs with not enough genes
            if ((int)px->cit->second.genes.size() < g2.gsize)
                continue;

            if (g1.gsize > 1) {
                if (g1.pgene[1] == 0) {
                    zerop = true; break;
                }
                // Loop over Y' ~ Y
                int sby1 = 0;
                vector <Homolog> hvy( g1.pgene[1]->homologs[sp2] );
                if (global.mode_homology && global.mode_info && !(g1.BBH & ORTY)) {
                    // add unique paralogs of each ortholog
                    vector <Homolog> para;
                    vector <Homolog>::iterator ypi = hvy.begin();
                    for ( ; ypi != hvy.end(); ypi++) {
                        vector <Homolog>& paryp = ypi->pgene->homologs[sp2]; // paralogs of ortholog
                        vector <Homolog>::iterator pityp = paryp.begin();
                        for ( ; pityp != paryp.end(); pityp++) {
                            vector <Homolog>::iterator herey = hvy.begin();
                            for ( ; herey != hvy.end(); herey++)
                                if (pityp->pgene == herey->pgene) break;
                            if (herey == hvy.end())
                                para.push_back(*pityp);  // will be added to the list of orthologs
                        }
                    }
                    vector <Homolog>::iterator pi = para.begin();
                    for ( ; pi != para.end(); pi++)
                        hvy.push_back(*pi);
                }
                if (global.mode_matrix && (g1.BBH & (BBHY | OBHY)))
                    sby1 = GetBestHit(hvy);     // find OBH value
                hity = hvy.begin();
                if ((grp.goon & 2) && grp.pgene[1]) {   // continue at last Y'
                    for ( ; hity != hvy.end(); hity++) {
                        // Check E-value
                        if (hity->evalue > g1.E) continue;
                        // Check best hit conditions
                        if (global.mode_matrix && (g1.BBH & (BBHY | OBHY))) {
                            if (hity->score < sby1) continue;
                        }
                        if (global.mode_matrix && (g1.BBH & (BBHY | IBHY))) {
                            PGene pgy = hity->pgene;
                            vector <Homolog> & hgy = pgy->homologs[sp1];
                            int sby2 = GetBestHit(hgy);      // find IBH value
                            vector <Homolog>::iterator hgyit = hgy.begin();
                            for ( ; hgyit != hgy.end(); hgyit++)
                                if (hgyit->pgene == g1.pgene[1]) break;
                            if (hgyit == hgy.end() || hgyit->score > sby2) continue;
                        }
                        if (hity->pgene == grp.pgene[1]) break;
                    }
                    if (hity == hvy.end()) hity = hvy.begin();
                    else if (g1.gsize == 2) hity++;         // increment Y'
                }
                for ( ; hity != hvy.end(); hity++) {
                    // Check E-value
                    if (hity->evalue > g1.E) continue;
                    // Check best hit conditions
                    if (global.mode_matrix && (g1.BBH & (BBHY | OBHY))) {
                        if (hity->score < sby1) continue;
                    }
                    if (global.mode_matrix && (g1.BBH & (BBHY | IBHY))) {
                        PGene pgy = hity->pgene;
                        vector <Homolog> & hgy = pgy->homologs[sp1];
                        int sby2 = GetBestHit(hgy);      // find IBH value
                        vector <Homolog>::iterator hgyit = hgy.begin();
                        for ( ; hgyit != hgy.end(); hgyit++)
                            if (hgyit->pgene == g1.pgene[1]) break;
                        if (hgyit == hgy.end() || hgyit->score < sby2) continue;
                    }
                    py = hity->pgene;
                    if (py == px) continue;
                    grp.pgene[1] = py;
                 
                    // Check if different species or contigs
                    if (px->sp != py->sp) {
                        ostringstream oss;
                        oss << "\n";
                        if (global.size > 1) oss << "[" << global.rank << "] ";
                        oss << "Internal error: genes " << px->name << ", " << py->name 
                            << " of diff. spp. " << px->sp << "," << py->sp;
                        cout << oss.str() << endl;
                        //exit(4);
                    }
                    if (px->cit != py->cit) continue;
                 
                    exspan = ExceedSpan(grp, span);
                    if (logging && g1.gsize==2 && (global.log_span2 || !exspan)) {
                        cerr << "Span: 1[" << grp.gsize << "," << span << "]";
                        for (int k = 0; k < grp.gsize; k++)
                            cerr << " " << (grp.pgene[k]==0 ? "0" : grp.pgene[k]->name);
                        cerr << " - " << (exspan ? "exceeded" : "ok") << endl;
                    }
                    if (exspan) continue;

                    if (g1.gsize > 2) {             // X,Y,Z
                        if (g1.pgene[2] == 0) {
                            zerop = true; break;
                        }
                        // Loop over Z' ~ Z
                        int sbz1 = 0;
                        vector <Homolog> hvz( g1.pgene[2]->homologs[sp2] );
                        if (global.mode_homology && global.mode_info && !(g1.BBH & ORTZ)) {
                            // add unique paralogs of each ortholog
                            vector <Homolog> para;
                            vector <Homolog>::iterator zpi = hvz.begin();
                            for ( ; zpi != hvz.end(); zpi++) {
                                vector <Homolog>& parzp = zpi->pgene->homologs[sp2]; // paralogs of ortholog
                                vector <Homolog>::iterator pitzp = parzp.begin();
                                for ( ; pitzp != parzp.end(); pitzp++) {
                                    vector <Homolog>::iterator herez = hvz.begin();
                                    for ( ; herez != hvz.end(); herez++)
                                        if (pitzp->pgene == herez->pgene) break;
                                    if (herez == hvz.end())
                                        para.push_back(*pitzp);  // will be added to the list of orthologs
                                }
                            }
                            vector <Homolog>::iterator pi = para.begin();
                            for ( ; pi != para.end(); pi++)
                                hvz.push_back(*pi);
                        }
                        if (global.mode_matrix && (g1.BBH & (BBHZ | OBHZ)))
                            sbz1 = GetBestHit(hvz);     // find OBH value
                        hitz = hvz.begin();
                        if ((grp.goon & 4) && grp.pgene[2]) {   // continue at last Z'
                            for ( ; hitz != hvz.end(); hitz++) {
                                // Check E-value
                                if (hitz->evalue > g1.E) continue;
                                // Check best hit conditions
                                if (global.mode_matrix && (g1.BBH & (BBHZ | OBHZ))) {
                                    if (hitz->score < sbz1) continue;
                                }
                                if (global.mode_matrix && (g1.BBH & (BBHZ | IBHZ))) {
                                    PGene pgz = hitz->pgene;
                                    vector <Homolog> & hgz = pgz->homologs[sp1];
                                    int sbz2 = GetBestHit(hgz);      // find IBH value
                                    vector <Homolog>::iterator hgzit = hgz.begin();
                                    for ( ; hgzit != hgz.end(); hgzit++)
                                        if (hgzit->pgene == g1.pgene[2]) break;
                                    if (hgzit == hgz.end() || hgzit->score < sbz2) continue;
                                }
                                if (hitz->pgene == grp.pgene[2]) break;
                            }
                            if (hitz == hvz.end()) hitz = hvz.begin();
                            else if (g1.gsize == 3) hitz++;         // increment Z'
                        }
                        for ( ; hitz != hvz.end(); hitz++) {
                            // Check E-value
                            if (hitz->evalue > g1.E) continue;
                            // Check best hit conditions
                            if (global.mode_matrix && (g1.BBH & (BBHZ | OBHZ))) {
                                if (hitz->score < sbz1) continue;
                            }
                            if (global.mode_matrix && (g1.BBH & (BBHZ | IBHZ))) {
                                PGene pgz = hitz->pgene;
                                vector <Homolog> & hgz = pgz->homologs[sp1];
                                int sbz2 = GetBestHit(hgz);      // find IBH value
                                vector <Homolog>::iterator hgzit = hgz.begin();
                                for ( ; hgzit != hgz.end(); hgzit++)
                                    if (hgzit->pgene == g1.pgene[2]) break;
                                if (hgzit == hgz.end() || hgzit->score < sbz2) continue;
                            }
                            pz = hitz->pgene;
                            if (pz == px) continue;
                            if (pz == py && ZneY) continue;
                            grp.pgene[2] = pz;

                            // Check if different species or contigs
                            if (px->sp != pz->sp) {
                                ostringstream oss;
                                if (global.size > 1) oss << "[" << global.rank << "] ";
                                oss << "Internal error: genes X',Z' from different species " 
                                    << px->sp << "," << pz->sp;
                                cerr << oss.str() << endl;
                                exit(4);
                            }
                            if (px->cit != pz->cit) continue;
                  
                            exspan = ExceedSpan(grp, span);
                            if (logging && (global.log_span2 || !exspan)) {
                                cerr << "Span: 1[" << grp.gsize << "," << span << "]";
                                for (int k = 0; k < grp.gsize; k++)
                                    cerr << " " << (grp.pgene[k]==0 ? "0" : grp.pgene[k]->name);
                                cerr << " - " << (exspan ? "exceeded" : "ok") << endl;
                            }
                            if (exspan) continue;

                            // Check synteny
                            insynt = InSynteny(g1, grp);
                            if (insynt) {
                                g2 = grp; break;
                            }
                        }     // next Z'
                        if (!insynt) grp.pgene[2] = 0;
                    }
                    else {                      // only X',Y'
                        grp.pgene[2] = 0;
                        insynt = InSynteny(g1, grp);
                        if (insynt) {
                            g2 = grp; break;
                        }
                    }
                }       // next Y'
                if (!insynt) grp.pgene[1] = 0;
                if (insynt || zerop) break;
            }
            else {      // X' only
                g2 = grp;
                insynt = true;
                break;
            }
        }       // next X'

        if (!insynt) grp.pgene[0] = 0;
        if (insynt || spec2 >= 0) break;
        // try next species from current taxon
        int oldsp2 = sp2;
        sp2 = unknown_species;
        for (int i = 0; i < global.taxa[-spec2].nspec; i++) {
            if (global.taxa[-spec2].specno[i] == oldsp2) {
                if (++i < global.taxa[-spec2].nspec)
                    sp2 = global.taxa[-spec2].specno[i];
                break;
            }
        }
    }
    return insynt;
}

// Set E-value and BBH flags of <geneno>-th gene in group as per term 
void    SetBestHit(Group & group, int geneno, Term & term) {
    group.E = term.E;
    switch (geneno) {
        case 0:
            group.BBH &= ~(BBHX | OBHX | IBHX);
            group.BBH |= term.BBH & (BBHX | OBHX | IBHX);
            break;
        case 1:
            group.BBH &= ~(BBHY | OBHY | IBHY);
            group.BBH |= term.BBH & (BBHY | OBHY | IBHY);
            break;
        case 2:
            group.BBH &= ~(BBHZ | OBHZ | IBHZ);
            group.BBH |= term.BBH & (BBHZ | OBHZ | IBHZ);
            break;
        default:
            if (global.rank == 0) 
                cerr << "Group of more than 3 genes has not been implemented yet." << endl;
    }
}

// Return best hit value for given list of homologies
int  GetBestHit(vector <Homolog> & hv) {
    int ret = 0;
    vector <Homolog>::iterator hvit = hv.begin();
    for ( ; hvit != hv.end(); hvit++) {
        if (hvit->score > ret)
            ret = hvit->score;
    }
    return ret;
}
