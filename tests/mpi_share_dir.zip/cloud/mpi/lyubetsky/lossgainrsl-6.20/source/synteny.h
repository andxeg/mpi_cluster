// synteny - common header
#ifndef SYNTENY_H
#define SYNTENY_H

#ifdef __unix__
#define LINUX
#elif defined(WIN32) || defined(_WIN32) || defined(_WIN64)
#define WINDOWS
#endif

#ifdef _DEBUG
#define NOMPI
#endif  // ifdef _DEBUG

//#define NOMPI               // Uncomment of define externally to disable MPI code

#ifndef NOMPI
#define SYNTENY_MPI         // Include mpi-related code
#endif

#ifdef SYNTENY_MPI
#define MSMPI_NO_DEPRECATE_20       // for MS MPI
#include "mpi.h"
#if defined(_MSC_VER) && _MSC_VER < 1600
#undef WCHAR_MIN                    // for old VCs
#undef WCHAR_MAX
#endif
#endif  // ifdef SYNTENY_MPI

#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <stack>
#include <map>
#include <algorithm>
#include <cstdlib>
#include <ctime>

using namespace std;

#ifdef SYNTENY_MPI
#define getTimer()  (global.size>1 ? MPI_Wtime() : (double)clock()/CLOCKS_PER_SEC)
#else
#define getTimer()  (double)clock()/CLOCKS_PER_SEC
#endif  // ifdef SYNTENY_MPI

#ifndef __max
#define __max(a,b)  (((a) > (b)) ? (a) : (b))
#endif
#ifndef __min
#define __min(a,b)  (((a) < (b)) ? (a) : (b))
#endif

const string version    = "6.20";
const string def_config = "config.ini";
const string defaultout = "result.txt";
const int buflen        = 65536;
const int ncol          = 6;        // Required data columns for each gene
enum Required {
    field_protein, field_gene, field_contig, field_begin, field_end, field_strand };
// in C\I mode, field_protein is considered as species id
const int inrecordstep  = 1000;
const int inogroupstep  = 10000;
const int inmatrixstep  = 100000;
const int outgenestep   = 10;
const int maxgroup      = 3;        // Max group of a species' genes
const int maxtuple      = 3;        // Max number of syntenic groups
const int maxfield      = 32;       // Max known/required fields of input file
const int def_witness   = 2;
const int def_range     = 2000000;
const double def_E      = 1e-5;
const double bigE       = 10.0;
const bool ZneY         = true;     // require Z' nonequal Y'
const int unknown_species = 0x0F0F0F0F;     // means "unknown"
const char startax      = '*';      // 1st character of the taxon name
const char subdelim     = ',';      // operator subdelimiter
const char noprefix     = '-';
const char pairsep      = '_';      // for the name of long homology files
const char tab          = '\t';      
const string eqsign = "=:";         // assignment character(s) for option value
const int maxloop       = 1000;     // max loop of terms per line calculation
const string back9      = "\b\b\b\b\b\b\b\b\b";
const double qtime      = 5.0/RAND_MAX;     // quantum of time to wait
const string paracount  = "#";      // name of virtual field with paralogs count
#ifdef SYNTENY_MAIN
    int currentdefrange = 0;        // means not set
#else
    extern int currentdefrange;
#endif

// Program mode options
const char Mode_Homology = 'H';     // Homologous pair at input (default mode) 
const char Mode_Cluster = 'C';      // Cluster at input (new format that needs I)
const char Mode_Ogroup  = 'Q';      // Orthogroup (old format w/o I, Species->Protein ID)
const char Mode_Matrix  = 'A';      // Matrix and gene info files at input
const char Mode_Order   = 'O';      // Consider ordered group for synteny
const char Mode_Direct  = 'D';      // Consider directed genes for synteny
const char Mode_Mirror  = 'M';      // Consider mirror (complement) synteny too
const char Mode_Extract = 'X';      // Extract mode (gene, not entire group downwards)
const char Span_Center  = 'B';      // Use intercenter distance to calc span
const char Span_Inner   = 'S';      // Use intergenic distance to calc span
const char Span_Outer   = 'E';      // Use outer edges to calc span

// Logging options
const char Log_Separate = 'I';      // Separate groups with blank line
const char Log_Tail     = 'J';      // Add X gene ID and # to each record of the group
const char Log_Gene     = 'G';      // Log specified gene(s)
const char Log_Protein  = 'P';      // Log specified protein(s)
const char Log_Verbose  = 'V';      // Verbose log for debug purposes
const char Log_Contig   = 'T';      // Log specified contig(s)
const char Log_ContigN  = 'N';      // Contig serial no. for logging
const char Log_Span1    = '1';      // Log all XYZ span checks (otherwise only good)
const char Log_Span2    = '2';      // Log all X'Y'Z' span checks (otherwise only good)
const char Log_Synteny  = '3';      // Log all synteny checks (otherwise only good)
const char Log_Union    = 'U';      // Log entire row/column of the matrix (cell otherwise)

struct Global;
struct Gene;
struct Homolog;
struct Contig;
struct Species;
struct Term;
struct Synteny;
struct Tuple1;
struct Tuple2;
struct Tuple3;
typedef Gene* PGene;
typedef map <string, Gene>::iterator Giter;
typedef pair <string, Gene> Gpair;
typedef map <string, Contig>::iterator Citer;
typedef pair <string, Contig> Cpair;
typedef map <string, Synteny>::iterator Siter;
typedef pair <string, Synteny> Spair;
typedef map <string, PGene>::iterator Piter;
typedef pair <string, PGene> Ppair;

enum  Term_Oper { 
    NOP, SET, ADD, IN, IN2, OVER, NEXT, BOR, EOR, GOTO, WIT, WITNESS, 
    EVAL, RANGE, HOLD1, HOLD2, BBH, ORTH, HEAD, HEADING, BAND, EAND, EOLIST };
const string TermOper[EOLIST] = { 
    "NOP", "SET", "ADD", "IN", "IN2", "OVER", "NEXT", "BOR", "EOR", 
    "GOTO", "WIT", "WITNESS", "EVAL", "RANGE", "HOLD1", "HOLD2", "BBH", 
    "ORTH", "HEAD", "HEADING", "BAND", "EAND" };
enum  Best_Hit { 
    NONE, ORTX=1, ORTY=2, ORTZ=4, BBHX=1, BBHY=2, BBHZ=4, 
    OBHX=8, OBHY=16, OBHZ=32, IBHX=64, IBHY=128, IBHZ=256 };
enum  Spec_Label { YES=-2, NO };
const string label_no = "NO";
const string label_yes = "YES"; 

struct Term {
    int     oper;   // term operation from Term_Oper
    int     sp;     // <0: taxon no.| >=0: species no. 
    int     yes;    // next term if satisfied
    int     no;     // next term if not satisfied
    int     nwit;   // number of witness required
    int     range;  // vicinity size
    double  E;      // max allowed E-value (except BBH modes)
    //unsigned int fmask;     // mask for required/known fields in ADD terms
    int     forder[maxfield];   // mask+order for required/known fields in ADD terms 
    int     uselast0;       // old witness flags (1/2/4) over pairs in a tuple
    int     uselast1;
    int     BBH;    // 0=none,1|2|4=ORTH/BBH,8|16|32=OBH,64|128|256=IBH (see Best_Hit enum)
    Term() {
        oper    = NOP;
        sp      = unknown_species;
        yes     = YES;
        no      = NO;
        nwit    = def_witness;
        range   = currentdefrange;
        E       = def_E;
        //fmask   = 0xffffffff;
        uselast0 = 1;   // same X in all 1st pairs (inside IN, OVER loops)
        uselast1 = 1;   // same X' in all 2nd pairs (inside IN2 loop)
        BBH     = 0;    // normally BBH not required
        for (int i = 0; i < maxfield; i++)
            forder[i] = 0;
    }
    void operator =(const Term & t) {
        oper    = t.oper;
        sp      = t.sp;
        yes     = t.yes;
        no      = t.no;
        nwit    = t.nwit;
        range   = t.range;
        E       = t.E;
        //fmask   = t.fmask;
        uselast0 = t.uselast0;
        uselast1 = t.uselast1;
        BBH     = t.BBH;
        for (int i = 0; i < maxfield; i++)
            forder[i] = t.forder[i];
    }
};

struct Homolog {
    PGene   pgene;
    double  evalue;
    int     score;
    Homolog() {
    }
    Homolog(PGene pg, double e, int s) {
        pgene  = pg;
        evalue = e;
        score  = s;
    }
};

struct Contig {
    string  name;
    map <string, Gene> genes;
    bool    log;        // logging flag
    Contig() {
        name = "";
        log = false;
        genes.clear();
    }
    Contig(string& str) {
        name = str;
        log = false;
        genes.clear();
    }
   ~Contig() {
        genes.clear();
    }
};

struct Species {
    string   name;
    bool need;
    bool needmatrix;
    bool needself;
    bool neednumpar;
    map <string, Contig> contigs;
    vector <string> fields;             // Names of fields that present at input
    vector <int> required;              // Maps to a number of required field or -1
    vector <int> myfields;              // [nColumns] Actual numbers of required and known fields
    Species() {
        name = "";
        need       = false;
        needmatrix = false;
        needself   = false;
        neednumpar = false;
    }
    Species(string& str) {
        name = str;
        need       = false;
        needmatrix = false;
        needself   = false;
        neednumpar = false;
    }
   ~Species() {
        contigs.clear();
        required.clear();
        fields.clear();
        myfields.clear();
    }
};

struct Group {
    int gsize;
    int goon;       // continue indicator: 1=X, 2=Y, 4=Z
    int BBH;        // see Best_Hit enumeration for bits
    double E;       // E-value used for this group
    PGene pgene[maxgroup];
    Group(int bbh = NONE) {
        gsize = 0; 
        goon = 0;
        BBH = bbh;
        E = bigE;
        for (int n=0; n<maxgroup; n++)
            pgene[n] = 0;
    }
    Group(const Group & gr) {
        gsize = gr.gsize;
        goon = gr.goon;
        BBH = gr.BBH;
        E = gr.E;
        for (int n=0; n<maxgroup; n++)
            pgene[n] = gr.pgene[n];
    }
    Group(PGene px, int bbh = NONE) {
        gsize = 1;
        goon = 0;
        BBH = bbh;
        E = bigE;
        pgene[0] = px;
        for (int n=1; n<maxgroup; n++)
            pgene[n] = 0;
    }
    Group(PGene px, PGene py, int bbh = NONE) {
        gsize = 2;
        goon = 0;
        BBH = bbh;
        E = bigE;
        pgene[0] = px;
        pgene[1] = py;
        for (int n=2; n<maxgroup; n++)
            pgene[n] = 0;
    }
    Group(PGene px, PGene py, PGene pz, int bbh = NONE) {
        gsize = 3;
        goon = 0;
        BBH = bbh;
        E = bigE;
        pgene[0] = px;
        pgene[1] = py;
        pgene[2] = pz;
        for (int n=3; n<maxgroup; n++)
            pgene[n] = 0;
    }
    void operator =(const Group & gr) {
        gsize = gr.gsize;
        goon = gr.goon;
        BBH = gr.BBH;
        E = gr.E;
        for (int n=0; n<maxgroup; n++)
            pgene[n] = gr.pgene[n];
    }
    void clear() {
        gsize = 0;
        goon = 0;
        BBH = NONE;
        E = bigE;
        for (int n=0; n<maxgroup; n++)
            pgene[n] = 0;
    }
};
struct Taxon {
    string      name;       // taxon name (begins with *)
    int         nspec;      // number of species in this taxon
    vector<int> specno;     // species numbers
    Taxon() {
        name.clear();
        nspec = 0;
        specno.clear();
    }
    Taxon(char ch) {
        name.assign(1, ch);
        nspec = 0;
        specno.clear();
    }
    Taxon(string& str) {
        name = str;
        nspec = 0;
        specno.clear();
    }
};

struct Global {
    string      progmode;      // Line of config file
    bool  mode_homology;
    bool  mode_single;          // single homology file
    bool  mode_cluster;
    bool  mode_ogroup;
    bool  mode_matrix;
    bool  mode_info;
    bool  span_center;
    bool  span_inner;
    bool  span_outer;
    bool  mode_extract;
    bool  mode_order;
    bool  mode_direct;
    bool  mode_mirror;
    bool  cmd_extract;      // extraction specified in cmd line
    bool  quiet;            // shorten console output
    bool  qquiet;           // minimum console output
    bool  log_separate;
    bool  log_tail;
    bool  log_gene;
    bool  log_protein;
    bool  log_verbose;
    bool  log_contig;
    bool  log_span1;
    bool  log_span2;
    bool  log_synteny;
    bool  log_union;        // true: log entire column/row of ID, false: cell
    int   log_contigno;     // if >= 0 then detail log for this contig
    int   log_geneno;       // if >= 0 then detail log for this gene of contigno
    int   currentgenestep;
    int   c_no, x_no;
    int   size, rank;       // MPI variables
    vector <string>  logID;         // GeneID/ProteinID(s)/ContigNo(s) to log
    string           homology_path; // Directory of the homology files
    string           homology_ext;  // Extension of the homology files
    string           paralogs_path; // Directory of the paralog files
    string           paralogs_ext;  // Extension of the paralog files
    string           matrix_path;   // Directory of the matrix files
    string           matrix_ext;    // Extension of the matrix files
    string           info_path;     // Directory of the gene info files
    string           info_ext;      // Extension of the gene info files
    vector <string>  cluster_files; // Names of the cluster or ogroup files
    int              nColumns;      // Actual number of usable columns (incl. Species)
    int              nAnimals;      // Species in total
    vector <Species> Animals;       // Array of species, #0=base
    vector <Taxon>   taxa;          // Array of taxons, 1 based
    vector <Term>    terms;
    double           Elimit;        // Max E-value used in predicate
    int              maxtpl;        // Max number of terms per line (of ADD terms)
    vector <int>     termnos;       // [maxtpl] List of terms in maximum set
    ofstream         out;
    vector <string>  myfields;      // [nColumns] Names of usable fields in fixed order 
    vector <string>  aliases;       // [nColumns] Aliases of these names (optional)
    map <string, PGene> stableid;   // Ensembl stable ID -> *Gene mapping
    string           heading;       // manually set heading line
    int              fnumpara;      // a number of known field with paralogs count
    map <string, double> parameter; // lowercase parameter -> double value
    Global() {
        cmd_extract = false;
        quiet = false;
        qquiet = false;
        mode_homology = true;
        mode_single = false;
        mode_cluster = false;
        mode_ogroup = false;
        mode_matrix = false;
        mode_info = false;
        mode_extract = false;
        mode_order = false;
        mode_direct = false;
        mode_mirror = false;
        span_center = false;
        span_inner = false;
        span_outer = true;
        log_separate = false;
        log_tail = false;
        log_gene = false;
        log_protein = false;
        log_verbose = false;
        log_contig = false;
        log_span1 = false;
        log_span2 = false;
        log_synteny = false;
        log_union = false;
        log_contigno = -1;
        log_geneno = -1;
        currentgenestep = outgenestep;
        nColumns = ncol;
        nAnimals = 0;
        maxtpl = 0;
        Elimit = 0;
        logID.clear();
        terms.clear();
        homology_path.clear();
        homology_ext.clear();
        paralogs_path.clear();
        paralogs_ext.clear();
        cluster_files.clear();
        matrix_path.clear();
        matrix_ext.clear();
        info_path.clear();
        info_ext.clear();
        stableid.clear();
        heading.clear();
        //Taxon tx;
        //taxa.push_back(tx);     // dummy entry for taxa numbering from 1
        Term tr;
        tr.oper = SET;
        tr.yes = 1; tr.no = 1;
        terms.push_back(tr);    // fixed entry to store current parameters
        size = 1;               // no MPI by default
        rank = 0;
        fnumpara = -1;
    }
};
   
#ifdef SYNTENY_MAIN
    Global global;
#else
    extern Global global;
#endif

struct  Gene {
    string  name;
    int     begin;
    int     end;
    int     strand;
    vector <vector <Homolog> > homologs;    // & paralogs
    vector <string> fields;     // original fields at input
    int     sp;         // animal no. - back reference
    Citer   cit;        // contig iterator - back reference
    bool    log;        // flaged for logging
    Gene() {
        name = "";
        begin = 0;
        end = 0;
        strand = 0;
        sp = -1;
        log = false;
        for (int k = 0; k < global.nAnimals; k++) {
            vector <Homolog> vpg;
            homologs.push_back(vpg);
        }
        fields.clear();
    }
   ~Gene() {
        homologs.clear();
        fields.clear();
    }
};

bool    ReadConfig (const char* filename);
bool    ReadData (int spec1, int spec2);
bool    ReadShortData (int spec, bool paralogs=false);
bool    ReadClusterData (const char* filename);
bool    ReadOgroupData (const char* filename);
bool    ReadGeneInfo (int spec);
bool    ReadMatrix (int spec);
bool    IsNewPair (const PGene pg1, const PGene pg2);
int     FindOrganism (const string & str);
int     FindSpecno (string & spec);
bool    Predicate (Gene & x, vector <Group> & grp);
bool    ExceedSpan (const Group & grp, const int span);
bool    HasSynteny (Group & g1, Group &g2, int sp2, const int span);
bool    InSynteny (const Group & g1, const Group & g2);
void    ParseExtension (const string& str);
void    SetBestHit (Group & group, int geneno, Term & term);
int     GetBestHit (vector <Homolog> &hv);
bool    GreaterGenes (Citer c1, Citer c2);

#endif
