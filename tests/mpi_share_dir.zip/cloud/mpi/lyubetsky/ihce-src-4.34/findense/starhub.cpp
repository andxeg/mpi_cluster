// Multi-Processing FinDense
// (c)2016,2017 Lev Rubanov, IITP RAS

#include "findense.h"

int nspall;             // Number of all (old) species
vector <int> LUT;       // Look-up table: old_spno -> new_spno

#pragma warning(disable : 4244)
bool    ReadStarFile(int specno, Mapping& map) {
    int vno = map.vertex(specno, global.rank);
    if (vno < 0)        // nothing to do
        return true;
    ifstream starfile;
    string starname = global.starname;
    string id = global.species[specno].id;
    string::size_type pos = starname.find_last_of('*');
    if (pos == string::npos) {
        cerr << "Star file name " << starname << " must contain *." << endl;
        return false;
    }
    starname[pos] = id[0];
    starname.insert(pos+1, id, 1, id.size()-1);
    starfile.open(starname.c_str(), ios_base::in | ios_base::binary);
    if (!starfile.good())
        return false;

    // Read star file header (here, use only nedges)
    StarFileHeader sfh;
    starfile.read((char*)&sfh, sizeof(StarFileHeader));
    if (!starfile.good())
        return false;

    int nstars = sfh.nstars;
    __int64 *offset = new __int64 [nstars];
    offset[0] = sfh.offset[0];
    starfile.read((char*)&offset[1], (nstars-1)*sizeof(__int64));
    if (!starfile.good())
        return false;
    if (sizeof(size_t)==sizeof(int) && sfh.filelen > numeric_limits<int>::max()) {
        cout << "Input file " << starname 
            << " too long (use 64-bit)" << endl;
        return false;
    }

    // Read relevant stars for this rank
    size_t vertexno = (size_t)vno;
    int starno = map.elemno(specno, global.rank);
    for ( ; starno < nstars; starno += global.size, vertexno++) {
        __int64 off = offset[starno];
        starfile.seekg(off);    // Be aware of MS error in VC++ prior v.11
        if (starfile.fail()) {
            cout << "Star positioning error: " << global.species[specno].id
                << " off=" << hex << off << endl;
            return false;
        }
        StarHeader shdr;
        starfile.read((char*)&shdr, sizeof(StarHeader));
        if (!starfile.good()) {
            cout << "Star read error: " << global.species[specno].id
                << " starno=" << starno << endl;
            return false;
        }

        int nedges = shdr.nedges;
        PVertex vertex = new Vertex(specno);
        vertex->elemno = starno;
        Edge edge;
        // Read & process edges
        for (int n = 0; n < nedges; n++) {
            starfile.read((char*)&edge, sizeof(Edge));
            if (!starfile.good()) {
                cout << "Star read error: " << global.species[specno].id
                    << " starno=" << starno << " edgeno=" << n << endl;
                return false;
            }

            //if (minweight != 0 && edge.weight < minweight)
            //    continue;       // skip underthreshold edges

            int sp = LUT[edge.specno];
            if (sp < 0)
                continue;       // skip absent species
            edge.specno = sp;
            vertex->perspec[sp]++;
            vertex->edges.push_back(edge);
        }

        if (!vertex->edges.empty()) {
            global.myvert[vertexno] = vertex;
        }
        else {
            global.myvert[vertexno] = 0;
            delete vertex;
        }
    }

    delete[] offset;
    return true;
}

bool    ReadHub(void) {
    ifstream hubfile;
    hubfile.open(global.hubname.c_str(), ios_base::in | ios_base::binary);
    if (hubfile.fail())
        return false;

    // Read hub file header
    HubFileHeader hfh;
    hubfile.read((char*)&hfh, sizeof(HubFileHeader));
    if (!hubfile.good())
        return false;

    nspall = hfh.nspecies;
    __int64 *offset = new __int64 [nspall];
    offset[0] = hfh.offset[0];
    hubfile.read((char*)&offset[1], (nspall-1)*sizeof(__int64));
    if (!hubfile.good())
        return false;

    // Fill look-up table
    int sp;
    for (int k = 0; k < nspall; k++) {
        hubfile.seekg((iostream::pos_type)offset[k]);
        char spid[specidsize];
        hubfile.read(spid, specidsize);
        if (!hubfile.good()) {
            cout << "Read error in hub file entry " << k << endl;
            return false;
        }

        string id;
        id.assign(spid);
        for (sp = 0; sp < global.nSpecies; sp++) {
            if (global.species[sp].id == id) {
                global.species[sp].oldsp = k;
                break;
            }
        }
        if (sp >= global.nSpecies)
            sp = -1;            // skipped species indicator
        LUT.push_back(sp);
    }

    // Check that all required species are present
    for (sp = 0; sp < global.nSpecies; sp++) {
        if (global.species[sp].oldsp < 0) {
            cout << "No data for species " << global.species[sp].id << endl;
            return false;
        }
    }

    // Read elements count and IDs
    for (sp = 0; sp < global.nSpecies; sp++) {
        int oldsp = global.species[sp].oldsp;
        hubfile.seekg((iostream::pos_type)offset[oldsp]);
        StripHeader shdr;
        hubfile.read((char*)&shdr, sizeof(StripHeader));
        if (!hubfile.good()) {
            cout << "Read error in hub file strip " << oldsp 
                << " (" << global.species[sp].id << ")" << endl;
            return false;
        }
        global.species[sp].nelem = shdr.nelem;
        //TODO string protid;
        Element element;
        memcpy(&element, &shdr.element[0], sizeof(Element));
        global.species[sp].elements.push_back(element);
        for (int np = 1; np < (int)shdr.nelem; np++) {
            hubfile.read((char*)(&element), sizeof(Element));
            if (!hubfile.good()) {
                cout << "Hub file strip error " << oldsp << " (" 
                    << global.species[sp].id << ", elem #" << np << ")" << endl;
                return false;
            }
            global.species[sp].elements.push_back(element);
        }
        cout << left << setw(20/*specidsize*/) << global.species[sp].id 
            << right << ": " << setw(6) << shdr.nelem << " elements" << endl;
    }

    delete [] offset;
    return true;
}

bool    ReadToplevel(int specno) {
    char buf[buflen];
    Species& spec = global.species[specno];
    ifstream fasta(spec.fasta.c_str());
    if (!fasta.good()) {
        cout << "Cannot open " << spec.fasta << endl;
        return false;
    }

    // Looping over sequences
    int tlno   = 1;     // top level sequence no.
    int lineno = 1;
    fasta.getline(buf, buflen);
    string line(buf);
    if (fasta.bad()) { 
        cout << "Cannot read input file " << spec.fasta << ", line=1" << endl;
        return false;
    }
    else if (line.substr(0,gbkintro.size()) == gbkintro) {     // read from Genbank
        spec.input &= ~infasta;
        spec.input |= ingbk;
        string token;
        Toplevel toplevel;
        toplevel.no = 1;
        istringstream is1(line.substr(gbkintro.size()));
        is1 >> toplevel.id >> toplevel.len;
        while (!fasta.eof()) {      // skip everything until FEATURES
            fasta.getline(buf, buflen);
            if (fasta.eof()) break;
            lineno++;
            line.assign(buf);
            if (line.substr(0,gbkfeature.size()) == gbkfeature) break;
        }

        bool skiptolow = true;
        bool nextchunk = false;
        bool indetail  = false;
        bool nextid    = false;
        bool nextdesc  = false;
        int type;
        int anngroup1  = 0;     // # of first annotation in a group
        string chunks;
        string id, description;
        while (!fasta.eof()) {
            fasta.getline(buf, buflen);
            if (fasta.eof()) break;
            lineno++;
            line.assign(buf);
            if (line.substr(0,gbkorigin.size()) == gbkorigin) break;
            
            int pos = (int)line.find_first_not_of(' ');     // 1st non-blank
            if (skiptolow && pos == global.gbvaloffset)
                continue;
            if (indetail) {
                if (pos == global.gblowoffset) {        // store detail
                    indetail = false;
                    // store ID & description in all pairs collected
                    for ( ; anngroup1 < (int)toplevel.annot.size(); anngroup1++) {
                        Annot& annot      = toplevel.annot[anngroup1];
                        annot.id          = id;
                        annot.description = description;
                    }
                }
                else if (pos == global.gbvaloffset) {   // parse detail
                    if (!nextid && !nextdesc) {
                        pos = StartWith(line, global.gbvaloffset, global.gbid[type-1]);
                        if (pos != -1 && line[pos+1] == '\"') {
                            if (!id.empty()) id += "; ";
                            id.append(line.substr(pos+2));
                            if (id[id.size()-1] != '\"')    // to be continued
                                nextid = true;
                            else id.erase(id.size()-1);
                            continue;
                        }
                        pos = StartWith(line, global.gbvaloffset, global.gbdescription[type-1]);
                        if (pos != -1 && line[pos+1] == '\"') {
                            if (!description.empty()) description += "; ";
                            description.append(line.substr(pos+2));
                            if (description[description.size()-1] != '\"')    // to be continued
                                nextdesc = true;
                            else description.erase(description.size()-1);
                            continue;
                        }
                        continue;
                    }
                    else if (nextid) {
                        id.append(line.substr(pos));
                        if (id[id.size()-1] == '\"') {
                            nextid = false;
                            id.erase(id.size()-1);
                        }
                        continue;
                    }
                    else if (nextdesc) {
                        description.append(line.substr(pos));
                        if (description[description.size()-1] == '\"') {
                            nextdesc = false;
                            description.erase(description.size()-1);
                        }
                        continue;
                    }
                    else continue;
                }
                else {
                    cout << "Error in GenBank file, lineno=" << lineno << endl;
                    skiptolow = true;
                    indetail  = false;
                    continue;
                }
            }
            if (nextchunk || pos == global.gblowoffset) {    // low type found
                skiptolow = false;
                istringstream is2(line.substr(pos));
                if (nextchunk) {    // continue collecting chunks
                    string ch;
                    is2 >> ch;
                    chunks.append(ch);
                }
                else {              // start collecting new chunks
                    string kind;
                    is2 >> kind;
                    string kind1 = "|" + kind + "|";
                    // Determine type and skip unneeded entries
                    for (type = 0; type < 3; type++)
                        if (global.lowtype[type].find(kind1) != string::npos) break;
                    if (type >= 3) {    // skip while value-only lines 
                        skiptolow = true;
                        continue;
                    }
                    type++;
                    is2 >> chunks;
                }
                if (chunks[chunks.size()-1] == ',') {
                    nextchunk = true;
                    continue;
                }
                nextchunk = false;
                anngroup1 = (int)toplevel.annot.size();
                int strand;

                pos = StartWith(chunks, 0, global.gbcomplement);
                if (pos != -1) {
                    strand = -1;
                    chunks.erase(0, pos+1);
                    chunks.erase(chunks.size()-1, 1);
                }
                else strand = 1;

                pos = StartWith(chunks, 0, global.gbjoin);
                if (pos != -1) {
                    chunks.erase(0, pos+1);
                    chunks.erase(chunks.size()-1, 1);
                }

                // collect pairs storing their coordinates
                for (int off = 0; off < (int)chunks.size(); ) {
                    pos = StartWith(chunks, off, global.gbcomplement);
                    int invert; 
                    if (pos == -1) invert = 1;
                    else {
                        invert = -1;
                        off = pos + 1;
                    }
                    if (chunks[off] == '<') off++;
                    Annot annot;
                    annot.type   = type;
                    annot.strand = strand * invert;
                    pos = (int)chunks.find_first_of('.', off);
                    istringstream is3(chunks.substr(off, pos-off));
                    is3 >> annot.begin;
                    off = pos+2;
                    if (chunks[off] == '>') off++;
                    pos = (int)chunks.find_first_of("),", off);
                    istringstream is4(chunks.substr(off, pos-off));
                    is4 >> annot.end;
                    toplevel.annot.push_back(annot);
                    if (pos < 0) break;
                    if (chunks[pos] == ')')
                        pos = pos + 1;
                    if (pos >= (int)chunks.size()) break;
                    if (chunks[pos] == ',')
                        off = pos + 1;
                }

                // continue with parsing ID and description
                if ((int)toplevel.annot.size() > anngroup1) {
                    indetail = true;
                    id.clear();
                    description.clear();
                }
                else
                    skiptolow = true;
                continue;
            }
        }

        while (!fasta.eof()) {
            fasta.getline(buf, buflen);
            if (fasta.eof()) break;
            line.assign(buf);
            if (line.substr(0,gbkend.size()) == gbkend) break;
            // Process sequence
            istringstream iss(line);
            int n;
            iss >> n;   // position
            for (n = 0; n < gbkgroups; n++) {
                string group;
                iss >> group;
                if (iss.fail()) break;
                upperCase(group);
                toplevel.seq.append(group);
            }
        }
        if ((int)toplevel.seq.size() != toplevel.len) {
            cout << "Sequence length mismatch in " << spec.fasta << ": " 
                << toplevel.seq.size() << " vs " << toplevel.len << endl;
        }
        spec.toplevels.push_back(toplevel);
        spec.tlmap.insert(SIpair(toplevel.id, spec.nToplevels++));
    }
    else if (buf[0]!='>') {
        cout << "Invalid FASTA heading in " << spec.fasta << ", line=1" << endl;
        return false;
    }
    else {              // read lines from fasta
        spec.input |= infasta;
        spec.input &= ~ingbk;
        while (fasta.good()) {
            line.assign(buf);
            Toplevel toplevel;
            toplevel.no  = tlno;
            toplevel.id  = getSequenceName(line);
            toplevel.len = 0;

            while (!fasta.eof()) {
                fasta.get(buf, buflen, '\n');
                if (fasta.eof()) break;
                if (fasta.fail()) {
                    fasta.clear();
                    char newline = fasta.get();     // extract \n
                    lineno++;
                    continue;
                }
                if (buf[0] == '>') {
                    char newline = fasta.get();     // extract \n
                    lineno++;
                    break;
                }
                string portion(buf);
                string::size_type lastpos = portion.length() - 1;
                if (portion[lastpos]=='\r' || portion[lastpos]=='\n')
                    portion.erase(lastpos);
                toplevel.len += (int)portion.length();
                upperCase(portion);
                toplevel.seq += portion;
            }

            spec.toplevels.push_back(toplevel);
            spec.tlmap.insert(SIpair(toplevel.id, spec.nToplevels++));
            tlno++;
        }
    }
    cout << left << setw(20/*specidsize*/) << spec.id << right << ": " 
        << spec.nToplevels << " sequence(s) read" << endl;
    fasta.close();
    return true;
}

// Get string value of 'key=value;' field within a string.
// Take last occurrence of the key if more than one exists.
// Also substitute blanks for pluses and decode %hh characters
string& getField (const string& str, const char* key) {
    static string result;
    string target(key);
    target += "=";
    string::size_type off = str.rfind(target);
    if (off != string::npos) {
        off += target.size();
        string::size_type pos = str.find_first_of(";", off);
        string value;
        result = (pos == string::npos) ? str.substr(off) : str.substr(off, pos - off);
        off = 0;
        while ((pos = result.find_first_of("+", off)) != string::npos) {
            result[pos] = ' ';
            off = ++pos;
        }
        off = 0;
        while ((pos = result.find_first_of("%", off)) != string::npos) {
            if (pos+2 < result.size()) {
                string hexbyte("0x");
                hexbyte += result.substr(pos+1, 2);
                istringstream ish(hexbyte);
                int intc;
                ish >> hex >> intc;
                string strc(1, intc);
                result.replace(pos, 3, strc);
            }
            off = ++pos;
        }
    }
    return result;
}
string& getField (const string& str, const string& key) {
    return getField(str, key.c_str());
}

bool    ReadGff (int specno) {
    int lineno = 1;
    int nTops  = 0;
    int nGenes = 0;
    int nCds   = 0;
    int nRnas  = 0;   
    Species& spec = global.species[specno];
    if (spec.gff.empty()) return true;
    ifstream gff(spec.gff.c_str());
    if (!gff.good()) {
        cout << "Cannot open " << spec.gff << endl;
        return false;
    }

    for ( ; !gff.eof(); lineno++) {
        string s;
        getline(gff, s, '\n');
        if (gff.eof()) break;
        if (gff.bad() || gff.fail()) {
            cout << left << setw(32) << spec.id << ": " << right
                << "\nError in GFF line " << lineno << endl;
            return false;
        }

        // Check for end of gene info
        if (s.find("##FASTA") != string::npos) 
            break;
        
        // Skip comments
        if (s[0] == '#') 
            continue;

        string::size_type off = 0;
        string::size_type pos;

        // 1: seqid
        pos = s.find_first_of(tab, off);
        if (pos == string::npos) {
            cout << "GFF line " << lineno << " format error (1_seqid)." << endl;
            return false;
        }
        string id = s.substr(off, pos - off);
        off = ++pos;

        // 2: source (ignored)
        pos = s.find_first_of(tab, off);
        if (pos == string::npos) {
            cout << "GFF line " << lineno << " format error (2_source)." << endl;
            return false;
        }
        off = ++pos;

        // 3: type
        pos = s.find_first_of(tab, off);
        if (pos == string::npos) {
            cout << "GFF line " << lineno << " format error (3_type)." << endl;
            return false;
        }
        string kind = s.substr(off, pos - off);
        string kind1 = "|" + kind + "|";
        off = ++pos;

        // Determine type and skip unneeded entries
        int type = -1;
        if (global.toptype.find(kind1) != string::npos)         type = 0;
        else if (global.lowtype[0].find(kind1) != string::npos) type = 1;
        else if (global.lowtype[1].find(kind1) != string::npos) type = 2;
        else if (global.lowtype[2].find(kind1) != string::npos) type = 3;
        else continue;

        SIiter tmit = spec.tlmap.find(id);
        if (tmit != spec.tlmap.end()) { 
            Toplevel& top = spec.toplevels[tmit->second];
            // Skip embedded toplevels (sub-region, repeat_region...)
            if (type == 0 && !top.annot.empty() && top.annot[0].type == 0) {
                //cout << "Embedded feature '" << id << ":" << kind 
                //    << "' ignored in GFF line " << lineno << "." << endl;
                continue;
            }
        }
        else {      // skip unknown tls
            //cout << "Unknown top level sequence " << id << endl;
            //return false;
            continue;
        }

        Toplevel& top = spec.toplevels[tmit->second];
        Annot annot;
        annot.type = type;

        // 4: begin
        pos = s.find_first_of(tab, off);
        if (pos == string::npos) {
            cout << "GFF line " << lineno << " format error (4_begin)." << endl;
            return false;
        }
        istringstream issbegin(s.substr(off, pos - off));
        off = ++pos;
        issbegin >> annot.begin;

        // 5: end
        pos = s.find_first_of(tab, off);
        if (pos == string::npos) {
            cout << "GFF line " << lineno << " format error (5_end)." << endl;
            return false;
        }
        istringstream issend(s.substr(off, pos - off));
        off = ++pos;
        issend >> annot.end;

        // 6: score (ignored)
        pos = s.find_first_of(tab, off);
        if (pos == string::npos) {
            cout << "GFF line " << lineno << " format error (6_score)." << endl;
            return false;
        }
        off = ++pos;

        // 7: strand
        pos = s.find_first_of(tab, off);
        if (pos == string::npos) {
            cout << "GFF line " << lineno << " format error (7_strand)." << endl;
            return false;
        }
        switch (s[off]) {
            case '+': annot.strand = 1; break;
            case '-': annot.strand = -1; break;
            default:  annot.strand = 0; break;
        }
        off = ++pos;

        // 8: phase (ignored)
        pos = s.find_first_of(tab, off);
        if (pos == string::npos) {
            cout << "GFF line " << lineno << " format error (8_phase)." << endl;
            return false;
        }
        off = ++pos;

        // 9: attributes (info)
        pos = s.find_first_of(tab, off);
        string info = (pos == string::npos) ? s.substr(off) : s.substr(off, pos - off);
        string tmp;

        switch (type) {
            case 0:         // toptype
                nTops++;
                annot.id = getField(info, "Name");
                annot.description = getField(info, "Note");
                break;

            case 1:         // gene
                nGenes++;
                annot.id = getField(info, "ID");
                annot.description = getField(info, "Name");
                if (annot.description.empty()) {
                    annot.description = getField(info, "description");
                    if (annot.description.empty())
                        annot.description = getField(info, "Note");
                }
                break;

            case 2:         // CDS
                nCds++;
                annot.id = getField(info, "Name");
                annot.description = getField(info, "product");
                break;

            case 3:         // RNA
                nRnas++;
                annot.id = getField(info, "Name");
                annot.description = getField(info, "product");
                break;
        }
        top.annot.push_back(annot);
    }
    for (int i = 0; i < spec.nToplevels; i++) {
        Toplevel& top = spec.toplevels[i];
        sort(top.annot.begin(), top.annot.end(), AnnotCompare());
    }
    cout << left << setw(20/*specidsize*/) << spec.id << right << ": seqs=" 
        << nTops << " genes=" << nGenes << " cds=" << nCds << " rnas=" 
        << nRnas << endl;
    gff.close();
    return true;
}

// Return annotation no. that intersects with given element, or -1
int     findAnnotation (Toplevel& top, Element& el, int type) {
    int num = -1;
    int begin = (global.sword.unite!=0 ? el.ustart : el.istart) 
        + global.annotate - (global.annotate > 0 ? 1 : 0);
    if (begin < 0) begin = 0;
    int end = (global.sword.unite!=0 ? el.ustart+el.ulen : el.istart+el.ilen) 
        - global.annotate - (global.annotate > 0 ? 0 : 1);
    if (end >= top.len) end = top.len-1;
    if (end < begin) return num;
    for (int i = 0; i < (int)top.annot.size(); i++) {
        Annot& annot = top.annot[i];
        if (annot.type != type) continue;
        if (annot.begin > end || annot.end < begin) continue;
        num = i; 
        break;
    }
    return num;
}

// Extract from fasta heading: gb | ref | everything
// Remove version no. if any
string  getSequenceName (string& line) {
    string::size_type pos, off = 1;
    pos = line.find("ref|", off);
    if (pos != string::npos)
        off = pos + 4;
    else {
        pos = line.find("gb|", off);
        if (pos != string::npos)
            off = pos + 3;
    }
    pos = line.find_first_of("|.", off);
    return line.substr(off, (pos==string::npos ? pos : pos-off));
}

// Check if the string at given offset starts with some of keys.
// Returns the position just following the key or -1.
int     StartWith (string& str, int off, string& keys) {
    string::size_type begin = keys.find_first_not_of('|');
    string::size_type end;
    while (begin != string::npos) {
        end = keys.find_first_of('|', begin);
        if (end == string::npos) 
            end = keys.size();
        if (str.substr(off, end-begin) == keys.substr(begin, end-begin)) 
            return off + (int)(end-begin);
        begin = keys.find_first_not_of('|', end);
    }
    return -1;
}
