// Multi-Processing FinDense
// (c)2016,2017 Lev Rubanov, IITP RAS

#include "findense.h"

void RemoveEdgeLocal(Signal& sig) {
    Vertex *vertex = global.myvert[sig.tovertex];
    if (vertex != 0) {
        if (vertex->specno != sig.tospecies || vertex->elemno != sig.toelement) {
            cout << "\nInvalid target to remove: v=" << sig.tovertex 
                << " s=" << sig.tospecies << " p=" << sig.toelement << endl;
            return;
        }
        list <Edge>::iterator lit = vertex->edges.begin();
        for ( ; lit != vertex->edges.end(); lit++) {
            if ((lit->specno & spmask) == sig.fromspecies &&
                lit->elemno == sig.fromelement)
                break;
        }
        if (lit != vertex->edges.end()) {
            vertex->perspec[lit->specno & spmask]--;
            vertex->edges.erase(lit);

            #ifdef MPFID_DEBUG_AUTO
            cerr << "-" << sig.tospecies << "_" << sig.toelement << ","
                << sig.fromspecies << "_" << sig.fromelement << " ";
            #endif

            if (vertex->edges.empty()) {    // Last edge removed
                #ifdef MPFID_DEBUG_AUTO
                cerr << "-" << vertex->specno << "_" << vertex->elemno << " ";
                #endif
                delete vertex;
                global.myvert[sig.tovertex] = 0;
            }
        }
    }
}

void LabelEdgeLocal(Signal& sig) {
    Vertex *vertex = global.myvert[sig.tovertex];
    if (vertex != 0) {
        if (vertex->specno != sig.tospecies || vertex->elemno != sig.toelement) {
            cout << "\nInvalid target to label: v=" << sig.tovertex 
                << " s=" << sig.tospecies << " p=" << sig.toelement << endl;
            return;
        }
        list <Edge>::iterator lit = vertex->edges.begin();
        for ( ; lit != vertex->edges.end(); lit++) {
            if ((lit->specno & spmask) == sig.fromspecies &&
                lit->elemno == sig.fromelement)
                break;
        }
        if (lit != vertex->edges.end()) {
            lit->specno |= flmask;
            #ifdef MPFID_DEBUG_AUTO
            cerr << "*" << vertex->specno << "_" << vertex->elemno << ","
                << (lit->specno & spmask) << "_" << lit->elemno << " ";
            #endif
        }
        else {
            cout << "No edge to label: " << sig.fromspecies << "_"
                << sig.fromelement << "," << sig.tospecies << "_"
                << sig.toelement << endl;
            return;
        }
    }
}

// Also makes edge thresholding at step==1
int MakeOdd(Mapping& map, int step) {
    int ch = 0;
    int nspecies = (int)global.species.size();
    int specno;
    int nvertices = map.nvertices(global.rank);
    int vertno;
    Signal sig;
    Queue& myqueue = *global.pqueue;
    //sig.fromrank = global.rank;
    global.t1 = mytime();
    for (vertno = 0; vertno < nvertices; vertno++) {
        //CheckReady(global.rank);
        if (global.milestone != 0) {
            global.t2 = mytime();
            if ((global.t2-global.t1)/60 >= global.milestone) {
                cout << (int)((global.t2-global.t0)/60) << " m: Odd step=" 
                    << step << " vertno=" << vertno << " changes=" << ch << endl;
                global.t1 = global.t2;
            }
        }
        Vertex *vertex = global.myvert[vertno];
        if (vertex == 0)
            continue;       // skip deleted vertices

        sig.fromvertex  = vertno;
        sig.fromspecies = vertex->specno;
        sig.fromelement = vertex->elemno;

        // Check rule #0 (only at first step): If the weight of incident edge
        //  is less than threshold, delete such edge. 
        //  Also delete exactly duplicated edges.
        if (step == 1) {
            list <Edge>::iterator lit = vertex->edges.begin();
            for ( ; lit != vertex->edges.end(); ) {   // no lit++
                list<Edge>::iterator tmp = lit;
                tmp++;      // next edge

                if ((global.minweight == 0 || lit->weight >= global.minweight) && 
                    (tmp == vertex->edges.end() || *tmp != *lit)) {
                    lit = tmp; 
                    continue; 
                }

                #ifdef MPFID_DEBUG_FILTER
                if (ch % 100000 == 0) {
                    global.t2 = mytime();
                    cerr << (int)((global.t2-global.t0)/60) << " m: -- sp=" 
                        << vertex->specno << " elem=" << vertex->elemno 
                        << " ch=" << ch << endl;
                }
                #endif
                // Delete current edge
                sig.tospecies = lit->specno & spmask;
                sig.toelement = lit->elemno;
                int torank = map.rank((lit->specno & spmask), lit->elemno, sig.tovertex);
                sig.operation = tagRemove;
                vertex->perspec[lit->specno & spmask]--;
                ch++;

                #ifdef MPFID_DEBUG_AUTO
                cerr << "=" << vertex->specno << "_" << vertex->elemno << ","
                    << (lit->specno & spmask) << "_" << lit->elemno << " ";
                #endif

                vertex->edges.erase(lit);
                myqueue[torank].push_back(sig);
                //CheckReady(global.rank);
                //RemoveEdge(sig);
                lit = tmp;
            }       // next edge

            // Delete vertex if no edges remain
            if (vertex->edges.empty()) {
                delete vertex;
                global.myvert[vertno] = 0;
            }
            continue;               // nothing to do more at first step
        }

        // Check rule #1 (after first step): If this vertex is connected with less than
        //  (m-1) parts of the graph, delete the vertex together with incident edges.
        int inclique = 1;   // count itself 
        for (specno = 0; specno < nspecies; specno++) {
            if (vertex->perspec[specno] != 0)
                inclique++;
        }
        if (inclique < global.minpart) {
            list <Edge>::iterator lit = vertex->edges.begin();
            for ( ; lit != vertex->edges.end(); ) {    // no lit++
                sig.tospecies = lit->specno & spmask;
                sig.toelement = lit->elemno;
                int torank = map.rank((lit->specno & spmask), lit->elemno, sig.tovertex);
                sig.operation = tagRemove;
                vertex->perspec[lit->specno & spmask]--;
                ch++;

                #ifdef MPFID_DEBUG_AUTO
                cerr << "-" << vertex->specno << "_" << vertex->elemno << ","
                    << (lit->specno & spmask) << "_" << lit->elemno << " ";
                #endif

                list<Edge>::iterator tmp = lit++;
                vertex->edges.erase(tmp);
                myqueue[torank].push_back(sig);
                //CheckReady(global.rank);
                //RemoveEdge(sig);
            }       // next edge
            #ifdef MPFID_DEBUG_AUTO
            cerr << "-" << vertex->specno << "_" << vertex->elemno << " ";
            #endif
            delete vertex;
            global.myvert[vertno] = 0;
            continue;       // nothing to do more with this vertex
        }

        //CheckReady(global.rank);

        // Check rule #2 (after first step): If this vertex is connected with some part
        //  of the graph by only one edge, label such edge.
        for (specno = 0; specno < nspecies; specno++) {
            if (vertex->perspec[specno] == 1)
                break;
        }
        if (specno < nspecies) {
            list <Edge>::iterator lit = vertex->edges.begin();
            for ( ; lit != vertex->edges.end(); lit++) {
                if ((lit->specno & flmask) == 0 && 
                    vertex->perspec[lit->specno & spmask] == 1) {
                    lit->specno |= flmask;
                    #ifdef MPFID_DEBUG_AUTO
                    cerr << "*" << vertex->specno << "_" << vertex->elemno << ","
                        << (lit->specno & spmask) << "_" << lit->elemno << " ";
                    #endif
                    sig.tospecies = lit->specno & spmask;
                    sig.toelement = lit->elemno;
                    int torank = map.rank((lit->specno & spmask), lit->elemno, sig.tovertex);
                    sig.operation = tagLabel;
                    myqueue[torank].push_back(sig);
                    //CheckReady(global.rank);
                    //LabelEdge(sig);
                    ch++;
                }
            }       // next edge
        }
    }       // next vertex

    if (step == 1) {
        global.t2 = mytime();
        cout << (int)((global.t2-global.t0)/60) << " m: Delete local edges=" 
            << ch << endl;
    }
    //BroadcastFinish(global.rank, map.size());
    return ch;
}

int MakeEven(Mapping& map) {
    int ch = 0;
    int nvertices = map.nvertices(global.rank);
    int vertno;
    Signal sig;
    Queue& myqueue = *global.pqueue;
    //sig.fromrank = global.rank;
    global.t2 = mytime();
    for (vertno = 0; vertno < nvertices; vertno++) {
        //CheckReady(global.rank);
        if (global.milestone != 0) {
            global.t2 = mytime();
            if ((global.t2-global.t1)/60 >= global.milestone) {
                cout << (int)((global.t2-global.t0)/60) << " m: Even step: "
                    << "vertno=" << vertno << " changes=" << ch << endl;
                global.t1 = global.t2;
            }
        }
        Vertex *vertex = global.myvert[vertno];
        if (vertex == 0)
            continue;       // skip deleted vertices

        sig.fromvertex  = vertno;
        sig.fromspecies = vertex->specno;
        sig.fromelement = vertex->elemno;

        // Check rule #3 (modified as per November 2014): If an edge from this vertex
        //  is not labeled and its weight is less than weights of other non-labeled
        //  incident edges (or there is only one non-labeled edge), delete such edge. 
        list <Edge>::iterator lit = vertex->edges.begin();
        for ( ; lit != vertex->edges.end(); lit++) { 
            if ((lit->specno & flmask) == 0) {
                float w = lit->weight;
                list <Edge>::iterator lit0 = lit;
                for (++lit; lit != vertex->edges.end(); lit++)
                    if ((lit->specno & flmask) == 0)
                        break;
                if (lit == vertex->edges.end() || lit->weight > w) {
                    sig.tospecies   = lit0->specno & spmask;
                    sig.toelement   = lit0->elemno;
                    int torank = map.rank((lit0->specno & spmask), lit0->elemno, sig.tovertex);
                    sig.operation = tagRemove;
                    vertex->perspec[lit0->specno & spmask]--;
                    ch++;

                    #ifdef MPFID_DEBUG_AUTO
                    cerr << "-" << vertex->specno << "_" << vertex->elemno << ","
                        << (lit0->specno & spmask) << "_" << lit0->elemno << " ";
                    #endif

                    vertex->edges.erase(lit0);
                    myqueue[torank].push_back(sig);
                    if (vertex->edges.empty()) {    // Last edge removed
                        #ifdef MPFID_DEBUG_AUTO
                        cerr << "-" << vertex->specno << "_" << vertex->elemno << " ";
                        #endif
                        delete vertex;
                        global.myvert[vertno] = 0;
                    }

                    //CheckReady(global.rank);
                    //RemoveEdge(sig);
                }
                break;      // delete not more than one edge per vertex
            }       // Skip labeled edge
        }       // Next edge
    }       // Next vertex
    //BroadcastFinish(global.rank, map.size());
    return ch;
}

int CommitChanges(Mapping& map) {
    int size    = map.size();
    int changes = 0;
    Queue& myqueue = *global.pqueue;
    // First exchange sub-queues between branches (by portions)
    #ifdef MPFID_MPI
    if (global.undermpi && size > 1) {
        int  *xbuf    = new int  [global.portion*quint];
        bool *recvers = new bool [size];
        int  *nSend   = new int  [size];
        for (int k = 0; k < size; k++) {
            recvers[k] = true;
            nSend[k] = (int)myqueue[k].size();
        }
        recvers[global.rank] = false;
        int nSenders = size - 1;    // expected senders to this process
        int nRecvers = size - 1;    // expected receivers of this process
        global.t1 = mytime();

        // Send/receive loop
        while (nRecvers+nSenders > 0) {
            if (nRecvers > 0) {              // Send a portion
                for (int k = 0; k < size; k++) {
                    if (!recvers[k]) continue;
                    int nq = (int)myqueue[k].size();
                    int sz = nq;
                    if (nq > global.portion) nq = global.portion;
                    if (nq > 0) {
                        int nb = 0;     // sendbuf index
                        for (int n = 0; n < nq; n++) {
                            Signal& q = myqueue[k].back();
                            xbuf[nb++] = q.fromvertex;
                            xbuf[nb++] = q.fromspecies;
                            xbuf[nb++] = q.fromelement; 
                            xbuf[nb++] = q.tovertex;
                            xbuf[nb++] = q.tospecies;
                            xbuf[nb++] = q.toelement;
                            xbuf[nb++] = q.operation;
                            myqueue[k].pop_back();
                        }
                    }
                    else {
                        recvers[k] = false;
                        nRecvers--;
                    }

                    #ifdef MPFID_DEBUG_COMMIT
                    cerr << "-> " << k << " " << sz << "/" << nSend[k] << "["
                        << global.portion << "]";
                    if (nq == 0) 
                        cerr << " Rs=" << nRecvers << " Ss=" << nSenders;
                    cerr << "\t\t\t\r";
                    #endif

                    if (global.milestone != 0) {
                        global.t2 = mytime();
                        if ((global.t2-global.t1)/60 >= global.milestone) {
                            cout << (int)((global.t2-global.t0)/60) 
                                << " m: Receivers=" << nRecvers << " Senders=" 
                                << nSenders << " Queued=" 
                                << myqueue[global.rank].size() << endl;
                            global.t1 = global.t2;
                        }
                    }

                    #ifdef MPFID_DEBUG_TRANSFER
                    cerr << global.rank << "->" << k << ": " << nq << "\t\t\t\r";
                    #endif
                    MPI_Send(xbuf, nq*quint, MPI_INT, k, tagPortion, MPI_COMM_WORLD);
                }
            }
            if (nSenders > 0) {             // Receive portions if ready
                while (true) {
                    MPI_Status status;
                    int flag;
                    MPI_Iprobe(MPI_ANY_SOURCE, tagPortion, MPI_COMM_WORLD, &flag, &status);
                    if (!flag) 
                        break;
                    int k = status.MPI_SOURCE;
                    int nb; 
                    MPI_Get_elements(&status, MPI_INT, &nb);
                    if (nb % quint != 0 || nb > global.portion * quint) {
                        cout << "Invalid queue of " << nb << " elements received" << endl;
                        abortEnvironment(10);
                    }

                    #ifdef MPFID_DEBUG_COMMIT
                    int nq = (int)myqueue[global.rank].size();
                    cerr << "<- " << k << " " << nq << "[" << nb/quint << "]";
                    if (nb == 0) 
                        cerr << " Rs=" << nRecvers << " Ss=" << nSenders;
                    cerr << "\t\t\t\r";
                    #endif

                    #ifdef MPFID_DEBUG_TRANSFER
                    cerr << global.rank << "<-" << k << ": " << nb/quint << "\t\t\t\r";
                    #endif
                    MPI_Recv(xbuf, nb, MPI_INT, k, tagPortion, MPI_COMM_WORLD, &status);
                    for (int j = 0; j < nb; ) {
                        Signal q;
                        q.fromvertex  = xbuf[j++];
                        q.fromspecies = xbuf[j++];
                        q.fromelement = xbuf[j++];
                        q.tovertex    = xbuf[j++];
                        q.tospecies   = xbuf[j++];
                        q.toelement   = xbuf[j++];
                        q.operation   = xbuf[j++];
                        myqueue[global.rank].push_back(q);
                    }
                    if (nb == 0) nSenders--;

                    if (global.milestone != 0) {
                        global.t2 = mytime();
                        if ((global.t2-global.t1)/60 >= global.milestone) {
                            cout << (int)((global.t2-global.t0)/60) 
                                << " m: Receivers=" << nRecvers << " Senders=" 
                                << nSenders << " Queued=" 
                                << myqueue[global.rank].size() << endl;
                            global.t1 = global.t2;
                        }
                    }
                }
            }
        }
        delete [] xbuf;
        delete [] recvers;
        delete [] nSend;
    }

    #ifdef MPFID_DEBUG_TRANSFER
    global.t1 = mytime();
    cerr << (int)((global.t1-global.t0)/60) << " m: Exchange finished, "
        << "local queue=" << myqueue[global.rank].size() << endl;
    #endif      // MPFID_DEBUG_TRANSFER
    #endif  // MPFID_MPI

    #ifdef MPFID_DEBUG_AUTO
    cerr << "\n : ";
    #endif

    // Then process the relevant queue
    while (!myqueue[global.rank].empty()) {
        if (global.milestone != 0) {
            global.t2 = mytime();
            if ((global.t2-global.t1)/60 >= global.milestone) {
                cout << (int)((global.t2-global.t0)/60) << " m: Queued=" 
                    << myqueue[global.rank].size() << endl;
                global.t1 = global.t2;
            }
        }
        Signal& sig = myqueue[global.rank].back();
        switch (sig.operation) {
            case tagRemove:
                RemoveEdgeLocal(sig);
                changes++;
                break;
            case tagLabel:
                LabelEdgeLocal(sig);
                changes++;
                break;
            default:
                cout << "Unknown operation " << sig.operation 
                    << " in the queue." << endl;
        }
        myqueue[global.rank].pop_back();
    }
    return changes;
}

void SumChanges(int& changes) {
    #ifdef MPFID_MPI
    if (!global.undermpi) return;
    int ch = changes;
    MPI_Allreduce(&changes, &ch, 1, MPI_INT, MPI_SUM, MPI_COMM_WORLD);
    changes = ch;
    #endif
}
