// Multi-Processing FinDense
// (c)2016,2017 Lev Rubanov, IITP RAS

#ifndef MPFID_HEADER
#define MPFID_HEADER

#ifdef __unix__
#define LINUX
#elif defined(WIN32) || defined(_WIN32) || defined(_WIN64)
#define WINDOWS
#endif

//#define NOMPI               // Uncomment or define externally to disable MPI code

#ifndef NOMPI
#define MPFID_MPI               // Include MPI-related functionality
#endif      // ifndef NOMPI
#define MPFID_RAXML             // Exclusive use of the result file for RAxML 

// Debugging macros
//#define MPFID_DEBUG_MAP         // Global mapping
//#define MPFID_DEBUG_FILTER      // Subthreshold/duplicated edge removal
//#define MPFID_DEBUG_AUTO        // Operation of the automata
//#define MPFID_DEBUG_COMMIT      // Progress of committing
//#define MPFID_DEBUG_TRANSFER    // Exchange of queues
//#define MPFID_DEBUG_EDGE        // Resulting edges, both local and global
//#define MPFID_DEBUG_CLUSTER     // Clustering operation details
//#define MPFID_DEBUG_GLOBALC     // Global clusters

#ifdef MPFID_MPI
#define MSMPI_NO_DEPRECATE_20   // for MS MPI
#include "mpi.h"
#endif  // MPFID_MPI
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <list>
#include <iomanip>
#include <algorithm>
#include <set>
#include <ctime>
#include <limits>
#include <locale>       // for tolower,toupper
#include <memory.h>     // for memcpy

using namespace std;

#ifdef MPFID_MPI
#define mytime()   (global.undermpi ? MPI_Wtime() : (double)clock()/CLOCKS_PER_SEC)
#else   // ifndef MPFID_MPI
#define mytime()   (double)(clock()/CLOCKS_PER_SEC) 
#endif  // MPFID_MPI

// Early declarations
struct Species;
struct Element;
struct Toplevel;
struct Vertex;
struct Node;
struct Cluster;
struct Signal;
struct Global;

#if !defined(_MSC_VER) && !defined(__ICC)
typedef long long           __int64;
#endif
typedef Vertex              *PVertex;
typedef Node                *PNode;
typedef map <int, int>      IImap;
typedef pair <int, int>     IIpair;
typedef IImap::iterator     IIiter;
typedef map <string, int>   SImap;
typedef pair <string, int>  SIpair;
typedef SImap::iterator     SIiter;
typedef vector <vector <Signal> > Queue;
enum sp_input { infasta=1, ingff, ingbk=4 };

const string version    = "1.6";
const int buflen        = 4096;
const char tab        = '\t';
#ifdef LINUX
const char slash = '/';         // Linux path slash
#elif defined(WINDOWS)
const char slash = '\\';        // Windows path slash
#endif
const string whitespace = " \t\r\n";
const string gbkintro   = "LOCUS";
const string gbkfeature = "FEATURES";
const string gbkorigin  = "ORIGIN";
const string gbkend     = "//";
const int gbkgroups     = 6;        // groups per sequence line in GenBank
const int specidsize    = 36;
const int def_minpart   = 3;        // min species per cluster, 0=all
const float def_minweight = 0;      // filter for edges, 0=none
const int ww[4] = {10000, 100, 1, 0};  // weight of the words
const int def_diversity = 2*ww[0];  // min cluster diversity, 0=all
const int def_milestone = 0;        // minutes between prints, 0=disable
const int def_annotate  = 8;        // min overlap to annotate, 0=disable
const int tagRemove     = 10;
const int tagLabel      = 20;
const int tagNodeInf    = 30;
const int tagNode       = 40;
const int tagPortion    = 50;
const int nprobes       = 10;
const int sendstep      = 0;        // 0=disable
const int spmask        = 0x7FFFFFFF;
const int flmask        = 0x80000000;
const int xlot          = 2000;     // queue entries to exchange
const int quint         = 7;        // number of ints in one entry
const double scale      = 10.0;     // for all scores

struct Species {
    int     oldsp;      // old serial number
    int     nelem;      // number of elements
    int     nToplevels;
    int     input;      // 1=fasta 2=gff 4=genbank
    string  id;
    string  name;       // optional long name for output
    string  taxa;       // taxonomy code
    string  fasta;
    string  gff;
    vector <Element> elements;
    vector <Toplevel> toplevels;
    SImap   tlmap;      // id -> s/n of toplevel seq
    Species() {
        oldsp       = -1;
        nelem       = 0;
        nToplevels  = 0;
        input       = 0;
    }
};

struct Element {    // A word from a species
    int tl;             // toplevel s/n within a species
    int ustart;         // union start position (+ strand, 1-based)
    int ulen;           // union length
    int istart;         // intersection start position (+ strand, 1-based)
    int ilen;           // intersection length
    int strand;         // +1/-1/0=undetermined 
};

struct Annot {     // Annotation elements
    int     type;       // 0=toplevel, 1=gene, 2=CDS, 3=RNA
    int     begin;
    int     end;
    int     strand;
    string  id;
    string  description;
};

struct AnnotCompare {
    bool operator() (const Annot& a1, const Annot& a2) const {
        if (a1.begin == a2.begin) {
            if (a1.end == a2.end)
                return (a1.type < a2.type);
            return (a1.end < a2.end);
        }
        return (a1.begin < a2.begin);
    }
};

struct Toplevel {
    int     no;         // seq_no for this species
    int     len;
    string  id;
    string  seq;
    vector <Annot> annot;     // sort by begin, end
};

struct HubFileHeader {
    char sig[4];            // HUB/HUD signature
    int nspecies;           // Number of species
    __int64 filelen;        // File length
    __int64 offset[1];      // [nspecies] strip offsets
};

struct StripHeader {
    char spid[specidsize];  // Species ID (short)
    int nelem;              // Number of elements
    Element element[1];     // [nelem] elements
};

struct StarFileHeader {
    char sig[4];            // STF signature
    int specno;             // This species number
    int headlen;            // Header length
    int nstars;             // Total number of stars
    __int64 filelen;        // File length
    __int64 offset[1];      // [nstar] star offsets
};

struct Edge {           // for Star and Vertex
    int specno;
    int elemno;         // element no. 
    float weight;
    bool operator==(const Edge& other) const {
        return specno == other.specno && 
               elemno == other.elemno &&
               weight == other.weight;
    }
    bool operator!=(const Edge& other) const {
        return !operator==(other);
    }
};

struct StarHeader {     // NB: coordinate with ReadStarFile
    int nedges;     
    //Edge edge[1];           // [nedges] edges
};

class Mapping {
public:
    Mapping(int size);
    ~Mapping();
    // return cpu no. & modify vertex no.
    int rank(int specno, int elemno, int &vertex);
    // return vertex count for the rank 
    int nvertices(int rank);
    // return 1st vertex serial of the species for the rank
    int vertex(int specno, int rank);
    // return 1st element of the species for the rank
    int elemno(int specno, int rank);
    // return node number in one-dimensional vector
    int node(int specno, int elemno);
    // return base node number for given rank
    int basenode(int rank);
    // CPU count in this run
    int size(void) { return mysize; }
private:
    int mysize;
    int *startrank;     // [nspecies+1] the rank the species starts from
    int *startserial;   // [nspecies+1] the serial the species starts from 
    int *ranknode;      // [size] each rank's 1st node (common serial)
};

struct Vertex {
    int specno;         // species no. of this vertex
    int elemno;         // element no. of this vertex
    int *perspec;       // number of connected edges per species
    list <Edge> edges;  // list of edges in the weight ascending order
    Vertex();
    Vertex(int sp);
    ~Vertex();
};

struct Vert {       // Variation of Vertex for interchange
    int specno;         // species no.
    int elemno;         // element no.
    int nedges;         // number of edges
};
const int vertint = 3;

struct Signal {
    int fromvertex;
    int fromspecies;
    int fromelement;
    int tovertex;
    int tospecies;
    int toelement;
    int operation;      // 1st phase: tagRemove/tagLabel
};

struct Node {           // Vertex of a cluster
    int     specno;
    int     elemno;         // element no. of this vertex
    int     degree;         // number of incident edges
    int     density;        // number of incident parts
    int     clustno;        // this cluster no.
    vector<int>   tonodes;  // [degree] all incident nodes numbers
    vector<float> weights;  // [degree] edge weights
};

struct Cluster {
    int clustno;
    int diversity;
    int nAnnots[3];         // num of Gene/CDS/RNA
    vector<int> nodenos;    // node nos. of this cluster
};

struct ClusterCompare {
    bool operator() (const Cluster& c1, const Cluster& c2) const {
        if (c1.diversity == c2.diversity) {
            if (c1.nodenos.size() == c2.nodenos.size())
                return (c1.clustno < c2.clustno);
            return (c1.nodenos.size() > c2.nodenos.size());
        }
        return (c1.diversity > c2.diversity);
    }
};

struct Sword {      // A mode of printing words from sequence 
    string  mode;       // output mode: aAcCuUiIxX (lowerUPPER)
    int     extend;     // X:extension 0=none 1=lower case 2=upper case
    int     unite;      // U:union     0=none 1=lower case 2=upper case
    int     intersect;  // I:intersect 0=none 1=lower case 2=upper case
    int     align;      // A:alignment 0=none 1=lower case 2=upper case
    int     conserve;   // C:conserved 0=none 1=lower case 2=upper case
    int     extra;      // number of characters to extend words
    Sword() {
        mode    = "xU";
        extend  = 0;
        unite   = 0;
        intersect   = 0;
        align   = 0;
        conserve    = 0;
        extra   = 5;
    }
};

struct Global {
    bool    undermpi;       // if we are under mpi
    int     size;           // number of cpu
    int     rank;           // this cpu number
    int     minpart;        // min species per cluster
    int     diversity;      // min cluster diversity       
    float   minweight;      // min edge weight
    int     milestone;      // minutes between prints, 0=disable
    int     annotate;       // min overlap to annotate, 0=disable
    int     keysize;        // key size
    int     minlen;         // min len of sought-for element
    int     maxindel;       // max number of indels in series (-1: no check)
    int     maxscore;       // SCALED max score of mismatches
    int     sc_indel;       // SCALED score value of each indel
    int     sc_mismatch;    // SCALED score value of each mismatch
    bool    offgene;        // true: print the word projection beyond gene
    bool    numnode;        // true: print node/tonode numbers
    double  t0, t1, t2;     // global timers
    int     nvertices;      // vertex count for this rank
    int     nSpecies;       // relevant species count
    vector <Species> species;
    IImap   spmap;          // oldsp -> ser.no. of species
    PVertex *myvert;        // [nvertices(rank)] array of vertex ptrs (or 0s)
    vector <Node> nodes;    // array of clustered nodes
    vector <IImap> spel2node;   // [nSpecies] map: elemno -> nodeno
    vector <Cluster> clusters;  // clusters within this rank
    IImap   clindex;        // cluster no. -> position in clusters vector
    Queue   *pqueue;
    string  fastapath;      // fasta files directory
    string  gffpath;        // gff files directory
    string  hubname;        // hub file pathname
    string  starname;       // stars file pathname (contains *)
    string  resultname;     // result file pathname (may contain #)
    string  clustername;    // cluster file pathname (may contain #)
    string  clstatname;     // clstat file pathname (may contain #)
    string  hcename;        // hcecount file pathname (may contain #)
    Sword   sword;          // sequence words output mode
    string  toptype;        // types of top level sequences in gff
    string  lowtype[3];     // types of relevant elements in gff
    string  gbcomplement;   // GenBank keyword for complement
    string  gbjoin;         // GenBank keyword(s) for join
    string  gbid[3];        // Genbank field(s) for ID
    string  gbdescription[3]; // Genbank field(s) for description
    int     gblowoffset;	// blanks in the left of a lowtype in Genbank
    int     gbvaloffset;	// blanks in the left of a value in Genbank
    int     portion;        // dynamic value of xlot

    // Constructor
    Global () {
        undermpi    = true;
        size        = 1;
        rank        = 0;
        minpart     = def_minpart;
        diversity   = def_diversity;
        minweight   = def_minweight;
        milestone   = def_milestone;
        annotate    = def_annotate;
        keysize     = 16;
        minlen      = 60;
        maxindel    = 2;
        maxscore    = 175;
        sc_indel    = 21;
        sc_mismatch = 10;
        offgene     = true;
        numnode     = false;
        nvertices   = 0;
        myvert      = 0;
        fastapath   = "fasta";
        fastapath   += slash;
        gffpath     = "gff";
        gffpath     += slash;
        #ifdef LINUX
        starname    = "graph/*.star";
        resultname  = "cluster/result_#.txt";
        clustername = "cluster/cluster_#.txt";
        clstatname  = "cluster/clstat_#.txt";
        hcename     = "cluster/hcecount_#.txt";
        #elif defined(WINDOWS)
        starname    = "graph\\*.star";
        resultname  = "cluster\\result_#.txt";
        clustername = "cluster\\cluster_#.txt";
        clstatname  = "cluster\\clstat_#.txt";
        hcename     = "cluster\\hcecount_#.txt";
        #endif
        portion     = xlot;
    }
};

#ifdef MPFID_MAIN
    Global global;
#else
    extern Global global;
#endif      // MPFID_MAIN

struct NodeCompare {
    bool operator() (int no1, int no2) const {
        Node& n1 = global.nodes[no1];
        Node& n2 = global.nodes[no2];
        if (n1.specno == n2.specno) {
            return (no1 < no2);
            //if (n1.density == n2.density) {
            //    if (n1.degree == n2.degree) {
            //        return (n1.elemno < n2.elemno);
            //    }
            //    return (n1.degree > n2.degree);
            //}
            //return (n1.density > n2.density);
        }
        return (n1.specno < n2.specno);
    }
};

void    showHelp (void);
bool    parseArguments (int & argc, char** & argv);
bool    initEnvironment (int & argc, char** & argv);
void    finalizeEnvironment (void);
void    abortEnvironment (int code);
bool    readConfig (void);
string  getKey    (const string & str, int lineno, string::size_type off);
bool    getBool   (const string & str, int lineno, string::size_type off);
int     getInt    (const string & str, int lineno, string::size_type off);
double  getDouble (const string & str, int lineno, string::size_type off);
string  getString (const string & str, int lineno, string::size_type off);
bool    ReadHub (void);
bool    ReadStarFile (int specno, Mapping& map);
int     MakeOdd (Mapping& map, int step);
int     MakeEven (Mapping& map);
int     CommitChanges (Mapping& map);
void    SumChanges (int& changes);
void    ClearFlags (int nvertices, int& nlvert, int& nledges);
void    LocalClusters (void);
bool    CollectVertices (void);
int     CalcDiversity (Cluster & c);
bool    ReadToplevel (int specno);
bool    ReadGff (int specno);
int     findAnnotation (Toplevel& top, Element& el, int type);
string  getSequenceName (string& line);
string  getClusterWord (Cluster& cl, int j);
void    lowerCase (string& str, string::size_type off=0, string::size_type count=string::npos);
void    upperCase (string& str, string::size_type off=0, string::size_type count=string::npos);
bool    reconcileCluster (Cluster& cl);
bool    alignCluster (Cluster& cl);
void    reverseComplement (string& seq);
int     maxEqual (string& a, string& b);
int     StartWith (string& str, int off, string& keys);

#endif      // #ifndef MPFID_HEADER
