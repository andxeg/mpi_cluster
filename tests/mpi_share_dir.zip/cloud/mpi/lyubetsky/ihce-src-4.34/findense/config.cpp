// Multi-Processing FinDense
// (c)2016,2017 Lev Rubanov, IITP RAS

#include "findense.h"

// Static variables
static string   config_file     = "config.ini";     // config file name
static ofstream     logfs;                          // log file stream (cout)
static streambuf*   logsb = 0;
static string   logname         = "findense";       // log file name or prefix
static string   logext          = ".log";           // log file extension
static bool     splitlog        = true;             // true: split log by branches
static bool     log_present     = false;            // log file specified in the command line
static ofstream     errfs;                          // err file stream (cerr)
static streambuf*   errsb = 0;
static string   errname         = "fd_err";         // err file name or prefix
static string   errext          = ".log";           // err file extension
static bool     err_present     = false;            // err file present
static bool     hub_present     = false;            // hub file specified
static bool     star_present    = false;            // star file specified
static bool     fp_present      = false;            // fastapath specified
static bool     gff_present     = false;            // gffpath specified
static bool     result_present  = false;            // result_name specified
static bool     cluster_present = false;            // cluster_name specified
static bool     clstat_present  = false;            // clstat_name specified
static bool     hce_present     = false;            // hcecount_name specified
static bool     div_present     = false;            // diversity specified
static bool     minpart_present = false;            // minpart specified
static bool     stamp_present   = false;            // milestone specified
static bool     weight_present  = false;            // weight specified
static bool     extra_present   = false;            // extra chars specified
static bool     seq_present     = false;            // seqmode specified
static bool     keysize_present = false;
static bool     minlen_present  = false;
static bool     belt_present    = false;
static bool     scdel_present   = false;
static bool     scmis_present   = false;
static bool     score_present   = false;
static bool     annot_present   = false;            // annotate specified
static bool     portion_present = false;            // portion size set in command line

// Show short help on command line arguments
void    showHelp (void) {
    cout << "\nFinDense v." << version 
        #ifdef MPFID_MPI
         << " (MPI)"
        #endif
         << " usage: [options] [config_file]\n"
         << "\nOptions:\n"
         << "-? (--help|?) view this help screen\n"
         << "-a (--annotate=) min overlap to annotate, 0=none [" << def_annotate << "]\n"
         << "-c (--config=) configuration file [" << config_file << "]\n"
         << "-d (--diversity=) min diversity of cluster [" << def_diversity << "]\n"
         << "-e (--err=) error file with # if split [" << errname 
            << (splitlog ? "#" : "") << errext << "]\n"
         << "-f (--fastapath=) prefix of fasta files [" << global.fastapath << "]\n"
         << "-g (--gffpath=) prefix of gff files [" << global.gffpath << "]\n"
         << "-h (--hub=) hub file pathname [none]\n"
         << "-i (--clstat=) cluster statistics file [" << global.clstatname << "]\n"
         << "-j (--hcecount=) species statistics file [" << global.hcename << "]\n"
         << "-k (--cluster=) cluster file [" << global.clustername << "]\n"
         << "-m (--minpart=) min species per cluster, 0=all [" << def_minpart << "]\n"
        #ifdef MPFID_MPI
         << "-n (--nompi) prevent from using MPI\n"
        #endif
         << "-o (--log=) log file with # if split [" << logname 
            << (splitlog ? "#" : "") << logext << "]\n"
         << "-p (--portion) size of exchange portion [" << global.portion << "]\n"
         << "-q (--seq=) sequence output: aAcCuUiIxX [" << global.sword.mode << "]\n"
         << "-r (--result=) result file |empty [" << global.resultname << "]\n"
         << "-s (--star=) star file pathname [" << global.starname << "]\n"
         << "-t (--stamp=) timestamp interval (m), 0=none [" << def_milestone << "]\n"
         << "-w (--weight=) min weight of the edge [" << def_minweight << "]\n"
         << "-x (--extra=) bilateral extension of words [" << global.sword.extra << "]\n"
         << endl;
}

// Return false at argument error or help request
bool    parseArguments (int & argc, char** & argv) {
    if (argc <= 1)
        return true;
    int positional = 0;

    for (int i = 1; i < argc; i += 2) {
        char c = argv[i][0];
        string a(argv[i]);      // whole option or parameter
        char *p = 0;
        string b;               // next parameter

        // Help request encountered
        if (c == '?') {
            showHelp();
            return false;
        }

        // Parse other options
        if (c == '-' || c == '/') {     // -options
            c = argv[i][1];
            a.erase(0,1);

            if (i < argc-1) {
                p = argv[i+1];
                b.assign(argv[i+1]);
            }
            else {
                p = 0;
                b.clear();
            }
            istringstream iss(b);
            string::size_type pos;

            switch (c) {
                case '?':               // -?
                    showHelp();
                    return false;
                    break;

                case '-': 
                case '/':                       // --options
                    a.erase(0,1);
                    b.clear();
                    pos = a.find_last_of('=');
                    if (pos != string::npos) {
                        b = a.substr(pos + 1);
                        a.erase(pos);
                    }
                    iss.str(b);

                    if (a == "help") {          // --help
                        showHelp();
                        return false;
                    }

                    else if (a == "config") {   // --config=
                        config_file = b;
                    }

                    else if (a == "diversity") { // --diversity=
                        div_present = true;
                        iss >> global.diversity;
                    }

                    else if (a == "err" || a == "error") { // --err=
                        err_present = true;
                        pos = b.find_last_of('#');
                        splitlog = (pos != string::npos);
                        errname = b.substr(0, pos);
                        errext = (pos!=string::npos) ? b.substr(pos+1) : "";
                    }

                    else if (a == "fastapath") { // --fastapath=
                        fp_present = true;
                        global.fastapath = b;
                    }

                    else if (a == "gffpath") {  // --gffpath=
                        gff_present = true;
                        global.gffpath = b;
                    }

                    else if (a == "hub" || a == "hubname") { // --hub=
                        hub_present = true;
                        global.hubname = b;
                    }

                    else if (a == "clstat") {   // --clstat=
                        clstat_present = true;
                        global.clstatname = b;
                    }

                    else if (a == "hcecount") { // --hcecount=
                        hce_present = true;
                        global.hcename = b;
                    }

                    else if (a == "clstat") {   // --cluster=
                        cluster_present = true;
                        global.clustername = b;
                    }

                    else if (a == "minpart") {  // --minpart=
                        minpart_present = true;
                        iss >> global.minpart;
                    }

                    else if (a == "nompi") {    // --nompi
                        global.undermpi = false;
                    }

                    else if (a == "log") {      // --log=
                        log_present = true;
                        pos = b.find_last_of('#');
                        splitlog = (pos != string::npos);
                        logname = b.substr(0, pos);
                        logext = (pos!=string::npos) ? b.substr(pos+1) : "";
                    }

                    else if (a == "overlap") {  // --overlap
                        annot_present = true;
                        iss >> global.annotate;
                    }

                    else if (a == "portion") {  // --portion
                        portion_present = true;
                        iss >> global.portion;
                    }

                    else if (a == "seq" || a == "seqmode") {   // --seq=
                        seq_present = true;
                        global.sword.mode = b;
                    }

                    else if (a == "result") {   // --result=
                        result_present = true;
                        global.resultname = b;
                    }

                    else if (a == "star" || a == "starname") { // --star=
                        star_present = true;
                        global.starname = b;
                    }

                    else if (a == "stamp" ||    // --stamp=
                        a == "timestamp" || a == "milestone") {
                        stamp_present = true;
                        iss >> global.milestone;
                    }

                    else if (a == "weight") {   // --weight=
                        weight_present = true;
                        iss >> global.minweight;
                    }

                    else if (a == "extra" ||    // --extra=
                        a == "extension" || a == "extend") {
                        extra_present = true;
                        iss >> global.sword.extra;
                    }

                    else {
                        cout << "Unknown option --" << a << endl;
                        return false;
                    }
                    i--;    // since --option include value if any
                    break;

                case 'a':               // -a
                    annot_present = true;
                    iss >> global.annotate;
                    break;

                case 'c':               // -c
                    config_file = b;
                    break;

                case 'd':               // -d
                    div_present = true;
                    iss >> global.diversity;
                    break;

                case 'e':               // -e
                    err_present = true;
                    pos = b.find_last_of('#');
                    splitlog = (pos != string::npos);
                    errname = b.substr(0, pos);
                    errext = (pos!=string::npos) ? b.substr(pos+1) : "";
                    break;

                case 'f':               // -f
                    fp_present = true;
                    global.fastapath = b;
                    break;

                case 'g':               // -g
                    gff_present = true;
                    global.gffpath = b;
                    break;

                case 'h':               // -h         
                    hub_present = true;
                    global.hubname = b;
                    break;

                case 'i':               // -i
                    clstat_present = true;
                    global.clstatname = b;
                    break;

                case 'j':               // -j
                    hce_present = true;
                    global.hcename = b;
                    break;

                case 'k':               // -k
                    cluster_present = true;
                    global.clustername = b;
                    break;

                case 'm':               // -m
                    minpart_present = true;
                    iss >> global.minpart;
                    break;

                case 'n':               // -n
                    global.undermpi = false;
                    i--;    // since no value given
                    break;

                case 'o':               // -o
                    log_present = true;
                    pos = b.find_last_of('#');
                    splitlog = (pos != string::npos);
                    logname = b.substr(0, pos);
                    logext = (pos!=string::npos) ? b.substr(pos+1) : "";
                    break;

                case 'p':               // -p
                    portion_present = true;
                    iss >> global.portion;
                    break;

                case 'q':               // -q
                    seq_present = true;
                    global.sword.mode = b;
                    break;

                case 'r':               // -r
                    result_present = true;
                    global.resultname = b;
                    break;

                case 's':               // -s
                    star_present = true;
                    global.starname = b;
                    break;

                case 't':               // -t
                    stamp_present = true;
                    iss >> global.milestone;
                    break;

                case 'w':               // -w
                    weight_present = true;
                    iss >> global.minweight;
                    break;

                case 'x':               // -x
                    extra_present = true;
                    iss >> global.sword.extra;
                    break;

                default:
                    cout << "Unknown option -" << a << endl;
                    return false;
            }
            continue;
        }

        // Parse positional arguments
        istringstream iss1(a);
        switch (positional) {
            case 0:         // config file name
                config_file = a;
                break;

            default:
                cout << "Extra argument '" << a << "' ignored." << endl;
        }
        positional++;
        i--;
    }
    return true;
}

// Return false at config error or no config file
bool    readConfig (void) {
    string::size_type pos;
    ifstream cfg(config_file.c_str());
    if (cfg.fail()) {
        cout << "Cannot open configuration file " << config_file << endl;
        return false;
    }
    char* buf = new char [buflen];

    // Read config file until end
    for (int line_no = 1; !cfg.eof(); line_no++) {
        cfg.getline(buf, buflen, '\n');
        string line(buf);

        // Skip empty lines
        if (line.empty()) continue;
        pos = line.find_first_not_of(whitespace);
        if (pos == string::npos) continue;

        // Skip comments
        if (line[pos] == '#' || line[pos] == ';' || line.substr(pos,2) == "//") 
            continue;

        // Process all sections
        while (line[pos] == '[') {

            // Analyze section header
            string::size_type off = pos + 1;
            pos = line.find_first_of(']', off);
            if (pos == string::npos) {
                cout << "Invalid section header in config line " << line_no << endl;
                delete [] buf;
                return false;
            }
            string section = line.substr(off, pos-off);

            // Analyze relevant sections
            if (section == "common") {                  // 'common' section
                for ( ; !cfg.eof(); line_no++) {
                    cfg.getline(buf, buflen, '\n');
                    line.assign(buf);

                    // Skip empty lines
                    if (line.empty()) continue;
                    pos = line.find_first_not_of(whitespace);
                    if (pos == string::npos) continue;

                    // Skip comments
                    if (line[pos] == '#' || line[pos] == ';' || line.substr(pos,2) == "//") 
                        continue;

                    // Break on the section end
                    if (line[pos] == '[') break;

                    // Process relevant statements
                    string key = getKey(line, line_no, pos);

                    if (!log_present && key == "splitlog") {
                        splitlog = getBool(line, line_no, pos);
                        continue;
                    }
                    if (!log_present && key == "logname") {
                        logname = getString(line, line_no, pos);
                        continue;
                    }
                    if (!log_present && key == "logext") {
                        logext = getString(line, line_no, pos);
                        continue;
                    }
                    if (!err_present && key == "errname") {
                        errname = getString(line, line_no, pos);
                        continue;
                    }
                    if (!err_present && key == "errext") {
                        errext = getString(line, line_no, pos);
                        continue;
                    }
                    if (!fp_present && (key == "fastapath" || key == "fpath")) {
                        global.fastapath = getString(line, line_no, pos);
                        continue;
                    }
                    if (!hub_present && (key == "hubname" || key == "hubfile")) {
                        global.hubname = getString(line, line_no, pos);
                        continue;
                    }
                    if (!star_present && (key == "starname" || key == "starfile")) {
                        global.starname = getString(line, line_no, pos);
                        continue;
                    }
                    if (!minlen_present && (key == "length" || key == "minlen")) {
                        global.minlen = getInt(line, line_no, pos);
                    }
                    if (!keysize_present && (key == "key" || key == "keysize")) {
                        global.keysize = getInt(line, line_no, pos);
                    }
                    if (!belt_present && (key == "belt" ||
                        key == "maxindel" || key == "serial_del")) {
                        global.maxindel = getInt(line, line_no, pos);
                    }
                    if (!scdel_present && (key == "score_del" || key == "sc_indel")) {
                        double dbl = getDouble(line, line_no, pos);
                        global.sc_indel = (int)(dbl * scale);
                    }
                    if (!scmis_present && (key == "score_mis" || key == "sc_mismatch")) {
                        double dbl = getDouble(line, line_no, pos);
                        global.sc_mismatch = (int)(dbl * scale);
                    }
                    if (!score_present && (key == "score" || key == "maxscore")) {
                        double dbl = getDouble(line, line_no, pos);
                        global.maxscore = (int)(dbl * scale);
                    }
                }
            }

            else if (section == "findense") {       // 'findense' section
                for ( ; !cfg.eof(); line_no++) {
                    cfg.getline(buf, buflen, '\n');
                    line.assign(buf);

                    // Skip empty lines
                    if (line.empty()) continue;
                    pos = line.find_first_not_of(whitespace);
                    if (pos == string::npos) continue;

                    // Skip comments
                    if (line[pos] == '#' || line[pos] == ';' || line.substr(pos,2) == "//") 
                        continue;

                    // Break on the section end
                    if (line[pos] == '[') break;

                    // Process relevant statements
                    string key = getKey(line, line_no, pos);

                    if (!log_present && key == "splitlog") {
                        splitlog = getBool(line, line_no, pos);
                        continue;
                    }
                    if (!log_present && key == "logname") {
                        logname = getString(line, line_no, pos);
                        continue;
                    }
                    if (!log_present && key == "logext") {
                        logext = getString(line, line_no, pos);
                        continue;
                    }
                    if (!err_present && key == "errname") {
                        errname = getString(line, line_no, pos);
                        continue;
                    }
                    if (!err_present && key == "errext") {
                        errext = getString(line, line_no, pos);
                        continue;
                    }
                    if (!fp_present && (key == "fastapath" || key == "fpath")) {
                        global.fastapath = getString(line, line_no, pos);
                        continue;
                    }
                    if (!gff_present && (key == "gffpath" || key == "gpath")) {
                        global.gffpath = getString(line, line_no, pos);
                        continue;
                    }
                    if (!hub_present && (key == "hubname" || key == "hubfile")) {
                        global.hubname = getString(line, line_no, pos);
                        continue;
                    }
                    if (!star_present && (key == "starname" || key == "starfile")) {
                        global.starname = getString(line, line_no, pos);
                        continue;
                    }
                    if (!result_present && key == "result") {
                        global.resultname = getString(line, line_no, pos);
                        continue;
                    }
                    if (!cluster_present && key == "cluster") {
                        global.clustername = getString(line, line_no, pos);
                        continue;
                    }
                    if (!clstat_present && key == "clstat") {
                        global.clstatname = getString(line, line_no, pos);
                        continue;
                    }
                    if (!hce_present && key == "hcecount") {
                        global.hcename = getString(line, line_no, pos);
                        continue;
                    }
                    if (!minpart_present && (key == "minpart" || key == "minspecies")) {
                        global.minpart = getInt(line, line_no, pos);
                        continue;
                    }
                    if (!weight_present && (key == "weight" || key == "minweight")) {
                        global.minweight = (float)getDouble(line, line_no, pos);
                        continue;
                    }
                    if (!div_present && (key == "div" || key == "diversity")) {
                        global.diversity = getInt(line, line_no, pos);
                        continue;
                    }
                    if (!stamp_present && (key == "stamp" || 
                        key == "timestamp" || key == "milestone")) {
                        global.milestone = getInt(line, line_no, pos);
                        continue;
                    }
                    if (!extra_present && (key == "extra" || 
                        key == "extend" || key == "extension")) {
                        global.sword.extra = getInt(line, line_no, pos);
                        continue;
                    }
                    if (!seq_present && (key == "seq" || key == "seqmode")) {
                        global.sword.mode = getString(line, line_no, pos);
                        continue;
                    }
                    if (!minlen_present && (key == "length" || key == "minlen")) {
                        global.minlen = getInt(line, line_no, pos);
                    }
                    if (!keysize_present && (key == "key" || key == "keysize")) {
                        global.keysize = getInt(line, line_no, pos);
                    }
                    if (!belt_present && (key == "belt" ||
                        key == "maxindel" || key == "serial_del")) {
                        global.maxindel = getInt(line, line_no, pos);
                    }
                    if (!scdel_present && (key == "score_del" || key == "sc_indel")) {
                        double dbl = getDouble(line, line_no, pos);
                        global.sc_indel = (int)(dbl * scale);
                    }
                    if (!scmis_present && (key == "score_mis" || key == "sc_mismatch")) {
                        double dbl = getDouble(line, line_no, pos);
                        global.sc_mismatch = (int)(dbl * scale);
                    }
                    if (!score_present && (key == "score" || key == "maxscore")) {
                        double dbl = getDouble(line, line_no, pos);
                        global.maxscore = (int)(dbl * scale);
                    }
                    if (!annot_present && key == "annotate") {
                        global.annotate = getInt(line, line_no, pos);
                    }
                    if (key == "offgene" || key == "outgene") {
                        global.offgene = getBool(line, line_no, pos);
                    }
                    if (key == "numnode" || key == "numnodes") {
                        global.numnode = getBool(line, line_no, pos);
                    }
                    if (key == "toptype") {
                        global.toptype = getString(line, line_no, pos);
                    }
                    if (key == "lowtype1") {
                        global.lowtype[0] = getString(line, line_no, pos);
                    }
                    if (key == "lowtype2") {
                        global.lowtype[1] = getString(line, line_no, pos);
                    }
                    if (key == "lowtype3") {
                        global.lowtype[2] = getString(line, line_no, pos);
                    }
                    if (key == "gbcomplement") {
                        global.gbcomplement = getString(line, line_no, pos);
                    }
                    if (key == "gbjoin") {
                        global.gbjoin = getString(line, line_no, pos);
                    }
                    if (key == "gbid1") {
                        global.gbid[0] = getString(line, line_no, pos);
                    }
                    if (key == "gbid2") {
                        global.gbid[1] = getString(line, line_no, pos);
                    }
                    if (key == "gbid3") {
                        global.gbid[2] = getString(line, line_no, pos);
                    }
                    if (key == "gbdescription1") {
                        global.gbdescription[0] = getString(line, line_no, pos);
                    }
                    if (key == "gbdescription2") {
                        global.gbdescription[1] = getString(line, line_no, pos);
                    }
                    if (key == "gbdescription3") {
                        global.gbdescription[2] = getString(line, line_no, pos);
                    }
                    if (key == "gblowoffset") {
                        global.gblowoffset = getInt(line, line_no, pos);
                    }
                    if (key == "gbvaloffset") {
                        global.gbvaloffset = getInt(line, line_no, pos);
                    }
                    if (!portion_present && key == "portion") {
                        global.portion = getInt(line, line_no, pos);
                        continue;
                    }

                    // More statements here.
                }
            }

            else if (section == "species") {            // 'species' section
                for ( ; !cfg.eof(); line_no++) {
                    cfg.getline(buf, buflen, '\n');
                    line.assign(buf);

                    // Skip empty lines
                    if (line.empty()) continue;
                    pos = line.find_first_not_of(whitespace);
                    if (pos == string::npos) continue;

                    // Skip comments
                    if (line[pos] == '#' || line[pos] == ';' || line.substr(pos,2) == "//") 
                        continue;

                    // Break on the section end
                    if (line[pos] == '[') break;

                    // Collect species data
                    Species sp;
                    off = pos;
                    pos = line.find_first_of(tab, off);
                    if (pos == string::npos) {
                        cout << "Species no. error in config at line " << line_no << endl;
                        return false;
                    }
                    string species_no = line.substr(off, pos-off);
                    istringstream issno(species_no);
                    issno >> sp.oldsp;

                    off = line.find_first_not_of(tab, pos);
                    pos = line.find_first_of(tab, off);
                    if (off == string::npos || pos == string::npos) {
                        cout << "Species id error in config at line " << line_no << endl;
                        return false;
                    }
                    sp.id = line.substr(off, pos-off);

                    off = line.find_first_not_of(tab, pos);
                    pos = line.find_first_of(tab, off);
                    if (off == string::npos || pos == string::npos) {
                        cout << "Species name error in config at line " << line_no << endl;
                        return false;
                    }
                    sp.name = line.substr(off, pos-off);

                    off = line.find_first_not_of(tab, pos);
                    pos = line.find_first_of(tab, off);
                    if (off == string::npos || pos == string::npos) {
                        cout << "Species code error in config at line " << line_no << endl;
                        return false;
                    }
                    sp.taxa = line.substr(off, pos-off);

                    off = line.find_first_not_of(tab, pos);
                    pos = line.find_first_of(tab, off);
                    if (off == string::npos) {
                        cout << "Species fasta error in config at line " << line_no << endl;
                        return false;
                    }
                    sp.fasta = global.fastapath + ( pos==string::npos ?
                        line.substr(off) : line.substr(off, pos-off) );
                    sp.input |= infasta;

                    if (pos != string::npos) {
                        off = line.find_first_not_of(tab, pos);
                        if (off != string::npos) {
                            if (line[off] != '#' && line[off] != ';' && 
                                (off >= line.size()-1 || line.substr(off,2) != "//")) {
                                pos = line.find_first_of(tab, off);
                                sp.gff = global.gffpath + ( pos==string::npos ? 
                                    line.substr(off) : line.substr(off, pos-off) );
                                sp.input |= ingff;
                            }
                        }
                    }

                    IIiter mit = global.spmap.find(sp.oldsp);
                    if (mit != global.spmap.end()) {
                        cout << "Duplicated species no. in config at line " << line_no << endl;
                        return false;
                    }
                    global.spmap.insert( pair <int, int> (sp.oldsp, global.nSpecies));
                    global.species.push_back(sp);
                    global.nSpecies++;
                }
            }
            // Ignore other sections for now
            if (cfg.eof()) break;
        }
    }
    global.nSpecies = (int)global.species.size();
    if (global.minpart == 0) global.minpart = global.nSpecies;

    // Substitute minpart for # in output file names
    ostringstream osm;
    osm << global.minpart;
    string mps = osm.str();
    string::size_type incount = mps.length() - 1;

    pos = global.resultname.find_last_of('#');
    if (pos != string::npos) {
        global.resultname[pos] = mps[0];
        global.resultname.insert(pos+1, mps, 1, incount);
    }

    pos = global.clustername.find_last_of('#');
    if (pos != string::npos) {
        global.clustername[pos] = mps[0];
        global.clustername.insert(pos+1, mps, 1, incount);
    }

    pos = global.clstatname.find_last_of('#');
    if (pos != string::npos) {
        global.clstatname[pos] = mps[0];
        global.clstatname.insert(pos+1, mps, 1, incount);
    }

    pos = global.hcename.find_last_of('#');
    if (pos != string::npos) {
        global.hcename[pos] = mps[0];
        global.hcename.insert(pos+1, mps, 1, incount);
    }

    // Interpret Sword::mode
    for (int i = 0; i < (int)global.sword.mode.size(); i++) {
        switch (global.sword.mode[i]) {
            case 'x':   global.sword.extend    = 1; break;
            case 'X':   global.sword.extend    = 2; break;
            case 'u':   global.sword.unite     = 1; break;
            case 'U':   global.sword.unite     = 2; break;
            case 'i':   global.sword.intersect = 1; break;
            case 'I':   global.sword.intersect = 2; break;
            case 'a':   global.sword.align     = 1; break;
            case 'A':   global.sword.align     = 2; break;
            case 'c':   global.sword.conserve  = 1; break;
            case 'C':   global.sword.conserve  = 1; break;
        }
    }

    delete [] buf;
    return true;
}

// Get the key from 'key = value' string
string  getKey (const string & str, int lineno, string::size_type off = 0) {
    string key;
    string::size_type begin = str.find_first_not_of(whitespace, off);
    if (begin == string::npos)
        return key;

    string::size_type end = str.find_first_of('=', begin);
    if (end == string::npos)
        return key;

    key = str.substr(begin, end - begin);
    if (!key.empty()) {
        end = key.find_first_of(whitespace);
        if (end != string::npos)
            key.erase(end);
    }
    else {
        cout << "Key not found in config line " << lineno << endl;
    }
    return key;
}

// Get boolean value from 'key = value' string or from 'value' string if lineno=0
bool    getBool (const string & str, int lineno, string::size_type off = 0) {
    string value = lineno > 0 ? getString(str, lineno, off) : str;
    if (value.size() == 1) {
        string positive = "yYtT+1";
        string negative = "nNfF-0";
        if (positive.find_first_of(value[0]) != string::npos)
            return true;
        if (negative.find_first_of(value[0]) != string::npos)
            return false;
        if (lineno > 0)
            cout << "Invalid Boolean value in config line " << lineno << endl;
        else
            cout << "Invalid Boolean value in command line" << endl;
    }
    else {
        string positive = "yesYesYEStrueTrueTRUE";
        string negative = "notNotNOTfalseFalseFALSE";
        if (positive.find(value) != string::npos)
            return true;
        if (negative.find(value) != string::npos)
            return false;
        if (lineno > 0)
            cout << "Invalid Boolean value in config line " << lineno << endl;
        else
            cout << "Invalid Boolean value in command line" << endl;
    }
    return false;
}

// Get integer value from 'key = value' string
int     getInt (const string & str, int lineno, string::size_type off = 0) {
    int result = -1;
    string value = getString(str, lineno, off);
    istringstream iss(value);
    iss >> result;
    return result;
}

// Get double value from 'key = value' string
double  getDouble (const string & str, int lineno, string::size_type off = 0) {
    double result = -1.0;
    string value = getString(str, lineno, off);
    istringstream iss(value);
    iss >> result;
    return result;
}

// Get possibly quoted string value from 'key = value' string
string  getString (const string & str, int lineno, string::size_type off = 0) {
    string result = "";
    string::size_type pos = str.find_first_of('=', off);
    if (pos == string::npos) {
        cout << "Value not found in config line " << lineno << endl;
        return result;
    }

    pos = str.find_first_not_of(whitespace, pos+1);
    if (pos == string::npos || str.substr(pos, 2) == "//") {
        // Allow empty value for a key
        //cout << "Value not found in config line " << lineno << endl;
        return result;
    }

    string::size_type end;
    if (str[pos] == '\"') {     // quoted string
        end = str.find_first_of('\"', ++pos);
        if (end == string::npos) {
            cout << "Invalid double quoted string in contig line " << lineno << endl;
            return result;
        }
        result = str.substr(pos, end - pos);
    }
    else {                      // non-quoted string
        end = str.find_first_of(whitespace, pos);
        if (end == string::npos)
            result = str.substr(pos);
        else
            result = str.substr(pos, end - pos);
    }
    return result;
}

// Initialize MPI and output files if needed 
bool    initEnvironment (int & argc, char** & argv) {
    if (global.undermpi) {
        #ifdef MPFID_MPI
        try {
            MPI_Init(&argc, &argv);
            MPI_Comm_size(MPI_COMM_WORLD, &global.size);
            MPI_Comm_rank(MPI_COMM_WORLD, &global.rank);
            int flag;
            MPI_Initialized(&flag);
            if (!flag)
                throw 1;
            else if (global.size < 2) {
                MPI_Finalize();
                throw 2;
            }

            // Redirect cout & cerr to separate files
            if (splitlog) {
                int width = 0;
                for (int k = 1; k < global.size; k *= 10)
                    width++;
                ostringstream num;
                if (width > 0)
                    num << setfill('0') << setw(width) << global.rank;
                if (!logname.empty()) {
                    string filename = logname + num.str() + logext;
                    logfs.open(filename.c_str());
                    logsb = cout.rdbuf(logfs.rdbuf());
                }

                // Also redirect cerr in this case
                if (!errname.empty()) {
                    string filename = errname + num.str() + errext;
                    errfs.open(filename.c_str());
                    errsb = cerr.rdbuf(errfs.rdbuf());
                }
            }
            
            // Redirect cout & cerr to a single files
            else {
                if (!logname.empty()) {
                    string filename = logname + logext;
                    logfs.open(filename.c_str());
                    logsb = cout.rdbuf(logfs.rdbuf());
                }
                if (!errname.empty()) {
                    string filename = errname + errext;
                    errfs.open(filename.c_str());
                    errsb = cerr.rdbuf(errfs.rdbuf());
                }
            }
        }
        catch (...) {
            global.undermpi = false;
            global.size = 1;
            global.rank = 0;
            if (!logname.empty()) {
                string filename = logname + logext;
                logfs.open(filename.c_str());
                logsb = cout.rdbuf(logfs.rdbuf());
            }
            if (!errname.empty()) {
                string filename = errname + errext;
                errfs.open(filename.c_str());
                errsb = cerr.rdbuf(errfs.rdbuf());
            }
        }
        #else
        global.undermpi = false;
        global.size = 1;
        global.rank = 0;
        if (!logname.empty()) {
            string filename = logname + logext;
            logfs.open(filename.c_str());
            logsb = cout.rdbuf(logfs.rdbuf());
        }
        if (!errname.empty()) {
            string filename = errname + errext;
            errfs.open(filename.c_str());
            errsb = cerr.rdbuf(errfs.rdbuf());
        }
        #endif
    }
    else {
        global.size = 1;
        global.rank = 0;
        if (!logname.empty()) {
            string filename = logname + logext;
            logfs.open(filename.c_str());
            logsb = cout.rdbuf(logfs.rdbuf());
        }
        if (!errname.empty()) {
            string filename = errname + errext;
            errfs.open(filename.c_str());
            errsb = cerr.rdbuf(errfs.rdbuf());
        }
    }
    return true;
}

// Finalize MPI and close output files if needed
void    finalizeEnvironment (void) {
    if (global.undermpi) {
        #ifdef MPFID_MPI
        int flag;
        MPI_Initialized(&flag);
        if (flag)
            MPI_Finalize();
        #endif
        global.undermpi = false;
    }
    logfs.close();
    if (logsb) cout.rdbuf(logsb);
    errfs.close();
    if (errsb) cerr.rdbuf(errsb);
}

// Abort MPI and close output files if needed
void    abortEnvironment (int code) {   // last=24 & 77
    if (global.undermpi) {
        #ifdef MPFID_MPI
        int flag;
        MPI_Initialized(&flag);
        if (flag)
            MPI_Abort(MPI_COMM_WORLD, code);
        #endif
        global.undermpi = false;
    }
    logfs.close();
    if (logsb) cout.rdbuf(logsb);
    errfs.close();
    if (errsb) cerr.rdbuf(errsb);
    cout << "\nAbnormal completion: " << code << endl;
    exit(code);
}
