// Multi-Processing FinDense
// (c)2016,2017 Lev Rubanov, IITP RAS

#include "findense.h"

// Clear labels on all edges, NOT delete perspec[]
void ClearFlags(int nvert, int& nlvert, int& nledges) {
    global.nvertices = nvert;
    nlvert = 0;
    nledges = 0;
    for (int v = 0; v < global.nvertices; v++) {
        if (global.myvert[v] == 0)
            continue;
        nlvert++;
        nledges += (int)global.myvert[v]->edges.size();
        //delete[] global.myvert[v]->perspec;
        //global.myvert[v]->perspec = 0;
        list <Edge>::iterator lit;
        lit = global.myvert[v]->edges.begin();
        for ( ; lit != global.myvert[v]->edges.end(); lit++)
            lit->specno &= spmask;
    }
}

// Collect all clusters locally at the root
void LocalClusters(void) {
    vector <int> planned;       // planned node nos.
    int clustno = 1, c, cv;

    global.t1 = mytime();
    cout << "\n" << (int)((global.t1-global.t0)/60) 
        << " m: Clustering at the root..." << endl;

    int runs = 0;
    int changes = 1;        // to run at least once
    while (changes != 0) {
        runs++;
        changes = 0;
        for (int nodeno = 0; nodeno < (int)global.nodes.size(); nodeno++) {
            Node& node = global.nodes[nodeno];
            if (node.clustno == 0) {    // establish new cluster
                c = clustno++;
                node.clustno = c;
                changes++;
            }
            else
                c = node.clustno;       // already belongs to c-th cluster

            int back = 0;
            int eno = 0;        // edge no.
            for ( ; eno < node.degree; eno++) {     // over edges
                int v = node.tonodes[eno];
                cv = global.nodes[v].clustno;
                if (cv == c) continue;  // nothing to do (already planned?)
                if (cv == 0 || cv > c) {
                    global.nodes[v].clustno = c;  // set clustno and plan
                    planned.push_back(v);
                    changes++;
                    back++;
                }
                else {      // refuse current clustno (skip it)
                    node.clustno = cv;
                    changes -= back;
                    while (back-- > 0)
                        planned.pop_back();
                    break;
                }
            }
            if (eno < node.degree)
                nodeno--;   // repeat this node
        }

        while (!planned.empty()) {
            int nodeno = planned.back();
            planned.pop_back();

            Node& node = global.nodes[nodeno];
            c = node.clustno;

            int back = 0;
            int eno = 0;        // edge no.
            for ( ; eno < node.degree; eno++) {     // over edges
                int v = node.tonodes[eno];
                cv = global.nodes[v].clustno;
                if (cv == c) continue;  // nothing to do (already planned?)
                if (cv == 0 || cv > c) {
                    global.nodes[v].clustno = c;  // set clustno and plan
                    planned.push_back(v);
                    changes++;
                    back++;
                }
                else {      // refuse current clustno
                    node.clustno = cv;
                    changes -= back;
                    while (back-- > 0)
                        planned.pop_back();
                    break;
                }
            }
            if (eno < node.degree)
                planned.push_back(nodeno);  // repeat this node
        }
    }

    // Fill global.clusters & clindex
    int nclust = 0;         // current number of clusters
    for (int nodeno = 0; nodeno < (int)global.nodes.size(); nodeno++) {
        Node& node = global.nodes[nodeno];
        c = node.clustno;
        pair <IImap::iterator, bool> res = 
            global.clindex.insert(IIpair(c, nclust));
        if (res.second) {       // new cluster met
            Cluster clu;
            clu.clustno   = c;
            clu.diversity = 0;
            clu.nodenos.push_back(nodeno);
            global.clusters.push_back(clu);
            nclust++;
        }
        else {
            Cluster& clu = global.clusters[res.first->second];
            clu.nodenos.push_back(nodeno);
        }
    }       // next node

    global.t1 = mytime();
    cout << (int)((global.t1-global.t0)/60) << " m: " << runs << " runs made, " 
        << nclust << " cluster(s) established" << endl;
    #ifdef MPFID_DEBUG_CLUSTER
    cerr << "\nClustered nodes:" << endl;
    for (int nodeno = 0; nodeno < (int)global.nodes.size(); nodeno++) {
        Node& node = global.nodes[nodeno];
        cerr << nodeno << ": " << node.specno << "_" << node.elemno 
            << ",c" << node.clustno << " [" << node.degree << "]:";
        for (int i = 0; i < node.degree; i++)
            cerr << " " << node.tonodes[i] << ":" << node.weights[i];
        cerr << endl;
    }
    #endif
}

// Collect all vertices as nodes at the root
bool CollectVertices() {
    #ifdef MPFID_MPI
    char *buf;
    int lbuf;   // buffer length
    int dummy;
    int nodeno = (int)global.nodes.size();
    int currentno, tonode;

    if (!global.undermpi) return true;
    int vertlen;                // vert: sp el nedges
    MPI_Pack_size(vertint, MPI_INT, MPI_COMM_WORLD, &vertlen);
    int edgelen, edgelen2;      // edge: sp el weight
    MPI_Pack_size(2, MPI_INT, MPI_COMM_WORLD, &edgelen);
    MPI_Pack_size(1, MPI_FLOAT, MPI_COMM_WORLD, &edgelen2);
    edgelen += edgelen2;

    if (global.rank == 0) {     // Receiver (root): requesting vertices & edges
        int* nNodes = new int [global.size];     // remaining vertices per process
        int nvert = 0;
        MPI_Gather(&nvert, 1, MPI_INT, nNodes, 1, MPI_INT, 0, MPI_COMM_WORLD);
        //cout << "0: nNodes: " << nNodes[0] << " " << nNodes[1] << endl; cout.flush();

        for (int r = 1; r < global.size; r++) {
            // For each rank, request each vertex' data
            MPI_Send(&dummy, 1, MPI_INT, r, tagNodeInf, MPI_COMM_WORLD);
            //cout << "0: Send request #" << tagNodeInf << " to " << r << endl; cout.flush();
            nvert = nNodes[r];
            int nint = nvert * vertint; 
            Vert *verts = new Vert [nvert];
            MPI_Status status;
            MPI_Recv(&verts[0], nint, MPI_INT, r, tagNodeInf, MPI_COMM_WORLD, &status);
            //cout << "0: Recv verts OK" << endl; cout.flush();

            // Receive edges of each vertex
            for (int v = 0; v < nvert; v++) {
                Vert& vert = verts[v];
                vector <int> toparts (global.nSpecies, 0);  // for density

                // Try adding this node
                pair <IIiter, bool> res = 
                    global.spel2node[vert.specno].insert( IIpair(vert.elemno, nodeno) );
                if (res.second) {       // add new node 
                    Node newnode;
                    newnode.specno  = vert.specno;
                    newnode.elemno  = vert.elemno;
                    global.nodes.push_back(newnode);
                    currentno       = nodeno++;
                }
                else {                  // already exists
                    currentno       = res.first->second;
                }
                Node& node   = global.nodes[currentno];
                node.degree  = vert.nedges;
                node.density = 0;
                node.clustno = 0;

                // Receive and store the node's train
                lbuf = edgelen * vert.nedges;
                buf = new char [lbuf];
                MPI_Recv(buf, lbuf, MPI_PACKED, r, tagNode, MPI_COMM_WORLD, &status);

                int pos = 0;
                for (int e = 0; e < vert.nedges; e++) {
                    Edge edge;
                    MPI_Unpack(buf, lbuf, &pos, &edge.specno, 2, MPI_INT, MPI_COMM_WORLD);
                    MPI_Unpack(buf, lbuf, &pos, &edge.weight, 1, MPI_FLOAT, MPI_COMM_WORLD);
                    toparts[edge.specno] = 1;
                    pair <IIiter, bool> res2 = 
                        global.spel2node[edge.specno].insert( IIpair(edge.elemno, nodeno) );
                    if (res2.second) {   // no such node yet -- add it
                        Node newnode;
                        newnode.specno  = edge.specno;
                        newnode.elemno  = edge.elemno;
                        global.nodes.push_back(newnode);
                        tonode          = nodeno++;
                    }
                    else {
                        tonode          = res2.first->second;
                    }
                    Node& node   = global.nodes[currentno];
                    node.tonodes.push_back(tonode);
                    node.weights.push_back(edge.weight);
                }       // next edge

                // Calc the node's density
                int density = 0;
                for (int k = 0; k < global.nSpecies; k++)
                    density += toparts[k];
                global.nodes[currentno].density = density;
                delete[] buf;
            }       // next vertex
            delete[] verts;
        }       // next rank
        delete[] nNodes;
    }
    else {                      // Senders (non-root): responding
        int nvert = 0;              // calculate remaining vertices
        for (int vx = 0; vx < global.nvertices; vx++)
            if (global.myvert[vx] != 0) nvert++;
        //cout << global.rank << ": " << nvert << " vertices remain" << endl; 
        //cout.flush();
        MPI_Gather(&nvert, 1, MPI_INT, 0, 1, MPI_INT, 0, MPI_COMM_WORLD);
        //cout << global.rank << ": " << nvert << " nodes reported to root." << endl; 
        //cout.flush();

        int nint = nvert * vertint;
        Vert *verts = new Vert [nvert];
        int v = 0;
        for (int vx = 0; vx < global.nvertices; vx++) {
            if (global.myvert[vx] == 0) continue;
            Vertex& vertex  = *global.myvert[vx];
            verts[v].specno = vertex.specno;
            verts[v].elemno = vertex.elemno;
            verts[v].nedges = (int)vertex.edges.size();
            v++;
        }
        MPI_Status status;
        MPI_Recv(&dummy, 1, MPI_INT, 0, tagNodeInf, MPI_COMM_WORLD, &status);
        MPI_Send(&verts[0], nint, MPI_INT, 0, tagNodeInf, MPI_COMM_WORLD);
        //cout << global.rank << ": Send verts OK" << endl; cout.flush();
        delete[] verts;

        // Send edges of each vertex
        for (int vx = 0; vx < global.nvertices; vx++) {
            if (global.myvert[vx] == 0) continue;
            Vertex& vertex  = *global.myvert[vx];
            lbuf = (int)vertex.edges.size() * edgelen;
            buf = new char [lbuf];
            int pos = 0;
            list <Edge>::iterator lit = vertex.edges.begin();
            for ( ; lit != vertex.edges.end(); lit++) {
                Edge& edge = *lit;
                MPI_Pack(&edge.specno, 2, MPI_INT, buf, lbuf, &pos, MPI_COMM_WORLD);
                MPI_Pack(&edge.weight, 1, MPI_FLOAT, buf, lbuf, &pos, MPI_COMM_WORLD);
            }       // next edge
            MPI_Send(buf, lbuf, MPI_PACKED, 0, tagNode, MPI_COMM_WORLD);
            delete[] buf;
            delete global.myvert[vx];
        }       // next vertex
        delete[] global.myvert;
    }

    #endif      // MPFID_MPI
    return true;
}

// Calculate and store the diversity of a given cluster
int CalcDiversity(Cluster& c) {
    int div = 0;
    int i;

    set <string> taxa;
    for (int n = 0; n < (int)c.nodenos.size(); n++) { 
        Node& node = global.nodes[c.nodenos[n]];
        taxa.insert(global.species[node.specno].taxa);
    }

    string last;
    int m = 0;
    set <string>::iterator tit = taxa.begin();
    for (; tit != taxa.end(); tit++) {
        string t = *tit;
        int n = (int)t.size();
        for (i = 0; i < m && i < n; i++)
            if (last[i] != t[i])
                break;
        do {
            div += ww[i++];
        } while (i < n);
        last = t;
        m = n;
    }

    c.diversity = div;
    return div;
}

string  getClusterWord (Cluster& cl, int j) {
    Sword& mode = global.sword;
    string word;
    if (mode.align != 0 || mode.conserve != 0) {
        cout << "In-cluster alignment is not implemented, use default mode." << endl;
        mode.align = 0;
        mode.conserve = 0;
        mode.extend = 0;
        mode.intersect = 2;
        mode.unite = 1;
    }
    Node& node    = global.nodes[cl.nodenos[j]];
    Species& spec = global.species[node.specno];
    Element& el   = spec.elements[node.elemno];
    string& seq   = spec.toplevels[el.tl].seq;

    int pos, len;       // reference position in the sequence
    if (mode.unite != 0) {
        pos = el.ustart - 1;
        len = el.ulen;
    }
    else if (mode.intersect != 0) {
        pos = el.istart - 1;
        len = el.ilen;
    }
    else return word;   // no reference -- return empty string

    int wpos = 0, wlen;     // inside the word
    if (mode.extend != 0 && mode.extra > 0) {
        // Print left extension
        int xpos, xlen;
        if (pos > mode.extra) {
            xpos = pos - mode.extra;
            xlen = mode.extra;
        }
        else {
            xpos = 0;
            xlen = pos;
        }
        if (xlen > 0) {
            word = seq.substr(xpos, xlen);      // upper case
            if (mode.extend == 1) lowerCase(word, 0, xlen);
            wpos = xlen;
        }
    }
    if (mode.unite != 0 && mode.intersect != 0) {
        // Print left union
        wlen = el.istart - el.ustart;
        if (wlen > 0) {
            word += seq.substr(pos, wlen);      // upper case
            if (mode.unite == 1) lowerCase(word, wpos, wlen);
            wpos += wlen;
        }
        // Print intersection
        wlen = el.ilen;
        word += seq.substr(el.istart-1, wlen);  // upper case
        if (mode.intersect == 1) lowerCase(word, wpos, wlen);
        wpos += wlen;
        // Print right union
        wlen = (el.ustart + el.ulen) - (el.istart + el.ilen);
        if (wlen > 0) {
            word += seq.substr(el.istart-1+el.ilen, wlen);  // upper case
            if (mode.unite == 1) lowerCase(word, wpos, wlen);
            wpos += wlen;
        }
        pos = el.ustart - 1 + el.ulen;
    }
    else if (mode.unite != 0) {
        // Print entire union
        wlen = el.ulen;
        word += seq.substr(pos, wlen);          // upper case
        if (mode.unite == 1) lowerCase(word, wpos, wlen);
        wpos += wlen;
        pos  += wlen;
    }
    else /*if (mode.intersect != 0)*/ {
        // Print entire intersection
        wlen = el.ilen;
        word += seq.substr(pos, wlen);          // upper case
        if (mode.intersect == 1) lowerCase(word, wpos, wlen);
        wpos += wlen;
        pos  += wlen;
    }
    if (mode.extend != 0 && mode.extra > 0) {
        // Print right extension
        wlen = mode.extra; 
        if (pos+mode.extra > (int)seq.size())
            wlen = (int)seq.size() - pos;
        if (wlen > 0) {
            word += seq.substr(pos, wlen);      // upper case
            if (mode.extend == 1) lowerCase(word, wpos, wlen);
        }
    }
    if (el.strand < 0) reverseComplement(word);
    return word;
}

// Convert [a part of] the given string to lower case
void    lowerCase (string& str, string::size_type off, string::size_type count) {
    string::size_type end = count==string::npos ? str.size() : off + count;
    for (string::size_type i = off; i < end; i++)
        str[i] = tolower(str[i], locale::classic());
}

// Convert [a part of] the given string to upper case
void    upperCase (string& str, string::size_type off, string::size_type count) {
    string::size_type end = count==string::npos ? str.size() : off + count;
    for (string::size_type i = off; i < end; i++)
        str[i] = toupper(str[i], locale::classic());
}

// Recursively assign a strand to the node and its neighbors
// Returns true (OK) or false (conflict)
bool    assignStrand (int nodeno, int strand) {
    Node& node = global.nodes[nodeno];
    Species& spec = global.species[node.specno];
    Element& elem = spec.elements[node.elemno];
    if (elem.strand == 0) {
        //tracenodes.push_back(nodeno);
        elem.strand = strand;
        Toplevel& top = spec.toplevels[elem.tl];
        string word = top.seq.substr(elem.ustart-1, elem.ulen);
        if (strand < 0) reverseComplement(word);

        // Check the node with incident nodes
        for (int i = 0; i < node.degree; i++) {
            Node& tonode    = global.nodes[node.tonodes[i]];
            Species& tospec = global.species[tonode.specno];
            Element& toelem = tospec.elements[tonode.elemno];
            Toplevel& totop = tospec.toplevels[toelem.tl];
            string toword = totop.seq.substr(toelem.ustart-1, toelem.ulen);

            int plus = maxEqual(word, toword);
            reverseComplement(toword);
            int minus = maxEqual(word, toword);
            int tostrand = 0;
            if (plus > minus && minus < global.keysize)
                tostrand = 1;
            else if (plus < minus && plus < global.keysize)
                tostrand = -1;
            else continue;      // postpone assignment

            if (!assignStrand(node.tonodes[i], tostrand)) return false;
        }
    }
    else if (elem.strand == strand) return true;
    else return false;
    return true;
}

// Make reverse complement where needed, and set el.strand.
bool    reconcileCluster (Cluster& cl) {
    int n0 = 0, d0;
    while (n0 >= 0) {
        n0 = -1;      
        d0 = 0;
        // Find an undetermined node with biggest degree
        for (int j = 0; j < (int)cl.nodenos.size(); j++) {
            Node&    node = global.nodes[cl.nodenos[j]];
            Species& spec = global.species[node.specno];
            Element& elem = spec.elements[node.elemno];
            if (elem.strand == 0 && node.degree > d0) {
                d0 = node.degree;
                n0 = cl.nodenos[j];
            }
        }
        if (n0 >= 0 && !assignStrand(n0, +1)) {   // snap the node to + strand
            for (int j = 0; j < (int)cl.nodenos.size(); j++) {
                Node&    node = global.nodes[cl.nodenos[j]];
                Species& spec = global.species[node.specno];
                Element& elem = spec.elements[node.elemno];
                elem.strand = 0;
            }
            return false;
        }
    }
    return true;
}

// Return maximum length of identical substrings from two sequences
int     maxEqual (string& a, string& b) {
    int alen = (int)a.size();
    int blen = (int)b.size();
    int len  = 0;
    for (int i = 0; i < alen-len; i++) {
        for (int j = 0; j < blen-len; j++) {
            int k = 0;
            for ( ; (i+k)<alen && (j+k)<blen && a[i+k]==b[j+k]; k++) ;
            if (--k > len) len = k;
        }
    }
    return len;
}

// Align words of the cluster if possible
bool    alignCluster (Cluster& cl) {
    return true;
}

char    RC (char c) {
    switch (c) {
        case 'A': return 'T';
        case 'C': return 'G';
        case 'G': return 'C';
        case 'T': return 'A';
        case 'a': return 't';
        case 'c': return 'g';
        case 'g': return 'c';
        case 't': return 'a';
    }
    return c;
}

// Convert string into its reverse complement
void    reverseComplement (string& seq) {
    int n = (int)seq.size();
    int i = 0;
    int j = n-1;
    for ( ; i < j; i++, j--) {
        char c = seq[i];
        seq[i] = RC(seq[j]);
        seq[j] = RC(c);
    }
    if (i == j)
        seq[i] = RC(seq[j]);
}
