// Multi-Processing FinDense
// (c)2016,2017 Lev Rubanov, IITP RAS

#include "findense.h"

Mapping::Mapping(int size) {
    int nspecies = (int)global.species.size();
    startrank = new int [nspecies+1];
    startserial = new int [nspecies+1];
    ranknode = new int [size];
    startrank[0] = 0;
    startserial[0] = 0;
    for (int i = 1; i <= nspecies; i++) {
        int n = global.species[i-1].nelem;
        startrank[i] = startrank[i-1] + n % size;
        startserial[i] = startserial[i-1] + n / size;
        if (startrank[i] >= size) {
            startrank[i] -= size;
            startserial[i]++;
        }
        #ifdef MPFID_DEBUG_MAP
        cerr << i << ": " << startrank[i] << " " << startserial[i] << endl;
        #endif
    }
    ranknode[0] = 0;
    #ifdef MPFID_DEBUG_MAP
    cerr << "ranknode: 0";
    #endif
    for (int j = 1; j < size; j++) {
        ranknode[j] = ranknode[j-1] + nvertices(j-1);
        #ifdef MPFID_DEBUG_MAP
        cerr << " " << ranknode[j];
        #endif
    }
    #ifdef MPFID_DEBUG_MAP
    cerr << endl;
    #endif
    mysize = size;
}

Mapping::~Mapping() {
    delete[] startrank;
    delete[] startserial;
    delete[] ranknode;
}

// return cpu no. & modify vertex no.
int Mapping::rank(int specno, int elemno, int & vertex) {
    int r   = startrank[specno] + elemno % mysize;
    vertex  = startserial[specno] + elemno / mysize;
    if (r >= mysize) {
        r -= mysize;
        vertex++;
    }
    return r;
}

// return vertex count for the rank
int Mapping::nvertices(int rank) {
    int nspecies = (int)global.species.size();
    if (rank < startrank[nspecies])
        return startserial[nspecies] + 1;
    else
        return startserial[nspecies];
}

// return 1st vertex serial of the species for the rank
// return -1 if this rank lacks the species
int Mapping::vertex(int specno, int rank) {
    int n = global.species[specno].nelem;
    int r = startrank[specno];
    int v = startserial[specno];
    if (r <= rank)
        return (rank - r) < n ? v : -1;
    else
        return (mysize - r + rank) < n ? v+1 : -1;
}

// return 1st element no. of this species for this rank
// return >= nelem if this rank lacks the species
int Mapping::elemno(int specno, int rank) {
    int n = global.species[specno].nelem;
    int r = startrank[specno];
    if (r <= rank)
        return rank - r;
    else
        return mysize - r + rank;
}

// return node number in one-dimensional vector
int Mapping::node(int specno, int elemno) {
    int r   = startrank[specno] + elemno % mysize;
    int vertno  = startserial[specno] + elemno / mysize;
    if (r >= mysize) {
        r -= mysize;
        vertno++;
    }
    vertno += ranknode[r];
    return vertno;
}

// return base node number for given rank
int Mapping::basenode(int rank) {
    return ranknode[rank];
}

Vertex::Vertex() {
    specno = -1;
    elemno = -1;
    perspec = new int [global.species.size()];
    for (int i = 0; i < (int)global.species.size(); i++)
        perspec[i] = 0;
    edges.clear();
}

Vertex::Vertex(int sp) {
    specno = sp;
    elemno = -1;
    perspec = new int [global.species.size()];
    for (int i = 0; i < (int)global.species.size(); i++)
        perspec[i] = 0;
    edges.clear();
}

Vertex::~Vertex() {
    edges.clear();
    if (perspec)
        delete[] perspec;
}
