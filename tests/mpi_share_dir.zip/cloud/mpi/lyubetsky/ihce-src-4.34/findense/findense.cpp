// Multi-Processing FinDense
// (c)2016,2017 Lev Rubanov, IITP RAS

#define MPFID_MAIN
#include "findense.h"

int main(int argc, char** argv) {
    vector <vector <__int64> > HCE;
    ofstream result;
    ofstream clstat;
    ofstream cluster;
    ofstream hcf;

    // Interpret command line agruments
    if (!parseArguments(argc, argv)) 
        return 0;

    // Read global configuration
    if (!readConfig())
        return 0;

    // Check if mpi is present and initialize it
    if (!initEnvironment(argc, argv))
        abortEnvironment(1);

    global.t0 = mytime();
    ostringstream ossmulti;
    if (global.size > 1) ossmulti << "*" << global.size;
    cout << "\nFinDense v." << version << " run" << ossmulti.str() << ":";
    if (global.rank == 0)
        cerr << "\nFinDense v." << version << " run" << ossmulti.str() << ":";
    for (int i = 1; i < argc; i++) {
        string arg(argv[i]);
        cout << " " << arg;
        if (global.rank == 0) cerr << " " << arg;
    }
    cout << endl;
    if (global.rank == 0) cerr << endl;

    if (ReadHub()) {
        int nspecies = global.nSpecies;
        if (global.minpart <= 0 || global.minpart > nspecies)
            global.minpart = nspecies;
        int tvertices = 0;      // total vertices  
        for (int i = 0; i < nspecies; i++)
            tvertices += global.species[i].nelem;
        if (global.undermpi) {
            global.t1 = mytime();
            cout << (int)((global.t1-global.t0)/60) << " m: Distribute " 
                << tvertices << " vertices from " << nspecies << " parts over " 
                << global.size << " CPUs (avg. " << tvertices/global.size 
                << ")" << endl;
        }

        // Loop over star files
        Mapping map(global.size);
        int nvertices = map.nvertices(global.rank);    // this rank vertices
        global.t1 = mytime();
        cout << "\n" << (int)((global.t1-global.t0)/60) 
            << " m: Local vertices=" << nvertices << endl;
        global.myvert = new PVertex [(size_t)nvertices];

        int specno;
        for (specno = 0; specno < nspecies; specno++) {
            if (!ReadStarFile(specno, map))
                break;
        }
        if (specno < nspecies) {
            cout << "Error in " << global.species[specno].id 
                << " input data processing" << endl;
        }
        else {      // star files read okay
            int nledges = 0;
            #ifdef MPFID_DEBUG_MAP
            for (int v = 0; v < nvertices; v++) {
                if (global.myvert[v] == 0) continue;
                cerr << v << " (" << global.myvert[v]->specno << "_" 
                    << global.myvert[v]->elemno << "):";
                list <Edge>::const_iterator lit;
                lit = global.myvert[v]->edges.begin();
                for ( ; lit != global.myvert[v]->edges.end(); lit++)
                    cerr << "  " << lit->specno << "_" << lit->elemno << " " 
                        << setprecision(5) << lit->weight;
                cerr << endl;
                nledges += (int)global.myvert[v]->edges.size();
            }
            #else
            for (int v = 0; v < nvertices; v++) {
                if (global.myvert[v] == 0) continue;
                nledges += (int)global.myvert[v]->edges.size();
            }
            #endif
            global.t1 = mytime();
            cout << (int)((global.t1-global.t0)/60) << " m: Local edges=" 
                << nledges << endl;

            #ifdef MPFID_MPI
            if (global.undermpi) {
                __int64 sendbuf[2] = { nvertices, nledges };
                __int64 recvbuf[2];
                MPI_Reduce(sendbuf, recvbuf, 2, MPI_LONG_LONG_INT, MPI_SUM, 0, MPI_COMM_WORLD);
                if (global.rank == 0) {
                    global.t1 = mytime();
                    cout << "\n" << (int)((global.t1-global.t0)/60) 
                        << " m: Global vertices=" << recvbuf[0] << " edges=" 
                        << recvbuf[1] << endl;
                }
            }
            #endif

            // Open result & print heading
            if (global.rank == 0) {
                int tedges = nledges;
                #ifdef MPFID_MPI
                if (global.undermpi)
                    MPI_Reduce(&nledges, &tedges, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
                #endif
                if (!global.resultname.empty()) {       // result
                    result.open(global.resultname.c_str());
                    if (!result.good()) {
                        cout << "Can't create result file " 
                            << global.resultname << endl;
                        abortEnvironment(11);
                    }
                    #ifndef MPFID_RAXML
                    result << "Parts" << tab << "Min.parts" << tab << "I.vertices" << tab
                        << "I.edges" << tab << "Steps" << tab << "F.vertices" << tab
                        << "F.edges" << tab << "Clusters" << tab << "Max.vertices" << tab
                        << "Min.vertices" << tab << "Avg.vertices" << endl;
                    result << nspecies << tab << global.minpart << tab << tvertices 
                        << tab << tedges << tab;
                    #endif
                }
                if (!global.clustername.empty()) {      // cluster
                    cluster.open(global.clustername.c_str());
                    if (!cluster.good()) {
                        cout << "Can't create cluster file " 
                            << global.clustername << endl;
                        abortEnvironment(11);
                    }
                    cluster << "Elem#\tSz\tDeg\tDen\tOrganism\tContig\t"
                        "Pos\tLen\t+-\tSequence";
                    if (global.annotate != 0) {
                        cluster << "\tGene\tBegin\tEnd\t+-\tDescription"
                            "\tCDS\tBegin\tEnd\t+-\tDescription"
                            "\tRNA\tBegin\tEnd\t+-\tDescription";
                        if (global.offgene) cluster << "\tOffgene";
                    }
                    if (global.numnode) cluster << "\tNode#\tTo ##";
                    cluster << endl;
                }
                if (!global.clstatname.empty()) {       // clstat
                    clstat.open(global.clstatname.c_str());
                    if (!clstat.good()) {
                        cout << "Can't create clstat file " 
                            << global.clstatname << endl;
                        abortEnvironment(11);
                    }
                    clstat << "Parts" << tab << "Min.parts" << tab << "I.vertices" << tab
                        << "I.edges" << tab << "Steps" << tab << "F.vertices" << tab
                        << "F.edges" << tab << "Clusters" << tab << "Max.vertices" << tab 
                        << "Min.vertices" << tab << "Avg.vertices";
                    for (int i = nspecies; i >= global.minpart; i--)
                        clstat << tab << i;
                    clstat << endl;
                    clstat << nspecies << tab << global.minpart << tab << tvertices 
                        << tab << tedges << tab;
                }
                if (!global.hcename.empty()) {          // hcecount
                    hcf.open(global.hcename.c_str()/*, ios_base::out | ios_base::app*/);
                    if (!hcf.good()) {
                        cout << "Can't create"/*/append*/" HCE count file " 
                            << global.hcename << endl;
                        abortEnvironment(11);
                    }
                }
            }
            #ifdef MPFID_MPI
            else if (global.undermpi) {
                MPI_Reduce(&nledges, NULL, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
            }
            #endif

            // Create & clear initial HCE matrix
            for (int n = 0; n <= nspecies; n++) {    // with total row
                vector <__int64> ucrow (nspecies, 0);
                HCE.push_back(ucrow);
            }
            // Fill initial HCE matrix (outbound) for this rank
            for (int vno = 0; vno < nvertices; vno++) {
                if (global.myvert[vno] == 0) continue;
                Vertex& vertex = *(global.myvert[vno]);
                for (int sp2 = 0; sp2 < nspecies; sp2++) {
                    HCE[vertex.specno][sp2] += vertex.perspec[sp2];
                }
            }
            #ifdef MPFID_MPI
            // Reduce initial HCE matrix over branches
            if (global.undermpi) {
                MPI_Barrier(MPI_COMM_WORLD);
                vector <__int64> recvrow(nspecies);
                for (int i = 0; i < nspecies; i++) {
                    MPI_Reduce(&HCE[i][0], &recvrow[0], nspecies, 
                        MPI_LONG_LONG_INT, MPI_SUM, 0, MPI_COMM_WORLD);
                    if (global.rank == 0)
                        HCE[i].assign(recvrow.begin(), recvrow.end());
                }
            }
            #endif

            // Write initial HCE matrix to the file
            if (global.rank == 0) {
                hcf << "\t";
                for (int j = 0; j < nspecies; j++)
                    hcf << tab << global.species[j].taxa;
                hcf << "\n\t";
                for (int j = 0; j < nspecies; j++)
                    hcf << tab << global.species[j].name;
                hcf << endl;

                for (int i = 0; i < nspecies; i++) {
                    hcf << global.species[i].taxa << tab << global.species[i].name;
                    for (int j = 0; j < nspecies; j++) {
                        hcf << tab << HCE[i][j];
                        HCE[nspecies][j] += HCE[i][j];
                    }
                    hcf << endl;
                }
                hcf << tab << "TOTAL";
                for (int j = 0; j < nspecies; j++)
                    hcf << tab << HCE[nspecies][j];
                hcf << endl;
            }

            // Prepare a queue for main loop of the program
            Queue myqueue (global.size);
            global.pqueue = & myqueue;
            //----- Loop of vertices & edges removal
            int changes = 0;    
            int step = 0;
            do {            // B-step loop of the automaton
                int ch;
                do {            // A-step loop of the automaton
                    step++;

                    if (global.milestone) {
                        global.t2 = mytime();
                        if ((global.t2-global.t1)/60 >= global.milestone) {
                            int cv = 0, ce = 0;
                            for (int v = 0; v < nvertices; v++) {
                                if (global.myvert[v]) {
                                    cv++;
                                    ce += (int)global.myvert[v]->edges.size();
                                }
                            }
                            cout << (int)((global.t2-global.t0)/60) 
                                << " m: step=" << step << " vertices=" 
                                << cv << " edges=" << ce << endl;
                            global.t1 = global.t2;
                        }
                    }

                    #ifdef MPFID_DEBUG_AUTO
                    cout << "\n" << step << "_A: ";
                    #endif

                    #ifdef MPFID_MPI
                    if (global.undermpi)
                        MPI_Barrier(MPI_COMM_WORLD);  // Even/Odd interstep barrier
                    #endif

                    if ((changes = MakeOdd(map, step)) < 0) { 
                        abortEnvironment(11);
                        break;
                    }

                    int chcopy = changes;

                    if ((ch = CommitChanges(map)) < 0) {
                        abortEnvironment(21);
                        break;
                    }
                    changes += ch;
                    if (global.undermpi) 
                        SumChanges(changes);

                    if (step == 1) {
                        int temp = chcopy;
                        if (global.undermpi) 
                            SumChanges(chcopy);
                        global.t1 = mytime();
                        cout << (int)((global.t1-global.t0)/60) 
                            << " m: Deleted subthreshold/duplicated edges: "
                            << "local=" << temp << " global=" << chcopy << endl;
                    }
                } while (changes != 0);     // Next A-step

                step++;
                #ifdef MPFID_DEBUG_AUTO
                cerr << "\n" << step << "_B: ";
                #endif

                #ifdef MPFID_MPI
                if (global.undermpi)
                    MPI_Barrier(MPI_COMM_WORLD);  // Odd/Even interstep barrier 
                #endif

                if ((changes = MakeEven(map)) < 0) {
                    abortEnvironment(12);
                    break;
                }
                if ((ch = CommitChanges(map)) < 0) {
                    abortEnvironment(22);
                    break;
                }
                changes += ch;
                if (global.undermpi) 
                    SumChanges(changes);

            } while (changes != 0);     // Next A-step after B-step
            //----- End of main loop ---------------
            int nlvert;
            ClearFlags(nvertices, nlvert, nledges);

            int lve[2] = { nlvert, nledges };
            int tve[2] = { nlvert, nledges };
            #ifdef MPFID_MPI
            if (global.undermpi)
                MPI_Reduce(lve, tve, 2, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
            #endif
            #ifndef MPFID_RAXML
            if (global.rank == 0) {
                result << step << tab << tve[0] << tab << tve[1] << tab;
            }
            #endif
            if (global.rank == 0)
                clstat << step << tab << tve[0] << tab << tve[1] << tab;

            global.t1 = mytime();
            cout << "\n" << (int)((global.t1-global.t0)/60) 
                << " m: Steps done: " << step << ". Remaining local vertices=" 
                << nlvert << ", edges=" << nledges << endl;
            if (global.undermpi && global.rank == 0)
                cout << (int)((global.t1-global.t0)/60) 
                    << " m: Remaining global vertices=" << tve[0] 
                    << ", edges=" << tve[1] << endl;

            // Clear final HCE matrix 
            for (int i = 0; i <= nspecies; i++)
                for (int j = 0; j < nspecies; j++)
                    HCE[i][j] = 0;
            // Fill final HCE matrix (outbound) for this rank
            for (int vno = 0; vno < nvertices; vno++) {
                if (global.myvert[vno] == 0) continue;
                Vertex& vertex = *(global.myvert[vno]);
                for (int sp2 = 0; sp2 < nspecies; sp2++) {
                    HCE[vertex.specno][sp2] += vertex.perspec[sp2];
                }
            }
            #ifdef MPFID_MPI
            // Reduce final HCE matrix over branches
            if (global.undermpi) {
                MPI_Barrier(MPI_COMM_WORLD);
                vector <__int64> recvrow(nspecies);
                for (int i = 0; i < nspecies; i++) {
                    MPI_Reduce(&HCE[i][0], &recvrow[0], nspecies, 
                        MPI_LONG_LONG_INT, MPI_SUM, 0, MPI_COMM_WORLD);
                    if (global.rank == 0)
                        HCE[i].assign(recvrow.begin(), recvrow.end());
                }
            }
            #endif

            // Write final HCE matrix to the file
            if (global.rank == 0) {
                hcf << "\n\t";
                for (int j = 0; j < nspecies; j++)
                    hcf << tab << global.species[j].taxa;
                hcf << "\n\t";
                for (int j = 0; j < nspecies; j++)
                    hcf << tab << global.species[j].name;
                hcf << endl;

                for (int i = 0; i < nspecies; i++) {
                    hcf << global.species[i].taxa << tab << global.species[i].name;
                    for (int j = 0; j < nspecies; j++) {
                        hcf << tab << HCE[i][j];
                        HCE[nspecies][j] += HCE[i][j];
                    }
                    hcf << endl;
                }
                hcf << tab << "TOTAL";
                for (int j = 0; j < nspecies; j++)
                    hcf << tab << HCE[nspecies][j];
                hcf << endl;

                hcf.close();
                HCE.clear();
            }

            #ifdef MPFID_DEBUG_EDGE
            for (int v = 0; v < nvertices; v++) {
                if (global.myvert[v] == 0)
                    continue;
                cerr << v << " (" << global.myvert[v]->specno << "_" 
                    << global.myvert[v]->elemno << ") [" 
                    << global.myvert[v]->edges.size() << "]:";
                list <Edge>::const_iterator lit;
                lit = global.myvert[v]->edges.begin();
                for ( ; lit != global.myvert[v]->edges.end(); lit++)
                    cerr << "  " << lit->specno << "_" << lit->elemno << " " 
                        << setprecision(5) << lit->weight;
                cerr << endl;
            }
            #endif

            if (global.rank == 0) {
                // Establish mapping <specno,elemno> -> nodeno
                for (specno = 0; specno < nspecies; specno++) {
                    IImap nodenos;
                    global.spel2node.push_back(nodenos);
                }

                // Convert root's vertices into nodes
                int nodeno = 0;                         // next node no.
                int currentno = -1;                     // current node no.
                for (int v = 0; v < nvertices; v++) {
                    if (global.myvert[v] == 0) continue;
                    Vertex& vertex = *global.myvert[v];
                    vector <int> toparts (nspecies, 0);     // for density

                    // Try adding this node
                    pair <IIiter, bool> res = 
                        global.spel2node[vertex.specno].insert( IIpair(vertex.elemno, nodeno) );
                    if (res.second) {       // add new node 
                        Node newnode;
                        newnode.specno  = vertex.specno;
                        newnode.elemno  = vertex.elemno;
                        global.nodes.push_back(newnode);
                        currentno       = nodeno++;
                    }
                    else {                  // already exists
                        currentno       = res.first->second;
                    }

                    Node& node   = global.nodes[currentno];
                    node.degree  = (int)vertex.edges.size();
                    node.density = 0;
                    node.clustno = 0;

                    // Store the current node's train
                    list <Edge>::iterator lit = vertex.edges.begin();
                    for ( ; lit != vertex.edges.end(); lit++) {
                        Edge& edge = *lit;
                        int tonode;     // node no. of another side of this edge
                        toparts[edge.specno] = 1;   // label this part as connected
                        pair <IIiter, bool> res2 = 
                            global.spel2node[edge.specno].insert( IIpair(edge.elemno, nodeno) );
                        if (res2.second) {   // no such node yet -- add it
                            Node newnode;
                            newnode.specno  = edge.specno;
                            newnode.elemno  = edge.elemno;
                            global.nodes.push_back(newnode);
                            tonode          = nodeno++;
                        }
                        else {
                            tonode          = res2.first->second;
                        }
                        Node& node   = global.nodes[currentno];
                        node.tonodes.push_back(tonode);
                        node.weights.push_back(edge.weight);
                    }

                    // Calc the node's density
                    int density = 0;
                    for (int k = 0; k < nspecies; k++)
                        density += toparts[k];
                    global.nodes[currentno].density = density;
                    delete global.myvert[v];
                }
                delete[] global.myvert;
                //cout << nvertices << " vertices -> " << global.nodes.size() 
                //    << " nodes." << endl; cout.flush();
            }

            // Collect all remaining vertices at the root
            if (global.undermpi) { 
                if (!CollectVertices()) {
                    global.t1 = mytime();
                    cout << (int)((global.t1-global.t0)/60) 
                        << " m: Vertices collecting error" << endl;
                    abortEnvironment(77);
                }
                else {
                    global.t1 = mytime();
                    cout << (int)((global.t1-global.t0)/60) 
                        << " m: Vertices collected OK" << endl;
                }
            }

            if (global.rank == 0) {     // Clusters build-up
                nvertices = (int)global.nodes.size();
                LocalClusters();
                global.t1 = mytime();
                cout << "\n" << (int)((global.t1-global.t0)/60) 
                    << " m: Global clusters: " << global.clusters.size() << endl;

                int clmin = numeric_limits<int>::max(); 
                int clmax = 0, clsum = 0;
                if (!global.clusters.empty()) {
                    // Calculate diversity
                    for (int k = 0; k < (int)global.clusters.size(); k++) 
                        CalcDiversity(global.clusters[k]);
                    // Sort result
                    sort(global.clusters.begin(), global.clusters.end(), 
                        ClusterCompare());
                    // Trim clusters vector
                    vector <Cluster>::reverse_iterator cit = global.clusters.rbegin();
                    while (cit != global.clusters.rend()) {
                        if (cit->diversity >= global.diversity)
                            break;
                        global.clusters.pop_back();
                        cit = global.clusters.rbegin();
                    }

                    if (!global.clusters.empty()) {
                        // Sort nodes within each cluster
                        for (int k = 0; k < (int)global.clusters.size(); k++) { 
                            sort(global.clusters[k].nodenos.begin(), 
                                 global.clusters[k].nodenos.end(), 
                                 NodeCompare());
                            int nn = (int)global.clusters[k].nodenos.size();
                            if (clmin > nn) clmin = nn;
                            if (clmax < nn) clmax = nn;
                            clsum += nn;
                        }
                        clsum /= (int)global.clusters.size();
                    }
                }

                #ifdef MPFID_DEBUG_GLOBALC
                for (int k = 0; k < (int)global.clusters.size(); k++) {
                    Cluster& cl = global.clusters[k];
                    cerr << "c" << cl.clustno << " [" << cl.nodenos.size() << "]:";
                    for (int n = 0; n < (int)cl.nodenos.size(); n++) {
                        Node& node = global.nodes[n];
                        cerr << " " << node.specno << "_" << node.elemno;
                    }
                    cerr << endl;
                }
                #endif

                // Read toplevel and annotation files
                for (specno = 0; specno < nspecies; specno++) {
                    Species& spec = global.species[specno];
                    if (!ReadToplevel(specno)) {
                        cout << "Error reading " << spec.id << " toplevel sequences" << endl;
                        abortEnvironment(23);
                    }
                    if (global.annotate != 0 && (spec.input & ingff) != 0 && !ReadGff(specno)) {
                        cout << "Error reading " << spec.id << " annotation" << endl;
                        abortEnvironment(24);
                    }
                }

                // Output results
                #ifndef MPFID_RAXML
                result << global.clusters.size() << tab << clmax << tab 
                    << clmin << tab << clsum << endl;
                // Write resulting clusters
                //for (int k = 0; k < nspecies; k++) {
                //    if (k > 0) result << tab;
                //    result << species[k].name;
                //}
                //result << endl;
                #else
                string *matrix = new string [nspecies];
                #endif

                for (int k = 0; k < (int)global.clusters.size(); k++) {
                    Cluster& cl = global.clusters[k];
                    cl.nAnnots[0] = 0;
                    cl.nAnnots[1] = 0;
                    cl.nAnnots[2] = 0;
                    int *idx = new int [nspecies];
                    for (int i = 0; i < nspecies; i++)
                        idx[i] = -1;

                    int nn = (int)cl.nodenos.size();
                    int present = 0;
                    for (int j = 0; j < nn; j++) {
                        int sp = global.nodes[cl.nodenos[j]].specno;
                        if (idx[sp] < 0) {
                            idx[sp] = cl.nodenos[j];
                            present++;
                        }
                    }
                    #ifndef MPFID_RAXML
                    result << k+1 << " " << nn;
                    #else
                    for (int i = 0; i < nspecies; i++)
                        matrix[i] += idx[i]<0 ? '0' : '1';
                    #endif

                    // Print headline of the cluster
                    cluster << k+1 << tab << present << tab << 99999 << tab 
                        << 999 << tab << nn << tab << cl.diversity << endl;
                    // Print nodes of the cluster
                    for (int j = 0; j < (int)cl.nodenos.size(); j++) {
                        Node& node = global.nodes[cl.nodenos[j]];
                        Species& spec = global.species[node.specno];
                        cluster << k+1 << tab << present << tab << node.degree 
                            << tab << node.density << tab << spec.name;
                        Element& el = spec.elements[node.elemno];

                        // Postprocess cluster if needed
                        if (j == 0) {
                            bool canAlign = true;
                            if (el.strand == 0) {
                                if ( !(canAlign = reconcileCluster(cl)))
                                    cout << "Cannot reconcile cluster " << k+1 
                                    << " (nodes=" << cl.nodenos.size() 
                                    << " div=" << cl.diversity << ")" << endl;
                            }
                            if (global.sword.align != 0) {
                                if (!canAlign || !alignCluster(cl))
                                    cout << "Cannot align cluster " << k+1 
                                    << " (nodes=" << cl.nodenos.size() 
                                    << " div=" << cl.diversity << ")" << endl;
                            }
                        }
 
                        // Print contig
                        Toplevel &top = spec.toplevels[el.tl];
                        cluster << tab << top.id;
                        int left, right;
                        if (global.sword.unite != 0) {
                            cluster << tab << el.ustart << tab << el.ulen;
                            left = el.ustart; right = el.ustart+el.ulen-1;
                        }
                        else { // if (global.sword.intersect != 0) {
                            cluster << tab << el.istart << tab << el.ilen; 
                            left = el.istart; right = el.istart+el.ilen-1;
                        }
                        /* else something in alignment case? */

                        // Print strand and sequence
                        cluster << tab << el.strand << tab << getClusterWord(cl,j);

                        // Optional print annotations 
                        if (global.annotate != 0) {
                            int offgene = 0;
                            for (int type = 1; type <= 3; type++) {
                                int ano = findAnnotation(top, el, type);
                                if (ano >= 0) {
                                    Annot& annot = top.annot[ano];
                                    cluster << tab << annot.id << tab 
                                        << annot.begin << tab << annot.end 
                                        << tab << annot.strand
                                        << tab << annot.description;
                                    cl.nAnnots[type-1]++;

                                    if (type == 1 && global.offgene) {
                                        if (annot.strand > 0) {
                                            if (left < annot.begin)
                                                offgene = left - annot.begin;
                                            else if (right > annot.end)
                                                offgene = right - annot.end;
                                        }
                                        else /*if (annot.strand >= 0)*/ {
                                            if (annot.end < right)
                                                offgene = annot.end - right;
                                            else if (annot.begin > left)
                                                offgene = annot.begin > left;
                                        }
                                    }
                                }
                                else cluster << "\t\t\t\t\t";
                            }
                            // Optional print if a word juts out the gene
                            if (global.offgene) {
                                cluster << tab;
                                if (offgene != 0) cluster << offgene;
                            }
                        }
                        // Optional print node & tonode numbers
                        if (global.numnode) {
                            cluster << tab << cl.nodenos[j];
                            for (int k = 0; k < node.degree; k++)
                                cluster << tab << node.tonodes[k];
                        }
                        cluster << endl;
                        #ifndef MPFID_RAXML
                        result << " " << node.specno << "_" << node.elemno;
                        #endif
                    }
                    #ifndef MPFID_RAXML
                    result << endl;
                    #endif
                    delete [] idx;
                }
                #ifdef MPFID_RAXML
                // Output matrix for RAxML to the result file
                for (int i = 0; i < nspecies; i++) {
                    result << ">" << global.species[i].name << "\n"
                        << matrix[i] << endl;
                }
                #endif

                // Write cluster statistics
                clstat << global.clusters.size() << tab << clmax << tab 
                    << clmin << tab << clsum;

                int maxdev = nspecies - global.minpart + 1;
                int *ncl = new int [maxdev];  // clusters of each deviation
                for (int dev = 0; dev < maxdev; dev++)
                    ncl[dev] = 0;

                int *nelem = new int [nspecies];  // elements per species
                for (int k = 0; k < (int)global.clusters.size(); k++) {
                    Cluster& cl = global.clusters[k];
                    for (int i = 0; i < nspecies; i++)
                        nelem[i] = 0;
                    int nn = (int)cl.nodenos.size();
                    for (int j = 0; j < nn; j++) {
                        Node& node = global.nodes[cl.nodenos[j]];
                        nelem[node.specno]++;
                    }
                    int dev = 0;
                    for (int i = 0; i < nspecies; i++)
                        if (nelem[i] == 0)
                            dev++;
                    ncl[dev]++;
                }
                for (int i = 0; i < maxdev; i++)
                    clstat << tab << ncl[i];
                clstat << endl;

                clstat << "#" << tab << "Total" << tab << "Parts";
                for (int i = 0; i < nspecies; i++) 
                    clstat << tab << global.species[i].id;
                if (global.annotate != 0) 
                    clstat << "\t\tGene\tCDS\tRNA"; 
                clstat << endl;

                int *ntotal = new int [nspecies];    // total elements
                for (int i = 0; i < nspecies; i++)
                    ntotal[i] = 0;
                for (int k = 0; k < (int)global.clusters.size(); k++) {
                    Cluster& cl = global.clusters[k];
                    for (int i = 0; i < nspecies; i++)
                        nelem[i] = 0;
                    int nn = (int)cl.nodenos.size();
                    for (int j = 0; j < nn; j++) {
                        Node& node = global.nodes[cl.nodenos[j]];
                        nelem[node.specno]++;
                    }
                    int dev = 0;
                    for (int i = 0; i < nspecies; i++)
                        if (nelem[i] == 0)
                            dev++;
                    clstat << k+1 << tab << nn << tab << nspecies-dev;
                    for (int i = 0; i < nspecies; i++) { 
                        clstat << tab << nelem[i];
                        ntotal[i] += nelem[i];
                    }
                    if (global.annotate != 0)
                        clstat << tab << tab << cl.nAnnots[0] << tab
                            << cl.nAnnots[1] << tab << cl.nAnnots[2];
                    clstat << endl;
                }
                clstat << tab << "Total" << tab;
                for (int i = 0; i < nspecies; i++)
                    clstat << tab << ntotal[i];
                clstat << endl;

                delete[] ntotal;
                delete[] nelem;
                delete[] ncl;
            }
        }
    }
    else {
        cout << "\nCan't read hub file " << global.hubname
            << "--nothing to do." << endl;
    }
    global.t1 = mytime();
    ostringstream oss;
    double dt = global.t1 - global.t0;
    if (dt < 300)
        oss << setprecision(4) << dt << " s.";
    else if (dt < 21600)
        oss << setprecision(4) << dt/60.0 << " m.";
    else
        oss << setprecision(4) << dt/3600.0 << " hr.";
    cout << "\nCompleted OK: time = " << oss.str() << endl;
    finalizeEnvironment();
    if (global.rank == 0)
        cout << global.clusters.size() << " clusters found.\n"
            "Completed OK: time = " << oss.str() << endl;
}
