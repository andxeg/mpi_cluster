#!/bin/bash
c1=4	# number of processors for pairhits
c2=4	# number of processors for bldgraph
c3=4	# number of processors for findense
w=	# specify -wait if supported by mpirun
r=	# specify non-blank to check return codes
hosts="slave1, master" # sprcify hosts for MPI cluster

cd data

if [ -z "$1" ]
then
  mpirun $w -np $c1 ./pairhits

  if [ -z "$r" ] || [ $? -eq 0 ]
  then
    ls -1 hits/*.txt >hits/file.lst
    mpirun $w -np $c2 ./bldgraph

    if [ -z "$r" ] || [ $? -eq 0 ]
    then
      mpirun $w -np $c3 ./findense
      if [ -z "$r" ] || [ $? -eq 0 ]
      then
        echo "Example completed OK."
      else
        echo "Error: FinDense failed."
      fi
    else
      echo "Error: BldGraph failed."
    fi
  else
    echo "Error: PairHits failed."
  fi

elif [ "$1" -eq "1" ]
then
  if [ -n "$2" ] ; then c1 = $2 ; fi
  mpirun $w -np $c1 ./pairhits

elif [ "$1" -eq "2" ]
then
  ls -1 hits/*.txt >hits/file.lst
  if [ -n "$2" ] ; then c2 = $2 ; fi
  mpirun -np $c2 ./bldgraph

elif [ "$1" -eq "3" ]
then
  if [ -n "$2" ] ; then c3 = $2 ; fi
  mpirun -np $c3 ./findense
fi

cd ..
