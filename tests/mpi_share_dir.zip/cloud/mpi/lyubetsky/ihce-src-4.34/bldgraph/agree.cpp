// (c)2016,2017 Lev Rubanov, IITP RAS
//
// Module:      agree.cpp
// Functions:   agreeOutbound qdesc exchangeQueue agreeInbound
//              equisign bcastNodes 

#include "bldgraph.h"
#include <limits.h>

// Join near nodes and fill queue by ranks
void    agreeOutbound (vector <vector <Queue> >& queue) {
    ofstream& dnf = global.dnf;
    int nq = 0;
    #ifdef BLDGRAPH_OUTBOUND
    cerr << "agreeOutbound\t\t\t\r";
    #endif

    // Loop over species
    for (int sp = 0; sp < global.nSpecies; sp++) {
        Species& species = global.species[sp];

        // Loop over relevant toplevel sequences
        for (int tl = 0; tl < species.nToplevels; tl++) {
            Toplevel& toplevel = species.toplevels[tl];
            if (toplevel.rank != global.rank) continue;

            // Loop over nodes
            Niter nit = toplevel.nodes.begin();
            for ( ; nit != toplevel.nodes.end(); nit++) {
                Node& node = nit->second;

                Niter jit = nit;
                // Join following nodes while possible
                for (++jit; jit != toplevel.nodes.end(); ) {
                    Node& join = jit->second;
                    if (global.strand && node.anchor < 0 && join.anchor > 0) break;
                    if (min(node.end, join.end) - 
                        max(node.begin, join.begin) < global.common-1) break;

                    if (node.left  > join.left)  node.left  = join.left;
                    if (node.right < join.right) node.right = join.right;
                    if (node.begin < join.begin) node.begin = join.begin;
                    if (node.end   > join.end)   node.end   = join.end;
                    // Move edges from join to node, modifying offset
                    node.nEdges += join.nEdges;
                    while (! join.edges.empty()) {
                        Edge& ej = join.edges.back();
                        Edge en = ej;
                        en.off1 = abs(join.anchor) + ej.off1 - abs(node.anchor);
                        node.edges.push_back(en);
                        join.edges.pop_back();
                    }

                    Niter tmp = jit++;
                    toplevel.nodes.erase(tmp);
                    toplevel.nNodes--;
                }
                sort(node.edges.begin(), node.edges.end());     // by oper<

                // Loop over edges to fill respective queues
                for (int ed = 0; ed < (int)node.edges.size(); ed++) {
                    Edge& edge = node.edges[ed];

                    // Add the queue entry
                    Queue q;
                    q.fromsp        = sp;
                    q.fromtl        = tl;
                    q.fromanchor    = node.anchor;
                    q.fromlen       = edge.len1;
                    q.fromoff       = edge.off1;
                    q.sp            = edge.sp;
                    q.tl            = edge.tl;
                    q.anchor        = edge.anchor;
                    q.len           = edge.len2;
                    q.off           = edge.off2;
                    queue[edge.rank].push_back(q);
                    #ifdef BLDGRAPH_OUTBOUND
                    if (milestone != 0 && nq % milestone == 0)
                        cerr << "-> " << sp << " " << tl << " " 
                            << node.anchor << " " << nq+1 << "\t\t\t\r";
                    #endif
                    nq++;

                    if (!global.dnodes.empty()) {
                        for (int j = 0; j < (int)global.dnodes.size(); j++) {
                            DebugNode& dnode = global.dnodes[j];
                            if (dnode.sp == sp && dnode.tl == tl && 
                                equisign(dnode.anchor, node.anchor) && abs(dnode.anchor-node.anchor) < global.common ||
                                dnode.sp == edge.sp && dnode.tl == edge.tl && 
                                equisign(dnode.anchor, edge.anchor) && abs(dnode.anchor-edge.anchor) < global.common) {
                                ostringstream oss;
                                oss << "out_" << global.rank << tab << sp << tab << tl << tab 
                                    << node.anchor << tab << showpos << edge.off1 << noshowpos 
                                    << tab << edge.len1 << tab << edge.sp << tab << edge.tl << tab 
                                    << edge.anchor << tab << showpos << edge.off2 << noshowpos
                                    << tab << edge.len2;
                                dnf << oss.str() << endl;
                                break;
                            }
                        }
                    }
                }   // next edge
            }   // next node
        }   // next toplevel
    }   // next species

    #ifdef BLDGRAPH_OUTBOUND
    if (milestone != 0)
        cerr << "\t\t\t\r";
    #endif
}

// Callback function for queue sort: DESC - to, from
bool    qdesc (const Queue& q1, const Queue& q2) {
    if (q1.sp == q2.sp) {
        if (q1.tl == q2.tl) {
            if (q1.anchor == q2.anchor) {
                if (q1.off == q2.off) {
                    if (q1.len == q2.len) {
                        if (q1.fromsp == q2.fromsp) {
                            if (q1.fromtl == q2.fromtl) {
                                if (q1.fromanchor == q2.fromanchor) {
                                    if (q1.fromoff == q2.fromoff)
                                        return q1.fromlen > q2.fromlen;
                                    return q1.fromoff > q2.fromoff;
                                }
                                return q1.fromanchor > q2.fromanchor;
                            }
                            return q1.fromtl > q2.fromtl;
                        }
                        return q1.fromsp > q2.fromsp;
                    }
                    return q1.len > q2.len;
                }
                return q1.off > q2.off;
            }
            return q1.anchor > q2.anchor;
        }
        return q1.tl > q2.tl;
    }
    return q1.sp > q2.sp;
}

// Synchronize processes (if multiple) and exchange queues
void    exchangeQueue   (vector <vector <Queue> >& queue) {
    #ifdef BLDGRAPH_TRANSFER
    cerr << "exchangeQueue\t\t\t\r";
    #endif
    // Synchronize processes
    #ifdef BLDGRAPHMPI
    if (global.undermpi) {
        MPI_Barrier(MPI_COMM_WORLD);
        // Append sub-queues from other processes to local sub-queues
        int *xbuf = new int [global.portion*quint];
        bool *recvers = new bool [global.size];
        for (int k = 0; k < global.size; k++) recvers[k] = true;
        recvers[global.rank] = false;
        int nSenders = global.size - 1;
        int nRecvers = global.size - 1;

        // Send/receive loop
        while (nRecvers+nSenders > 0) {
            if (nRecvers > 0) {              // Send a portion
                for (int k = 0; k < global.size; k++) {     
                    if (!recvers[k]) continue;
                    int nq = (int)queue[k].size();
                    if (nq > global.portion) nq = global.portion;
                    if (nq > 0) {
                        int nb = 0;     // sendbuf index
                        for (int n = 0; n < nq; n++) {
                            Queue& q = queue[k].back();
                            xbuf[nb++] = q.sp;
                            xbuf[nb++] = q.tl;
                            xbuf[nb++] = q.anchor;
                            xbuf[nb++] = q.fromsp;
                            xbuf[nb++] = q.fromtl;
                            xbuf[nb++] = q.fromanchor;
                            xbuf[nb++] = (((int)q.off)<<16)|(int)q.len;
                            xbuf[nb++] = (((int)q.fromoff)<<16)|(int)q.fromlen;
                            queue[k].pop_back();
                        }
                    }
                    else {
                        recvers[k] = false;
                        nRecvers--;
                    }
                    #ifdef BLDGRAPH_TRANSFER
                    cerr << global.rank << "->" << k << ": " << nq << "\t\t\t\r";
                    #endif
                    MPI_Send(xbuf, nq*quint, MPI_INT, k, tag1, MPI_COMM_WORLD);
                }
            }
            if (nSenders > 0) {             // Receive portions if ready
                while (true) {
                    MPI_Status status;
                    int flag;
                    MPI_Iprobe(MPI_ANY_SOURCE, tag1, MPI_COMM_WORLD, &flag, &status);
                    if (!flag) break;
                    int k = status.MPI_SOURCE;
                    int nb;
                    MPI_Get_elements(&status, MPI_INT, &nb);
                    if (nb % quint != 0 || nb > global.portion * quint) {
                        cout << "Invalid queue of " << nb << " elements received" << endl;
                        abortEnvironment(10);
                    }
                    #ifdef BLDGRAPH_TRANSFER
                    cerr << global.rank << "<-" << k << ": " << nb/quint << "\t\t\t\r";
                    #endif
                    MPI_Recv(xbuf, nb, MPI_INT, k, tag1, MPI_COMM_WORLD, &status);
                    for (int j = 0; j < nb; ) {
                        Queue q;
                        q.sp         = xbuf[j++];
                        q.tl         = xbuf[j++];
                        q.anchor     = xbuf[j++];
                        q.fromsp     = xbuf[j++];
                        q.fromtl     = xbuf[j++];
                        q.fromanchor = xbuf[j++];
                        q.off        = (short)(xbuf[j]>>16);
                        q.len        = (short)(xbuf[j++]&0xFFFF);
                        q.fromoff    = (short)(xbuf[j]>>16);
                        q.fromlen    = (short)(xbuf[j++]&0xFFFF);
                        queue[global.rank].push_back(q);
                    }
                    if (nb == 0) nSenders--;
                }
            }
        }
        delete [] xbuf;
    }
    #endif
    // Sort queue
    int k = global.rank;
    sort(queue[k].begin(), queue[k].end(), qdesc);    // used in agreeInbound
}

// Empty queue
void    agreeInbound  (vector <vector <Queue> >& queue) {
    int nq = 0;
    vector <Queue>& vq = queue[global.rank];
    int lastiq = (int)vq.size() - 1;
    int lastline = (int)vq.size() + 1;
    ofstream& dnf = global.dnf;
    #ifdef BLDGRAPH_INBOUND
    cerr << "agreeInbound\t\t\t\r";
    #endif

    // Loop over species
    for (int sp = 0; sp < global.nSpecies; sp++) {
        Species& species = global.species[sp];

        // Loop over relevant toplevel sequences
        for (int tl = 0; tl < species.nToplevels; tl++) {
            Toplevel& toplevel = species.toplevels[tl];
            if (toplevel.rank != global.rank) continue;

            // Loop over nodes
            Niter nit = toplevel.nodes.begin();
            for ( ; nit != toplevel.nodes.end(); nit++) {
                Node& node = nit->second;

                // Loop over edges to fulfill respective queues
                for (int e = 0; e < (int)node.edges.size(); e++) {
                    Edge& edge = node.edges[e];

                    // Finding the edge backward over subqueue
                    bool edge_found = false;
                    while (lastiq >= 0) {
                        if (vq[lastiq].sp < 0) {
                            vq.pop_back();
                            lastiq--;
                            continue;
                        }
                        int iq = lastiq;

                        // Find mate edge in the queue
                        for ( ; iq >= 0; iq--) {
                            Queue& q = vq[iq];
                            if (q.sp < 0) continue;

                            if (edge.sp == q.fromsp && edge.tl == q.fromtl && 
                                edge.len1 == q.len && edge.len2 == q.fromlen && 
                                equisign(edge.anchor, q.fromanchor) && 
                                abs(edge.anchor)+edge.off2 == abs(q.fromanchor)+q.fromoff) 
                                    break;
                        }
                        if (iq >= 0) {    // Edge found - modify target
                            Queue& q = vq[iq];
                            edge_found = true;
                            edge.anchor = q.fromanchor;
                            edge.off2   = q.fromoff;
                            q.sp        = -1;   // indicate processed entry

                            if (!global.dnodes.empty()) {
                                for (int j = 0; j < (int)global.dnodes.size(); j++) {
                                    DebugNode& dnode = global.dnodes[j];
                                    if (dnode.sp == sp && dnode.tl == tl && 
                                        equisign(dnode.anchor, q.anchor) && abs(dnode.anchor-q.anchor) < global.common ||
                                        dnode.sp == edge.sp && dnode.tl == edge.tl && 
                                        equisign(dnode.anchor, edge.anchor) && abs(dnode.anchor-edge.anchor) < global.common) {
                                        ostringstream oss;
                                        oss << "in_" << global.rank << tab << sp << tab << tl << tab 
                                            << node.anchor << tab << showpos << edge.off1 << tab << noshowpos 
                                            << edge.len1 << tab << edge.sp << tab << edge.tl << tab 
                                            << edge.anchor << tab << showpos << edge.off2 << tab << noshowpos 
                                            << edge.len2;
                                        dnf << oss.str() << endl;
                                        break;
                                    }
                                }
                            }       // end of debug output

                            #ifdef BLDGRAPH_INBOUND
                            if (milestone != 0 && nq % milestone == 0)
                                cerr << "#" << nq+1 << ": <- " << sp << " " 
                                << tl << " " << node.anchor << " " << e+1 
                                << " (" << lastline-iq << ")\t\t\r";
                            #endif
                            nq++;
                            break;   // next edge 
                        }
                        // Edge not found
                        cout << "ERROR: Edge " << nq+1 << " (" << edge.sp << " " 
                            << edge.tl << " " << edge.anchor << " " << showpos 
                            << edge.off2 << noshowpos << " " << edge.len2 << ")->(" 
                            << sp << " " << tl << " " << node.anchor << " " 
                            << showpos << edge.off1 << noshowpos << " " 
                            << edge.len2 << ") not found in queue [" 
                            << vq.size() << "]"<< endl;
                        //if (!global.dump_dir.empty()) dumpQueue(queue, -2);
                        //break;
                        abortEnvironment(12);
                    }
                }   // next edge
            }   // next node
        }   // next toplevel
    }   // next species
    #ifdef BLDGRAPH_INBOUND
    cerr << "\t\t\t\t\t\r";
    #endif
}

// Determine whether two integers have the same sign.
bool    equisign(int a, int b) {
    return a<0 && b<0 || a>0 && b>0;
}

#pragma warning(disable : 4101)
// Broadcast all nodes and positions (not edges) to other ranks
// NB: Also establish serial numbering of nodes in each species!
void    bcastNodes(void) {
    int *xbuf;
    if (global.undermpi) {
        #ifdef BLDGRAPHMPI
        xbuf = new int [global.portion*noint];
        MPI_Barrier(MPI_COMM_WORLD);
        #endif
    }
    #ifdef BLDGRAPH_BCASTNODES
    cerr << "bcastNodes\t\t\t\r";
    #endif
    for (int sp = 0; sp < global.nSpecies; sp++) {
        Species& species = global.species[sp];
        int serial = 0;

        // Loop over toplevel sequences
        for (int tl = 0; tl < species.nToplevels; tl++) {
            Toplevel& toplevel = species.toplevels[tl];
            toplevel.firstnode = serial;

            // Loop over nodes
            if (toplevel.rank == global.rank) {             // Sender
                int node_no = 0;
                int nb = 0;         // sendbuf index
                Niter nit = toplevel.nodes.begin();
                for ( ; nit != toplevel.nodes.end(); nit++) {
                    if (global.undermpi) {
                        #ifdef BLDGRAPH_BCASTNODES
                        if (milestone != 0 && node_no % milestone == 0)
                            cerr << sp << " " << tl << " " << node_no << "\t\t\t\r";
                        #endif
                    }

                    Node& node = nit->second;
                    if (global.undermpi) {
                        #ifdef BLDGRAPHMPI
                        xbuf[nb++] = node.anchor;
                        xbuf[nb++] = node.left;
                        xbuf[nb++] = node.right;
                        xbuf[nb++] = node.begin;
                        xbuf[nb++] = node.end;
                        #endif
                    }
                    node.anchor = serial++;     // 2nd use of anchor!
                    node_no++;

                    if (global.undermpi) {
                        #ifdef BLDGRAPHMPI
                        if (node_no % global.portion == 0) {
                            #ifdef BLDGRAPH_BCASTNODES
                            cerr << sp << " " << tl << " -> " << nb/noint << " of " << global.portion << "\t\t\r";
                            #endif
                            MPI_Bcast(xbuf, global.portion*noint, MPI_INT, toplevel.rank, MPI_COMM_WORLD);
                            nb = 0;
                        }
                        #endif
                    }
                }
                if (global.undermpi) {
                    #ifdef BLDGRAPHMPI
                    xbuf[nb] = 0;   // indicate end-of-nodes
                    #ifdef BLDGRAPH_BCASTNODES
                    cerr << sp << " " << tl << " -> " << nb/noint << " of " << global.portion << "\t\t\r";
                    #endif
                    MPI_Bcast(xbuf, global.portion*noint, MPI_INT, toplevel.rank, MPI_COMM_WORLD);
                    #endif
                }
            }

            else if (global.undermpi) {                         // Receiver
                #ifdef BLDGRAPHMPI
                while (true) {
                    MPI_Bcast(xbuf, global.portion*noint, MPI_INT, toplevel.rank, MPI_COMM_WORLD);
                    int node_no = 0;
                    int nb = 0;     // recvbuf index
                    for ( ; node_no < global.portion; node_no++) {
                        if (xbuf[nb] == 0) break;
                        Node node;
                        node.sp     = sp;
                        node.tl     = tl;
                        int anchor  = xbuf[nb++];
                        node.left   = xbuf[nb++];
                        node.right  = xbuf[nb++];
                        node.begin  = xbuf[nb++];
                        node.end    = xbuf[nb++];
                        node.anchor = serial++;
                        pair <Niter, bool> res = toplevel.nodes.insert(Npair(anchor, node));
                        if (!res.second) {
                            cout << "Cannot insert node: sp=" << sp << " tl=" 
                                << tl << " @" << anchor << endl;
                            abortEnvironment(24);
                        }
                        else toplevel.nNodes++;
                    }
                    #ifdef BLDGRAPH_BCASTNODES
                    cerr << sp << " " << tl << " <- " << nb/noint << " of " << global.portion << "\t\t\r";
                    #endif
                    if (node_no < global.portion) break;
                }
                #endif
            }
        }       // next toplevel
    }
    #ifdef BLDGRAPHMPI
    if (global.undermpi) {
        delete [] xbuf;
        #ifdef BLDGRAPH_BCASTNODES
        cerr << "\t\t\t\r" << endl;
        #endif
    }
    #endif
}
