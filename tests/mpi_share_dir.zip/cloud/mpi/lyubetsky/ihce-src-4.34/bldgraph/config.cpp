// (c)2016,2017 Lev Rubanov, IITP RAS
//
// Module:      config.cpp
// Functions:   showHelp parseArguments readConfig getKey getBool getInt getDouble
//              getString initEnvironment finalizeEnvironment abortEnvironment

#include <stdlib.h>
#include "bldgraph.h"

// Static variables
static ofstream     logfs;                          // log file stream
static streambuf*   logsb = 0;
static ofstream     errfs;                          // stderr file stream
static streambuf*   errsb = 0;
static bool     splitlog        = true;             // true: split log by branches
static string   config_file     = "config.ini";     // config file name
#ifdef LINUX
static string   fastapath       = "fasta/";         // prefix of fasta files
static string   hits_dir        = "hits/file.lst";  // list of hit files
#elif defined(WINDOWS)
static string   fastapath       = "fasta\\";        // prefix of fasta files
static string   hits_dir        = "hits\\file.lst"; // list of hit files
#endif
static string   logname         = "bldg_log";       // log file name or prefix
static string   logext          = ".txt";           // log file extension
static string   errname         = "bldg_err";       // err file name or prefix
static string   errext          = ".log";           // err file extension
static bool     log_specified   = false;            // log file specified in the command line
static bool     fp_specified    = false;            // fastapath specified in command line
static bool     common_present  = false;            // common specified in the command line
static bool     minlen_present  = false;            // minlen specified in the command line
static bool     ratio_present   = false;            // ratio specified in the command line
static bool     hits_present    = false;            // hits dir specified in command line
static bool     strand_present  = false;            // strand usage specified in command line
static bool     usedump_present = false;            // use of dump requested in command line
static bool     statonly_present = false;           // statonly requested in command line
static bool     portion_present = false;            // portion size set in command line

// Show short help on command line arguments
void    showHelp (void) {
    cout << "\nBldGraph v." << version 
        #ifdef BLDGRAPHMPI
         << " (MPI)"
        #endif
         << " usage: [options] [config_file]\n"
         << "\nOptions:\n"
         << "-? (--help|?) view this help screen\n"
         << "-c (--config=) configuration file [" << config_file << "]\n"
         << "-d (--strand=) distinct strands [" << (global.strand ? "yes" : "no") << "]\n"
         << "-e (--statonly=) count statistics and exit [" << (global.statonly ? "yes" : "no") << "]\n"
         << "-f (--fastapath=) prefix of fasta files [" << fastapath << "]\n"
         << "-h (--hits=) list of hits files [" << hits_dir << "]\n"
         << "-l (--length) min length of hit [" << global.minlen << "]\n"
        #ifdef BLDGRAPHMPI
         << "-n (--nompi) prevent from using MPI\n"
        #endif
         << "-o (--log=) log file with # if split [" << logname 
            << (splitlog ? "#" : "") << logext << "]\n"
         << "-p (--portion) size of exchange portion [" << global.portion << "]\n"
         << "-r (--ratio) max compression ratio | 0 [" << global.maxratio << "]\n"
         << "-s (--common=) min common part of seqs [" << global.common << "]\n"
         << "-u (--usedump=) number of dump sections to read from [0=none]" << "]\n"
         << endl;
}

// Return false at argument error or help request
bool    parseArguments (int & argc, char** & argv) {
    if (argc <= 1)
        return true;
    int positional = 0;

    for (int i = 1; i < argc; i += 2) {
        char c = argv[i][0];
        string a(argv[i]);      // whole option or parameter
        char *p = 0;
        string b;               // next parameter

        // Help request encountered
        if (c == '?') {
            showHelp();
            return false;
        }

        // Parse other options
        if (c == '-' || c == '/') {     // -options
            c = argv[i][1];
            a.erase(0,1);

            if (i < argc-1) {
                p = argv[i+1];
                b.assign(argv[i+1]);
            }
            else {
                p = 0;
                b.clear();
            }
            istringstream iss(b);
            string::size_type pos;

            switch (c) {
                case '?':               // -?
                    showHelp();
                    return false;
                    break;

                case '-': 
                case '/':                       // --options
                    a.erase(0,1);
                    b.clear();
                    pos = a.find_last_of('=');
                    if (pos != string::npos) {
                        b = a.substr(pos + 1);
                        a.erase(pos);
                    }
                    iss.str(b);

                    if (a == "help") {          // --help
                        showHelp();
                        return false;
                    }

                    else if (a == "config") {   // --config=
                        config_file = b;
                    }

                    else if (a == "strand" || a == "distinct") {    // --strand=
                        strand_present = true;
                        global.strand = getBool(b, 0, 0);
                    }

                    else if (a == "hits") {     // --hits=
                        hits_present = true;
                        iss >> global.hits_dir;
                    }

                    else if (a == "length" || a == "minlen") {      // --length=
                        minlen_present = true;
                        iss >> global.minlen;
                    }

                    else if (a == "log") {      // --log=
                        log_specified = true;
                        pos = b.find_last_of('#');
                        splitlog = (pos != string::npos);
                        logname = b.substr(0, pos);
                        logext = (pos != string::npos) ? b.substr(pos + 1) : "";
                    }

                    else if (a == "nompi") {    // --nompi
                        global.undermpi = false;
                    }

                    else if (a == "portion") {  // --portion
                        portion_present = true;
                        iss >> global.portion;
                    }

                    else if (a == "ratio" || a == "maxratio") {     // --ratio=
                        ratio_present = true;
                        iss >> global.maxratio;
                    }

                    else if (a == "section" || a == "common") {     // --shift=
                        common_present = true;
                        iss >> global.common;
                    }

                    else if (a == "usedump") {  // --usedump=
                        usedump_present = true;
                        iss >> global.usedump;
                    }

                    else if (a == "statonly") { // --statonly=
                        statonly_present = true;
                        global.statonly = getBool(b, 0, 0);
                    }

                    else if (a == "fastapath") { // --fastapath=
                        fp_specified = true;
                        global.fastapath = b;
                    }

                    else {
                        cout << "Unknown option --" << a << endl;
                        return false;
                    }
                    i--;    // since --option include value if any
                    break;

                case 'c':               // -c
                    config_file = b;
                    break;

                case 'd':               // -d
                    strand_present = true;
                    global.strand = getBool(b, 0, 0);
                    break;

                case 'e':               // -e
                    statonly_present = true;
                    global.statonly = getBool(b, 0, 0);
                    break;

                case 'f':               // -f
                    fp_specified = true;
                    global.fastapath = b;
                    break;

                case 'h':               // -h         
                    hits_present = true;
                    iss >> global.hits_dir;
                    break;

                case 'l':               // -l
                    minlen_present = true;
                    iss >> global.minlen;
                    break;

                case 'n':               // -n
                    global.undermpi = false;
                    i--;    // since no value given
                    break;

                case 'o':               // -o
                    log_specified = true;
                    pos = b.find_last_of('#');
                    splitlog = (pos != string::npos);
                    logname = b.substr(0, pos);
                    logext = (pos != string::npos) ? b.substr(pos + 1) : "";
                    break;

                case 'p':               // -p
                    portion_present = true;
                    iss >> global.portion;
                    break;

                case 'r':               // -r
                    ratio_present = true;
                    iss >> global.maxratio;
                    break;

                case 's':               // -s
                    common_present = true;
                    iss >> global.common;
                    break;

                case 'u':               // -u
                    usedump_present = true;
                    iss >> global.usedump;
                    break;

                default:
                    cout << "Unknown option -" << a << endl;
                    return false;
            }
            continue;
        }

        // Parse positional arguments
        istringstream iss1(a);
        switch (positional) {
            case 0:         // config file name
                config_file = a;
                break;

            default:
                cout << "Extra argument '" << a << "' ignored." << endl;
        }
        positional++;
        i--;
    }

    return true;
}

// Return false at config error or no config file
bool    readConfig (void) {
    string::size_type pos;
    ifstream cfg(config_file.c_str());
    if (cfg.fail()) {
        cout << "Cannot open configuration file " << config_file << endl;
        return false;
    }
    char* buf = new char [buflen];

    // Read config file until end
    for (int line_no = 1; !cfg.eof(); line_no++) {
        cfg.getline(buf, buflen, '\n');
        string line(buf);

        // Skip empty lines
        if (line.empty()) continue;
        pos = line.find_first_not_of(whitespace);
        if (pos == string::npos) continue;

        // Skip comments
        if (line[pos] == '#' || line[pos] == ';' || line.substr(pos,2) == "//") 
            continue;

        // Process all sections
        while (line[pos] == '[') {

            // Analyze section header
            string::size_type off = pos + 1;
            pos = line.find_first_of(']', off);
            if (pos == string::npos) {
                cout << "Invalid section header in config line " << line_no << endl;
                delete [] buf;
                return false;
            }
            string section = line.substr(off, pos-off);

            // Analyze relevant sections
            if (section == "common") {                  // 'common' section
                for ( ; !cfg.eof(); line_no++) {
                    cfg.getline(buf, buflen, '\n');
                    line.assign(buf);

                    // Skip empty lines
                    if (line.empty()) continue;
                    pos = line.find_first_not_of(whitespace);
                    if (pos == string::npos) continue;

                    // Skip comments
                    if (line[pos] == '#' || line[pos] == ';' || line.substr(pos,2) == "//") 
                        continue;

                    // Break on the section end
                    if (line[pos] == '[') break;

                    // Process relevant statements
                    string key = getKey(line, line_no, pos);

                    if (!log_specified && key == "splitlog") {
                        splitlog = getBool(line, line_no, pos);
                        continue;
                    }
                    if (!log_specified && key == "logname") {
                        logname = getString(line, line_no, pos);
                        continue;
                    }
                    if (!log_specified && key == "logext") {
                        logext = getString(line, line_no, pos);
                        continue;
                    }
                    if (key == "errname") {
                        errname = getString(line, line_no, pos);
                        continue;
                    }
                    if (key == "errext") {
                        errext = getString(line, line_no, pos);
                        continue;
                    }
                    if (!fp_specified && (key == "fastapath" || key == "fpath")) {
                        global.fastapath = getString(line, line_no, pos);
                        continue;
                    }
                    if (key == "hubname" || key == "hubfile") {
                        global.hubname = getString(line, line_no, pos);
                        continue;
                    }
                    if (key == "starname" || key == "starfile") {
                        global.starname = getString(line, line_no, pos);
                        continue;
                    }
                    if (!minlen_present && (key == "length" || key == "minlen")) {
                        global.minlen = getInt(line, line_no, pos);
                        continue;
                    }
                    if (!ratio_present && (key == "ratio" || key == "maxratio")) {
                        global.maxratio = (float)getDouble(line, line_no, pos);
                        continue;
                    }
                }
            }

            else if (section == "bldgraph") {       // 'bldgraph' section
                for ( ; !cfg.eof(); line_no++) {
                    cfg.getline(buf, buflen, '\n');
                    line.assign(buf);

                    // Skip empty lines
                    if (line.empty()) continue;
                    pos = line.find_first_not_of(whitespace);
                    if (pos == string::npos) continue;

                    // Skip comments
                    if (line[pos] == '#' || line[pos] == ';' || line.substr(pos,2) == "//") 
                        continue;

                    // Break on the section end
                    if (line[pos] == '[') break;

                    // Process relevant statements
                    string key = getKey(line, line_no, pos);

                    if (!log_specified && key == "splitlog") {
                        splitlog = getBool(line, line_no, pos);
                        continue;
                    }
                    if (!log_specified && key == "logname") {
                        logname = getString(line, line_no, pos);
                        continue;
                    }
                    if (!log_specified && key == "logext") {
                        logext = getString(line, line_no, pos);
                        continue;
                    }
                    if (key == "errname") {
                        errname = getString(line, line_no, pos);
                        continue;
                    }
                    if (key == "errext") {
                        errext = getString(line, line_no, pos);
                        continue;
                    }
                    if (!fp_specified && (key == "fastapath" || key == "fpath")) {
                        global.fastapath = getString(line, line_no, pos);
                        continue;
                    }
                    if (key == "hubname" || key == "hubfile") {
                        global.hubname = getString(line, line_no, pos);
                        continue;
                    }
                    if (key == "starname" || key == "starfile") {
                        global.starname = getString(line, line_no, pos);
                        continue;
                    }
                    if (!common_present && (key == "overlap" || key == "common")) {
                        global.common = getInt(line, line_no, pos);
                        continue;
                    }
                    if (!minlen_present && (key == "length" || key == "minlen")) {
                        global.minlen = getInt(line, line_no, pos);
                        continue;
                    }
                    if (!ratio_present && (key == "ratio" || key == "maxratio")) {
                        global.maxratio = (float)getDouble(line, line_no, pos);
                        continue;
                    }
                    if (!strand_present && (key == "strand" || key == "distinct")) {
                        global.strand = getBool(line, line_no, pos);
                        continue;
                    }
                    if (!hits_present && key == "hits") {
                        global.hits_dir = getString(line, line_no, pos);
                        continue;
                    }
                    if (key == "dump") {
                        global.dump_dir = getString(line, line_no, pos);
                        continue;
                    }
                    if (key == "debug") {
                        string dbgline = getString(line, line_no, pos);
                        istringstream ids(dbgline);
                        while (true) {
                            DebugNode dnode;
                            ids >> dnode.sp >> dnode.tl >> dnode.anchor;
                            if (ids.fail()) break;
                            global.dnodes.push_back(dnode);
                        }
                        continue;
                    }
                    if (!usedump_present && key == "usedump") {
                        global.usedump = getInt(line, line_no, pos);
                        continue;
                    }
                    if (key == "hcecount") {
                        global.hcecount = getString(line, line_no, pos);
                        continue;
                    }
                    if (!statonly_present && key == "statonly") {
                        global.statonly = getBool(line, line_no, pos);
                        continue;
                    }
                    if (!portion_present && key == "portion") {
                        global.portion = getInt(line, line_no, pos);
                        continue;
                    }

                     // More statements here.
                }
            }

            else if (section == "species") {            // 'species' section
                for ( ; !cfg.eof(); line_no++) {
                    cfg.getline(buf, buflen, '\n');
                    line.assign(buf);

                    // Skip empty lines
                    if (line.empty()) continue;
                    pos = line.find_first_not_of(whitespace);
                    if (pos == string::npos) continue;

                    // Skip comments
                    if (line[pos] == '#' || line[pos] == ';' || line.substr(pos,2) == "//") 
                        continue;

                    // Break on the section end
                    if (line[pos] == '[') break;

                    // Collect species data
                    Species sp;
                    sp.no = -1;
                    off = pos;
                    pos = line.find_first_of(tab, off);
                    if (pos == string::npos) {
                        cout << "Species no. error in config at line " << line_no << endl;
                        return false;
                    }
                    string species_no = line.substr(off, pos-off);
                    istringstream issno(species_no);
                    issno >> sp.no;

                    off = line.find_first_not_of(tab, pos);
                    pos = line.find_first_of(tab, off);
                    if (off == string::npos || pos == string::npos) {
                        cout << "Species id error in config at line " << line_no << endl;
                        return false;
                    }
                    sp.id = line.substr(off, pos-off);

                    off = line.find_first_not_of(tab, pos);
                    pos = line.find_first_of(tab, off);
                    if (off == string::npos || pos == string::npos) {
                        cout << "Species name error in config at line " << line_no << endl;
                        return false;
                    }
                    sp.name = line.substr(off, pos-off);

                    off = line.find_first_not_of(tab, pos);
                    pos = line.find_first_of(tab, off);
                    if (off == string::npos || pos == string::npos) {
                        cout << "Species code error in config at line " << line_no << endl;
                        return false;
                    }
                    sp.code = line.substr(off, pos-off);

                    off = line.find_first_not_of(tab, pos);
                    pos = line.find_first_of(tab, off);
                    if (off == string::npos) {
                        cout << "Species fasta error in config at line " << line_no << endl;
                        return false;
                    }
                    sp.fasta = global.fastapath + ( pos==string::npos ?
                        line.substr(off) : line.substr(off, pos-off) );

                    // ignore GFF

                    IIiter mit = global.spmap.find(sp.no);
                    if (mit != global.spmap.end()) {
                        cout << "Duplicated species no. in config at line " << line_no << endl;
                        return false;
                    }
                    global.spmap.insert( pair <int, int> (sp.no, global.nSpecies));
                    global.species.push_back(sp);
                    global.nSpecies++;
                }
            }
            // Ignore other sections for now
            if (cfg.eof()) break;
        }
    }

    global.nSpecies = (int)global.species.size();
    if (global.fastapath.empty())   global.fastapath = fastapath;
    if (global.hits_dir.empty())    global.hits_dir  = hits_dir;
    if (global.maxratio <= 0)       global.maxratio  = bigratio;
    if (global.usedump != 0 && global.dump_dir.empty()) 
                                    global.usedump   = 0;

    delete [] buf;
    return true;
}

// Get the key from 'key = value' string
string  getKey (const string & str, int lineno, string::size_type off = 0) {
    string key;
    string::size_type begin = str.find_first_not_of(whitespace, off);
    if (begin == string::npos)
        return key;

    string::size_type end = str.find_first_of('=', begin);
    if (end == string::npos)
        return key;

    key = str.substr(begin, end - begin);
    if (!key.empty()) {
        end = key.find_first_of(whitespace);
        if (end != string::npos)
            key.erase(end);
    }
    else {
        cout << "Key not found in config line " << lineno << endl;
    }
    return key;
}

// Get boolean value from 'key = value' string or from 'value' string if lineno=0
bool    getBool (const string & str, int lineno, string::size_type off = 0) {
    string value = lineno > 0 ? getString(str, lineno, off) : str;
    if (value.size() == 1) {
        string positive = "yYtT+1";
        string negative = "nNfF-0";
        if (positive.find_first_of(value[0]) != string::npos)
            return true;
        if (negative.find_first_of(value[0]) != string::npos)
            return false;
        if (lineno > 0)
            cout << "Invalid Boolean value in config line " << lineno << endl;
        else
            cout << "Invalid Boolean value in command line" << endl;
    }
    else {
        string positive = "yesYesYEStrueTrueTRUE";
        string negative = "notNotNOTfalseFalseFALSE";
        if (positive.find(value) != string::npos)
            return true;
        if (negative.find(value) != string::npos)
            return false;
        if (lineno > 0)
            cout << "Invalid Boolean value in config line " << lineno << endl;
        else
            cout << "Invalid Boolean value in command line" << endl;
    }
    return false;
}

// Get integer value from 'key = value' string
int     getInt (const string & str, int lineno, string::size_type off = 0) {
    int result = -1;
    string value = getString(str, lineno, off);
    istringstream iss(value);
    iss >> result;
    return result;
}

// Get double value from 'key = value' string
double  getDouble (const string & str, int lineno, string::size_type off = 0) {
    double result = -1.0;
    string value = getString(str, lineno, off);
    istringstream iss(value);
    iss >> result;
    return result;
}

// Get possibly quoted string value from 'key = value' string
string  getString (const string & str, int lineno, string::size_type off = 0) {
    string result;
    string::size_type pos = str.find_first_of('=', off);
    if (pos == string::npos) {
        cout << "Value not found in config line " << lineno << endl;
        return result;
    }

    pos = str.find_first_not_of(whitespace, pos+1);
    if (pos == string::npos || str.substr(pos, 2) == "//") {
        // Allow empty value for a key
        //cout << "Value not found in config line " << lineno << endl;
        return result;
    }

    string::size_type end;
    if (str[pos] == '\"') {     // quoted string
        end = str.find_first_of('\"', ++pos);
        if (end == string::npos) {
            cout << "Invalid double quoted string in contig line " << lineno << endl;
            return result;
        }
        result = str.substr(pos, end - pos);
    }
    else {                      // non-quoted string
        end = str.find_first_of(whitespace, pos);
        if (end == string::npos)
            result = str.substr(pos);
        else
            result = str.substr(pos, end - pos);
    }
    return result;
}

// Initialize MPI and output files if needed 
bool    initEnvironment (int & argc, char** & argv) {
    if (global.undermpi) {
        #ifdef BLDGRAPHMPI
        try {
            MPI_Init(&argc, &argv);
            MPI_Comm_size(MPI_COMM_WORLD, &global.size);
            MPI_Comm_rank(MPI_COMM_WORLD, &global.rank);
            int flag;
            MPI_Initialized(&flag);
            if (!flag)
                throw 1;
            else if (global.size < 2) {
                MPI_Finalize();
                throw 2;
            }

            // Redirect cout & cerr to separate files
            if (splitlog) {
                int width = 0;
                for (int k = 1; k < global.size; k *= 10)
                    width++;
                ostringstream num;
                if (width > 0)
                    num << setfill('0') << setw(width) << global.rank;
                if (!logname.empty()) {
                    string filename = logname + num.str() + logext;
                    logfs.open(filename.c_str());
                    logsb = cout.rdbuf(logfs.rdbuf());
                }

                // Also redirect cerr in this case
                if (!errname.empty()) {
                    string filename = errname + num.str() + errext;
                    errfs.open(filename.c_str());
                    errsb = cerr.rdbuf(errfs.rdbuf());
                }
            }
            
            // Redirect cout & cerr to a single file
            else {
                if (!logname.empty()) {
                    string filename = logname + logext;
                    logfs.open(filename.c_str());
                    logsb = cout.rdbuf(logfs.rdbuf());
                }
                if (!errname.empty()) {
                    string filename = errname + errext;
                    errfs.open(filename.c_str());
                    errsb = cerr.rdbuf(errfs.rdbuf());
                }
            }
        }
        catch (...) {
            global.undermpi = false;
            global.size = 1;
            global.rank = 0;
            if (!logname.empty()) {
                string filename = logname + logext;
                logfs.open(filename.c_str());
                logsb = cout.rdbuf(logfs.rdbuf());
            }
            if (!errname.empty()) {
                string filename = errname + errext;
                errfs.open(filename.c_str());
                errsb = cerr.rdbuf(errfs.rdbuf());
            }
        }
        #else
        global.undermpi = false;
        global.size = 1;
        global.rank = 0;
        if (!logname.empty()) {
            string filename = logname + logext;
            logfs.open(filename.c_str());
            logsb = cout.rdbuf(logfs.rdbuf());
        }
        if (!errname.empty()) {
            string filename = errname + errext;
            errfs.open(filename.c_str());
            errsb = cerr.rdbuf(errfs.rdbuf());
        }
        #endif
    }
    else {
        global.size = 1;
        global.rank = 0;
        if (!logname.empty()) {
            string filename = logname + logext;
            logfs.open(filename.c_str());
            logsb = cout.rdbuf(logfs.rdbuf());
        }
        if (!errname.empty()) {
            string filename = errname + errext;
            errfs.open(filename.c_str());
            errsb = cerr.rdbuf(errfs.rdbuf());
        }
    }
    return true;
}

// Finalize MPI and close output files if needed
void    finalizeEnvironment (void) {
    if (global.undermpi) {
        #ifdef BLDGRAPHMPI
        int flag;
        MPI_Initialized(&flag);
        if (flag)
            MPI_Finalize();
        #endif
        global.undermpi = false;
    }
    logfs.close();
    if (logsb) cout.rdbuf(logsb);
    errfs.close();
    if (errsb) cerr.rdbuf(errsb);
}

// Abort MPI and close output files if needed
void    abortEnvironment (int code) {   // last=24
    if (global.undermpi) {
        #ifdef BLDGRAPHMPI
        int flag;
        MPI_Initialized(&flag);
        if (flag)
            MPI_Abort(MPI_COMM_WORLD, code);
        #endif
        global.undermpi = false;
    }
    logfs.close();
    if (logsb) cout.rdbuf(logsb);
    errfs.close();
    if (errsb) cerr.rdbuf(errsb);
    cout << "\nAbnormal completion: " << code << endl;
    exit(code);
}
