// (c)2016,2017 Lev Rubanov, IITP RAS
//
// Module:      bldgraph.h
//

#ifndef BLDGRAPH_HEADER
#define BLDGRAPH_HEADER

#ifdef __unix__
#define LINUX
#elif defined(WIN32) || defined(_WIN32) || defined(_WIN64)
#define WINDOWS
#endif

//#define NOMPI               // Uncomment or define externally to disable MPI code

#ifndef NOMPI
#define BLDGRAPHMPI        // Include mpi-related code
#endif

//#define BLDGRAPH_READTOPLEVEL   // Report reading toplevel seqs to stderr
//#define BLDGRAPH_READHITS       // Report reading hits to stderr
//#define BLDGRAPH_DUMP           // Report dumping graph to stderr
//#define BLDGRAPH_OUTBOUND       // Report outbound changes to stderr
//#define BLDGRAPH_INBOUND        // Report inbound changes to stderr
//#define BLDGRAPH_DUMPQUEUE      // Dump edge agreeing queue
//#define BLDGRAPH_TRANSFER       // Report MPI transfers to stderr
//#define BLDGRAPH_BCASTNODES     // Report broadcasting of nodes to stderr
//#define BLDGRAPH_MERGENODES     // Report merging of nodes to stderr
//#define BLDGRAPH_BCASTREMAP     // Report broadcasting of nodes remap to stderr
//#define BLDGRAPH_AGREEEDGES     // Report agreeing of edges to stderr
//#define BLDGRAPH_CLEARDUMMY     // Report clearing of old nodes to stderr
//#define BLDGRAPH_EQUALEDGES     // Report equalization of edges to stderr
//#define BLDGRAPH_WRITESTAR      // Report writing stars file to stderr
#define BLDGRAPH_REVCOMPL       // Store reverse complement at negative strand
#define BLDGRAPH_FIXNEGPOS      // Fix position at negative strand (pairhits bug)

#ifdef BLDGRAPHMPI
#define MSMPI_NO_DEPRECATE_20       // for MS MPI
#include "mpi.h"
#endif //BLDGRAPHMPI
#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <iomanip>
#include <vector>
#include <map>
#include <list>
#include <algorithm>
#include <limits>
#include <ctime>
#include <locale>       // for tolower,toupper
#include <memory.h>     // for memset

using namespace std;

#ifdef BLDGRAPHMPI
#define getTimer()  (global.undermpi ? MPI_Wtime() : (double)clock()/CLOCKS_PER_SEC)
#else
#define getTimer()  (double)clock()/CLOCKS_PER_SEC
#endif //BLDGRAPHMPI

struct Node;
struct Edge;
bool    equisign(int a, int b);

#if !defined(_MSC_VER) && !defined(__ICC)
typedef long long       __int64;
#endif
typedef map <int, Node>  Nmap;
typedef Nmap::iterator   Niter;
typedef pair <int, Node> Npair;
typedef map <int, int>  IImap;
typedef pair <int, int> IIpair;
typedef IImap::iterator IIiter;

const string    version     = "2.16";
const int       buflen      = 4096;
const string    whitespace  = " \t\r\n";
const char      tab         = '\t';
#ifdef LINUX
const char      slash       = '/';      // Linux path slash
#elif defined(WINDOWS)
const char      slash       = '\\';     // Windows path slash
#endif
const string    gbkintro    = "LOCUS";
const string    gbkorigin   = "ORIGIN";
const string    gbkend      = "//";
const int       gbkgroups   = 6;        // groups per sequence line in GenBank
const int       milestone   = 10000;
const float     bigratio    = 1000.0F;
const int       specidsize  = 36;       // for hub & star
const int       quint       = 8;        // number of int's in Queue
const int       noint       = 5;        // number of int's in exch Node
const int       tag1        = 1;        // exchanging queue elements
const int       xlot        = 1000;     // queue elements to exchange
const unsigned int errorcode = 0xFFFFFFFF;  // for writePartition

enum dumpGraphMode {    // dumpGraph modes:
    dg_normal,          // 0=normal 
    dg_sequence,        // 1=whole toplevel sequences
    dg_element,         // 2=UC-elements (common intersection)
    dg_union    = 4,    // 4=UC-elements (union inside bounds)
    dg_final    = 8     // unnumbered dump files for 2nd step
};

struct Hit {
    int     species_no1;
    int     seq_no1;
    int     center1;        // 1-based from pairHits, = begin+end
    int     species_no2;
    int     seq_no2;
    int     center2;        // 1-based from pairHits, = begin+end
    short   len1;
    short   len2;
    short   strand2;    // if < 0, ctr2 is from the right!
    Hit() {
        species_no1 = species_no2 = 0;
        seq_no1 = seq_no2 = 0;
        center1 = center2 = 0;
        len1 = len2 = strand2 = 0;
    }
    void    operator= (Hit& other) {
        species_no1 = other.species_no1;
        seq_no1     = other.seq_no1;
        center1     = other.center1;
        len1        = other.len1;
        species_no2 = other.species_no2;
        seq_no2     = other.seq_no2;
        center2     = other.center2;
        len2        = other.len2;
        strand2     = other.strand2;
    }
    bool    operator== (Hit& other) {
        return species_no1 == other.species_no1 && seq_no1 == other.seq_no1
            && species_no2 == other.species_no2 && seq_no2 == other.seq_no2
            && center1 == other.center1 && center2 == other.center2
            && strand2 == other.strand2;
    }
    bool    operator!= (Hit& other) {
        return !operator==(other);
    }
};

struct Queue {
    int     sp;
    int     tl;
    int     anchor;
    int     fromsp;
    int     fromtl;
    int     fromanchor;
    short   len;
    short   off;
    short   fromlen;
    short   fromoff;
    bool    operator< (const Queue& my) const {     // ASC - from
        if (fromsp == my.fromsp) {
            if (fromtl == my.fromtl) {
                if (fromanchor<0 && my.fromanchor>0) return true;
                if (fromanchor>0 && my.fromanchor<0) return false;
                if (abs(fromanchor)+fromoff == abs(my.fromanchor)+my.fromoff)
                    return fromlen < my.fromlen;
                return abs(fromanchor)+fromoff < abs(my.fromanchor)+my.fromoff;
            }
            return fromtl < my.fromtl;
        }
        return fromsp < my.fromsp;
    }
};

struct Node {
    int     sp;         // Species serial
    int     tl;         // Toplevel serial no.
    int     anchor;     // inner position, signed if strand-sensitive | serial no.
    int     left;       // left bound of entire seq at a node, 0-based
    int     right;      // right bound of entire seq at a node, 0-based
    int     begin;      // begin of common sequence, 0-based
    int     end;        // end of common sequence, 0-based
    int     nEdges;     // 
    vector <Edge> edges;
    Node() { 
        anchor = 0;
        nEdges = 0;
    }
};

struct Edge {
    int     rank;       // TO node
    int     sp;         // TO node
    int     tl;         // TO node
    int     anchor;     // TO node
    short   len1;       // FROM node
    short   off1;       // FROM node [begin1-abs(anchor1)]
    short   len2;       // TO node
    short   off2;       // TO node [begin2-abs(anchor2)]
    Edge() {
        rank = -1;
        anchor = 0;
    }
    Edge(const Edge& e) {
        rank    = e.rank;
        sp      = e.sp;
        tl      = e.tl;
        anchor  = e.anchor;
        len1    = e.len1;
        off1    = e.off1;
        len2    = e.len2;
        off2    = e.off2;
    }
    bool    operator< (const Edge& my) const {  // natural order
        if (sp == my.sp) {
            if (tl == my.tl) {
                if (anchor == my.anchor) {
                    if (off2 == my.off2) {
                        if (len2 == my.len2) {
                            if (off1 == my.off1)
                                return len1 < my.len1;
                            return off1 < my.off1;
                        }
                        return len2 < my.len2;
                    }
                    return off2 < my.off2;
                }
                return anchor < my.anchor;
            }
            return tl < my.tl;
        }
        return sp < my.sp;
    }
    bool    operator== (const Edge& my) const { // assuming from same node
        return (sp == my.sp && tl == my.tl && len2 == my.len2 && 
            equisign(anchor, my.anchor>0) &&
            abs(anchor)+off2 == abs(my.anchor)+my.off2);
    }
    bool    operator!= (const Edge& my) const { // assuming from same node
        return !operator==(my);
    }
};

struct Toplevel {
    int     rank;           // relevance
    int     no;             // = seq_no
    string  id;             // = seq_id
    int     len;
    string  seq;            // zero based
    int     nNodes;
    Nmap    nodes;          // mapped by center
    int     firstnode;      // first node number
    int     nEdges;
    Toplevel() {
        rank   = -1;
        nNodes = 0;
        nEdges = 0;
        firstnode = -1;
    }
};

struct Species {
    int     no;             // = species_no
    string  id;
    string  name;
    string  code;           // Ignored
    string  fasta;
    string  gff;            // Ignored
    // Below are actual data (above threshold)
    int     nToplevels;
    vector <Toplevel> toplevels;
    IImap   tlmap;              // code -> ser.no. of toplevel seq
    Species() {
        no          = 0;
        nToplevels  = 0;
    }
};

struct DebugNode {
    int anchor;
    int sp;
    int tl;
};

struct Global {
    bool    undermpi;           // if we are under mpi
    int     size;               // number of cpu
    int     rank;               // this cpu number
    int     common;             // min common part of seqs at a node
    int     minlen;             // min length of (merged) hit
    float   maxratio;           // max compression ratio to hold (0: no check)
    bool    strand;             // distinct strand of a hit
    int     nSpecies;           // relevant species count
    vector <Species> species;   // relevant species IDs
    IImap   spmap;              // code -> ser.no. of species
    string  fastapath;
    string  toplevel_file;
    string  hits_dir;
    string  dump_dir;
    string  hubname;
    string  starname;           // substitute species ID for *
    double  t0;
    __int64 totalPower;         // total length of the graph arcs
    __int64 totalHits;          // total hits read
    __int64 nHits;              // relevant hits count
    __int64 nNodes;             // nodes created
    __int64 nEdges;             // edges created
    int     nFiles;             // total files read
    vector <DebugNode> dnodes;
    ofstream dnf;
    int     spidw;              // specied id width (max)
    int     usedump;            // dump branches to write output from (0=none)
    string  hcecount;           // filename to output HCE counts
    bool    statonly;           // true: collect input statistics and exit
    vector <vector <__int64> > HCE;  // HCE count matrix
    int     portion;            // dynamic value of xlot

    // Constructor
    Global () {
        undermpi    = true;
        size        = 1;
        rank        = 0;
        common      = 32;
        minlen      = 60;
        maxratio    = 2.2F;
        strand      = true;
        nSpecies    = 0;
        totalHits   = 0;
        nHits       = 0;
        nFiles      = 0;
        nNodes      = 0;
        nEdges      = 0;
        totalPower  = 0;
        spidw       = 0;
        usedump     = 0;
        statonly    = false;
        portion     = xlot;
    }
};

// Output file structures
struct HubFileHeader {
    char sig[4];        // HUB signature (HUD if distinct strands)
    int nspecies;       // Number of species
    __int64 filelen;    // File length
    __int64 offset[1];  // [nspecies] strip offsets
};

struct Element {    // New word from a species
    int tl;             // toplevel no. within a species
    int ustart;         // union start position (+ strand, 1-based)
    int ulen;           // union length
    int istart;         // intersection start position (+ strand, 1-based)
    int ilen;           // intersection length
    int strand;         // +1/-1/0=unknown 
};

struct StripHeader {
    char specid[specidsize];    // Species ID (short)
    int nelem;                  // Number of elements
    Element element[1];         // [nelem] elements themselves
};

struct StarFileHeader {
    char sig[4];            // STF signature
    int specno;             // This species number
    int headlen;            // Header length
    int nstars;             // Total number of stars (=nelem)
    __int64 filelen;        // File length
    __int64 offset[1];      // [nstar] star offsets
};

struct Ray {
    int     specno2;
    int     nodeno2;
    float   weight;
};

struct Star {
    int nrays;
    Ray ray[1];     // [nrays] rays
};

#ifdef BLDGRAPH_MAINMODULE
    Global global;
#else
    extern Global global;
#endif      // BLDGRAPH_MAINMODULE

void    showHelp (void);
bool    parseArguments (int & argc, char** & argv);
bool    initEnvironment (int & argc, char** & argv);
void    finalizeEnvironment (void);
void    abortEnvironment (int code);
bool    readConfig (void);
string  getKey    (const string & str, int lineno, string::size_type off);
bool    getBool   (const string & str, int lineno, string::size_type off);
int     getInt    (const string & str, int lineno, string::size_type off);
double  getDouble (const string & str, int lineno, string::size_type off);
string  getString (const string & str, int lineno, string::size_type off);
bool    readToplevel (bool readseq = true);
//bool    readToplevel2 (void);
string  getSequenceName (string& line);
bool    readHits (void);
void    sortEdges (void);
void    dumpGraph (int mode = dg_normal);
string& reverseComplement (const string& str, int strand);
#ifdef BLDGRAPH_DUMPQUEUE
void    dumpQueue (vector <vector <Queue> >& queue, int serial);
#endif
void    agreeOutbound (vector <vector <Queue> >& queue);
void    agreeInbound  (vector <vector <Queue> >& queue);
void    exchangeQueue (vector <vector <Queue> >& queue);
bool    qdesc (const Queue& q1, const Queue& q2);
void    bcastNodes (void);
void    measureGraph (void);
bool    lessWeight (const Edge& e1, const Edge& e2);
bool    checkSpecies (void);
void    clearSpeciesData (Species& spec);
bool    rebuildSpeciesData (int sp);
bool    writeHub (void);
unsigned int    writePartition (int n);

#endif //BLDGRAPH_HEADER
