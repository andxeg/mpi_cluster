// (c)2016,2017 Lev Rubanov, IITP RAS
//
// Module:      bldgraph.cpp
// Functions:   main
// Input:       Configuration file 
//              Species and Toplevel files (table dumps)
//              Hit files in subdirectories
//              Generated result files
// Result:      Graph data files (*.hub, *.stars) as per MPCLA/MPCLC.
//

#define BLDGRAPH_MAINMODULE
#include "bldgraph.h"
#undef BLDGRAPH_MAINMODULE

int main(int argc, char **argv) {
    double& t0 = global.t0;
    double  t1;

    // Interpret command line agruments
    if (!parseArguments(argc, argv)) 
        abortEnvironment(1);

    // Read global configuration
    if (!readConfig())
        abortEnvironment(2);

    // Check if mpi is present and initialize it
    if (!initEnvironment(argc, argv))
        abortEnvironment(3);

    t0 = getTimer();
    ostringstream ossmulti;
    if (global.size > 1) ossmulti << "*" << global.size;
    cout << "\nBldGraph v." << version << " run" << ossmulti.str() << ":";
    if (global.rank == 0)
        cerr << "\nBldGraph v." << version << " run" << ossmulti.str() << ":";
    for (int i = 1; i < argc; i++) {
        string arg(argv[i]);
        cout << " " << arg;
        if (global.rank == 0)
            cerr << " " << arg;
    }

    cout << "\nA total of " << global.nSpecies << " organism IDs read:" << endl;
    for (int n = 0; n < global.nSpecies; n++) {
        Species& spn = global.species[n];
        cout << setw(4) << spn.no << " " << spn.id << endl;
        if ((int)spn.id.size() > global.spidw) 
            global.spidw = (int)spn.id.size();
    }
    cout << endl;
    cout.flush();
    if (global.rank == 0)
        cerr << "\nA total of " << global.nSpecies << " organism IDs read." << endl;

    if (global.undermpi && global.dump_dir.empty()) {
        cout << "Dump directory is required." << endl;
        abortEnvironment(19);
    }

    // If not just writing stars & hub files
    if (global.usedump == 0) {

        // Read and store toplevel sequences
        if (!readToplevel())
            abortEnvironment(4);
        t1 = getTimer();
        cout << (int)((t1-t0)/60) << " m: All-process toplevel sequences read:" << endl;
        for (int n = 0; n < global.nSpecies; n++) {
            Species& spn = global.species[n];
            cout << setw(4) << spn.no << " " << spn.id << " \t" 
                << spn.nToplevels << endl;
        }
        cout << endl;
        // Prepare debug result file if requested
        if (!global.dnodes.empty() && !global.dump_dir.empty()) {
            ostringstream odf;
            odf << global.dump_dir << "debug";
            if (global.undermpi) odf << global.rank;
            odf << ".txt";
            global.dnf.open(odf.str().c_str());
            if (global.dnf.fail() || global.dnf.bad()) {
                cout << "Cannot create file " << odf.str() << endl;
                abortEnvironment(5);
            }
        }
        // Prepare HCE count matrix if requested
        if (!global.hcecount.empty() ) {
            for (int n = 0; n <= global.nSpecies; n++) {    // with total row
                vector <__int64> ucrow (global.nSpecies, 0);
                global.HCE.push_back(ucrow);
            }
        }
        ofstream hcf;
        if( global.rank == 0 && !global.hcecount.empty() ) {
            hcf.open(global.hcecount.c_str());
            if (!hcf.good()) 
                cout << "Cannot write HCE counts to " << global.hcecount << endl;
        }

        // Read selected hits
        if (!readHits())            // and count HCE (here, edges)
            finalizeEnvironment();
        #ifdef BLDGRAPH_READHITS
        cerr << endl;
        #endif

        // Write HCE counts to file if requested
        if( global.rank == 0 && !global.hcecount.empty() ) {
            hcf << tab;
            for (int j = 0; j < global.nSpecies; j++)
                hcf << tab << global.species[j].no;
            hcf << "\n\t";
            for (int j = 0; j < global.nSpecies; j++)
                hcf << tab << global.species[j].name;
            hcf << endl;

            for (int i = 0; i < global.nSpecies; i++) {
                hcf << global.species[i].no << tab << global.species[i].name;
                for (int j = 0; j < global.nSpecies; j++) {
                    hcf << tab << global.HCE[i][j];
                    global.HCE[global.nSpecies][j] += global.HCE[i][j];
                }
                hcf << endl;
            }
            hcf << tab << "TOTAL";
            for (int j = 0; j < global.nSpecies; j++)
                hcf << tab << global.HCE[global.nSpecies][j];
            hcf << endl;
            for (int i = 0; i <= global.nSpecies; i++)
                for (int j = 0; j < global.nSpecies; j++)
                    global.HCE[i][j] = 0;
        }
        //sortEdges();    // by target:  species, toplevel, anchor+off, len

        t1 = getTimer();
        string scope = global.undermpi ? "Local" : "Global";
        cout << endl;
        cout << (int)((t1-t0)/60) << " m: " << scope << " read: files=" << global.nFiles 
            << " hits=" << global.nHits << "/" << global.totalHits << " nodes="
            << global.nNodes << " edges=" << global.nEdges << " power=" 
            << global.totalPower << endl;

        #ifdef BLDGRAPHMPI
        if (global.undermpi) {
            __int64 sendint64[4] = { global.nHits, global.nNodes, global.nEdges, global.totalPower };
            __int64 recvint64[4];
            MPI_Reduce(sendint64, recvint64, 4, MPI_LONG_LONG_INT, MPI_SUM, 0, MPI_COMM_WORLD);

            if (global.rank == 0) {
                t1 = getTimer();
                cout << (int)((t1-t0)/60) << " m: Global read: files=" << global.nFiles 
                    << " hits=" << recvint64[0] << "/" << global.totalHits << " nodes=" 
                    << recvint64[1] << " edges=" << recvint64[2] << " power=" 
                    << recvint64[3] << endl;
            }
        }
        #endif

        t1 = getTimer();
        cout << "\n" << (int)((t1-t0)/60) << " m: Measuring initial graph..." << endl;
        measureGraph();

        //if (!global.dump_dir.empty())   dumpGraph();
        if (global.statonly) {
            t1 = getTimer();
            cout << "\n" << (int)((t1-t0)/60) << " m: Finished OK." << endl;
            finalizeEnvironment();
        }

        // Queueing outbound edges
        t1 = getTimer();
        cout << "\n" << (int)((t1-t0)/60) << " m: Queueing outbound edges..." << endl;

        vector <vector <Queue> > queue (global.size);

        agreeOutbound(queue);
        #ifdef BLDGRAPH_DUMPQUEUE
        if (!global.dump_dir.empty()) dumpQueue(queue, 0);
        #endif

            
        t1 = getTimer();
        cout << "\n" << (int)((t1-t0)/60) << " m: Measuring aggregated graph..." << endl;
        measureGraph();

        //if (!global.dump_dir.empty())   dumpGraph(dg_element|dg_union);

        // Exchanging queues
        t1 = getTimer();
        cout << "\n" << (int)((t1-t0)/60) << " m: Exchanging queues..." << endl;

        exchangeQueue(queue);     // exchange queues
        #ifdef BLDGRAPH_DUMPQUEUE
        if (!global.dump_dir.empty()) dumpQueue(queue, -1);
        #endif

        // Relinking inbound edges
        t1 = getTimer();
        cout << "\n" << (int)((t1-t0)/60) << " m: Relinking inbound edges..." << endl;

        agreeInbound(queue);

        t1 = getTimer();
        cout << "\n" << (int)((t1-t0)/60) << " m: The graph with nodes and edges agreed." << endl;
        measureGraph();

        // If needed, broadcast nodes to all processes (without edges)
        t1 = getTimer();
        cout << "\n" << (int)((t1-t0)/60) << " m: Broadcasting nodes over processes..." << endl;
        bcastNodes();

        t1 = getTimer();
        cout << "\n" << (int)((t1-t0)/60) << " m: The final graph built." << endl;
        measureGraph();

        if (!global.dump_dir.empty())   dumpGraph(dg_final);
        global.usedump = global.size;

        #ifdef BLDGRAPHMPI
        if (global.undermpi) 
            MPI_Barrier(MPI_COMM_WORLD);
        #endif

        if (!global.hcecount.empty()) {
            // Count HCEs only for outbound edges
            for (int sp = 0; sp < global.nSpecies; sp++) {
                Species& spec = global.species[sp];
                for (int tl = 0; tl < spec.nToplevels; tl++) {
                    Toplevel& toplevel = spec.toplevels[tl];
                    if (toplevel.rank != global.rank) continue;

                    Niter nit = toplevel.nodes.begin();
                    for ( ; nit != toplevel.nodes.end(); nit++) {
                        Node& node = nit->second;
                        for (int e = 0; e < (int)node.edges.size(); e++) {
                            Edge& edge = node.edges[e];
                            global.HCE[sp][edge.sp]++;
                        }
                    }
                }
            }
            //cerr << "Local UCE counted." << endl;

            // Sum matrices over all branches
            #ifdef BLDGRAPHMPI
            if (global.undermpi) {
                MPI_Barrier(MPI_COMM_WORLD);
                vector <__int64> recvrow (global.nSpecies);
                for (int i = 0; i < global.nSpecies; i++) {
                    MPI_Reduce(&global.HCE[i][0], &recvrow[0], global.nSpecies, 
                        MPI_LONG_LONG_INT, MPI_SUM, 0, MPI_COMM_WORLD);
                    if (global.rank == 0)
                        global.HCE[i].assign(recvrow.begin(), recvrow.end());
                    //cerr << "HCE row " << i << " reduced." << endl;
                }
                //cerr << "HCE matrix reduced." << endl;
            }
            #endif

            // Write UCE counts to file
            hcf << "\n\t";
            for (int j = 0; j < global.nSpecies; j++)
                hcf << tab << global.species[j].no;
            hcf << "\n\t";
            for (int j = 0; j < global.nSpecies; j++)
                hcf << tab << global.species[j].name;
            hcf << endl;

            for (int i = 0; i < global.nSpecies; i++) {
                hcf << global.species[i].no << tab << global.species[i].name;
                for (int j = 0; j < global.nSpecies; j++) {
                    hcf << tab << global.HCE[i][j];
                    global.HCE[global.nSpecies][j] += global.HCE[i][j];
                }
                hcf << endl;
            }
            hcf << tab << "TOTAL";
            for (int j = 0; j < global.nSpecies; j++)
                hcf << tab << global.HCE[global.nSpecies][j];
            hcf << endl;
            hcf.close();
            global.HCE.clear();
            //cerr << "HCE matrix written." << endl;
        }

    }   // or use ready final dump


    #ifdef BLDGRAPHMPI
    if (global.undermpi) 
        MPI_Barrier(MPI_COMM_WORLD);
    #endif

    t1 = getTimer();
    cout << "\n" << (int)((t1-t0)/60) << " m: Writing the graph to output files...\n" << endl;
    if (global.usedump != 0 && !checkSpecies()) {
        cout << "Inconsistent species - cannot use the dump." << endl;
        abortEnvironment(20);
    }

    // Rebuild all species data in each branch
    if (global.usedump != 0) { 
        for (int n = 0; n < global.nSpecies; n++) {
            if (!rebuildSpeciesData(n)) {
                cout << "Cannot rebuild species #" << n << " ("
                    << global.species[n].id << ")" << endl;
                abortEnvironment(21);
            }
        }
    }

    // Write the partition per species
    for (int n = global.rank; n < global.nSpecies; n += global.size) {
        Species& spn = global.species[n];
        #ifdef BLDGRAPH_WRITESTAR
        cerr << left << setw(global.spidw) << spn.id << " : \t\t\t\r";
        #endif
        cout << left << setw(global.spidw) << spn.id << " : ";

        unsigned int tot = writePartition(n);
        if (tot == errorcode) {
            #ifdef BLDGRAPH_WRITESTAR
            cerr << endl;
            #endif
            cout << endl;
            abortEnvironment(6);
        }
        #ifdef BLDGRAPH_WRITESTAR
        cerr << left << setw(global.spidw) << spn.id << " : " 
            << tot << " edges written" << endl;
        #endif
        cout << tot << " edges written" << endl;
    }

    if (global.rank == 0) {
        if (!writeHub()) {
            #ifdef BLDGRAPH_WRITESTAR
            cerr << endl;
            #endif
            cout << endl;
            abortEnvironment(7);
        }
        t1 = getTimer();
        cerr << (int)((t1-t0)/60) << " m: Initial graph built." << endl;
    }

    t1 = getTimer();
    cout << "\n" << (int)((t1-t0)/60) << " m: Finished OK." << endl;
    finalizeEnvironment();
    if (global.rank == 0)
        cout << "Completed OK: time = " << (int)((t1-t0)/60) << " m." << endl;
}
