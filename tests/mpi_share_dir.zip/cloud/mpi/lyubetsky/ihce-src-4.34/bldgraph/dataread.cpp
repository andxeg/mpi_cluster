// (c)2016,2017 Lev Rubanov, IITP RAS
//
// Module:      dataread.cpp
// Functions:   readToplevel readToplevel2 readHits sortEdges
//              dumpGraph lessWeight reverseComplement dumpQueue 
//              measureGraph writeHub writePartition checkSpecies 
//              clearSpeciesData rebuildSpeciesData

#include "bldgraph.h"

// Doesn't read the sequences themselves, if readseq=false
bool    readToplevel (bool readseq) {
    char buf[buflen];
    #ifdef BLDGRAPH_READTOPLEVEL
    cerr << "readToplevel\t\t\t\r";
    #endif
    int r = 0;      // next rank to assign

    for (int species_no = 0; species_no < global.nSpecies; species_no++) {
        Species& spec = global.species[species_no];

        // Open fasta file
        ifstream fasta;
        fasta.open(spec.fasta.c_str());
        if (!fasta.good()) {
            cout << "Cannot open " << spec.fasta << endl;
            return false;
        }

        // Looping over sequences
        int seq_no  = 1;
        int line_no = 1;
        fasta.getline(buf, buflen);
        string line(buf);
        if (fasta.bad()) {
            cout << "Cannot read input file " << spec.fasta << ", line=1" << endl;
            return false;
        }
        else if (line.substr(0,gbkintro.size()) == gbkintro) {     // read from Genbank
            Toplevel toplevel;
            toplevel.no = 1;
            istringstream is1(line.substr(gbkintro.size()));
            is1 >> toplevel.id >> toplevel.len;
            if (readseq) {
                while (!fasta.eof()) {      // skip everything until ORIGIN
                    fasta.getline(buf, buflen);
                    if (fasta.eof()) break;
                    line_no++;
                    line.assign(buf);
                    if (line.substr(0,gbkorigin.size()) == gbkorigin) break;
                }
                while (!fasta.eof()) {
                    fasta.getline(buf, buflen);
                    if (fasta.eof()) break;
                    line.assign(buf);
                    if (line.substr(0,gbkend.size()) == gbkend) break;
                    // Process sequence
                    istringstream iss(line);
                    int n;
                    iss >> n;   // position
                    for (n = 0; n < gbkgroups; n++) {
                        string group;
                        iss >> group;
                        if (iss.fail()) break;
                        for (int i=0; i < (int)group.size(); i++)
                            group[i] = toupper(group[i], locale::classic());
                        toplevel.seq.append(group);
                    }
                }
                if ((int)toplevel.seq.size() != toplevel.len) {
                    cout << "Sequence length mismatch in " << spec.fasta << ": " 
                        << toplevel.seq.size() << " vs " << toplevel.len << endl;
                }
            }

            toplevel.rank = r++;
            r %= global.size;

            spec.toplevels.push_back(toplevel);
            spec.tlmap.insert(IIpair(toplevel.no, spec.nToplevels++));
        }
        else if (buf[0] != '>') {
            cout << "Invalid heading: species_no=" << species_no
                << " line=" << line_no << endl;
            return false;
        }
        else {              // read lines from fasta
            for ( ; fasta.good(); ) {
                #ifdef BLDGRAPH_READTOPLEVEL
                if (milestone != 0 && line_no % milestone == 1)
                    cerr << line_no - 1 << "\t\t\t\r";
                #endif
                Toplevel toplevel;
                toplevel.no  = seq_no;
                toplevel.id  = getSequenceName(line);
                toplevel.len = 0;

                while (!fasta.eof()) {
                    fasta.get(buf, buflen, '\n');
                    if (fasta.eof()) break;
                    if (fasta.fail()) {
                        fasta.clear();
                        char newline = fasta.get();     // extract \n
                        line_no++;
                        continue;
                    }
                    if (buf[0] == '>') {
                        char newline = fasta.get();     // extract \n
                        line_no++;
                        break;
                    }
                    string portion(buf);
                    string::size_type lastpos = portion.length() - 1;
                    if (portion[lastpos]=='\r' || portion[lastpos]=='\n')
                        portion.erase(lastpos);
                    toplevel.len += (int)portion.length();
                    if (readseq) {
                        for (int i=0; i < (int)portion.size(); i++)
                            portion[i] = toupper(portion[i], locale::classic());
                        toplevel.seq += portion;
                    }
                }

                toplevel.rank = r++;
                r %= global.size;

                spec.toplevels.push_back(toplevel);
                spec.tlmap.insert(IIpair(toplevel.no, spec.nToplevels++));
                seq_no++;
            }
        }
        fasta.close();
    }

    #ifdef BLDGRAPH_READTOPLEVEL
    if (milestone != 0)
        cerr << line_no - 1 << "\t\t\t\r";
    #endif
    return true;
}

bool    readHits(void) {
    double& t0 = global.t0;
    double  t1;
    bool rc = true;
    ifstream lst;
    ifstream hif;
    char buf[buflen];
    ofstream& dnf = global.dnf;
    #ifdef BLDGRAPH_READHITS
    cerr << "readHits\t\t\t\r";
    #endif
    int inerr = 0;

    lst.open(global.hits_dir.c_str());
    if (!lst.good()) {
        cout << "Cannot open " << global.hits_dir << endl;
        return false;
    }

    // Read file names
    for (int line_no = 1; lst.good(); line_no++) {
        lst.getline(buf, buflen, '\n');
        if (!lst.good()) break;
        string filename(buf);

        hif.open(buf);
        if (!hif.good()) {
            cout << "Cannot open " << filename << " in line " << line_no << endl;
            lst.close();
            return false;
        }

        // Read current file of hits
        global.nFiles++;
        __int64 totalHits = 0;  // this file counters
        int nHits = 0;
        int nNodes = 0;
        int nEdges = 0;
        int totalPower = 0;
        int hit_no = 0;
        for (; hif.good(); hit_no++) {
            #ifdef BLDGRAPH_READHITS
            if (milestone != 0 && hit_no % milestone == 0)
                cerr << filename << "  " << hit_no << " \t\r";
            #endif
            hif.getline(buf, buflen, '\n');
            if (!hif.good()) break;
            string line(buf);

            istringstream iss(line);
            Hit     hit;
            int     score;
            float   ratio;
            iss >> hit.species_no1 >> hit.seq_no1 >> hit.center1 >> hit.len1
                >> hit.species_no2 >> hit.seq_no2 >> hit.center2 >> hit.len2
                >> hit.strand2 >> score >> ratio;
            totalHits++;

            // Apply maxratio and minlen filters
            if (hit.len1 < global.minlen || hit.len2 < global.minlen || 
                ratio > global.maxratio) continue;

            int sp1 = -1;       // species_no1 mapping
            IIiter it = global.spmap.find(hit.species_no1);
            if (it == global.spmap.end()) continue;
            sp1 = it->second;
            Species& spec1 = global.species[sp1];

            int tl1 = -1;       // seq_no1 mapping
            it = spec1.tlmap.find(hit.seq_no1);
            if (it == spec1.tlmap.end()) continue;
            tl1 = it->second;

            int sp2 = -1;       // species_no2 mapping
            it = global.spmap.find(hit.species_no2);
            if (it == global.spmap.end()) continue;
            sp2 = it->second;
            Species& spec2 = global.species[sp2];

            int tl2 = -1;       // seq_no2 mapping
            it = spec2.tlmap.find(hit.seq_no2);
            if (it == spec2.tlmap.end()) continue;
            tl2 = it->second;

            if (global.rank == 0 && !global.hcecount.empty()) {
                global.HCE[sp1][sp2]++;
                global.HCE[sp2][sp1]++;
            }

            if (!global.dnodes.empty()) {
                for (int j = 0; j < (int)global.dnodes.size(); j++) {
                    DebugNode& dnode = global.dnodes[j];
                    if (dnode.sp == sp1 && dnode.tl == tl1 && abs(dnode.anchor-hit.center1) < global.common ||
                        dnode.sp == sp2 && dnode.tl == tl2 && abs(dnode.anchor-hit.center2) < global.common) {
                        dnf << "read" << tab << sp1 << tab << tl1 << tab << hit.center1 << tab << hit.len1 
                            << tab << sp2 << tab << tl2 << tab << hit.center2 << tab << hit.len2 << endl;
                        break;
                    }
                }
            }

            if (spec1.toplevels[tl1].rank == global.rank ||
                spec2.toplevels[tl2].rank == global.rank)
                    nHits++;
            else continue;

            #ifdef BLDGRAPH_FIXNEGPOS
            // Fix coordinates at negative strand (to be removed)
            if (hit.strand2 < 0)
                hit.center2 = 2*spec2.toplevels[tl2].len - hit.center2 + 2;
            #endif

            // Essential 0-based coordinates of current hit
            int begin1 = (hit.center1 - hit.len1 - 1) / 2;
            int end1 = begin1 + hit.len1 - 1;
            int begin2 = (hit.center2 - hit.len2 - 1) / 2;
            int end2 = begin2 + hit.len2 - 1;
            int anchor1 = (begin1 + end1) / 2;
            int anchor2 = (begin2 + end2) / 2;
            if (global.strand && hit.strand2 < 0) 
                anchor2 = -anchor2;

            // Create/change node with hit.center1 (on positive strand)
            if (spec1.toplevels[tl1].rank == global.rank) {
                Nmap& nodes = spec1.toplevels[tl1].nodes;
                Niter nit = nodes.find(anchor1);

                if (nit != nodes.end()) {       // Modify existing node
                    Node& node = nit->second;

                    // Create new edge from this node
                    Edge edge;
                    edge.rank   = spec2.toplevels[tl2].rank;
                    edge.sp     = sp2;
                    edge.tl     = tl2;
                    edge.anchor = anchor2;  // may be negative 
                    edge.len1   = hit.len1;
                    edge.off1   = (short)(begin1 - anchor1);
                    edge.len2   = hit.len2;
                    edge.off2   = (short)(begin2 - abs(anchor2));
                    node.edges.push_back(edge);
                    node.nEdges++;
                    nEdges++;
                    totalPower += edge.len1;
                    spec1.toplevels[tl1].nEdges++;

                    // Modify the node accordingly
                    if (begin1 > node.begin)    node.begin = begin1;    // intersection
                    if (end1   < node.end)      node.end   = end1;
                    if (begin1 < node.left)     node.left  = begin1;    // union
                    if (end1   > node.right)    node.right = end1;
                }
                else {                          // Create new node
                    Node node;
                    node.sp     = sp1;
                    node.tl     = tl1;
                    node.anchor = anchor1;  // always positive
                    node.left   = begin1;
                    node.right  = end1;
                    node.begin  = begin1;
                    node.end    = end1;
                    // Create new edge from this node
                    Edge edge;
                    edge.rank   = spec2.toplevels[tl2].rank;
                    edge.sp     = sp2;
                    edge.tl     = tl2;
                    edge.anchor = anchor2;  // may be negative
                    edge.len1   = hit.len1;
                    edge.off1   = (short)(begin1 - anchor1);
                    edge.len2   = hit.len2;
                    edge.off2   = (short)(begin2 - abs(anchor2));
                    node.edges.push_back(edge);
                    node.nEdges = 1;
                    nEdges++;
                    totalPower += edge.len1;
                    // Insert the node in the toplevel's map
                    pair <Niter, bool> inres =
                        nodes.insert(Npair(node.anchor, node));
                    if (!inres.second) {
                        cout << "Error " << ++inerr << " in hit " << hit_no+1 
                        << ": node " << sp1 << " " << tl1 << " " << node.anchor 
                        << " " << node.left << "(" << hit.len1 << ") exists" 
                        << endl; 
                        abortEnvironment(22);
                    }
                    spec1.toplevels[tl1].nNodes++;
                    spec1.toplevels[tl1].nEdges++;
                    nNodes++;
                }
            }

            // Create/change node with hit.center2 (on either strand)
            if (spec2.toplevels[tl2].rank == global.rank) {
                Nmap& nodes = spec2.toplevels[tl2].nodes;
                Niter nit = nodes.find(anchor2);

                if (nit != nodes.end()) {       // Modify existing node
                    Node& node = nit->second;

                    // Create new edge from this node
                    Edge edge;
                    edge.rank   = spec1.toplevels[tl1].rank;
                    edge.sp     = sp1;
                    edge.tl     = tl1;
                    edge.anchor = anchor1;  // always positive
                    edge.len1   = hit.len2;
                    edge.off1   = (short)(begin2 - abs(anchor2));
                    edge.len2   = hit.len1;
                    edge.off2   = (short)(begin1 - anchor1);
                    node.edges.push_back(edge);
                    node.nEdges++;
                    nEdges++;
                    totalPower += edge.len1;
                    spec2.toplevels[tl2].nEdges++;

                    // Modify the node accordingly
                    if (begin2 > node.begin)    node.begin = begin2;    // intersection
                    if (end2   < node.end)      node.end   = end2;
                    if (begin2 < node.left)     node.left  = begin2;    // union
                    if (end2   > node.right)    node.right = end2;
                }
                else {                          // Create new node
                    Node node;
                    node.sp     = sp2;
                    node.tl     = tl2;
                    node.anchor = anchor2;  // may be negative
                    node.left   = begin2;
                    node.right  = end2;
                    node.begin  = begin2;
                    node.end    = end2;
                    // Create new edge from this node
                    Edge edge;
                    edge.rank   = spec1.toplevels[tl1].rank;
                    edge.sp     = sp1;
                    edge.tl     = tl1;
                    edge.anchor = anchor1;  // always positive
                    edge.len1   = hit.len2;
                    edge.off1   = (short)(begin2 - abs(anchor2));
                    edge.len2   = hit.len1;
                    edge.off2   = (short)(begin1 - anchor1);
                    node.edges.push_back(edge);
                    node.nEdges = 1;
                    nEdges++;
                    totalPower += edge.len1;
                    // Insert the node in the toplevel's map
                    pair <Niter, bool> inres =
                        nodes.insert(Npair(node.anchor, node));
                    if (!inres.second) {
                        cout << "Error " << ++inerr << " in hit " << hit_no+1 
                        << ": node " << sp2 << " " << tl2 << " " << node.anchor 
                        << " " << node.left << "(" << hit.len2 << ") exists" 
                        << endl; 
                        abortEnvironment(23);
                    }
                    spec2.toplevels[tl2].nNodes++;
                    spec2.toplevels[tl2].nEdges++;
                    nNodes++;
                }
            }
        }       // next hit

        t1 = getTimer();
        cout << (int)((t1-t0)/60) << " m: " << filename << " hits=" << nHits 
            << "/" << totalHits << " nodes=" << nNodes << " edges=" << nEdges 
            << " power=" << totalPower << endl;
        
        global.totalHits += totalHits;
        global.nHits     += nHits;
        global.nNodes    += nNodes;
        global.nEdges    += nEdges;
        global.totalPower += totalPower;
        hif.clear();
        hif.close();
    }       // next file in list

    lst.close();
    #ifdef BLDGRAPH_READHITS
    if (milestone != 0)
        cerr << endl;
    #endif
    return rc;
}

// Sort node's edges by target: species, toplevel, anchor+off, len
void    sortEdges (void) {
    // Loop over relevant species
    for (int sp = 0; sp < global.nSpecies; sp++) {
        Species& species = global.species[sp];

        // Loop over toplevel sequences
        for (int tl = 0; tl < species.nToplevels; tl++) {
            Toplevel& toplevel = species.toplevels[tl];
            if (toplevel.rank != global.rank) continue;

            // Loop over nodes
            Niter nit = toplevel.nodes.begin();
            for ( ; nit != toplevel.nodes.end(); nit++) {
                Node& node = nit->second;
                sort(node.edges.begin(), node.edges.end());     // operator<
            }   // next node
        }   // next toplevel
    }   // next species
}

// mode: dg_normal/dg_sequence/dg_element/dg_union/dg_final
//  dg_final is a special format for writing hub&stars files
// see dumpGraphMode enum in bldgraph.h
void    dumpGraph (int mode) {
    static int loop = -1;
    #ifdef BLDGRAPH_DUMP
    if ((mode & dg_final) == 0)
        cerr << "dumpGraph #" << ++loop << "\t\t\t\r";
    else {
        cerr << "dumpGraph\t\t\t\r";
    }
    #endif
    if ((mode & dg_final) != 0) {
        //mode |= dg_element | dg_union;
        //mode &= ~dg_sequence;
        mode &= ~(dg_sequence | dg_element | dg_union);
    }

    // Dump all-species table
    if (global.rank == 0 && loop < 1) {
        string fn = global.dump_dir + "species.txt";
        ofstream dsp(fn.c_str());
        if (dsp.bad() || dsp.fail())
            cout << "Cannot dump to " << fn << endl;
        else {
            dsp << "#\tCode\tID\tOrganism\tnToplevels" << endl;
            for (int n = 0; n < global.nSpecies; n++) {
                Species& spn = global.species[n];
                dsp << n << tab << spn.no << tab << spn.id << tab 
                    << spn.name << tab << spn.nToplevels << endl;
            }
            dsp.clear();
            dsp.close();
        }
    }

    // Dump relevant species detail, per rank
    for (int n = 0; n < global.nSpecies; n++) {
        Species& spn = global.species[n];

        // Number dump sections starting from 0th toplevel
        int section = (global.size - spn.toplevels.front().rank + global.rank) % global.size;
    
        // Stream dsp for node & edge details
        ostringstream oss;
        oss << global.dump_dir << n << "." << section;
        if ((mode & dg_final) == 0) oss << ".#" << loop;
        oss << ".txt";
        ofstream dsp(oss.str().c_str());
        if (dsp.bad() || dsp.fail()) {
            cout << "Cannot dump to " << oss.str() << endl;
            continue;
        }

        // Stream dst for toplevel seq details
        ostringstream ost;
        ost << global.dump_dir << "t" << n << "." << section;
        if ((mode & dg_final) == 0) ost << ".#" << loop;
        ost << ".txt";
        ofstream dst(ost.str().c_str());
        if (dst.bad() || dst.fail()) {
            cout << "Cannot dump to " << ost.str() << endl;
            continue;
        }

        // Toplevel file heading
        dst << "#\tCode\tID\tLength\tnNodes\tnEdges";
        if ((mode & dg_sequence) != 0) dst << "\tSequence";
        dst << endl;

        for (int m = 0; m < spn.nToplevels; m++) {
            Toplevel& tlm = spn.toplevels[m];
            if (tlm.rank != global.rank) continue;

            // Toplevel file record
            dst << m << tab << tlm.no << tab << tlm.id << tab 
                << tlm.len << tab << tlm.nNodes << tab << tlm.nEdges;
            if ((mode & dg_sequence) != 0) dst << tab << tlm.seq;
            dst << endl;

            // Toplevel heading in main (node&edge) file
            dsp << "#\tCode\tID\tLength\tnNodes\tnEdges";
            if ((mode & dg_sequence) != 0) dsp << "\tSequence";
            dsp << endl;
            // Toplevel record in main file
            dsp << m << tab << tlm.no << tab << tlm.id << tab 
                << tlm.len << tab << tlm.nNodes << tab << tlm.nEdges;
            if ((mode & dg_sequence) != 0) dsp << tab << tlm.seq;
            dsp << endl;

            // Nodes heading in main file
            dsp << "no.\tSpecies\tToplvl\tAnchor\tLeft/To\tLen\tBegin/F"
                "\tLen\tnEdges/e";
            if ((mode & dg_element) != 0 && (mode & dg_union) == 0)
                dsp << "\tElement";
            else if ((mode & dg_element) != 0 && (mode & dg_union) != 0)
                dsp << "\tUnion & ELEMENT";
            else if ((mode & dg_element) == 0 && (mode & dg_union) != 0)
                dsp << "\tUnion";
            dsp << endl;

            Niter nit  = tlm.nodes.begin();
            for (int node_no = 1; nit != tlm.nodes.end(); nit++) {
                #ifdef BLDGRAPH_DUMP
                if (milestone != 0 && node_no % milestone == 1)
                    cerr << n << " " << m << " " << node_no - 1 << "\t\t\t\r";
                #endif
                int anchor = nit->first;
                Node& node = nit->second;

                // Print out the node itself
                if (node.nEdges < 0)        // dummy (relocated) node
                    dsp << "mapped to\t" << node.sp << tab << tab;
                else                        // regular node
                    dsp << node_no << tab << n << tab << m << tab; 
                dsp << anchor << tab << node.left << tab << node.right-node.left+1 
                    << tab << node.begin << tab << node.end-node.begin+1 
                    << tab << node.nEdges;

                if ((mode & dg_element) != 0 && (mode & dg_union) == 0)
                    dsp << tab << reverseComplement
                    ( tlm.seq.substr(node.begin, node.end-node.begin+1), anchor );
                else if ((mode & dg_element) == 0 && (mode & dg_union) != 0)
                    dsp << tab << reverseComplement
                    ( tlm.seq.substr(node.left, node.right-node.left+1), anchor );
                else if ((mode & dg_element) != 0 && (mode & dg_union) != 0) {
                    string s = reverseComplement(
                        tlm.seq.substr(node.left, node.right-node.left+1), anchor);
                    for (int i = 0; i < node.begin-node.left; i++) 
                        s[i] = tolower(s[i], locale::classic());
                    for (int i = node.end-node.left+1; i <= node.right-node.left; i++)
                        s[i] = tolower(s[i], locale::classic());
                    dsp << tab << s;
                }
                dsp << endl;

                // Print out incident edges
                if (node.nEdges < 0) continue;
                if ((mode & dg_final) != 0) // Sort edges by len/sp/tl/anchor+off2
                    sort(node.edges.begin(), node.edges.end(), lessWeight);

                for (int edge_no = 0; edge_no < (int)node.edges.size(); edge_no++) {
                    Edge& edge = node.edges[edge_no];

                    dsp << tab << edge.sp << tab << edge.tl << tab << edge.anchor
                        << tab << abs(edge.anchor)+edge.off2 << tab << edge.len2 
                        << tab << abs(anchor)+edge.off1 << tab << edge.len1 
                        << tab << edge_no+1; 

                    if ((mode & dg_final) != 0) {
                        int strand = 0;
                        if (global.strand) strand = edge.anchor<0 ? -1 : 1;
                        dsp << tab << strand;
                    }
                    else {
                        Toplevel& tt = global.species[edge.sp].toplevels[edge.tl];
                        string s = tt.seq.substr(abs(edge.anchor)+edge.off2, edge.len2);
                        dsp << tab << reverseComplement(s, edge.anchor );
                    }
                    dsp << endl;
                }       // next edge (edge_no)
                node_no++;
            }       // next node (node_no & nit)
        }       // next toplevel (m)

        #ifdef BLDGRAPH_DUMP
        if (milestone != 0)
            cerr << "\t\t\t\t\t\r" << endl;
        #endif
        dst.clear();
        dst.close();
        dsp.clear();
        dsp.close();
    }       // next species (n)
}

// Predicate to re-sort edges by FROM length
bool    lessWeight (const Edge& e1, const Edge& e2) {
    if (e1.len1 == e2.len1) {
        if (e1.sp == e2.sp) {
            if (e1.tl == e2.tl) {
                if (e1.anchor<0 && e2.anchor>0) return true;
                if (e1.anchor>0 && e2.anchor<0) return false;
                return abs(e1.anchor)+e1.off2 < abs(e2.anchor)+e2.off2;
            }
            return e1.tl < e2.tl;
        }
        return e1.sp < e2.sp;
    }
    return e1.len1 < e2.len1;
}

string& reverseComplement(const string& str, int strand) {
    static char CBT[256];
    static bool init = true;
    static string result;

    #ifndef BLDGRAPH_REVCOMPL
    result = str;
    return result;
    #endif

    if (init) {
        init = false;
        for (int k = 0; k < 256; k++)
            CBT[k] = 'N';
        CBT['A'] = 'T'; CBT['a'] = 'T';
        CBT['C'] = 'G'; CBT['c'] = 'G';
        CBT['G'] = 'C'; CBT['g'] = 'C';
        CBT['T'] = 'A'; CBT['t'] = 'A';
        CBT['R'] = 'Y'; CBT['r'] = 'Y';
        CBT['Y'] = 'R'; CBT['y'] = 'R';
        //CBT['N'] = 'N'; CBT['n'] = 'N';
    }

    // return source string for positive strand
    if (strand > 0) {
        result = str;
        return result;
    }

    // convert str to result for negative strand
    result.clear();
    for (int i = (int)str.size() - 1; i >= 0; i--)
        result += CBT[str[i]];
    return result;
}

#ifdef BLDGRAPH_DUMPQUEUE
// abs(serial) will be appended to the filename
// if serial<0 the queue will print in reverse order
void    dumpQueue (vector <vector <Queue> >& queue, int serial) {
    cerr << "dumpQueue " << serial << "\t\t\t\r";
    for (int k = 0; k < global.size; k++) {
        if (queue[k].empty()) continue;
        ostringstream oss;
        oss << global.dump_dir << "q" << global.rank << "." << k 
            << "#" << abs(serial) << ".txt";
        ofstream dsq(oss.str().c_str());
        if (dsq.bad() || dsq.fail()) {
            cout << "Cannot dump to " << oss.str() << endl;
            continue;
        }

        dsq << "fSp\tfTl\tfAnchor\tfOff\tfLen\tSp\tTl\tAnchor\tOff\tLen" << endl;
        if (serial >= 0) {
            for (int i = 0; i < (int)queue[k].size(); i++) {
                Queue& q = queue[k][i];
                dsq << q.fromsp << tab << q.fromtl << tab << q.fromanchor << tab
                    << showpos << q.fromoff << noshowpos << tab << q.fromlen 
                    << tab << q.sp << tab << q.tl << tab << q.anchor << tab 
                    << showpos << q.off << noshowpos << tab << q.len << endl;
            }
        }
        else {
            for (int i = (int)queue[k].size()-1; i >= 0; i--) {
                Queue& q = queue[k][i];
                dsq << q.fromsp << tab << q.fromtl << tab << q.fromanchor << tab
                    << showpos << q.fromoff << noshowpos << tab << q.fromlen 
                    << tab << q.sp << tab << q.tl << tab << q.anchor << tab 
                    << showpos << q.off << noshowpos << tab << q.len << endl;
            }
        }

        dsq.clear();
        dsq.close();
    }
}
#endif

void    measureGraph(void) {
    __int64 nNodes    = 0;      // Overall graph
    __int64 nEdges    = 0;      // Overall graph
    __int64 nDummy    = 0;      // Overall dummy nodes
    __int64 Power = 0;          // Overall graph

    int minNodes  = numeric_limits<int>::max( );    // Over graph subparts
    int minEdges  = numeric_limits<int>::max( );    // Over graph subparts
    int minDegree = numeric_limits<int>::max( );    // Over all nodes

    int maxNodes  = 0;          // Over graph subparts
    int maxEdges  = 0;          // Over graph subparts
    int maxDegree = 0;          // Over all nodes

    int* partNodes = new int [global.nSpecies];     // per species
    int* partEdges = new int [global.nSpecies];     // per species

    for (int n = 0; n < global.nSpecies; n++) {
        Species& spn = global.species[n];

        partNodes[n] = 0;
        partEdges[n] = 0;
        for (int m = 0; m < spn.nToplevels; m++) {
            Toplevel& tlm = spn.toplevels[m];
            if (tlm.nNodes == 0 || tlm.rank != global.rank) continue;

            nNodes += tlm.nNodes;
            if (tlm.nNodes < minNodes) minNodes = tlm.nNodes;
            if (tlm.nNodes > maxNodes) maxNodes = tlm.nNodes;

            nEdges += tlm.nEdges;
            if (tlm.nEdges < minEdges) minEdges = tlm.nEdges;
            if (tlm.nEdges > maxEdges) maxEdges = tlm.nEdges;

            partNodes[n] += tlm.nNodes;
            partEdges[n] += tlm.nEdges;

            Niter nit = tlm.nodes.begin();
            for (int node_no = 1; nit != tlm.nodes.end(); nit++,node_no++) {
                Node& node = nit->second;
                if (node.nEdges < 0) {
                    nDummy++;
                    continue;
                }
                if (node.nEdges < minDegree) minDegree = node.nEdges;
                if (node.nEdges > maxDegree) maxDegree = node.nEdges;

                for (int edge_no = 0; edge_no < (int)node.edges.size(); edge_no++) {
                    Edge& edge = node.edges[edge_no];
                    Power += edge.len1;
                }   // next edge
            }   // next node
        }   // next toplevel sequence
    }   // next species

    #ifdef BLDGRAPHMPI
    if (global.undermpi) {
        __int64 sendint64[4] = { nNodes, nEdges, nDummy, Power };
        __int64 recvint64[4];
        MPI_Reduce(sendint64, recvint64, 4, MPI_LONG_LONG_INT, MPI_SUM, 0, MPI_COMM_WORLD);
        if (global.rank == 0) {
            nNodes = recvint64[0];
            nEdges = recvint64[1];
            nDummy = recvint64[2];
            Power  = recvint64[3];
        }

        int sminint[3] = { minNodes, minEdges, minDegree };
        int recvint[3];
        MPI_Reduce(sminint, recvint, 3, MPI_INT, MPI_MIN, 0, MPI_COMM_WORLD);
        if (global.rank == 0) {
            minNodes  = recvint[0]; 
            minEdges  = recvint[1]; 
            minDegree = recvint[2];
        }

        int smaxint[3] = { maxNodes, maxEdges, maxDegree };
        MPI_Reduce(smaxint, recvint, 3, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);
        if (global.rank == 0) {
            maxNodes  = recvint[0]; 
            maxEdges  = recvint[1]; 
            maxDegree = recvint[2];
        }

        int* snecount = new int [2*global.nSpecies];
        int* rnecount = new int [2*global.nSpecies];
        int k = 0;
        for (int i = 0; i < global.nSpecies; i++, k++)
            snecount[k] = partNodes[i];
        for (int i = 0; i < global.nSpecies; i++, k++)
            snecount[k] = partEdges[i];
        MPI_Reduce(snecount, rnecount, 2*global.nSpecies, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
        if (global.rank == 0) {
            k = 0;
            for (int i = 0; i < global.nSpecies; i++, k++)
                partNodes[i] = rnecount[k];
            for (int i = 0; i < global.nSpecies; i++, k++)
                partEdges[i] = rnecount[k];
        }
        delete [] snecount;
        delete [] rnecount;
    }
    #endif

    if (global.rank == 0) {
        cout << "Graph totals: nodes=" << nNodes;
        if (nDummy > 0) cout << " + dummy=" << nDummy; 
        cout << " edges=" << nEdges << " power="
            << Power << " degree=" << nEdges/nNodes << "(" << minDegree << "..."
            << maxDegree << ")" << endl;
        int nToplevels = 0;
        for (int n = 0; n < global.nSpecies; n++) {
            Species& spn = global.species[n];
            nToplevels += spn.nToplevels;
            cout << spn.id << ": nodes=" << partNodes[n] << " edges=" << partEdges[n] << endl;
        }
        cout << "Sequences: count=" << nToplevels << " nodes=" << nNodes/nToplevels
            << "(" << minNodes << "..." << maxNodes << ") edges=" << nEdges/nToplevels
            << "(" << minEdges << "..." << maxEdges << ")" << endl;
    }

    delete [] partNodes;
    delete [] partEdges;
}

#pragma warning(disable : 4996)
// Return total number of edges written or errorcode
unsigned int    writePartition (int n) {
    unsigned total = 0;     // total edges
    char buf[buflen];
    Species& spec = global.species[n];
    Toplevel& btpl = spec.toplevels.back();
    int nNodes = btpl.firstnode + btpl.nNodes;   // 2ndary use of rank

    ofstream starfile;
    string starname = global.starname;
    string::size_type pos = starname.find('*');
    if (pos == string::npos) {
        starname.insert(0, 1, '*');
        pos = 0; 
    }
    starname.replace(pos, 1, spec.id);
    starfile.open(starname.c_str(), ios_base::out | ios_base::binary);
    if (starfile.fail() || starfile.bad()) {
        cout << "Can't create star file " << starname << endl;
        return errorcode;
    }

    // Open dump file sections
    ifstream *dmp = new ifstream [global.usedump];
    for (int m = 0; m < global.usedump; m++) {
        ostringstream oss;
        oss << global.dump_dir << n << "." << m << ".txt";
        dmp[m].open(oss.str().c_str());
        if (dmp[m].bad() || dmp[m].fail()) {
            cout << "Can't open dump file " << oss.str() << endl;
            return errorcode;
        }
    }

    // Allocate and fill stars file header
    int headlen = (int)sizeof(StarFileHeader) + (nNodes-1) * sizeof(__int64);
    char *hdrbuf = new char [headlen];
    StarFileHeader *hdr = (StarFileHeader*) hdrbuf;

    string sig = "STF";
    sig.copy(hdr->sig, 3);
    hdr->sig[3] = 0;
    hdr->specno = n;
    hdr->headlen = headlen;
    hdr->nstars = nNodes;

    __int64 offset = headlen;
    int tot_nodes = 0;
    int tl;
    for (tl = 0; tl < spec.nToplevels; ) {      // loop over toplevels
        int m;                                  // loop over dump files
        for (m = 0; m < global.usedump && tl < spec.nToplevels; m++) {
            Toplevel& toplevel = spec.toplevels[tl];
            // Read toplevel heading
            dmp[m].getline(buf, buflen, '\n');
            if (!dmp[m].good()) break;      // eof/err found
            if (buf[0] != '#') {            // format error
                cout << "Toplevel heading error: sp=" << n << " tl=" << tl
                    << " m=" << m << endl;
                return errorcode;
            }
            
            // Read toplevel line
            dmp[m].getline(buf, buflen, '\n');          
            if (!dmp[m].good()) break;      // eof/err found

            string tlinfo(buf);
            istringstream iss(tlinfo);
            int num, code, len, nn, ne;
            string id;
            iss >> num >> code >> id >> len >> nn >> ne;
            if (num != tl || code != toplevel.no || id != toplevel.id ||
                len != (int)toplevel.len || nn != toplevel.nNodes ||
                ne   != toplevel.nEdges) {
                cout << "Toplevel line error: sp=" << n << " tl=" << tl
                    << " m=" << m << endl;
                return errorcode;
            }
            
            // Read node heading
            dmp[m].getline(buf, buflen, '\n');
            if (!dmp[m].good()) break;      // eof/err found
            
            // Loop over nodes of current toplevel
            Niter nit = toplevel.nodes.begin();
            int node_no = 0;
            for ( ; nit != toplevel.nodes.end(); nit++, node_no++) {
                int   curc = nit->first;      // current node's anchor
                Node& curn = nit->second;     // current node
                Node node;          // Place to read node info from dump
                dmp[m].getline(buf, buflen, '\n');
                if (!dmp[m].good()) break;                  // eof/err

                string nodeinfo(buf);
                istringstream isn(nodeinfo);
                int lenU, lenI;
                isn >> num >> node.sp >> node.tl >> node.anchor >> node.left
                    >> lenU >> node.begin >> lenI >> node.nEdges;
                node.right = node.left + lenU - 1;
                node.end = node.begin + lenI - 1;
                if (curn.anchor != toplevel.firstnode + node_no ||
                    node.anchor != curc || 
                    node.sp != curn.sp || node.tl != curn.tl || 
                    node.left != curn.left || node.right != curn.right ||
                    node.begin != curn.begin || node.end != curn.end ||
                    node.nEdges != curn.nEdges) {
                    cout << "Node line error: sp=" << node.sp << "/" << curn.sp 
                        << " tl=" << node.tl << "/" << curn.tl << " m=" << m
                        << " #=" << num << "/" << node_no+1 << endl;
                    return errorcode;
                }

                // Loop over edges of current node
                int edge_no;
                for (edge_no = 0; edge_no < curn.nEdges; edge_no++) {
                    dmp[m].getline(buf, buflen, '\n');      // read edge info
                    if (!dmp[m].good()) break;                  // eof/err

                    Edge edge;
                    string edgeinfo(buf);
                    istringstream ise(edgeinfo);
                    int topos, frompos;
                    ise >> edge.sp >> edge.tl >> edge.anchor >> topos 
                        >> edge.len2 >> frompos >> edge.len1 >> num;
                    edge.off1 = frompos - abs(curc);
                    edge.off2 = topos - abs(edge.anchor);
                    if (num != edge_no+1) {
                        cout << "Edge " << edge_no+1 << " error from: sp=" 
                            << curn.sp << " tl=" << curn.tl << " anchor=" 
                            << curc << " #=" << node_no+1 << "(" 
                            << curn.anchor+1 << ") m=" << m << endl;
                        return errorcode;
                    }
                    curn.edges.push_back(edge);
                }
                if (edge_no < curn.nEdges) {
                    cout << "Edge " << edge_no+1 << " error from: sp=" 
                        << curn.sp << " tl=" << curn.tl << " anchor=" 
                        << curc << " #=" << node_no+1 << "(" 
                        << curn.anchor+1 << ") m=" << m << endl;
                    return errorcode;
                }

                // Sort edges (to handle bugs or later changes in the dump sort order)
                sort(curn.edges.begin(), curn.edges.end(), lessWeight);

                int nrays = curn.nEdges;
                hdr->offset[tot_nodes++] = offset;
                offset += (__int64)sizeof(Star) + 
                    (nrays > 0 ? (nrays-1)*sizeof(Ray) : 0);

            }       // next node
            if (node_no < toplevel.nNodes) {
                cout << "Node " << node_no+1 << " error: sp=" << n 
                    << " tl=" << tl << " m=" << m << endl;
                return errorcode;
            }
            tl++;
        }       // next section (m)
        if (m >= global.usedump) continue;  // next slice
        if (tl >= spec.nToplevels) break;   // all toplevels done
        if (dmp[m].eof()) break;
        cout << "Error reading " << n << "." << m << ".txt" << endl;
        return errorcode;
    }       // next slice of toplevels
    if (tl < spec.nToplevels) {
        cout << "Error reading toplevel: sp=" << n << " tl=" << tl << endl;
        return errorcode;
    }
    hdr->filelen = offset;

    // Close dump files
    for (int m = 0; m < global.usedump; m++) {
        dmp[m].clear();
        dmp[m].close();
    }
    delete [] dmp;

    // Write stars file header
    starfile.write((char*)hdr, headlen);
    if (!starfile.good())
        return errorcode;

    // Write stars in turn
    tot_nodes = 0;
    for (int tl = 0; tl < (int)spec.toplevels.size(); tl++) {
        Toplevel& toplevel = spec.toplevels[tl];
        Niter nit = toplevel.nodes.begin();
        for ( ; nit != toplevel.nodes.end(); nit++, tot_nodes++) {
            Node& node = nit->second;
            int nrays    = node.nEdges;
            int starlen  = (int)sizeof(Star) + 
                (nrays > 0 ? (nrays-1)*sizeof(Ray) : 0);
            int *starbuf = new int [starlen/sizeof(int)+1];
            Star *star   = (Star*) starbuf;
            star->nrays  = nrays;

            // Fill star's rays
            for (int k = 0; k < nrays; k++) {
                Ray& ray    = star->ray[k];
                Edge& edge  = node.edges[k];
                #ifdef BLDGRAPH_WRITESTAR
                if (milestone != 0 && total % milestone == 0) {
                    cerr << left << setw(global.spidw) << spec.id << " : " 
                        << tl << " " << tot_nodes << " " << k << " \t\r";
                }
                #endif
                ray.specno2 = edge.sp;
                Toplevel& toplevel2 = global.species[edge.sp].toplevels[edge.tl];
                Niter nit2 = toplevel2.nodes.find(edge.anchor);
                if (nit2 == toplevel2.nodes.end()) {
                    cout << "Target node not found: (" << n << " " << tl << " "
                        << nit->first << "=#" << node.anchor << ") -> (" 
                        << edge.sp << " " << edge.tl << " " << edge.anchor
                        << ")" << endl;
                    return errorcode;
                }
                ray.nodeno2 = (int)nit2->second.anchor;
                ray.weight  = (float)edge.len1;
                total++;
            }       // next ray

            // Write star
            starfile.write((char*)star, starlen);
            if(!starfile.good())
                return errorcode;
            delete [] starbuf;
        }       // next node
    }       // next toplevel

    starfile.close();
    delete [] hdrbuf;
    return total;
}

#pragma warning(disable : 4996)
bool    writeHub (void) {
    char buf[buflen];
    ofstream hubfile;
    hubfile.open(global.hubname.c_str(), ios_base::out | ios_base::binary);
    if (hubfile.fail()) {
        cout << "Can't create hub file " << global.hubname << endl;
        return false;
    }

    // Allocate and fill hub file header
    int headlen = (int)sizeof(HubFileHeader) + (global.nSpecies - 1)*sizeof(__int64);
    char *hdrbuf = new char [headlen];
    HubFileHeader *hdr = (HubFileHeader*) hdrbuf;

    string sig = global.strand ? "HUD" : "HUB";
    sig.copy(hdr->sig, 3);
    hdr->sig[3] = 0;
    hdr->nspecies = global.nSpecies;

    __int64 offset = headlen;
    // Advance calculate nodes over all species
    for (int sp = 0; sp < global.nSpecies; sp++) {
        Species& spec = global.species[sp];
        int nelem = 0; 
        for (int tl = 0; tl < spec.nToplevels; tl++)
            nelem += spec.toplevels[tl].nNodes;

        hdr->offset[sp] = offset;
        offset += (__int64)sizeof(StripHeader) + 
            (__int64)(nelem-1)*sizeof(Element);
    }
    hdr->filelen = offset;

    // Write hub file header
    hubfile.write((char*)hdr, headlen);
    if (!hubfile.good())
        return false;
    delete [] hdrbuf;

    // Write strips in turn
    for (int sp = 0; sp < global.nSpecies; sp++) {
        Species& spec = global.species[sp];
        // Calculate nodes
        int nelem = 0; 
        for (int tl = 0; tl < spec.nToplevels; tl++)
            nelem += spec.toplevels[tl].nNodes;

        __int64 striplen = (__int64)sizeof(StripHeader) + 
            (__int64)(nelem-1)*sizeof(Element);
        char *stripbuf = new char [striplen];
        StripHeader *shdr = (StripHeader*) stripbuf;
        memset(shdr->specid, 0, specidsize);
        spec.id.copy(shdr->specid, specidsize-1);
        shdr->nelem = nelem;

        // Open dump file sections
        ifstream *dmp = new ifstream [global.usedump];
        for (int m = 0; m < global.usedump; m++) {
            ostringstream oss;
            oss << global.dump_dir << sp << "." << m << ".txt";
            dmp[m].open(oss.str().c_str());
            if (dmp[m].bad() || dmp[m].fail()) {
                cout << "Can't open dump file " << oss.str() << endl;
                return false;
            }
        }

        // Fill elements
        int elem = 0;
        int tl;
        for (tl = 0; tl < spec.nToplevels; ) {  // no tl++
            int m;                                  // loop over dump files
            for (m = 0; m < global.usedump && tl < spec.nToplevels; m++) {
                Toplevel& toplevel = spec.toplevels[tl];
                // Read toplevel heading
                dmp[m].getline(buf, buflen, '\n');
                if (!dmp[m].good()) break;      // eof/err found
                if (buf[0] != '#') {            // format error
                    cout << "Toplevel heading error: sp=" << sp << " tl=" << tl
                        << " m=" << m << endl;
                    return false;
                }

                // Read toplevel line
                dmp[m].getline(buf, buflen, '\n');
                if (!dmp[m].good()) break;      // eof/err found

                string tlinfo(buf);
                istringstream iss(tlinfo);
                int num, code, len, nn, ne;
                string id;
                iss >> num >> code >> id >> len >> nn >> ne;
                if (num != tl || code != toplevel.no || id != toplevel.id ||
                    len != (int)toplevel.len || nn != toplevel.nNodes ||
                    ne != toplevel.nEdges) {
                    cout << "Toplevel line error: sp=" << sp << " tl=" << tl
                        << " m=" << m << endl;
                    return false;
                }

                // Read node heading
                dmp[m].getline(buf, buflen, '\n');
                if (!dmp[m].good()) break;      // eof/err found

                // Loop over current toplevel nodes
                Niter nit = toplevel.nodes.begin();
                for ( ; nit != toplevel.nodes.end(); nit++,elem++) {
                    int   curc = nit->first;      // current node's anchor
                    Node& curn = nit->second;     // current node
                    Node node;          // Place to read node info from dump
                    dmp[m].getline(buf, buflen, '\n');
                    if (!dmp[m].good()) break;                  // eof/err

                    string nodeinfo(buf);
                    istringstream isn(nodeinfo);
                    int lenU, lenI;
                    //string seq;   // because final format assumed
                    isn >> num >> node.sp >> node.tl >> node.anchor >> node.left
                        >> lenU >> node.begin >> lenI >> node.nEdges;
                    node.right = node.left + lenU - 1;
                    node.end = node.begin + lenI - 1;
                    if (node.anchor != curc || curn.anchor != elem ||
                        node.sp != curn.sp || node.tl != curn.tl ||
                        node.left != curn.left || node.right != curn.right ||
                        node.begin != curn.begin || node.end != curn.end ||
                        node.nEdges != curn.nEdges) {
                        cout << "Node line error: sp=" << node.sp << "/" << curn.sp 
                            << " tl=" << node.tl << "/" << curn.tl << " m=" << m
                            << " #=" << num << "/" << elem+1-toplevel.firstnode << endl;
                        return false;
                    }

                    Element element;
                    element.tl      = node.tl;
                    element.ustart  = node.left + 1;
                    element.ulen    = lenU;
                    element.istart  = node.begin + 1;
                    element.ilen    = lenI;
                    element.strand  = !global.strand ? 0 : (curc<0 ? -1 : 1);
                    memcpy(&shdr->element[elem], &element, sizeof(Element));

                    //len = node.right - node.left + 1;
                    //ostringstream oss;
                    //oss << toplevel.id << tab << node.left+1 << tab << len << tab 
                    //    << (curc > 0 ? 1 : -1) << tab << seq;
                    //if (oss.str().size() >= elemsize) {
                    //    cout << spec.id << ": (" << toplevel.id << " " << curc << " " 
                    //        << len << ") needs elemsize " << oss.str().size() << endl;
                    //}
                    //memset(&shdr->element[elem][0], 0, elemsize);
                    //oss.str().copy(&shdr->element[elem][0], elemsize-1);

                    // Skip edge lines
                    int edge_no;
                    for (edge_no = 0; edge_no < curn.nEdges; edge_no++) {
                        dmp[m].getline(buf, buflen, '\n');      // read edge info
                        if (!dmp[m].good()) break;                  // eof/err
                    }
                    if (edge_no < curn.nEdges) {
                        cout << "Edge " << edge_no+1 << " error from: sp=" 
                            << curn.sp << " tl=" << curn.tl << " anchor=" 
                            << curc << " (#" << curn.anchor+1 << ") m=" << m << endl;
                        return false;
                    }
                }       // next node
                if (nit != toplevel.nodes.end()) {
                    cout << "Node " << nit->first << " error: sp=" << sp 
                        << " tl=" << tl << " m=" << m << endl;
                    return false;
                }
                tl++;
            }       // next section (m)
            if (m >= global.usedump) continue;  // next slice
            if (tl >= spec.nToplevels) break;   // all toplevels done
            if (dmp[m].eof()) break;
            cout << "Error reading " << sp << "." << m << ".txt" << endl;
            return false;
        }       // next slice of toplevels
        if (tl < spec.nToplevels) {
            cout << "Error reading toplevel: sp=" << sp << " tl=" << tl << endl;
            return false;
        }

        // Close dump files
        for (int m = 0; m < global.usedump; m++) {
            dmp[m].clear();
            dmp[m].close();
        }
        delete [] dmp;

        // Write strip
        hubfile.write((char*)shdr, striplen);
        if(!hubfile.good())
            return false;
        delete [] stripbuf;
    }

    hubfile.close();
    return true;
}

// Check dump\species.txt against global.species
bool    checkSpecies (void) {
    bool rc = true;
    char buf[buflen];
    //cerr << "checkSpecies\t\t\t\r";
    if (global.rank != 0) return true;
    string fn = global.dump_dir + "species.txt";
    ifstream dsp(fn.c_str());
    if (dsp.bad() || dsp.fail())
        cout << "Cannot open " << fn << endl;

    dsp.getline(buf, buflen, '\n');     // skip heading
    int species_no = 0;
    for (int line_no = 2; rc && dsp.good(); line_no++) {
        dsp.getline(buf, buflen, '\n');
        if (!dsp.good()) break;
        string line(buf);
        istringstream iss(line);
        int number, no;
        string id;
        iss >> number >> no >> id;
        if (number != species_no) {
            cout << "Number " << number << " out of order." << endl;
            rc = false;
        }
        if (no != global.species[number].no) {
            cout << "Code #" << number << " (" << no << ") mismatch." << endl;
            rc = false;
        }
        if (id != global.species[number].id) {
            cout << "ID #" << number << " (" << id << ") mismatch." << endl;
            rc = false;
        }
        species_no++;
    }
    if (species_no != global.nSpecies) {
        cout << "Invalid number of species: " << species_no << endl;
        rc = false;
    }

    dsp.clear();
    dsp.close();
    return rc;
}

void    clearSpeciesData (Species& spec) {
    for (int tl = 0; tl < (int)spec.toplevels.size(); tl++) {
        Toplevel& toplevel = spec.toplevels[tl];
        Niter nit = toplevel.nodes.begin();
        for ( ; nit != toplevel.nodes.end(); nit++) {
            Node& node = nit->second;
            node.edges.clear();
        }
        toplevel.nodes.clear();
    }
    spec.toplevels.clear();
    spec.tlmap.clear();
    spec.nToplevels = 0;
}

// Rebuild species/toplevels/nodes data (not edges!)
bool    rebuildSpeciesData (int sp) {
    char buf[buflen];
    Species& spec = global.species[sp];
    //cerr << "rebuildSpeciesData " << sp <<"\t\t\r";
    clearSpeciesData(spec);

    // Open dump t-file sections
    ifstream *dmp = new ifstream [global.usedump];
    for (int m = 0; m < global.usedump; m++) {
        ostringstream oss;
        oss << global.dump_dir << "t" << sp << "." << m << ".txt";
        dmp[m].open(oss.str().c_str());
        if (dmp[m].bad() || dmp[m].fail()) {
            cout << "Can't open dump file " << oss.str() << endl;
            return 0;
        }
        dmp[m].getline(buf, buflen, '\n');      // skip heading line
    }

    // Calculate nodes&edges and fill spn.toplevels
    int nNodes = 0;
    int nEdges = 0;
    int tl = 0;         // serial tl
    while (true) {      // loop over toplevels
        int m;
        for (m = 0; m < global.usedump; m++) {
            dmp[m].getline(buf, buflen, '\n');
            if (!dmp[m].good()) break;      // eof/err found

            string tlinfo(buf);
            istringstream iss(tlinfo);
            Toplevel toplevel;
            toplevel.firstnode = nNodes;
            int num;
            iss >> num >> toplevel.no >> toplevel.id >> toplevel.len 
                >> toplevel.nNodes >> toplevel.nEdges;
            if (num != tl) {
                cout << "Sp." << sp << ", toplevel " << num << " out of order (" 
                    << tl << " expected)." << endl;
                return false;
            }
            nNodes += toplevel.nNodes;
            nEdges += toplevel.nEdges;
            spec.toplevels.push_back(toplevel);
            spec.nToplevels++;
            tl++;
        }       // next t-file
        if (m >= global.usedump) continue;  // next slice
        if (dmp[m].eof()) break;
        cout << "Error reading t" << sp << "." << m << ".txt" << endl;
        return false;
    }

    // Close t-files
    for (int m = 0; m < global.usedump; m++) {
        dmp[m].clear();
        dmp[m].close();
    }

    // Open dump file sections
    for (int m = 0; m < global.usedump; m++) {
        ostringstream oss;
        oss << global.dump_dir << sp << "." << m << ".txt";
        dmp[m].open(oss.str().c_str());
        if (dmp[m].bad() || dmp[m].fail()) {
            cout << "Can't open dump file " << oss.str() << endl;
            return 0;
        }
    }
    // Gather nodes by toplevels
    for (tl = 0; tl < spec.nToplevels; ) {      // loop over toplevels
        int m;                                  // loop over dump files
        for (m = 0; m < global.usedump && tl < spec.nToplevels; m++) {
            Toplevel& toplevel = spec.toplevels[tl];
            // Read toplevel heading
            dmp[m].getline(buf, buflen, '\n');
            if (!dmp[m].good()) break;      // eof/err found
            if (buf[0] != '#') {            // format error
                cout << "Toplevel heading error: sp=" << sp << " tl=" << tl
                    << " m=" << m << endl;
                return 0;
            }

            // Read toplevel line
            dmp[m].getline(buf, buflen, '\n');
            if (!dmp[m].good()) break;      // eof/err found

            string tlinfo(buf);
            istringstream iss(tlinfo);
            int num, code, len, nn, ne;
            string id;
            iss >> num >> code >> id >> len >> nn >> ne;
            if (num != tl || code != toplevel.no || id != toplevel.id ||
                len != (int)toplevel.len || nn != toplevel.nNodes ||
                ne != toplevel.nEdges) {
                cout << "Toplevel line error: sp=" << sp << " tl=" << tl
                    << " m=" << m << endl;
                return 0;
            }

            // Read node heading
            dmp[m].getline(buf, buflen, '\n');
            if (!dmp[m].good()) break;      // eof/err found

            // Loop over current toplevel nodes
            int node_no;
            for (node_no = 0; node_no < toplevel.nNodes; node_no++) {
                Node node;          // Read node info
                dmp[m].getline(buf, buflen, '\n');
                if (!dmp[m].good()) break;      // eof/err found

                string nodeinfo(buf);
                istringstream isn(nodeinfo);
                int anchor, lenU, lenI;
                isn >> num >> node.sp >> node.tl >> anchor >> node.left 
                    >> lenU >> node.begin >> lenI >> node.nEdges;
                node.right = node.left + lenU - 1;
                node.end = node.begin + lenI - 1;
                if (num-1 != node_no || node.sp != sp || node.tl != tl) {
                    cout << "Node line error: sp=" << node.sp << "/" << sp 
                        << " tl=" << node.tl << "/" << tl << " m=" << m
                        << " #=" << num << "/" << node_no+1 << endl;
                    return false;
                }

                node.anchor = toplevel.firstnode + node_no;  // use anchor for node #
                toplevel.nodes.insert(Npair(anchor, node));

                // Skip edge lines
                int edge_no;
                for (edge_no = 0; edge_no < node.nEdges; edge_no++) {
                    dmp[m].getline(buf, buflen, '\n');
                    if (!dmp[m].good()) break;      // eof/err found
                }       // next edge

                if (edge_no < node.nEdges) {
                    cout << "Edge " << edge_no+1 << " error: sp=" << sp 
                        << " tl=" << tl << " anchor=" << anchor 
                        << " #=" << node_no+1 << "(" << node.anchor+1 
                        << ") m=" << m << endl;
                    return false;
                }
            }       // next node
            if (node_no < toplevel.nNodes) {
                cout << "Node " << node_no+1 << " error: sp" << sp 
                    << " tl=" << tl << " m=" << m << endl;
                return false;
            }
            tl++;
        }       // next section (m)
        if (m >= global.usedump) continue;  // next slice
        if (tl >= spec.nToplevels) break;   // all toplevels done
        if (dmp[m].eof()) break;
        cout << "Error reading " << sp << "." << m << ".txt" << endl;
        return false;
    }       // next slice of toplevels
    if (tl < spec.nToplevels) {
        cout << "Error reading toplevel: sp=" << sp << " tl=" << tl << endl;
        return false;
    }

    // Close dump files
    for (int m = 0; m < global.usedump; m++) {
        dmp[m].seekg(0, ios_base::beg);
        dmp[m].clear();
        dmp[m].close();
    }

    delete [] dmp;
    return true;
}

// Extract from fasta heading: gb | ref | everything
// Remove version no. if any
string  getSequenceName (string& line) {
    string::size_type pos, off = 1;
    pos = line.find("ref|", off);
    if (pos != string::npos)
        off = pos + 4;
    else {
        pos = line.find("gb|", off);
        if (pos != string::npos)
            off = pos + 3;
    }
    pos = line.find_first_of("|.", off);
    return line.substr(off, (pos==string::npos ? pos : pos-off));
}
