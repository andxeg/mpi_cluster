// (c)2016,2017 Lev Rubanov, IITP RAS
//
// Module:      config.cpp
// Functions:   showHelp parseArguments readConfig getKey getBool getInt getDouble
//              getString initEnvironment finalizeEnvironment abortEnvironment

#include <stdlib.h>
#include "pairhits.h"

// Static variables
static ofstream     logfs;                          // log file stream       
static streambuf*   logsb = 0;
static ofstream     errfs;                          // stderr file stream
static streambuf*   errsb = 0;
static bool     splitlog        = true;             // true: split log by branches
static string   config_file     = "config.ini";     // config file name
static string   logname         = "phs_log";        // log file name or prefix
static string   logext          = ".txt";           // log file extension
static string   errname         = "phs_err";        // err file name or prefix
static string   errext          = ".log";           // err file extension
static bool     log_specified   = false;            // log file specified in the command line
static bool     job_specified   = false;            // job path/ext specified in the cmd line 
static bool     fp_specified    = false;            // fastapath specified in the cmd line
static bool     res_specified   = false;            // result specified in the cmd line
static bool     app_specified   = false;            // append/rewrite specified in the cmd line
static bool     belt_present    = false;
static bool     scdel_present   = false;
static bool     scmis_present   = false;
static bool     keysize_present = false;
static bool     keystep_present = false;
static bool     minlen_present  = false;
static bool     freq_present    = false;
static bool     score_present   = false;
static bool     ratio_present   = false;
static bool     width_present   = false;
static bool     start_present   = false;
static bool     stop_present    = false;
static bool     minletter_present = false;

// Show short help on command line arguments
void    showHelp (void) {
    cout << "\nPairHits v." 
        #ifdef BLDGRAPHMPI
         << " (MPI)"
        #endif
         << version << " usage: [options] [config_file]\n"
         << "\nOptions:\n"
         << "-? (--help|?) view this help screen\n"
         << "-a (--append) append results to output files\n"
         << "-b (--belt=) max number of dels in succession | -1 [" << global.maxindel << "]\n"
         << "-c (--config=) config_file [" << config_file << "]\n"
         << "-d (--score_del=) score of indel [" << global.sc_indel / scale << "]\n"
         << "-e (--minletter=) XY different letters in word/key, 0=no check [" << global.minletter << "]\n"
         << "-f (--fastapath=) path or prefix of fasta files [" << global.fastapath << "]\n"
         << "-i (--score_mis=) score of mismatch [" << global.sc_mismatch / scale << "]\n"
         << "-j (--job=) path/file name of job files [" << global.jobpath 
            << "#" << global.jobext << "]\n"
         << "-k (--key=) identical key size [" << global.keysize << "]\n"
         << "-l (--length) min length of hit [" << global.minlen << "]\n"
        #ifdef PAIRHITSMPI
         << "-n (--nompi) prevent from using MPI\n"
        #endif
         << "-o (--log=) log file with # if split [" << logname 
            << (splitlog ? "#" : "") << logext << "]\n"
         << "-p (--step=) key selection step [" << global.keystep << "]\n"
         << "-q (--frequency) max key frequency | 0 [" << global.frequency << "]\n"
         << "-r (--result=) result file names [" << global.result 
            << "#" << global.resext << "]\n"
         << "-s (--score=) max score value [" << global.maxscore / scale << "]\n"
         << "-t (--start=) job to start from [" << global.start << "]\n"
         << "-u (--use=) max number of jobs to use [" << global.stop << "]\n"
         << "-w (--rewrite) rewrite output files with new results [default]\n"
         << "-y (--width=) decimal places of file_no | 0 [" << global.width << "]\n"
        #ifdef ZCOMPLEXITY
         << "-z (--ratio) max compression ratio | 0 [" << global.maxratio << "]\n"
        #endif
         << endl;
}

// Return false at argument error or help request
bool    parseArguments (int & argc, char** & argv) {
    if (argc <= 1)
        return true;
    int positional = 0;

    for (int i = 1; i < argc; i += 2) {
        char c = argv[i][0];
        string a(argv[i]);      // whole option or parameter
        char *p = 0;
        string b;               // next parameter

        // Help request encountered
        if (c == '?') {
            showHelp();
            return false;
        }

        // Parse other options
        if (c == '-' || c == '/') {     // -options
            c = argv[i][1];
            a.erase(0,1);

            if (i < argc-1) {
                p = argv[i+1];
                b.assign(argv[i+1]);
            }
            else {
                p = 0;
                b.clear();
            }
            istringstream iss(b);
            string::size_type pos;
            double dbl;

            switch (c) {
                case '?':               // -?
                    showHelp();
                    return false;
                    break;

                case '-': 
                case '/':                       // --options
                    a.erase(0,1);
                    b.clear();
                    pos = a.find_last_of('=');
                    if (pos != string::npos) {
                        b = a.substr(pos + 1);
                        a.erase(pos);
                    }
                    iss.str(b);

                    if (a == "help") {          // --help
                        showHelp();
                        return false;
                    }

                    else if (a == "append") {   // --append
                        app_specified = true;
                        global.append = true;
                    }

                    else if (a == "belt" ||     // --belt
                      a == "maxindel" || a == "serial_del") {
                        belt_present = true;
                        iss >> global.maxindel;
                    }

                    else if (a == "config") {   // --config=
                        config_file = b;
                    }

                    else if (a == "score_del"   // --score_del=
                      || a == "sc_indel") {
                         scdel_present = true;
                         iss >> dbl;
                         global.sc_indel = (int)(dbl * scale);
                    }

                    else if (a == "fastapath") { // --fastapath=
                        fp_specified = true;
                        global.fastapath = b;
                    }

                    else if (a == "score_mis"   // --score_mis=
                      || a == "sc_mismatch") {
                         scmis_present = true;
                         iss >> dbl;
                         global.sc_mismatch = (int)(dbl * scale);
                    }

                    else if (a == "job") {      // --job=
                        job_specified = true;
                        pos = b.find_last_of('#');
                        global.jobpath = b.substr(0, pos);
                        global.jobext = (pos != string::npos) ? b.substr(pos + 1) : "";
                    }

                    else if (a == "key" ||      // --key=
                      a == "keysize") {
                        keysize_present = true;
                        iss >> global.keysize;
                    }

                    else if (a == "length" ||   // --length=
                      a == "minlen") {
                        minlen_present = true;
                        iss >> global.minlen;
                    }

                    else if (a == "log") {      // --log=
                        log_specified = true;
                        pos = b.find_last_of('#');
                        splitlog = (pos != string::npos);
                        logname = b.substr(0, pos);
                        logext = (pos != string::npos) ? b.substr(pos + 1) : "";
                    }

                    else if (a == "minletter") {    // --minletter
                        minletter_present = true;
                        iss >> global.minletter;
                    }

                    else if (a == "nompi") {    // --nompi
                        global.undermpi = false;
                    }

                    else if (a == "step" ||     // --step=
                      a == "keystep") {
                        keystep_present = true;
                        iss >> global.keystep;
                    }

                    else if (a == "frequency" || a == "freq") { // --frequency=
                        freq_present = true;
                        iss >> global.frequency;
                    }

                    else if (a == "result") {   // --result=
                        res_specified = true;
                        pos = b.find_last_of('#');
                        global.result = b.substr(0, pos);
                        global.resext = (pos != string::npos) ? b.substr(pos + 1) : "";
                    }

                    else if (a == "score" ||    // --score=
                      a == "maxscore") {
                        score_present = true;
                        iss >> dbl;
                        global.maxscore = (int)(dbl * scale);
                    }

                    else if (a == "rewrite") {  // --rewrite
                        app_specified = true;
                        global.append = false;
                    }

                    else if (a == "ratio" ||    // --ratio=
                      a == "maxratio") {
                        ratio_present = true;
                        iss >> global.maxratio;
                    }

                    else if (a == "width") {    // --width=
                        width_present = true;
                        iss >> global.width;
                    }

                    else if (a == "start") {    // --start=
                        start_present = true;
                        iss >> global.start;
                    }

                    else if (a == "stop" || a == "use") {   // --stop|--use
                        stop_present = true;
                        iss >> global.stop;
                    }

                    else {
                        cout << "Unknown option --" << a << endl;
                        return false;
                    }
                    i--;    // since --option include value if any
                    break;

                case 'a':               // -a
                    app_specified = true;
                    global.append = true;
                    i--;
                    break;

                case 'b':               // -b
                    belt_present = true;
                    iss >> global.maxindel;
                    break;

                case 'c':               // -c
                    config_file = b;
                    break;

                case 'd':               // -d
                    scdel_present = true;
                    iss >> dbl;
                    global.sc_indel = (int)(dbl * scale);
                    break;

                case 'e':               // -e
                    minletter_present = true;
                    iss >> global.minletter;
                    break;

                case 'f':               // -f
                    fp_specified = true;
                    global.fastapath = b;
                    break;

                case 'i':               // -i
                    scmis_present = true;
                    iss >> dbl;
                    global.sc_mismatch = (int)(dbl * scale);
                    break;

                case 'j':               // -j
                    job_specified = true;
                    pos = b.find_last_of('#');
                    global.jobpath = b.substr(0, pos);
                    global.jobext = (pos != string::npos) ? b.substr(pos + 1) : "";
                    break;

                case 'k':               // -k
                    keysize_present = true;
                    iss >> global.keysize;
                    break;

                case 'l':               // -l
                    minlen_present = true;
                    iss >> global.minlen;
                    break;

                case 'n':               // -n
                    global.undermpi = false;
                    i--;    // since no value given
                    break;

                case 'o':               // -o
                    log_specified = true;
                    pos = b.find_last_of('#');
                    splitlog = (pos != string::npos);
                    logname = b.substr(0, pos);
                    logext = (pos != string::npos) ? b.substr(pos + 1) : "";
                    break;

                case 'p':               // -p
                    keystep_present = true;
                    iss >> global.keystep;
                    break;

                case 'q':               // -q
                    freq_present = true;
                    iss >> global.frequency;
                    break;

                case 'r':               // -r
                    res_specified = true;
                    pos = b.find_last_of('#');
                    global.result = b.substr(0, pos);
                    global.resext = (pos != string::npos) ? b.substr(pos + 1) : "";
                    break;

                case 's':               // -s
                    score_present = true;
                    iss >> dbl;
                    global.maxscore = (int)(dbl * scale);
                    break;

                case 't':               // -t
                    start_present = true;
                    iss >> global.start;
                    break;

                case 'u':               // -u
                    stop_present = true;
                    iss >> global.stop;
                    break;

                case 'w':               // -w
                    app_specified = true;
                    global.append = false;
                    i--;
                    break;

                case 'y':               // -y
                    width_present = true;
                    iss >> global.width;
                    break;

                case 'z':               // -z
                    ratio_present = true;
                    iss >> global.maxratio;
                    break;

                default:
                    cout << "Unknown option -" << a << endl;
                    return false;
            }
            continue;
        }

        // Parse positional arguments
        istringstream iss(a);
        switch (positional) {
            case 0:         // config file name
                config_file = a;
                break;

            case 1:         // fastalist
                fp_specified = true;
                global.fastapath = a;
                break;

            default:
                cout << "Extra argument '" << a << "' ignored." << endl;
        }
        positional++;
        i--;
    }

    return true;
}

// Return false at config error or no config file
bool    readConfig (void) {
    string::size_type pos;
    ifstream cfg(config_file.c_str());
    if (cfg.fail()) {
        cout << "Cannot open configuration file " << config_file << endl;
        return false;
    }
    char* buf = new char [buflen];

    // Read config file until end
    for (int line_no = 1; !cfg.eof(); line_no++) {
        cfg.getline(buf, buflen, '\n');
        string line(buf);

        // Skip empty lines
        if (line.empty()) continue;
        pos = line.find_first_not_of(whitespace);
        if (pos == string::npos) continue;

        // Skip comments
        if (line[pos] == '#' || line[pos] == ';' || line.substr(pos,2) == "//") 
            continue;

        // Process all sections
        while (line[pos] == '[') {

            // Analyze section header
            string::size_type off = pos + 1;
            pos = line.find_first_of(']', off);
            if (pos == string::npos) {
                cout << "Invalid section header in config line " << line_no << endl;
                delete [] buf;
                return false;
            }
            string section = line.substr(off, pos-off);

            // Analyze relevant sections
            if (section == "common") {                  // 'common' section
                for ( ; !cfg.eof(); line_no++) {
                    cfg.getline(buf, buflen, '\n');
                    line.assign(buf);

                    // Skip empty lines
                    if (line.empty()) continue;
                    pos = line.find_first_not_of(whitespace);
                    if (pos == string::npos) continue;

                    // Skip comments
                    if (line[pos] == '#' || line[pos] == ';' || line.substr(pos,2) == "//") 
                        continue;

                    // Break on the section end
                    if (line[pos] == '[') break;

                    // Process relevant statements
                    string key = getKey(line, line_no, pos);

                    if (!log_specified && key == "splitlog") {
                        splitlog = getBool(line, line_no, pos);
                        continue;
                    }
                    if (!log_specified && key == "logname") {
                        logname = getString(line, line_no, pos);
                        continue;
                    }
                    if (!log_specified && key == "logext") {
                        logext = getString(line, line_no, pos);
                        continue;
                    }
                    if (key == "errname") {
                        errname = getString(line, line_no, pos);
                        continue;
                    }
                    if (key == "errext") {
                        errext = getString(line, line_no, pos);
                        continue;
                    }
                    if (!fp_specified && (key == "fastapath" || key == "fpath")) {
                        global.fastapath = getString(line, line_no, pos);
                        continue;
                    }
                    if (!minlen_present && (key == "length" || key == "minlen")) {
                        global.minlen = getInt(line, line_no, pos);
                        continue;
                    }
                    if (!ratio_present && (key == "ratio" || key == "maxratio")) {
                        global.maxratio = getDouble(line, line_no, pos);
                        continue;
                    }
                    if (!keysize_present && (key == "key" || key == "keysize")) {
                        global.keysize = getInt(line, line_no, pos);
                        continue;
                    }
                    if (!belt_present && (key == "belt" ||
                        key == "maxindel" || key == "serial_del")) {
                        global.maxindel = getInt(line, line_no, pos);
                        continue;
                    }
                    if (!scdel_present && (key == "score_del" || key == "sc_indel")) {
                        double dbl = getDouble(line, line_no, pos);
                        global.sc_indel = (int)(dbl * scale);
                        continue;
                    }
                    if (!scmis_present && (key == "score_mis" || key == "sc_mismatch")) {
                        double dbl = getDouble(line, line_no, pos);
                        global.sc_mismatch = (int)(dbl * scale);
                        continue;
                    }
                    if (!score_present && (key == "score" || key == "maxscore")) {
                        double dbl = getDouble(line, line_no, pos);
                        global.maxscore = (int)(dbl * scale);
                        continue;
                    }
                }
            }

            else if (section == "pairhits") {       // 'pairhits' section
                for ( ; !cfg.eof(); line_no++) {
                    cfg.getline(buf, buflen, '\n');
                    line.assign(buf);

                    // Skip empty lines
                    if (line.empty()) continue;
                    pos = line.find_first_not_of(whitespace);
                    if (pos == string::npos) continue;

                    // Skip comments
                    if (line[pos] == '#' || line[pos] == ';' || line.substr(pos,2) == "//") 
                        continue;

                    // Break on the section end
                    if (line[pos] == '[') break;

                    // Process relevant statements
                    string key = getKey(line, line_no, pos);

                    if (!log_specified && key == "splitlog") {
                        splitlog = getBool(line, line_no, pos);
                        continue;
                    }
                    if (!log_specified && key == "logname") {
                        logname = getString(line, line_no, pos);
                        continue;
                    }
                    if (!log_specified && key == "logext") {
                        logext = getString(line, line_no, pos);
                        continue;
                    }
                    if (key == "errname") {
                        errname = getString(line, line_no, pos);
                        continue;
                    }
                    if (key == "errext") {
                        errext = getString(line, line_no, pos);
                        continue;
                    }
                    if (!job_specified && key == "jobpath") {
                        global.jobpath = getString(line, line_no, pos);
                        continue;
                    }
                    if (!job_specified && key == "jobext") {
                        global.jobext = getString(line, line_no, pos);
                        continue;
                    }
                    if (!fp_specified && (key == "fastapath" || key == "fpath")) {
                        global.fastapath = getString(line, line_no, pos);
                        continue;
                    }
                    if (!res_specified && key == "result") {
                        global.result = getString(line, line_no, pos);
                        continue;
                    }
                    if (!res_specified && key == "resext") {
                        global.resext = getString(line, line_no, pos);
                        continue;
                    }
                    if (!app_specified && key == "append") {
                        global.append = getBool(line, line_no, pos);
                        continue;
                    }
                    if (!belt_present && (key == "belt" ||
                        key == "maxindel" || key == "serial_del")) {
                        global.maxindel = getInt(line, line_no, pos);
                        continue;
                    }
                    if (!scdel_present && (key == "score_del" || key == "sc_indel")) {
                        double dbl = getDouble(line, line_no, pos);
                        global.sc_indel = (int)(dbl * scale);
                        continue;
                    }
                    if (!scmis_present && (key == "score_mis" || key == "sc_mismatch")) {
                        double dbl = getDouble(line, line_no, pos);
                        global.sc_mismatch = (int)(dbl * scale);
                        continue;
                    }
                    if (!keysize_present && (key == "key" || key == "keysize")) {
                        global.keysize = getInt(line, line_no, pos);
                        continue;
                    }
                    if (!keystep_present && (key == "step" || key == "keystep")) {
                        global.keystep = getInt(line, line_no, pos);
                        continue;
                    }
                    if (!minlen_present && (key == "length" || key == "minlen")) {
                        global.minlen = getInt(line, line_no, pos);
                        continue;
                    }
                    if (!freq_present && (key == "freq" || key == "frequency")) {
                        global.frequency = getInt(line, line_no, pos);
                        continue;
                    }
                    if (!score_present && (key == "score" || key == "maxscore")) {
                        double dbl = getDouble(line, line_no, pos);
                        global.maxscore = (int)(dbl * scale);
                        continue;
                    }
                    if (!ratio_present && (key == "ratio" || key == "maxratio")) {
                        global.maxratio = getDouble(line, line_no, pos);
                        continue;
                    }
                    if (!width_present && (key == "width")) {
                        global.width = getInt(line, line_no, pos);
                        continue;
                    }
                    if (!start_present && (key == "start")) {
                        global.start = getInt(line, line_no, pos);
                        continue;
                    }
                    if (!stop_present && (key == "stop" || key == "use")) {
                        global.stop = getInt(line, line_no, pos);
                        continue;
                    }
                    if (!minletter_present && (key == "minletter")) {
                        global.minletter = getInt(line, line_no, pos);
                        continue;
                    }

                    // More statements here.
                }
            }

            else if (section == "species") {            // 'species' section
                for ( ; !cfg.eof(); line_no++) {
                    cfg.getline(buf, buflen, '\n');
                    if (cfg.eof()) break;
                    line.assign(buf);

                    // Skip empty lines
                    if (line.empty()) continue;
                    pos = line.find_first_not_of(whitespace);
                    if (pos == string::npos) continue;

                    // Skip comments
                    if (line[pos] == '#' || line[pos] == ';' || line.substr(pos,2) == "//") 
                        continue;

                    // Break on the section end
                    if (line[pos] == '[') break;

                    // Collect species data
                    Species sp;
                    off = pos;
                    pos = line.find_first_of(tab, off);
                    if (pos == string::npos) {
                        cout << "Species no. error in config at line " << line_no << endl;
                        return false;
                    }
                    string species_no = line.substr(off, pos-off);
                    istringstream issno(species_no);
                    issno >> sp.no;

                    off = line.find_first_not_of(tab, pos);
                    pos = line.find_first_of(tab, off);
                    if (off == string::npos || pos == string::npos) {
                        cout << "Species id error in config at line " << line_no << endl;
                        return false;
                    }
                    sp.id = line.substr(off, pos-off);

                    off = line.find_first_not_of(tab, pos);
                    pos = line.find_first_of(tab, off);
                    if (off == string::npos || pos == string::npos) {
                        cout << "Species name error in config at line " << line_no << endl;
                        return false;
                    }
                    sp.name = line.substr(off, pos-off);

                    off = line.find_first_not_of(tab, pos);
                    pos = line.find_first_of(tab, off);
                    if (off == string::npos || pos == string::npos) {
                        cout << "Species code error in config at line " << line_no << endl;
                        return false;
                    }
                    sp.code = line.substr(off, pos-off);

                    off = line.find_first_not_of(tab, pos);
                    pos = line.find_first_of(tab, off);
                    if (off == string::npos) {
                        cout << "Species fasta error in config at line " << line_no << endl;
                        return false;
                    }
                    sp.fasta = global.fastapath + ( pos==string::npos ? 
                        line.substr(off) : line.substr(off, pos-off) );

                    // ignore GFF

                    map <int, int>::iterator mit = global.spec_nos.find(sp.no);
                    if (mit != global.spec_nos.end()) {
                        cout << "Duplicated species no. in config, line " << line_no << endl;
                        return false;
                    }
                    global.spec_nos.insert( pair <int, int> (sp.no, global.nSpecies));
                    global.species.push_back(sp);
                    global.nSpecies++;
                }
            }
            // Ignore other sections for now
            if (cfg.eof()) break;
        }
    }

    // Configuration postprocessing
    selectMyCompare();

    delete [] buf;
    return true;
}

// Get the key from 'key = value' string
string  getKey (const string & str, int lineno, string::size_type off = 0) {
    string key;
    string::size_type begin = str.find_first_not_of(whitespace, off);
    if (begin == string::npos)
        return key;

    string::size_type end = str.find_first_of('=', begin);
    if (end == string::npos)
        return key;

    key = str.substr(begin, end - begin);
    if (!key.empty()) {
        end = key.find_first_of(whitespace);
        if (end != string::npos)
            key.erase(end);
    }
    else {
        cout << "Key not found in config line " << lineno << endl;
    }
    return key;
}

// Get boolean value from 'key = value' string
bool    getBool (const string & str, int lineno, string::size_type off = 0) {
    string value = getString(str, lineno, off);
    if (value.size() == 1) {
        string positive = "yYtT+1";
        string negative = "nNfF-0";
        if (positive.find_first_of(value[0]) != string::npos)
            return true;
        if (negative.find_first_of(value[0]) != string::npos)
            return false;
        cout << "Invalid Boolean value in config line " << lineno << endl;
    }
    else {
        string positive = "yesYesYEStrueTrueTRUE";
        string negative = "notNotNOTfalseFalseFALSE";
        if (positive.find(value) != string::npos)
            return true;
        if (negative.find(value) != string::npos)
            return false;
        cout << "Invalid Boolean value in config line " << lineno << endl;
    }
    return false;
}

// Get integer value from 'key = value' string
int     getInt (const string & str, int lineno, string::size_type off = 0) {
    int result = -1;
    string value = getString(str, lineno, off);
    istringstream iss(value);
    iss >> result;
    return result;
}

// Get double value from 'key = value' string
double  getDouble (const string & str, int lineno, string::size_type off = 0) {
    double result = -1.0;
    string value = getString(str, lineno, off);
    istringstream iss(value);
    iss >> result;
    return result;
}

// Get possibly quoted string value from 'key = value' string
string  getString (const string & str, int lineno, string::size_type off = 0) {
    string result;
    string::size_type pos = str.find_first_of('=', off);
    if (pos == string::npos) {
        cout << "Value not found in config line " << lineno << endl;
        return result;
    }

    pos = str.find_first_not_of(whitespace, pos+1);
    if (pos == string::npos || str.substr(pos, 2) == "//") {
        // Allow empty value for a key
        //cout << "Value not found in config line " << lineno << endl;
        return result;
    }

    string::size_type end;
    if (str[pos] == '\"') {     // quoted string
        end = str.find_first_of('\"', ++pos);
        if (end == string::npos) {
            cout << "Invalid double quoted string in contig line " << lineno << endl;
            return result;
        }
        result = str.substr(pos, end - pos);
    }
    else {                      // non-quoted string
        end = str.find_first_of(whitespace, pos);
        if (end == string::npos)
            result = str.substr(pos);
        else
            result = str.substr(pos, end - pos);
    }
    return result;
}

// Initialize MPI and output files if needed 
bool    initEnvironment (int & argc, char** & argv) {
    if (global.undermpi) {
        #ifdef PAIRHITSMPI
        try {
            MPI_Init(&argc, &argv);
            MPI_Comm_size(MPI_COMM_WORLD, &global.size);
            MPI_Comm_rank(MPI_COMM_WORLD, &global.rank);
            int flag;
            MPI_Initialized(&flag);
            if (!flag)
                throw 1;
            else if (global.size < 2) {
                MPI_Finalize();
                throw 2;
            }

            // Redirect cout & cerr to separate files
            if (splitlog) {
                int width = 0;
                for (int k = 1; k < global.size; k *= 10)
                    width++;
                ostringstream num;
                num << setfill('0') << setw(width) << global.rank;
                if (!logname.empty()) {
                    string filename = logname + num.str() + logext;
                    logfs.open(filename.c_str());
                    logsb = cout.rdbuf(logfs.rdbuf());
                }

                // Also redirect cerr in this case
                if (!errname.empty()) {
                    string filename = errname + num.str() + errext;
                    errfs.open(filename.c_str());
                    errsb = cerr.rdbuf(errfs.rdbuf());
                }
            }
            
            // Redirect cout & cerr to a single file
            else {
                if (!logname.empty()) {
                    string filename = logname + logext;
                    logfs.open(filename.c_str());
                    logsb = cout.rdbuf(logfs.rdbuf());
                }
                if (!errname.empty()) {
                    string filename = errname + errext;
                    errfs.open(filename.c_str());
                    errsb = cerr.rdbuf(errfs.rdbuf());
                }
            }
        }
        catch (...) {
            global.undermpi = false;
            global.size = 1;
            global.rank = 0;
            if (!logname.empty()) {
                string filename = logname + logext;
                logfs.open(filename.c_str());
                logsb = cout.rdbuf(logfs.rdbuf());
            }
            if (!errname.empty()) {
                string filename = errname + errext;
                errfs.open(filename.c_str());
                errsb = cerr.rdbuf(errfs.rdbuf());
            }
        }
        #else
        global.undermpi = false;
        global.size = 1;
        global.rank = 0;
        if (!logname.empty()) {
            string filename = logname + logext;
            logfs.open(filename.c_str());
            logsb = cout.rdbuf(logfs.rdbuf());
        }
        if (!errname.empty()) {
            string filename = errname + errext;
            errfs.open(filename.c_str());
            errsb = cerr.rdbuf(errfs.rdbuf());
        }
        #endif
    }
    else {      //global.undermpi == false;
        global.size = 1;
        global.rank = 0;
        if (!logname.empty()) {
            string filename = logname + logext;
            logfs.open(filename.c_str());
            logsb = cout.rdbuf(logfs.rdbuf());
        }
        if (!errname.empty()) {
            string filename = errname + errext;
            errfs.open(filename.c_str());
            errsb = cerr.rdbuf(errfs.rdbuf());
        }
    }
    return true;
}

// Finalize MPI and close output files if needed
void    finalizeEnvironment (void) {
    if (global.undermpi) {
        #ifdef PAIRHITSMPI
        int flag;
        MPI_Initialized(&flag);
        if (flag)
            MPI_Finalize();
        #endif
        global.undermpi = false;
    }
    logfs.close();
    if (logsb) cout.rdbuf(logsb);
    errfs.close();
    if (errsb) cerr.rdbuf(errsb);
}

// Abort MPI and close output files if needed
void    abortEnvironment (int code) {   // Last: 9
    if (global.undermpi) {
        #ifdef PAIRHITSMPI
        int flag;
        MPI_Initialized(&flag);
        if (flag)
            MPI_Abort(MPI_COMM_WORLD, code);
        #endif
        global.undermpi = false;
    }
    logfs.close();
    if (logsb) cout.rdbuf(logsb);
    errfs.close();
    if (errsb) cerr.rdbuf(errsb);
    cout << "\nAbnormal completion: " << code << endl;
    exit(code);
}
