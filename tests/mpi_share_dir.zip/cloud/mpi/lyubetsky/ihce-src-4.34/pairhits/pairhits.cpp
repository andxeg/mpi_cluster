// (c)2016,2017 Lev Rubanov, IITP RAS
//
// Module:      pairhits.cpp
// Functions:   main  sleep
// Input:       Configuration file with the program parameters
//              Species status file (# and OS-dependent pathnames)
//              Job file according to the rank
// Result:      Jobs done are labeled in the job file
//              Write/append hits found to the result file
//

#define PAIRHITS_MAINMODULE
#include "pairhits.h"
#undef PAIRHITS_MAINMODULE

int main(int argc, char **argv) {
    int& nDone      = global.counters[0];
    int& nHits      = global.counters[1];
    int& nErrors    = global.counters[2];

    // Interpret command line agruments
    if (!parseArguments(argc, argv)) 
        abortEnvironment(1);

    // Read global configuration
    if (!readConfig())
        abortEnvironment(2);

    // Check if mpi is present and initialize it
    if (!initEnvironment(argc, argv))
        abortEnvironment(3);

    global.t0 = getTimer();
    fillLUT();
    fillCBT();

    ostringstream ossmulti;
    if (global.size > 1) ossmulti << "*" << global.size;
    cout << "\nPairHits v." << version << " run" << ossmulti.str() << ":";
    if (global.rank == 0)
        cerr << "\nPairHits v." << version << " run" << ossmulti.str() << ":";
    for (int i = 1; i < argc; i++) {
        string arg(argv[i]);
        cout << " " << arg;
        if (global.rank == 0) 
            cerr << " " << arg;
    }
    cout << "\nA total of " << global.nSpecies << " organism IDs read." << endl;
    cout.flush();
    if (global.rank == 0) {
        cerr << "\nA total of " << global.nSpecies << " organism IDs read." << endl;
        cerr.flush();
    }

#ifdef PAIRHITS_DEBUG
    for (int spn = 0; spn < global.nSpecies; spn++) {
        cout << setw(2) << spn << setw(4) << global.species[spn].no 
            << " " << global.species[spn].id << endl;
    }
#endif

    // Determine number of decimal places in file numbers; open initial files
    fstream job; 
    ofstream res;
    string jobfile;
    string resfile;
    int attempt;
    int jobno = global.start;
    if (global.width == 0) {        // unknown width
        for ( ; jobno < global.start+global.stop; jobno += global.size) {
            for (global.width = 1; global.width <= maxdecimal; global.width++) {
                for (attempt = 0; attempt < 2; attempt++) {
                    ostringstream oss;
                    oss << global.jobpath << setfill('0') << setw(global.width) 
                        << jobno + global.rank << global.jobext;
                    jobfile = oss.str();
                    job.open(jobfile.c_str(), ios_base::in | ios_base::out | ios_base::binary);
                    if (job.fail() || job.bad()) {
                        job.clear();
                        if (job.is_open()) job.close();
                        sleep(delay);       // some waiting
                        continue;           // try again
                    }
                    break;
                }
                if (attempt < 2) break;
            }
            if (global.width <= maxdecimal) break; 
        }
        if (jobno >= global.start+global.stop) {
            cout << "Cannot determine decimal places for rank " << global.rank << endl;
            abortEnvironment(4);
        }
    }
    else {                          // width was specified
        for ( ; jobno < global.start+global.stop; jobno += global.size) {
            for (attempt = 0; attempt < 2; attempt++) {
                ostringstream oss;
                oss << global.jobpath << setfill('0') << setw(global.width) 
                    << jobno + global.rank << global.jobext;
                jobfile = oss.str();
                job.open(jobfile.c_str(), ios_base::in | ios_base::out | ios_base::binary);
                if (job.fail() || job.bad()) {
                    job.clear();
                    if (job.is_open()) job.close();
                    sleep(delay);
                    continue;
                }
                break;
            }
            if (attempt < 2) break;
        }
        if (jobno >= global.start+global.stop) {
            cout << "Cannot open first job file for rank " << global.rank << endl;
            abortEnvironment(5);
        }
    }

    // Set result file mode
    ios_base::openmode resmode =  ios_base::out;
    if (global.append) resmode |= ios_base::app;
    else {
        char c;
        job.get(c);
        if (c == labelchar) resmode |= ios_base::app;
        else                resmode |= ios_base::trunc;
    }

    for (attempt = 0; attempt < 2; attempt++) {
        ostringstream oss;
        oss << global.result << setfill('0') << setw(global.width) 
            << jobno + global.rank << global.resext;
        resfile = oss.str();
        res.open(resfile.c_str(), resmode);
        if (res.fail() || res.bad()) {
            res.clear();
            if (res.is_open()) res.close();
            sleep(delay);
            continue;
        }
        break;
    }
    if (attempt >= 2) {
        cout << "Cannot open/create result file " << resfile << endl;
        abortEnvironment(6);
    }

    job.seekp(0);
    job.put(labelchar);         // Assign job to the rank
    job.flush();
    job.seekg(0);

#ifdef PAIRHITS_DEBUG
    cout << "\nDetermined number of decimal places: " << width << endl;
#endif

    // Main loop until stop reached
    for (int i = jobno+global.rank; i < global.start+global.stop; i += global.size) {
        int subDone = 0, subHits = 0, subErrors = 0;    // subtotals per file

        // Open job and result files if necessary
        if (!job.is_open()) {
            for (attempt = 0; attempt < 2; attempt++) {
                ostringstream oss;
                oss << global.jobpath << setfill('0') << setw(global.width) << i << global.jobext;
                jobfile = oss.str();
                job.open(jobfile.c_str(), ios_base::in | ios_base::out | ios_base::binary);
                if (job.fail() || job.bad()) {
                    job.clear();
                    if (job.is_open()) job.close();
                    sleep(delay);
                    continue;
                }
                break;
            }
            if (attempt >= 2) continue;    // try next file

            // Set result file mode
            if (!global.append) {
                char c;
                job.get(c);
                if (c == labelchar) resmode |= ios_base::app;
                else                resmode |= ios_base::trunc;
            }

            // Close last result file if still opened
            if (res.is_open()) {
                res.clear();
                res.close();
            }

            // Establish results for new job file
            for (attempt = 0; attempt < 2; attempt++) {
                ostringstream oss;
                oss << global.result << setfill('0') << setw(global.width) << i << global.resext;
                resfile = oss.str();
                res.open(resfile.c_str(), resmode);
                if (res.fail() || res.bad()) {
                    res.clear();
                    if (res.is_open()) res.close();
                    sleep(delay);
                    continue;
                }
                break;
            }
            if (attempt >= 2) {
                cout << "Cannot open/create result file " << resfile << endl;
                subErrors++;
                continue;
            }

            // Assign job to this rank
            job.seekp(0);
            job.put(labelchar);
            job.flush();
            job.seekg(0);
        }

        // Read first sequence from the file header
        Sequence seq1;
        char buf[buflen];
        job.getline(buf, buflen);
        if (!job.eof() && !job.bad()) {
            string line(buf+1);
            istringstream iss(line);
            iss >> seq1.species_no >> seq1.seq_no >> seq1.head_pos;

            // Per file timestamp
            map <int, int>::const_iterator mit = global.spec_nos.find(seq1.species_no);
            if (mit == global.spec_nos.end()) {
                cout << "Unknown organism " << seq1.species_no << endl;
                abortEnvironment(9);
            }
            double t1 = getTimer();
            cout << "\n" << (int)((t1-global.t0)/60) << " m: __" << global.species[mit->second].id
                << " (" << seq1.species_no << ") seq_no=" << seq1.seq_no << " offset="
                << hex << seq1.head_pos << dec << " [" << jobfile << "]" << endl;

            if (readSequence(seq1)) {

#ifdef PAIRHITS_DEBUG
                cout << "Seq1: " << seq1.species_no << "_" << seq1.seq_no << " +"
                    << hex << seq1.head_pos << dec << " [" << seq1.str.size() << "]="
                    << seq1.str.substr(0,16) << "..." << endl;
#endif
                Sequence seq2;
                // Loop over unprocessed second sequences
                for (int j = 2; ; j++) {
                    __int64 label_offset = job.tellg();
                    job.getline(buf, buflen);
                    line.assign(buf);
                    if (job.eof()) break;
                    if (line[0] == labelchar) continue;

#ifdef PAIRHITS_DEBUG
                    cout << "\nLine " << j << ": " << line << endl;
#endif
                    istringstream iss2(line);
                    iss2 >> seq2.species_no >> seq2.seq_no >> seq2.head_pos;

#ifdef PAIRHITS_DEBUG
                    map <int, int>::iterator mit2 = global.spec_nos.find(seq2.species_no);
                    if (mit2 == global.spec_nos.end()) {
                        cout << "Unknown organism " << seq2.species_no << endl;
                        abortEnvironment(8);
                    }
                    cout << "  " << global.species[mit2->second].id 
                        << " (" << seq2.species_no << ") seq_no=" << seq2.seq_no << " offset=" 
                        << hex << seq2.head_pos << dec << endl;
#endif

                    if (readSequence(seq2)) {

#ifdef PAIRHITS_DEBUG
                        cout << "Seq2[" << j-1 << "]: " << seq2.species_no << "_" << seq2.seq_no 
                            << " +" << hex << seq2.head_pos << dec << " [" << seq2.str.size() 
                            << "]=" << seq2.str.substr(0,16) << "..." << endl;
#endif
                        int hits = findHits(res, seq1, seq2, strand_pos);
                        if (hits >= 0) {
                            nHits += hits;  
                            subHits += hits;
                            invertSequence(seq2);
                            hits = findHits(res, seq1, seq2, strand_neg);
                            if (hits >= 0) {
                                // Label job done
                                __int64 current = job.tellg();
                                job.seekp(label_offset);
                                job.put(labelchar);
                                job.flush();
                                job.seekg(current);
                                nDone++;
                                subDone++;
                                nHits += hits;
                                subHits += hits;
                            }
                            else {
                                cout << "Error " << hits << " when finding invert hits: job="
                                    << i << " line=" << j << endl;
                                nErrors++; subErrors++;
                            }
                        }
                        else {
                            cout << "Error " << hits << " when finding direct hits: job="
                                << i << " line=" << j << endl;
                            nErrors++; subErrors++;
                        }
                    }
                    else {
                        cout << "Error reading second sequence in job file #" << i 
                            << ", line " << j << endl;
                        nErrors++; subErrors++;
                    }
                }
            }
            else {
                cout << "Error reading first sequence in job file #" << i << endl;
                nErrors++; subErrors++;
            }
        }
        else {
            cout << "\nAbsent or bad job file #" << i << endl;
            break;
        }
        // Print subtotal results
        double t = getTimer();
        cout << (int)((t-global.t0)/60) << " m: Subtotal " << subDone << " jobs done OK, "
            << subHits << " hits found, " << subErrors << " errors encountered" << endl;

        job.clear(); job.close();
        res.clear();
        if (res.tellp() == (std::streampos)0) {
            res.close();
            remove(resfile.c_str());
        }
        if (res.is_open()) res.close();
    }

    // Print out results
    double t = getTimer();
    cout << "\n" << (int)((t-global.t0)/60) << " m: Total " << nDone << " jobs done OK, "
        << nHits << " hits found, " << nErrors << " errors encountered" << endl;

    // Collect local results
    #ifdef PAIRHITSMPI
    if (global.undermpi) {
        int sendbuf[3] = { nDone, nHits, nErrors };
        MPI_Reduce(sendbuf, global.counters, 3, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
    }
    #endif  // PAIRHITSMPI

    if (global.rank == 0) {
        t = getTimer();
        cout << "\n" << (int)((t-global.t0)/60) << " m: Supertotal " << nDone << " jobs done, " 
            << nHits << " hits found, " << nErrors << " errors encountered" << endl;
    }

    finalizeEnvironment();
    if (global.rank == 0) {
        cout << nHits << " hits found.\nCompleted OK: time = " 
            << (int)((t-global.t0)/60) << " m." << endl;
    }
}

void    sleep(double duration) {
    double t = getTimer();
    while (getTimer() - t < duration) ;
}
