// (c)2016,2017 Lev Rubanov, IITP RAS
//
// Module:      pairhits.h
//

#ifndef PAIRHITS_HEADER
#define PAIRHITS_HEADER

#ifdef __unix__
#define LINUX
#elif defined(WIN32) || defined(_WIN32) || defined(_WIN64)
#define WINDOWS
#endif

//#define NOMPI               // Uncomment of define externally to disable MPI code

#ifndef NOMPI
#define PAIRHITSMPI         // Include mpi-related code
#endif
#define KEYPACK             // Pack keys
#define FREQUENT_KEYS       // Avoid use of frequent keys
#define ZCOMPLEXITY         // Use zlib to check complexity

// Debugging macros
//#define PAIRHITS_DEBUG
//#define DEBUG_SEQUENCES
//#define DEBUG_MATRIX
//#define DEBUG_POINTS
//#define DEBUG_ALIGNMENT

#ifdef PAIRHITSMPI
#define MSMPI_NO_DEPRECATE_20       // for MS MPI
#include "mpi.h"
#endif
#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <iomanip>
#include <vector>
#include <limits>
#include <ctime>
#include <map>
#ifdef _MSC_VER
#include <unordered_map>
#else
#include <tr1/unordered_map>
#endif

using namespace std;
using namespace std::tr1;   // for VS2008 & gcc compatibility

#ifdef PAIRHITSMPI
#define getTimer()  (global.undermpi ? MPI_Wtime() : (double)clock()/CLOCKS_PER_SEC)
#else
#define getTimer()  (double)clock()/CLOCKS_PER_SEC
#endif  // PAIRHITSMPI

#ifdef ZCOMPLEXITY
//#define ZLIB_WINAPI
#include "zlib.h"
#endif

#if !defined(_MSC_VER) && !defined(__ICC)
typedef long long                               __int64;
#endif
typedef unsigned int                            Position;
typedef unordered_multimap <string, Position>   Index;
typedef pair <Index::iterator, Index::iterator> IndexRange;
typedef pair <string, Position>                 IndexPair;
#ifdef FREQUENT_KEYS
typedef map <string, Position>                  EqualCounters;
#endif
struct Hit;
typedef map <__int64, Hit>                      History;
typedef pair <__int64, Hit>                     HistoryPair;
typedef vector <int>                            Vint;
typedef int MY_CMP_FUNC(const string&, const string&, Position&, Position&, int&, int&);


const string    version     = "1.12";
const int       buflen      = 4096;
const string    whitespace  = " \t\r\n";
const char      tab         = '\t';
const char      labelchar   = '*';
const char      chsep       = '\\';     // sequence bracketing character
#ifdef LINUX
const char      slash       = '/';      // Linux path slash
#elif defined(WINDOWS)
const char      slash       = '\\';     // Windows path slash
#endif
const string    gbkintro    = "LOCUS";
const string    gbkorigin   = "ORIGIN";
const string    gbkend      = "//";
const int       gbkgroups   = 6;        // groups per sequence line in GenBank
const string    lengthkey   = "length=";
const double    scale       = 10.0;
const int       chunk       = 65536;
const int       npoints     = 32;       // connected to global.maxscore!
const int       maxlen      = 512;      // each tail beyond the matching key
const int       mycmpnot    = -1;
const int       mycmperr    = -2;
const int       strand_pos  = 1;
const int       strand_neg  = -1;
const int       maxdecimal  = 5;        // limit of decimal places in the job number
const double    delay       = 5.0;      // number of seconds before 2nd open attempt

struct Point {
    Position i;
    Position j;
    int e;
    #ifdef DEBUG_ALIGNMENT
    int u;
    int v;
    #endif
};

struct Species {            // From file sp_status.txt   
    int     no;
    string  id;
    string  name;           // Ignored
    string  code;           // Ignored
    string  fasta;          // Includes OS dependent path
    string  gff;            // Ignored
};

struct Sequence {           // From the job & fasta files
    int     species_no;
    int     seq_no;
    __int64 head_pos;
    string  str;            // includes brackets as 1st and last chars 
};

struct Hit {
    Position    center1;        // begin+end
    Position    size1;          // end-begin+1
    Position    center2;        // begin+end
    Position    size2;          // end-begin+1
    short       strand2;        // +/- 1
    short       score;          // SCALED
    float       ratio;
};

struct Global {
    double  t0;                 // start time
    bool    undermpi;           // if we are under mpi
    int     size;               // number of cpu
    int     rank;               // this cpu number
    int     counters[3];        // nDone, nHits, nErrors
    int     nSpecies;           // species count
    vector <Species> species;   // vector of Species
    map <int, int> spec_nos;    // species_no to species iterator mapping
    string  jobpath;            // job file name or prefix
    string  jobext;             // job file extension
    string  fastapath;          // fasta file dir prefix
    bool    append;             // true=append, false=rewrite
    string  result;             // result file name or prefix
    string  resext;             // result file extension
    int     keysize;            // key size
    int     keystep;            // key selection step
    int     minlen;             // min len of sought-for element
    int     maxindel;           // max number of indels in series (-1: no check)
    int     maxscore;           // SCALED max score of mismatches
    int     sc_indel;           // SCALED score value of each indel
    int     sc_mismatch;        // SCALED score value of each mismatch
    #ifdef ZCOMPLEXITY
    double  maxratio;           // max compression ratio to hold (0: no check)
    #endif
    #ifdef FREQUENT_KEYS
    int     frequency;          // max repetitions of the key to hold
    #endif
    int     width;              // decimal places of the file number
    int     start;              // first job file to try
    int     stop;               // max number of jobs after start
    int     minletter;          // XY letters in the word & key

    // Constructor
    Global () {
        undermpi    = true;
        size        = 1;
        rank        = 0;
        counters[0] = 0;
        counters[1] = 0;
        counters[2] = 0;
        nSpecies    = 0;
        jobpath     = "jobs";
        jobpath     += slash;
        jobext      = ".txt";
        fastapath   = "fasta";
        fastapath   += slash;
        append      = false;
        result      = "results";
        result      += slash;
        resext      = ".txt";
        keysize     = 16;
        keystep     = 1;
        minlen      = 60;
        maxindel    = 2;
        maxscore    = 175;
        sc_indel    = 21;
        sc_mismatch = 10;
        #ifdef ZCOMPLEXITY
        maxratio    = 2.2;
        #endif
        #ifdef FREQUENT_KEYS
        frequency   = 200;
        #endif
        width       = 0;
        start       = 0;
        stop        = 10000;
        minletter   = 43;
    }
};

#ifdef PAIRHITS_MAINMODULE
    Global global;
#else
    extern Global global;
#endif      // PAIRHITS_MAINMODULE

void    showHelp (void);
bool    parseArguments (int & argc, char** & argv);
bool    initEnvironment (int & argc, char** & argv);
void    finalizeEnvironment (void);
void    abortEnvironment (int code);
bool    readConfig (void);
string  getKey    (const string& str, int lineno, string::size_type off);
bool    getBool   (const string& str, int lineno, string::size_type off);
int     getInt    (const string& str, int lineno, string::size_type off);
double  getDouble (const string& str, int lineno, string::size_type off);
string  getString (const string& str, int lineno, string::size_type off);
void    fillLUT(void);
void    fillCBT(void);
#ifdef KEYPACK
void    packKey(string& key);
#endif      // KEYPACK
bool    readSequence(Sequence& seq);
void    invertSequence(Sequence& seq);
int     findHits(ofstream& res, const Sequence& seq1, const Sequence& seq2, const int strand);
void    selectMyCompare(void);
int     mycompare1(const string& seq1, const string& seq2, Position& p1, Position& p2, int& len1, int& len2);
int     mycompare2(const string& seq1, const string& seq2, Position& p1, Position& p2, int& len1, int& len2);
void    sleep(double duration);
int     countLetters(const string& str, const Position off, const int len);

#endif      // PAIRHITS_HEADER
