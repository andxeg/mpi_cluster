// (c)2016,2017 Lev Rubanov, IITP RAS
//
// Module:      seqproc.cpp
// Functions:   fillLUT fillCBT packKey Compression
//              readSequence invertSequence findHits
//

#include "pairhits.h"

#ifndef __min
#define __min(a,b)  (((a) < (b)) ? (a) : (b))
#endif

// Static variables
static char LUT[256];           // lookup table for checking/recoding
static char CBT[256];           // lookup table for complement base
static Index dict(0x100000);    // up to 1M keys by default
static MY_CMP_FUNC *mycompare;

// Construct Look-Up Table
void    fillLUT(void) {
    for (int k = 0; k < 256; k++)
        LUT[k] = 0;
    LUT['A'] = 'A'; LUT['a'] = 'A';
    LUT['C'] = 'C'; LUT['c'] = 'C';
    LUT['G'] = 'G'; LUT['g'] = 'G';
    LUT['T'] = 'T'; LUT['t'] = 'T';
    LUT['R'] = 'R'; LUT['r'] = 'R';
    LUT['Y'] = 'Y'; LUT['y'] = 'Y';
    LUT['N'] = 'N'; LUT['n'] = 'N';
}

// Construct Complement Base Table
void    fillCBT(void) {
    for (int k = 0; k < 256; k++)
        CBT[k] = 0;
    CBT['A'] = 'T'; CBT['a'] = 'T';
    CBT['C'] = 'G'; CBT['c'] = 'G';
    CBT['G'] = 'C'; CBT['g'] = 'C';
    CBT['T'] = 'A'; CBT['t'] = 'A';
    CBT['R'] = 'Y'; CBT['r'] = 'Y';
    CBT['Y'] = 'R'; CBT['y'] = 'R';
    CBT['N'] = 'N'; CBT['n'] = 'N';
}

// Count different letters (of A,C,G,T) in a string
int    countLetters(const string& str, const Position off = 0, const int len = -1) {
    int na=0, nc=0, ng=0, nt=0;
    int iend = (int)str.length();
    if (len >= 0 && ((int)off + len) < iend)
        iend = (int)off + len;
    for (int i = (int)off; i < iend; i++) {
        switch (str[i]) {
            case 'A':
                na = 1;
                break;
            case 'C':
                nc = 1;
                break;
            case 'G':
                ng = 1;
                break;
            case 'T':
                nt = 1;
                break;
        }
    }
    return (na + nc + ng + nt);
}

#ifdef KEYPACK
// Pack given key in place
void    packKey(string& key) {
    string pack;
    char c = 0;
    // Make length multiple of 4
    int len = (int)key.size();
    switch (len % 4) {
        case 0:
            break;
        case 1:
            key += "AAA";
            len += 3;
            break;
        case 2:
            key += "AA";
            len += 2;
            break;
        case 3:
            key += "A";
            len ++;
            break;
    }

    // Encode 4-tuples
    for (int i = 0; i < len; i++) {
        switch (key[i]) {
            case 'A':
                c |= 0;
                break;
            case 'C':
                c |= 1;
                break;
            case 'G':
                c |= 2;
                break;
            case 'T':
                c |= 3;
                break;
        }
        if (i % 4 == 3) {
            pack.append(1, c);
            c = 0;
        }
        else c <<= 2;
    }

    key = pack;
}
#endif      // KEYPACK

#ifdef ZCOMPLEXITY
// Return len / output_len
#pragma  warning(disable : 4996)
double Compression(const string& seq, Position p, int len) {
    double ratio;
    int ret, flush = Z_FINISH;
    unsigned have;
    z_stream strm;
    unsigned char in[chunk];
    unsigned char out[chunk];
    if (len > chunk) len = chunk;

    /* allocate deflate state */
    strm.zalloc = Z_NULL;
    strm.zfree = Z_NULL;
    strm.opaque = Z_NULL;
    ret = deflateInit2(&strm, Z_DEFAULT_COMPRESSION, 
            Z_DEFLATED, // method
            -15,        // windowBits: default & raw_deflate (no zlib wrapper)
            9,          // memLevel (maximum performance)
            Z_DEFAULT_STRATEGY);    // strategy
    if (ret != Z_OK) {
        cout << "zlib: ";
        switch (ret) {
            case Z_ERRNO:
                cout << "read or write error" << endl;
                break;
            case Z_STREAM_ERROR:
                cout << "invalid compression level" << endl;
                break;
            case Z_DATA_ERROR:
                cout << "invalid or incomplete deflate data" << endl;
                break;
            case Z_MEM_ERROR:
                cout << "out of memory" << endl;
                break;
            case Z_VERSION_ERROR:
                cout << "zlib version mismatch!" << endl;
        }
        return 0;
    }

    seq.copy((char*)in, len, p);
    strm.avail_in = len;
    strm.next_in = in;
    strm.avail_out = chunk;
    strm.next_out = out;
    ret = deflate(&strm, flush);    /* no bad return value */
    have = chunk - strm.avail_out;
    deflateEnd(&strm);

    ratio = (double)len / have;
    return ratio; 
}
#endif

// Return position i from (u,v)
Position uv2i(int u, int v) {
    return (Position)(v + (u>global.maxindel ? u-global.maxindel : 0));
}

// Return position j from (u,v)
Position uv2j(int u, int v) {
    return (Position)(v + (u<global.maxindel ? global.maxindel-u : 0));
}

// Set seq.str based on species_no, head_pos
bool    readSequence(Sequence& seq) {
    static int species_no = 0;
    static ifstream fasta;
    static string filename;
    char buf[buflen];
    string::size_type seqlen = 0;

    // Reopen file if necessary
    if (seq.species_no != species_no) {
        if (fasta.is_open()) {
            fasta.clear(); 
            fasta.close();
        }

        // Find serial number of the species
        map <int, int>::const_iterator mit = global.spec_nos.find(seq.species_no);
        if (mit == global.spec_nos.end()) {
            cout << "Unknown organism code: " << seq.species_no << endl;
            return false;
        }
        int sernum = mit->second;
        species_no = seq.species_no;

        // Open fasta file
        filename = global.species[sernum].fasta;
        fasta.open(filename.c_str(), ios_base::in);
        if (!fasta.good()) {
            cout << "Cannot open file " << filename << endl;
            return false;
        }
    }

    // Check heading and read sequence
    fasta.seekg(seq.head_pos);  // should be 0 if GenBank file
    fasta.getline(buf, buflen);
    string line(buf);
    if (fasta.bad()) {
        cout << "Cannot read input file " << filename << " at position " << seq.head_pos << endl;
        return false;
    }
    else if (line.substr(0,gbkintro.size()) == gbkintro) {     // read from Genbank
        string id;
        istringstream is1(line.substr(gbkintro.size()));
        is1 >> id >> seqlen;
        while (!fasta.eof()) {      // skip everything until ORIGIN
            fasta.getline(buf, buflen);
            if (fasta.eof()) break;
            line.assign(buf);
            if (line.substr(0,gbkorigin.size()) == gbkorigin) break;
        }
        // Gather sequence
        seq.str.clear();
        while (!fasta.eof()) {
            fasta.getline(buf, buflen);
            if (fasta.eof()) break;
            line.assign(buf);
            if (line.substr(0,gbkend.size()) == gbkend) break;
            // Process sequence
            istringstream iss(line);
            int n;
            iss >> n;   // position
            for (n = 0; n < gbkgroups; n++) {
                string group;
                iss >> group;
                if (iss.fail()) break;
                seq.str.append(group);
            }
        }
    }
    else if (buf[0] != '>') {
        cout << "Invalid heading: species_no=" << species_no << " seq_no=" << seq.seq_no 
            << " begin=" << seq.head_pos << endl;
        return false;
    }
    else {              // read lines from fasta
        seqlen = 0;         // promised length
        string::size_type pos = line.find(lengthkey);
        if (pos != string::npos) {
            istringstream iss(line.substr(pos + lengthkey.size()));
            iss >> seqlen;
        }

        // Gather sequence
        seq.str.clear();
        while (!fasta.eof()) {
            fasta.get(buf, buflen, '\n');
            if (fasta.eof()) break;
            if (fasta.fail()) {
                fasta.clear();
                char newline = fasta.get();     // extract \n
                continue;
            }
            if (buf[0] == '>') {
                char newline = fasta.get();     // extract \n
                break;
            }
            string portion(buf);
            string::size_type lastpos = portion.length() - 1;
            if (portion[lastpos]=='\r' || portion[lastpos]=='\n')
                portion.erase(lastpos);
            seq.str += portion;
        }
    }

    // Check length
    if (seqlen == 0) 
        seqlen = seq.str.size();
    else if (seqlen != seq.str.size()) {
        cout << "Length mismatch: species_no=" << species_no << " seq_no=" 
            << seq.seq_no << " begin=" << seq.head_pos << " length=" 
            << seq.str.size() << "_" << seqlen << endl;
        return false;
    }

    // Recode by LUT
    for (int i = 0; i < seqlen; i++)
        seq.str[i] = LUT[seq.str[i]];

    // Check for invalid characters
    line.assign(seq.str.c_str());
    if (seqlen != line.size()) {
        cout << "Illegal base: species_no=" << species_no << " seq_no=" 
            << seq.seq_no << " begin=" << seq.head_pos << " position=" 
            << line.size() << endl;
    }

    // Add brackets
    seq.str = chsep + seq.str + chsep;

    return true;
}

// Rewrite sequence string in opposite direction
void    invertSequence(Sequence& seq) {
    int n = (int)seq.str.size();
    int i = 1;          // exclude bracket
    int j = n-2;        // exclude bracket
    for ( ; i < j; i++, j--) {
        char c = seq.str[i];
        seq.str[i] = CBT[seq.str[j]];
        seq.str[j] = CBT[c];
    }
    if (i == j)
        seq.str[i] = CBT[seq.str[j]];
}

// Select actual mycompare variant
void    selectMyCompare(void) {
    mycompare = (global.maxindel<0 ? mycompare1 : mycompare2);
}

// Return SCALED score of alignment & modified p1, p2, len1, len2
// Optimal version driven by NW-align alorithm
int  mycompare1(const string& seq1, const string& seq2, Position& p1, Position& p2, int& len1, int& len2) {
    static int ltab[maxlen+1][maxlen+1];
    static int rtab[maxlen+1][maxlen+1];
    static Position ilpoint[npoints];
    static Position jlpoint[npoints];
    static int elpoint[npoints];
    static Position irpoint[npoints];
    static Position jrpoint[npoints];
    static int erpoint[npoints];
    static bool firstrun = true;
    int err = 0;

    try {
        if (firstrun) {
            firstrun = false;
            for (int i = 0; i < maxlen; i++) {
                ltab[i][0] = i*global.sc_indel;
                ltab[0][i] = i*global.sc_indel;
                rtab[i][0] = i*global.sc_indel;
                rtab[0][i] = i*global.sc_indel;
            }
        }

        Position il, jl, ir, jr;        // indices
        // Forward run to the left
        for (il = 1; il < maxlen; il++) {
            char a = seq1[p1-il];
            for (jl = 1; jl < maxlen; jl++) {
                char b = seq2[p2-jl];
                int v0 = ltab[il-1][jl-1] + (a == b && a != 'N' ? 0 : global.sc_mismatch);
                int v1 = ltab[il-1][jl] + global.sc_indel;
                int v2 = ltab[il][jl-1] + global.sc_indel;
                ltab[il][jl] = __min(v0, __min(v1,v2));
                if (b == chsep) {
                    jl++; break;
                }
            }
            if (a == chsep) {
                il++; break;
            }
        }
        // Make il,jl last row/column of ltab[][]
        il--; jl--;     

        #ifdef DEBUG_MATRIX
        if (outmode & D_MATRIX) {
            xlog << " \t ";
            for (Position j=1; j<=jl; j++) 
                xlog << "\t" << seq2[p2-j];
            xlog << endl;
            for (Position i=0; i<=il; i++) {
                const char c = (i==0) ? chmis : seq1[p1-i];
                xlog << c;
                for (Position j=0; j<=jl; j++)
                    xlog << "\t" << ltab[i][j];
                xlog << endl;
            }
        }
        #endif

        // Fill left points from outside
        int k = 0;
        int e = ltab[il][jl];
        if (e <= global.maxscore) {
            ilpoint[k] = p1-il;
            jlpoint[k] = p2-jl;
            elpoint[k++] = e + global.sc_mismatch;
        }
        for ( ; il>0 || jl>0; ) {
            e = ltab[il][jl];
            int s = (seq1[p1-il] == seq2[p2-jl] && seq1[p1-il] != 'N' ? 0 : global.sc_mismatch);
            int v0 = (il==0 || jl==0) ? global.maxscore+1 : ltab[il-1][jl-1];
            int v1 = (il==0) ? global.maxscore+1 : ltab[il-1][jl];
            int v2 = (jl==0) ? global.maxscore+1 : ltab[il][jl-1];
            if (v0+s == e) {
                il--; jl--;
                if (v0 > global.maxscore) continue;
                if (v0 < e) {
                    ilpoint[k] = p1-il-1;
                    jlpoint[k] = p2-jl-1;
                    elpoint[k++] = e;
                }
            }
            else if (v1+global.sc_indel == e) {
                il--;
                if (v1 > global.maxscore) continue;
                ilpoint[k] = p1-il-1;
                jlpoint[k] = p2-jl;
                elpoint[k++] = e;
            }
            else {
                jl--;
                if (v2 > global.maxscore) continue;
                ilpoint[k] = p1-il;
                jlpoint[k] = p2-jl-1;
                elpoint[k++] = e;
            }
        }
        ilpoint[k] = p1;
        jlpoint[k] = p2;
        elpoint[k] = 0;
        int lk = k;
        
        #ifdef DEBUG_POINTS
        if (outmode & D_POINTS) {
            xlog << "\nlpoint:";
            for (k=0; k<=lk; k++) 
                xlog << "\t" << k;
            xlog << endl;
            xlog << "pos1:";
            for (k=0; k<=lk; k++) 
                xlog << "\t" << ilpoint[k];
            xlog << endl;
            xlog << "pos2:";
            for (k=0; k<=lk; k++) 
                xlog << "\t" << jlpoint[k];
            xlog << endl;
            xlog << "score:";
            for (k=0; k<=lk; k++) 
                xlog << "\t" << elpoint[k]/scale;
            xlog << endl;
        }
        #endif

        Position q1 = p1+len1-1;
        Position q2 = p2+len2-1;
        // Forward run to the right
        for (ir = 1; ir < maxlen; ir++) {
            char a = seq1[q1+ir];
            for (jr = 1; jr < maxlen; jr++) {
                char b = seq2[q2+jr];
                int v0 = rtab[ir-1][jr-1] + (a == b && a != 'N' ? 0 : global.sc_mismatch);
                int v1 = rtab[ir-1][jr] + global.sc_indel;
                int v2 = rtab[ir][jr-1] + global.sc_indel;
                rtab[ir][jr] = __min(v0, __min(v1,v2));
                if (b == chsep) {
                    jr++; break;
                }
            }
            if (a == chsep) {
                ir++; break;
            }
        }
        // Make ir,jr last row/column of rtab[][]
        ir--; jr--;     
        

        #ifdef DEBUG_MATRIX
        if (outmode & D_MATRIX) {
            xlog << " \t ";
            for (Position j=1; j<=jr; j++) 
                xlog << "\t" << seq2[q2+j];
            xlog << endl;
            for (Position i=0; i<=ir; i++) {
                const char c = (i==0) ? chmis : seq1[q1+i];
                xlog << c;
                for (Position j=0; j<=jr; j++)
                    xlog << "\t" << rtab[i][j];
                xlog << endl;
            }
        }
        #endif

        // Fill right points from outside 
        k = 0;
        e = rtab[ir][jr];
        if (e <= global.maxscore) {
            irpoint[k] = q1+ir;
            jrpoint[k] = q2+jr;
            erpoint[k++] = e + global.sc_mismatch;
        }
        for ( ; ir>0 || jr>0; ) {
            e = rtab[ir][jr];
            int s = (seq1[q1+ir] == seq2[q2+jr] && seq1[q1+ir] != 'N' ? 0 : global.sc_mismatch);
            int v0 = (ir==0 || jr==0) ? global.maxscore+1 : rtab[ir-1][jr-1];
            int v1 = (ir==0) ? global.maxscore+1 : rtab[ir-1][jr];
            int v2 = (jr==0) ? global.maxscore+1 : rtab[ir][jr-1];
            if (v0+s == e) {
                ir--; jr--;
                if (v0 > global.maxscore) continue;
                if (v0 < e) {
                    irpoint[k] = q1+ir+1;
                    jrpoint[k] = q2+jr+1;
                    erpoint[k++] = e;
                }
            }
            else if (v1+global.sc_indel == e) {
                ir--;
                if (v1 > global.maxscore) continue;
                irpoint[k] = q1+ir+1;
                jrpoint[k] = q2+jr;
                erpoint[k++] = e;
            }
            else {
                jr--;
                if (v2 > global.maxscore) continue;
                irpoint[k] = q1+ir;
                jrpoint[k] = q2+jr+1;
                erpoint[k++] = e;
            }
        }
        irpoint[k] = q1;
        jrpoint[k] = q2;
        erpoint[k] = 0;
        int rk = k;
        
        #ifdef DEBUG_POINTS
        if (outmode & D_POINTS) {
            xlog << "\nrpoint:";
            for (k=0; k<=rk; k++) 
                xlog << "\t" << k;
            xlog << endl;
            xlog << "pos1:";
            for (k=0; k<=rk; k++) 
                xlog << "\t" << irpoint[k];
            xlog << endl;
            xlog << "pos2:";
            for (k=0; k<=rk; k++) 
                xlog << "\t" << jrpoint[k];
            xlog << endl;
            xlog << "score:";
            for (k=0; k<=rk; k++) 
                xlog << "\t" << erpoint[k]/scale;
            xlog << endl;
        }
        #endif

        // Choose best option: max length with allowed errors
        Position bestlen = 0;
        int bestk = -1, bestr = -1;
        for (int k = 0; k <= lk; k++) {
            for (int r = rk; r >= 0; r--) {
                // Calculate total score
                int tsc = elpoint[k+1] + erpoint[r+1];
                if (tsc > global.maxscore) break;
                // Calculate total length
                Position len = irpoint[r]-ilpoint[k]+jrpoint[r]-jlpoint[k]-2;
                if (elpoint[k]-elpoint[k+1] == global.sc_indel) 
                    len++;
                if (erpoint[r]-erpoint[r+1] == global.sc_indel) 
                    len++;
                // Store if better
                if (len > (Position)global.minlen*2 && len > bestlen) {
                    bestlen = len;
                    bestk = k;
                    bestr = r;
                    err = tsc;
                }
            }
        }
        #ifdef DEBUG_POINTS
        if (outmode & D_POINTS)
            xlog << "\nBest points: left=" << bestk << " right=" << bestr 
                << " sumlen=" << bestlen << " score=" << err/scale << endl;
        #endif

        // Form response
        if (bestk<0 || bestr<0) return mycmpnot;
        Position si, sj, li, lj;
        if (bestk == lk) {
            si=0; sj=0;
        }
        else {
            li = ilpoint[bestk+1] - ilpoint[bestk];
            lj = jlpoint[bestk+1] - jlpoint[bestk];
            if (li == lj) {
                si=1; sj=1;
            }
            else if (li > lj) {
                si=1; sj=0;
            }
            else {
                si=0; sj=1;
            }
        }
        p1 = ilpoint[bestk] + si;
        p2 = jlpoint[bestk] + sj;

        if (bestr == rk) {
            si=0; sj=0;
        }
        else {
            li = irpoint[bestr] - irpoint[bestr+1];
            lj = jrpoint[bestr] - jrpoint[bestr+1];
            if (li == lj) {
                si=1; sj=1;
            }
            else if (li > lj) {
                si=1; sj=0;
            }
            else {
                si=0; sj=1;
            }
        }
        len1 = irpoint[bestr] - si - p1 + 1;
        len2 = jrpoint[bestr] - sj - p2 + 1;

        #ifdef DEBUG_ALIGNMENT
        if (outmode & D_ALIGNMENT && bestlen>0) {
            // Print alignment
            string s1, s2, s3, ast;
            for (int k = bestk; k < lk; k++) {
                li = ilpoint[k+1] - ilpoint[k];
                lj = jlpoint[k+1] - jlpoint[k];
                int derr = elpoint[k] - elpoint[k+1];

                if (derr == sc_mismatch) {        // mismatch
                    if (k != bestk) {
                        s1 += seq1[ilpoint[k]];
                        s2 += seq2[jlpoint[k]];
                        s3 += chmis;
                    }
                    si=1; sj=1;
                }
                else if (derr == sc_indel) {      // indel
                    if (li > lj) {
                        if (k != bestk) {
                            s1 += seq1[ilpoint[k]];
                            s2 += chgap;
                            s3 += chdel;
                        }
                        si=1; sj=0; 
                        lj++;
                    }
                    else if (li < lj) {
                        if (k != bestk) {
                            s1 += chgap;
                            s2 += seq2[jlpoint[k]];
                            s3 += chdel;
                        }
                        si=0; sj=1; 
                        li++;
                    }
                    else throw "Error: indel with equal lengths (left).";
                }
                else throw "Error: score increment invalid (left).";

                s1 += seq1.substr(ilpoint[k]+si, --li);
                s2 += seq2.substr(jlpoint[k]+sj, --lj);
                if (li != lj)
                    throw "Error: different lengths of equal segments (left).";
                ast.assign(li, chast);
                s3 += ast;
            }

            li = irpoint[rk]-ilpoint[lk]+1;
            lj = jrpoint[rk]-jlpoint[lk]+1;
            s1 += seq1.substr(ilpoint[lk], li);
            s2 += seq2.substr(jlpoint[lk], lj);
            if (li != lj)
                throw "Error: different lengths of equal segments (middle).";
            ast.assign(li, chast);
            s3 += ast;

            string t1, t2, t3;
            for (int k = bestr; k < rk; k++) {
                string tt1, tt2, tt3;
                li = irpoint[k] - irpoint[k+1];
                lj = jrpoint[k] - jrpoint[k+1];
                int derr = erpoint[k] - erpoint[k+1];

                if (derr == sc_mismatch) {        // mismatch
                    if (k != bestr) {
                        tt1 = seq1[irpoint[k]];
                        tt2 = seq2[jrpoint[k]];
                        tt3 = chmis;
                    }
                }
                else if (derr == sc_indel) {      // indel
                    if (li > lj) {
                        if (k != bestr) {
                            tt1 = seq1[irpoint[k]];
                            tt2 = chgap;
                            tt3 = chdel;
                        }
                        lj++;
                    }
                    else if (li < lj) {
                        if (k != bestr) {
                            tt1 = chgap;
                            tt2 = seq2[jrpoint[k]];
                            tt3 = chdel;
                        }
                        li++;
                    }
                    else throw "Error: indel with equal lengths (right).";
                }
                else throw "Error: score increment invalid (right).";

                t1 = seq1.substr(irpoint[k+1]+1, --li) + tt1 + t1;
                t2 = seq2.substr(jrpoint[k+1]+1, --lj) + tt2 + t2;
                if (li != lj)
                    throw "Error: different lengths of equal segments (right).";
                ast.assign(li, chast);
                t3 = ast +tt3 + t3;
            }

            xlog << s1 << t1 << "\n" << s2 << t2 << "\n" << s3 << t3 << endl;
        }
        #endif
    }
    catch(const char* e) {
        string msg(e);
        cerr << "\n" << msg << endl;
        err = mycmperr;
    }

    return err;
}

// Quasi-optimal version driven by the belt width (-g)
int  mycompare2(const string& seq1, const string& seq2, Position& p1, Position& p2, int& len1, int& len2) {
    enum Direction { END, UP, ULEFT, LEFT, DLEFT, DOWN, NONE };
    const int bigerror = global.maxscore*2; 
    const string direction = "=^\\</v ";
    static vector <Vint> ltab(2*global.maxindel+1);
    static vector <Vint> rtab(2*global.maxindel+1);
    static vector <Vint> lptr(2*global.maxindel+1);
    static vector <Vint> rptr(2*global.maxindel+1);
    static vector <Point> lpoint;
    static vector <Point> rpoint;
    static bool firstrun = true;
    int err = 0;

    try {
        if (firstrun) {
            firstrun = false;
            ltab[global.maxindel].push_back(0);
            rtab[global.maxindel].push_back(0);
            lptr[global.maxindel].push_back(END);
            rptr[global.maxindel].push_back(END);
            for (int i = 1; i <= global.maxindel; i++) {
                ltab[global.maxindel-i].push_back(i*global.sc_indel);
                ltab[global.maxindel+i].push_back(i*global.sc_indel);
                rtab[global.maxindel-i].push_back(i*global.sc_indel);
                rtab[global.maxindel+i].push_back(i*global.sc_indel);
                lptr[global.maxindel-i].push_back(DOWN);
                lptr[global.maxindel+i].push_back(UP);
                rptr[global.maxindel-i].push_back(DOWN);
                rptr[global.maxindel+i].push_back(UP);
            }
        }
        else {
            for (int i = 0; i <= 2*global.maxindel; i++) {
                ltab[i].erase(ltab[i].begin()+1, ltab[i].end());
                rtab[i].erase(rtab[i].begin()+1, rtab[i].end());
                lptr[i].erase(lptr[i].begin()+1, lptr[i].end());
                rptr[i].erase(rptr[i].begin()+1, rptr[i].end());
            }
            lpoint.clear();
            rpoint.clear();
        }

        int ul, vl, ur, vr;        // indices
        int U=global.maxindel, V=0;
        // Forward run to the left
        for (vl = 1; ; vl++) {
            char a = seq1[p1-vl];
            char b = seq2[p2-vl];
            if (a == chsep || b == chsep)
                break;

            int v0 = ltab[global.maxindel]  [vl-1] + (a == b && a != 'N' ? 0 : global.sc_mismatch);
            if (global.maxindel == 0) {     // special case of prohibited deletions
                ltab[0].push_back(v0);
                lptr[0].push_back(LEFT);
                U = 0; V = vl;
                if (ltab[U][V] > global.maxscore) { --V; break; }
                continue;
            }
            int v1 = ltab[global.maxindel-1][vl-1] + global.sc_indel;
            int v2 = ltab[global.maxindel+1][vl-1] + global.sc_indel;
            if (v0 <= v1 && v0 <= v2) {
                ltab[global.maxindel].push_back(v0);
                lptr[global.maxindel].push_back(LEFT);
            }
            else if (v1 <= v2) {
                ltab[global.maxindel].push_back(v1);
                lptr[global.maxindel].push_back(ULEFT);
            }
            else {
                ltab[global.maxindel].push_back(v2);
                lptr[global.maxindel].push_back(DLEFT);
            }
            
            bool end1=false, end2=false;
            for (ul = 1; ul <= global.maxindel; ul++) {

                a = seq1[p1-vl];
                if (!end2) b = seq2[p2-(vl+ul)];
                if (b == chsep) end2 = true;
                if (!end2) {
                    v0 = ltab[global.maxindel-ul][vl-1] + (a == b && a != 'N' ? 0 : global.sc_mismatch);
                    v1 = (ul<global.maxindel ? ltab[global.maxindel-ul-1][vl-1] + global.sc_indel : bigerror);
                    v2 = ltab[global.maxindel-ul+1][vl] + global.sc_indel;
                    if (v0 <= v1 && v0 <= v2) {
                        ltab[global.maxindel-ul].push_back(v0);
                        lptr[global.maxindel-ul].push_back(LEFT);
                    }
                    else if (v1 <= v2) {
                        ltab[global.maxindel-ul].push_back(v1);
                        lptr[global.maxindel-ul].push_back(ULEFT);
                    }
                    else {
                        ltab[global.maxindel-ul].push_back(v2);
                        lptr[global.maxindel-ul].push_back(DOWN);
                    }
                }
                else {
                    ltab[global.maxindel-ul].push_back(bigerror);
                    lptr[global.maxindel-ul].push_back(NONE);
                }

                if (!end1) a = seq1[p1-(ul+vl)];
                b = seq2[p2-vl];
                if (a == chsep) end1 = true;
                if (!end1) {
                    v0 = ltab[global.maxindel+ul][vl-1] + (a == b && a != 'N' ? 0 : global.sc_mismatch);
                    v1 = ltab[global.maxindel+ul-1][vl] + global.sc_indel;
                    v2 = (ul<global.maxindel ? ltab[global.maxindel+ul+1][vl-1] + global.sc_indel : bigerror);
                    if (v0 <= v1 && v0 <= v2) {
                        ltab[global.maxindel+ul].push_back(v0);
                        lptr[global.maxindel+ul].push_back(LEFT);
                    }
                    else if (v1 <= v2) {
                        ltab[global.maxindel+ul].push_back(v1);
                        lptr[global.maxindel+ul].push_back(UP);
                    }
                    else {
                        ltab[global.maxindel+ul].push_back(v2);
                        lptr[global.maxindel+ul].push_back(DLEFT);
                    }
                }
                else {
                    ltab[global.maxindel+ul].push_back(bigerror);
                    lptr[global.maxindel+ul].push_back(NONE);
                }
            }       // next ul

            int opt = ltab[global.maxindel][vl];
            U = global.maxindel; V = vl;
            for (ul = 1; ul <= global.maxindel; ul++) {
                if (ltab[global.maxindel-ul][vl] < opt) {
                    opt = ltab[global.maxindel-ul][vl];
                    U = global.maxindel-ul;
                }
                if (ltab[global.maxindel+ul][vl] < opt) {
                    opt = ltab[global.maxindel+ul][vl];
                    U = global.maxindel+ul;
                }
            }
            if (ltab[U][V] > global.maxscore) { --V; break; }
        }       // next vl

        #ifdef DEBUG_MATRIX
        if (outmode & D_MATRIX) {
            xlog << endl;
            for (int v=0; v<=V; v++) 
                xlog << "\t" << v;
            xlog << endl;
            for (int u=0; u<=2*maxindel; u++) {
                xlog << u;
                for (int v=0; v<=V; v++)
                    xlog << "\t" << direction[lptr[u][v]] << " " << ltab[u][v];
                xlog << endl;
            }
        }
        #endif

        // Fill left points from outside
        for (U=0; U<=2*global.maxindel; U++) {
            if (ltab[U][V] <= global.maxscore) {
                Point pt;
                Position di = uv2i(U,V);
                Position dj = uv2j(U,V);
                int e = ltab[U][V], de;
                if (p1 > di) pt.i = p1 - di;
                else continue;
                if (p2 > dj) pt.j = p2 - dj;
                else continue;
                pt.e = e;
                #ifdef DEBUG_ALIGNMENT
                if (outmode & D_ALIGNMENT) {
                    pt.u = U;
                    pt.v = V;
                }
                #endif
                lpoint.push_back(pt);
                int ul = U, vl = V;
                while (lptr[ul][vl] != END) {
                    di = uv2i(ul,vl);
                    if (p1 <= di) break;
                    Position il = p1 - di;
                    dj = uv2j(ul,vl);
                    if (p2 <= dj) break;
                    Position jl = p2 - dj;
                    switch (lptr[ul][vl]) {
                        case LEFT:
                            il++; jl++;
                            vl--;
                            break;
                        case ULEFT:
                            il++;
                            ul--; vl--;
                            break;
                        case DLEFT:
                            jl++;
                            ul++; vl--;
                            break;
                        case UP:
                            il++;
                            ul--;
                            break;
                        case DOWN:
                            jl++;
                            ul++;
                            break;
                        case NONE:
                        default:
                            throw "Error in left pointer matrix.";
                    }
                    pt.i = il;
                    pt.j = jl;
                    de = e - ltab[ul][vl];
                    if (de == 0) 
                        continue;
                    e -= de;
                    pt.e = e;
                    #ifdef DEBUG_ALIGNMENT
                    if (outmode & D_ALIGNMENT) {
                        pt.u = ul;
                        pt.v = vl;
                    }
                    #endif
                    if (e <= global.maxscore)
                        lpoint.push_back(pt);
                }
            }
        }
        
        #ifdef DEBUG_POINTS
        if (outmode & D_POINTS) {
            ostringstream line1, line2, line3;
            #ifdef DEBUG_ALIGNMENT
            ostringstream line4, line5;
            #endif
            xlog << "\nlpoint:";
            line1 << "pos1:";
            line2 << "pos2:";
            line3 << "score:";
            #ifdef DEBUG_ALIGNMENT
            if (outmode & D_ALIGNMENT) {
                line4 << "u:";
                line5 << "v:";
            }
            #endif
            for (int k = 0; k < (int)lpoint.size(); k++) { 
                xlog << "\t" << k;
                line1 << "\t" << lpoint[k].i;
                line2 << "\t" << lpoint[k].j;
                line3 << "\t" << lpoint[k].e/scale;
                #ifdef DEBUG_ALIGNMENT
                if (outmode & D_ALIGNMENT) {
                    line4 << "\t" << lpoint[k].u;
                    line5 << "\t" << lpoint[k].v;
                }
                #endif
            }
            xlog << "\n" << line1.str() << "\n" << line2.str() << "\n" << line3.str();
            #ifdef DEBUG_ALIGNMENT
            if (outmode & D_ALIGNMENT) 
                xlog << "\n" << line4.str() << "\n" << line5.str();
            #endif
            xlog << endl;
        }
        #endif

        // Forward run to the right
        Position q1 = p1+len1-1;
        Position q2 = p2+len2-1;
        U = global.maxindel; V = 0;
        for (vr = 1; ; vr++) {
            char a = seq1[q1+vr];
            char b = seq2[q2+vr];
            if (a == chsep || b == chsep)
                break;

            int v0 = rtab[global.maxindel]  [vr-1] + (a == b && a != 'N' ? 0 : global.sc_mismatch);
            if (global.maxindel == 0) {     // special case of prohibited deletions
                rtab[0].push_back(v0);
                rptr[0].push_back(LEFT);
                U = 0; V = vr;
                if (rtab[U][V] > global.maxscore) { --V; break; }
                continue;
            }
            int v1 = rtab[global.maxindel-1][vr-1] + global.sc_indel;
            int v2 = rtab[global.maxindel+1][vr-1] + global.sc_indel;
            if (v0 <= v1 && v0 <= v2) {
                rtab[global.maxindel].push_back(v0);
                rptr[global.maxindel].push_back(LEFT);
            }
            else if (v1 <= v2) {
                rtab[global.maxindel].push_back(v1);
                rptr[global.maxindel].push_back(ULEFT);
            }
            else {
                rtab[global.maxindel].push_back(v2);
                rptr[global.maxindel].push_back(DLEFT);
            }

            bool end1=false, end2=false;
            for (ur = 1; ur <= global.maxindel; ur++) {

                a = seq1[q1+vr];
                if (!end2) b = seq2[q2+(vr+ur)];
                if (b == chsep) end2 = true;
                if (!end2) {
                    v0 = rtab[global.maxindel-ur][vr-1] + (a == b && a != 'N' ? 0 : global.sc_mismatch);
                    v1 = (ur<global.maxindel ? rtab[global.maxindel-ur-1][vr-1] + global.sc_indel : bigerror);
                    v2 = rtab[global.maxindel-ur+1][vr] + global.sc_indel;
                    if (v0 <= v1 && v0 <= v2) {
                        rtab[global.maxindel-ur].push_back(v0);
                        rptr[global.maxindel-ur].push_back(LEFT);
                    }
                    else if (v1 <= v2) {
                        rtab[global.maxindel-ur].push_back(v1);
                        rptr[global.maxindel-ur].push_back(ULEFT);
                    }
                    else {
                        rtab[global.maxindel-ur].push_back(v2);
                        rptr[global.maxindel-ur].push_back(DOWN);
                    }
                }
                else {
                    rtab[global.maxindel-ur].push_back(bigerror);
                    rptr[global.maxindel-ur].push_back(NONE);
                }

                if (!end1) a = seq1[q1+(ur+vr)];
                b = seq2[q2+vr];
                if (a == chsep) end1 = true;
                if (!end1) {
                    v0 = rtab[global.maxindel+ur][vr-1] + (a == b && a != 'N' ? 0 : global.sc_mismatch);
                    v1 = rtab[global.maxindel+ur-1][vr] + global.sc_indel;
                    v2 = (ur<global.maxindel ? rtab[global.maxindel+ur+1][vr-1] + global.sc_indel : bigerror);
                    if (v0 <= v1 && v0 <= v2) {
                        rtab[global.maxindel+ur].push_back(v0);
                        rptr[global.maxindel+ur].push_back(LEFT);
                    }
                    else if (v1 <= v2) {
                        rtab[global.maxindel+ur].push_back(v1);
                        rptr[global.maxindel+ur].push_back(UP);
                    }
                    else {
                        rtab[global.maxindel+ur].push_back(v2);
                        rptr[global.maxindel+ur].push_back(DLEFT);
                    }
                }
                else {
                    rtab[global.maxindel+ur].push_back(bigerror);
                    rptr[global.maxindel+ur].push_back(NONE);
                }
            }       // next ur

            int opt = rtab[global.maxindel][vr];
            U = global.maxindel; V = vr;
            for (ur = 1; ur <= global.maxindel; ur++) {
                if (rtab[global.maxindel-ur][vr] < opt) {
                    opt = rtab[global.maxindel-ur][vr];
                    U = global.maxindel-ur;
                }
                if (rtab[global.maxindel+ur][vr] < opt) {
                    opt = rtab[global.maxindel+ur][vr];
                    U = global.maxindel+ur;
                }
            }
            if (rtab[U][V] > global.maxscore) { --V; break; }
        }       // next vr
        
        #ifdef DEBUG_MATRIX
        if (outmode & D_MATRIX) {
            xlog << endl;
            for (int v=0; v<=V; v++) 
                xlog << "\t" << v;
            xlog << endl;
            for (int u=0; u<=2*maxindel; u++) {
                xlog << u;
                for (int v=0; v<=V; v++)
                    xlog << "\t" << direction[rptr[u][v]] << " " << rtab[u][v];
                xlog << endl;
            }
        }
        #endif

        // Fill right points from outside 
        for (U=0; U<=2*global.maxindel; U++) {
            if (rtab[U][V] <= global.maxscore) {
                Point pt;
                Position di = uv2i(U,V);
                Position dj = uv2j(U,V);
                int e = rtab[U][V], de;
                if (q1+di < seq1.size()-1)
                    pt.i = q1 + di;
                else continue;
                if (q2+dj < seq2.size()-1)
                    pt.j = q2 + dj;
                else continue;
                pt.e = e;
                #ifdef DEBUG_ALIGNMENT
                if (outmode & D_ALIGNMENT) {
                    pt.u = U;
                    pt.v = V;
                }
                #endif
                rpoint.push_back(pt);
                int ur = U, vr = V;
                while (rptr[ur][vr] != END) {
                    di = uv2i(ur,vr);
                    if (q1+di >= seq1.size()-1) break;
                    Position ir = q1 + di;
                    dj = uv2j(ur,vr);
                    if (q2+dj >= seq2.size()-1) break;
                    Position jr = q2 + dj;
                    switch (rptr[ur][vr]) {
                        case LEFT:
                            ir--; jr--;
                            vr--;
                            break;
                        case ULEFT:
                            ir--;
                            ur--; vr--;
                            break;
                        case DLEFT:
                            jr--;
                            ur++; vr--;
                            break;
                        case UP:
                            ir--;
                            ur--;
                            break;
                        case DOWN:
                            jr--;
                            ur++;
                            break;
                        case NONE:
                        default:
                            throw "Error in right pointer matrix.";
                    }
                    pt.i = ir;
                    pt.j = jr;
                    de = e - rtab[ur][vr];
                    if (de == 0) 
                        continue;
                    e -= de;
                    pt.e = e;
                    #ifdef DEBUG_ALIGNMENT
                    if (outmode & D_ALIGNMENT) {
                        pt.u = ur;
                        pt.v = vr;
                    }
                    #endif
                    if (e <= global.maxscore)
                        rpoint.push_back(pt);
                }
            }
        }
        
        #ifdef DEBUG_POINTS
        if (outmode & D_POINTS) {
            ostringstream rine1, rine2, rine3;
            #ifdef DEBUG_ALIGNMENT
            ostringstream rine4, rine5;
            #endif
            xlog << "\nrpoint:";
            rine1 << "pos1:";
            rine2 << "pos2:";
            rine3 << "score:";
            #ifdef DEBUG_ALIGNMENT
            if (outmode & D_ALIGNMENT) {
                rine4 << "u:";
                rine5 << "v:";
            }
            #endif
            for (int k = 0; k < (int)rpoint.size(); k++) {
                xlog << "\t" << k;
                rine1 << "\t" << rpoint[k].i;
                rine2 << "\t" << rpoint[k].j;
                rine3 << "\t" << rpoint[k].e/scale;
                #ifdef DEBUG_ALIGNMENT
                if (outmode & D_ALIGNMENT) {
                    rine4 << "\t" << rpoint[k].u;
                    rine5 << "\t" << rpoint[k].v;
                }
                #endif
            }
            xlog << "\n" << rine1.str() << "\n" << rine2.str() << "\n" << rine3.str();
            #ifdef DEBUG_ALIGNMENT
            if (outmode & D_ALIGNMENT) 
                xlog << "\n" << rine4.str() << "\n" << rine5.str();
            #endif
            xlog << endl;
        }
        #endif

        // Choose best option: max length with allowed errors
        Position bestlen = 0;
        int bestk = -1, bestr = -1;
        for (int k = 0; k < (int)lpoint.size(); k++) {
            for (int r = 0; r < (int)rpoint.size(); r++) {
                // Calculate total score
                int tsc = lpoint[k].e + rpoint[r].e;
                if (tsc > global.maxscore) continue;
                // Calculate total length
                Position len = rpoint[r].i-lpoint[k].i+rpoint[r].j-lpoint[k].j+2;
                // Store if better
                if (len > (Position)global.minlen*2 && len > bestlen) {
                    bestlen = len;
                    bestk = k;
                    bestr = r;
                    err = tsc;
                }
            }
        }
        #ifdef DEBUG_POINTS
        if (outmode & D_POINTS)
            xlog << "\nBest points: left=" << bestk << " right=" << bestr 
                << " sumlen=" << bestlen << " score=" << err/scale << endl;
        #endif

        #ifdef DEBUG_ALIGNMENT
        if (outmode & D_ALIGNMENT && bestlen>0) {
            string s1, s2, s3, ast;
            // Form left alignment
            ul = lpoint[bestk].u;
            vl = lpoint[bestk].v;
            Position il = p1 - uv2i(ul,vl);
            Position jl = p2 - uv2j(ul,vl);
            while (lptr[ul][vl] != END) {
                switch (lptr[ul][vl]) {
                    case LEFT:
                        s1 += seq1[il];
                        s2 += seq2[jl];
                        s3 += (seq1[il] == seq2[jl] && seq1[il] != 'N' ? chast : chmis);
                        il++; jl++;
                        vl--;
                        break;
                    case ULEFT:
                        s1 += seq1[il];
                        s2 += chgap;
                        s3 += chdel;
                        il++;
                        ul--; vl--;
                        break;
                    case DLEFT:
                        s1 += chgap;
                        s2 += seq2[jl];
                        s3 += chdel;
                        jl++;
                        ul++; vl--;
                        break;
                    case UP:
                        s1 += seq1[il];
                        s2 += chgap;
                        s3 += chdel;
                        il++;
                        ul--;
                        break;
                    case DOWN:
                        s1 += chgap;
                        s2 += seq2[jl];
                        s3 += chdel;
                        jl++;
                        ul++;
                        break;
                    case NONE:
                    default:
                        throw "Error in left pointer matrix.";
                }
            }
            // Form middle alignment
            s1 += seq1.substr(p1, len1);
            s2 += seq2.substr(p2, len2);
            ast.assign(len1, chast);
            s3 += ast;
            // Form right alignment
            string t1, t2, t3;
            ur = rpoint[bestr].u;
            vr = rpoint[bestr].v;
            Position ir = q1 + uv2i(ur,vr);
            Position jr = q2 + uv2j(ur,vr);
            while (rptr[ur][vr] != END) {
                switch (rptr[ur][vr]) {
                    case LEFT:
                        t1 = seq1[ir] + t1;
                        t2 = seq2[jr] + t2;
                        t3 = (seq1[ir] == seq2[jr] && seq1[ir] != 'N' ? chast : chmis) + t3;
                        ir--; jr--;
                        vr--;
                        break;
                    case ULEFT:
                        t1 = seq1[ir] + t1;
                        t2 = chgap + t2;
                        t3 = chdel + t3;
                        ir--;
                        ur--; vr--;
                        break;
                    case DLEFT:
                        t1 = chgap + t1;
                        t2 = seq2[jr] + t2;
                        t3 = chdel + t3;
                        jr--;
                        ur++; vr--;
                        break;
                    case UP:
                        t1 = seq1[ir] + t1;
                        t2 = chgap + t2;
                        t3 = chdel + t3;
                        ir--;
                        ur--;
                        break;
                    case DOWN:
                        t1 = chgap + t1;
                        t2 = seq2[jr] + t2;
                        t3 = chdel + t3;
                        jr--;
                        ur++;
                        break;
                    case NONE:
                    default:
                        throw "Error in right pointer matrix.";
                }
            }
            xlog << s1 << t1 << "\n" << s2 << t2 << "\n" << s3 << t3 << endl;
        }
        #endif

        // Form response
        if (bestk<0 || bestr<0) return mycmpnot;
        p1 = lpoint[bestk].i;
        p2 = lpoint[bestk].j;
        len1 = rpoint[bestr].i - p1 + 1;
        len2 = rpoint[bestr].j - p2 + 1;
    }
    catch(const char* e) {
        string msg(e);
        cerr << "\n" << msg << endl;
        err = mycmperr;
    }

    return err;
}

// Find hits for two strings and write them to the stream 
int     findHits(ofstream& res, const Sequence& seq1, const Sequence& seq2, int strand) {
    static int species_no = 0;
    static int seq_no = 0;
    int nTotal = 0;     // Total number of keys in 2nd seq
    int nPresent = 0;   // Number of keys that appear in 1st seq
    int nMulti = 0;     // Number of keys that appear more than once
    int nHits = 0;
    int trivkey = 0;    // Number of keys consisting of too little letters
    History history;

    // Rebuild hash table Index if necessary
    if (seq1.species_no != species_no || seq1.seq_no != seq_no) {
        if (!dict.empty()) dict.clear();
        dict.max_load_factor(1.0F);

        #ifdef FREQUENT_KEYS
        EqualCounters equalCounters;
        #endif
        Position position = 1;
        Position stoppos = (Position)seq1.str.size() - global.keysize;
        for ( ; position < stoppos; position += global.keystep) {
            string key = seq1.str.substr(position, global.keysize);
            int dlk = global.minletter % 10;
            if (dlk != 0 && countLetters(key) < dlk) {
                trivkey++;
                continue;   // skip keys with too little letters
            }
            #ifdef KEYPACK
            packKey(key);
            #endif

            #ifdef FREQUENT_KEYS
            // Check if the key is already too frequent
            EqualCounters::iterator eit = equalCounters.find(key);
            if (eit != equalCounters.end()) {
                eit->second++;
                continue;
            }

            // Compute current frequency of the key
            IndexRange range = dict.equal_range(key);
            int nEqual = 0;
            for (Index::iterator it = range.first; it != range.second; it++, nEqual++) ;

            // Store the key as too frequent if its frequency exceeds the limit
            if (global.frequency > 0 && nEqual > global.frequency) {
                equalCounters.insert( IndexPair(key, nEqual));
                continue;
            }
            #endif

            dict.insert( IndexPair(key, position));
        }

        // Delete frequent keys from the hash table
        #ifdef FREQUENT_KEYS
        Position nfk = (Position)equalCounters.size();
        Position fkmin=numeric_limits<unsigned int>::max( );
        Position fkmax=0, fkavg=0;
        for (EqualCounters::iterator eit=equalCounters.begin(); eit!=equalCounters.end(); eit++) {
            if (eit->second < fkmin) fkmin = eit->second;
            if (eit->second > fkmax) fkmax = eit->second;
            fkavg += eit->second;
            dict.erase(eit->first);
        }
        double avg = (nfk==0 ? 0 : (double)fkavg / nfk);
        #endif

        // Report on hash table built
        double t = getTimer();
        #ifdef FREQUENT_KEYS
        if (nfk > 0) {
            cout << (int)((t-global.t0)/60) << " m: " << nfk << " frequent keys removed";
            cout << " (min=" << fkmin << " max=" << fkmax << " avg=" << setprecision(6) << avg << ")"; 
            cout << endl;
        }
        #endif
        // Calculate statistics
        Position nkeys = 0;
        int nmax = 0;
        string oldkey;
        for (Index::iterator it = dict.begin(); it != dict.end(); it++) {
            if (it->first != oldkey) {
                oldkey = it->first;
                nkeys++;
                int nn = (int)dict.count(oldkey);
                if (nn > nmax)
                    nmax = nn;
            }
        }
        double navg = (double)dict.size() / nkeys;
        t = getTimer();
        cout << (int)((t-global.t0)/60) << " m: keys=" << position-1 << " triv="
            << trivkey << " unique=" << nkeys << " nmax=" << nmax << " navg=" 
            << setprecision(4) << navg << " Lf=" << setprecision(4) 
            << dict.load_factor() << " B=" << dict.bucket_count() << endl;
        species_no = seq1.species_no;
        seq_no     = seq1.seq_no;
    }

    // Process 2nd sequence
    trivkey = 0;
    Position position = 1;
    Position stoppos = (Position)seq2.str.size() - global.keysize;
    for ( ; position < stoppos; position += global.keystep) {
        nTotal++;
        string key = seq2.str.substr(position, global.keysize);
        int dlk = global.minletter % 10;
        if (dlk != 0 && countLetters(key) < dlk) {
            trivkey++;
            continue;   // skip keys with too little letters
        }
        #ifdef KEYPACK
        packKey(key);
        #endif

        // Check against hash table
        Index::iterator it = dict.find(key);
        if (it == dict.end()) continue;         // skip keys not from the hash table

        nPresent++;
        // Try equal keys in turn
        IndexRange range = dict.equal_range(key);
        if (range.first != range.second)
            nMulti++;
        for (it = range.first; it != range.second; it++) {
            Position p1 = it->second;
            Position p2 = position;
            int len1 = global.keysize;
            int len2 = global.keysize;

            #ifdef DEBUG_SEQUENCES
            if (outmode & D_SEQUENCES) {
                xlog << equal << "." << sub << ") \t"
                    << "1: " << p1 << "[" << len1 << "] \t"
                    << "2: " << p2 << "[" << len2 << "] \t"
                    << seq1.substr(p1, len1) << endl;
            }
            #endif      // DEBUG_SEQUENCES

            // My comparison with extending
            int err = (*mycompare)(seq1.str, seq2.str, p1, p2, len1, len2);
            if (err < 0) continue;

            // Check number of different letters
            int dlw = global.minletter / 10;
            if (dlw != 0 && (countLetters(seq1.str, p1, len1) < dlw ||
                             countLetters(seq2.str, p2, len2) < dlw) ) 
                continue;

            #ifdef ZCOMPLEXITY
            // Check compression ratio
            double ratio = global.maxratio > 0 ? Compression(seq1.str, p1, len1) : 0;
            if (ratio > global.maxratio) {
                #ifdef DEBUG_SEQUENCES
                if (outmode & D_SEQUENCES) {
                    xlog << "Max. ratio exceeded (" << ratio << ")\n" << endl;
                }
                #endif
                continue;
            }
            #endif      // ZCOMPLEXITY

            // Store in history if new
            Hit hit;
            hit.center1 = p1*2 + len1 - 1;
            hit.center2 = p2*2 + len2 - 1;
            __int64 keyhist = ((__int64)hit.center1 << 32) | hit.center2;
            
            if (history.find(keyhist) != history.end())
                continue;

            hit.size1 = (Position)len1;
            hit.size2 = (Position)len2;
            hit.score = (short)err;
            hit.strand2 = (short)strand;
            hit.ratio = (float)ratio;
            history.insert(HistoryPair(keyhist, hit));
            nHits++;
        }
    }
    // Output history to res
    History::const_iterator hi = history.begin();
    for ( ; hi != history.end(); hi++) {
        const Hit& hit = hi->second;
        ostringstream oss;
        oss << seq1.species_no << tab << seq1.seq_no << tab << hit.center1 << tab << hit.size1 << tab
            << seq2.species_no << tab << seq2.seq_no << tab << hit.center2 << tab << hit.size2 << tab
            << hit.strand2 << tab << hit.score << tab << setprecision(3) << fixed << hit.ratio << endl;
        res << oss.str();
    }

    // Output resume to the log
    map <int, int>::const_iterator mit = global.spec_nos.find(seq2.species_no);
    if (mit == global.spec_nos.end()) {
        cout << "Unknown organism " << seq2.species_no << "." << endl;
        abortEnvironment(7);
    }
    double t1 = getTimer();
    cout << (int)((t1-global.t0)/60) << " m: " << (strand>0 ? ">>" : "<<") 
        << global.species[mit->second].id << " ("  
        << seq2.species_no << ") seq_no=" << seq2.seq_no << " offset="
        << hex << seq2.head_pos << dec << " keys=" << nTotal << " triv=" 
        << trivkey << " present=" << nPresent << " multi=" << nMulti 
        << " hits=" << nHits << endl;
    return nHits;
}
