#!/bin/bash
cd data
./pairhits --nompi
if [ $? -eq 0 ]
then
  ls -1 hits/*.txt >hits/file.lst
  ./bldgraph --nompi
  if [ $? -eq 0 ]
  then
    ./findense --nompi
    if [ $? -eq 0 ]
    then
      echo "Example completed OK."
    else
      echo "Terminated due to errors."
    fi
  else
    echo "Terminated due to errors."
  fi
else
  echo "Terminated due to errors."
fi
cd ..
