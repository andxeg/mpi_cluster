// embed3GL: A program for phylogenetic study of joint gene & species evolution.
//
// The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/embed3gl]
//
// (C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
// E-mail: rubanov{at}iitp.ru
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// Functions: InsertSpecies, FindSpecies, FindKey, GetSpeciesCount, FillSpecies

#include <string>
#include <map>
#include <string.h>
#include "embed3gl.h"

using namespace std;

typedef map<string, int> STRING2INT;

static STRING2INT Stable;

// Return true on successful insertion of a species,
//  or false if such key already exists.
bool     InsertSpecies(char* name, int index) {
   string key(name);
   pair< STRING2INT::iterator, bool > ins;
   ins = Stable.insert( STRING2INT::value_type(key, index) );
   return ins.second;
}

// Return index of given key or 0 if not exists.
int      FindSpecies(char* name) {
   STRING2INT::const_iterator citer;
   string key(name);
   citer = Stable.find(key);
   return (citer == Stable.end()) ? 0 : citer->second;
}

// Return key for given index [complexity = O(n)]
const char*    FindKey(int index) {
   STRING2INT::const_iterator citer;
   citer = Stable.begin();
   while(citer != Stable.end()) {
      if(citer->second == index)
         return citer->first.c_str();
      citer++;
   }
   return 0;
}

// Return current number of species
int      GetSpeciesCount(void) {
   return (int)Stable.size();
}

// Fill array of structures, Species
void     FillSpecies(SPTABLE *species) {
   STRING2INT::const_iterator citer;
   citer = Stable.begin();
   while(citer != Stable.end()) {
      int index = citer->second;
      species[index].enable = false;
      strncpy(species[index].name, citer->first.c_str(), MAXNODENAME);
      citer++;
   }
   species[0].enable = true;
   strncpy(species[0].name, OutgroupName, MAXNODENAME);
}

// Delete a species from the list
void     DeleteSpecies(char* name) {
   string key(name);
   Stable.erase(key);
}
