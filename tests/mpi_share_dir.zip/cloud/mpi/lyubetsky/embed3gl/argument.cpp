// embed3GL: A program for phylogenetic study of joint gene & species evolution.
//
// The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/embed3gl]
//
// (C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
// E-mail: rubanov{at}iitp.ru
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// Functions: ParseArguments, PrintHelpInfo

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "embed3gl.h"

// Command line parser
// Return: true=OK, false=Error
bool     ParseArguments(int argc, char **argv) {
	DBG( printf("Command line:"); )
	DBG( for(int i = 0; i < argc; ++i) 
           printf(" %s", argv[i]); )
	DBG( printf("\n"); )

   for(int i = 1; i < argc; i++) {
      char option = argv[i][0];
      if(option != '-' && option != '/') {
         CON( printf("No prefix in option #%d.\n", i); )
         return false;
      }

      bool error = false;
      option = argv[i][1];
      switch( option ) {

         case 'A':               // Log file
         case 'a':
         case 'L':
         case 'l':
            if(++i < argc) {
               strncpy(LogFilename, argv[i], MAXPATH-1);
               CmdLogfile = true;
               LogAppend = (option == 'A' || option == 'a');
            }
            else 
               error = true;
            break;

         case 'C':               // Cost parameters
         case 'c':
            if(i + 1 < argc) {
               if(_stricmp(argv[i] + 1, "cbiga") == 0) {
                  c_gain_big = (int)(atof(argv[++i]) * SCALE);
                  Cmd_gain_big = true;
               }
               else if(_stricmp(argv[i] + 1, "cdupl") == 0) {
                  c_dupl = (int)(atof(argv[++i]) * SCALE);
                  Cmd_dupl = true;
               }
               else if(_stricmp(argv[i] + 1, "cgain") == 0) {
                  c_gain = (int)(atof(argv[++i]) * SCALE);
                  Cmd_gain = true;
               }
               else if(_stricmp(argv[i] + 1, "closs") == 0) {
                  c_loss = (int)(atof(argv[++i]) * SCALE);
                  Cmd_loss = true;
               }
               else if(_stricmp(argv[i] + 1, "closs1") == 0) {
                  c_loss1 = (int)(atof(argv[++i]) * SCALE);
                  Cmd_loss1 = true;
               }
               else if(_stricmp(argv[i] + 1, "ctrwi") == 0) {
                  c_tr_with = (int)(atof(argv[++i]) * SCALE);
                  Cmd_tr_with = true;
               }
               else if(_stricmp(argv[i] + 1, "ctrwo") == 0) {
                  c_tr_without = (int)(atof(argv[++i]) * SCALE);
                  Cmd_tr_without = true;
               }
               else if(_stricmp(argv[i] + 1, "cinit") == 0) {
                  c_init = (int)(atof(argv[++i]) * SCALE);
                  Cmd_init_cost = true;
               }
               else if(_stricmp(argv[i] + 1, "cexpo") == 0) {
                  c_exponent = atof(argv[++i]);
                  Cmd_exponent = true;
               }
               else if(_stricmp(argv[i] + 1, "corrk") == 0) {
                  k_correction = atof(argv[++i]);
                  Cmd_correction = true;
               }
               else if(_strnicmp(argv[i] + 1, "conf", 4) == 0 || 
                       _stricmp(argv[i] + 1, "c") == 0){
                  if(++i < argc)
                     strncpy(ConfigFilename, argv[i], MAXPATH-1);
                  else 
                     error = true;
               }
               else {
                  ++i;
                  error = true;
               }
            }
            else 
               error = true;
            break;

         case 'G':               // Gene tree
         case 'g':
            if(++i < argc) {
               GTNAME* gtname = (GTNAME*)malloc(sizeof(GTNAME));
               char* filename = (char*)malloc( strlen(argv[i]) + 1 );
               if(!gtname || !filename) {
                  CON( printf("ARG: Not enough memory.\n"); )
                  return false;
               }
               if(MemoryCount) {
                  MemUsed[housekeeping] += M16(sizeof(GTNAME));
                  MemUsed[housekeeping] += M16(strlen(argv[i]) + 1);
               }
               strcpy(filename, argv[i]);
               gtname->filename = filename;
               gtname->next = NULL;

               // Insert in GTNAME list
               if(GeneTreeNameLast)
                  GeneTreeNameLast->next = gtname;
               else 
                  GeneTreeNameFirst = gtname;
               GeneTreeNameLast = gtname;
            }
            else 
               error = true;
            break;

         case 'H':               // Help
         case 'h':
         case '?':
            PrintHelpInfo();
            return false;

         case 'I':               // Configuration 
         case 'i':
         case 'Q':
         case 'q':
            if(++i < argc)
               strncpy(ConfigFilename, argv[i], MAXPATH-1);
            else 
               error = true;
            break;

         case 'K':               // Max number of best events to hold
         case 'k':
            if(++i < argc) {
               MaxEvents = atoi(argv[i]);
               if(MaxEvents < 1)
                  error = true;
               CmdMaxEvents = true;
            }
            else 
               error = true;
            break;

         case 'N':
         case 'n':
            if(_stricmp(argv[i] + 1, "nompi") == 0) {
               #ifdef   EMBED3MPI
               embed3_mpi = false;
               #endif
            }
            else
               error = true;
            break;

         case 'O':               // Console output mode
         case 'o':
            if(++i < argc) {
               int outmode = atoi(argv[i]);
               Console     = ((outmode & 1) != 0);
               Console2Log = ((outmode & 2) != 0);
               #ifdef   EMBED3MPI
               if((outmode & 4) == 0 && rank_mpi != 0) 
                  Console = false;
               #endif
            }
            else 
               error = true;
            break;

         case 'R':
         case 'r':
            r_shift = atof(argv[i]);
            Cmd_shift = true;
            break;

         case 'S':               // Species tree
         case 's':
            if(++i < argc) {
               strncpy(SpeciesTreeName, argv[i], MAXPATH-1);
               CmdSpeciesTree = true;
            }
            else 
               error = true;
            break;

         case 'W':               // Min weight
         case 'w':
            if(++i < argc) {
               MinWeight = atof(argv[i]);
               MinWeightGiven = true;
            }
            else
               error = true;
            break;

         case '-':               // --options
         case '/':
            option = argv[i][2];
            switch( option ) {
               case 'A':               // Log file mode switched
               case 'a':
               case 'L':
               case 'l':
                  if(++i < argc) {
                     strncpy(LogFilename, argv[i], MAXPATH-1);
                     CmdLogfile = true;
                     LogAppend = (option == 'L' || option == 'l');
                  }
                  else 
                     error = true;
                  break;

               case 'G':               // Gene tree (exclusive)
               case 'g':
                  CmdNoGeneTrees = true;     // exclusion
                  if(++i < argc) {
                     GTNAME* gtname = (GTNAME*)malloc(sizeof(GTNAME));
                     char* filename = (char*)malloc( strlen(argv[i]) + 1 );
                     if(!gtname || !filename) {
                        CON( printf("ARG: Not enough memory.\n"); )
                        return false;
                     }
                     if(MemoryCount) {
                        MemUsed[housekeeping] += M16(sizeof(GTNAME));
                        MemUsed[housekeeping] += M16(strlen(argv[i]) + 1);
                     }
                     strcpy(filename, argv[i]);
                     gtname->filename = filename;
                     gtname->next = NULL;

                     // Insert in GTNAME list
                     if(GeneTreeNameLast)
                        GeneTreeNameLast->next = gtname;
                     else 
                        GeneTreeNameFirst = gtname;
                     GeneTreeNameLast = gtname;
                  }
                  else 
                     error = true;
                  break;

               case 'M':
               case 'm':
                  if(_stricmp(argv[i] + 2, "mpi") == 0) {
                     #ifdef   EMBED3MPI
                     embed3_mpi = false;
                     #endif
                  }
                  else
                     error = true;
                  break;

               case 'W':
               case 'w':
                  TreeWeight = false;
                  MinWeightGiven = true;
                  break;

              default:
                  CON( printf("Unknown option '--%c' (#%d).\n", option, i); )
                  return false;
            }
            break;

         default:
            CON( printf("Unknown option '-%c' (#%d).\n", option, i); )
            return false;
      }
      if(error) {
         CON( printf("Error in option '%c'.\n", option); )
         return false;
      }
   }        // Next option

	return true;
}

void     PrintHelpInfo(void) {
   int outmode = 0;
   if(Console)       outmode ++;
   if(Console2Log)   outmode += 2;
   CON( printf(
      "Command line arguments recognized (all option keys are case insensitive):\n"
      "-a pathname : output log file (append mode),       --a : overwrite mode\n"
      "-cbiga cost : cost of \"big\" gain (default %g)\n"
      "-cdupl cost : cost of gene duplication (default %g)\n"
      "-cgain cost : cost of gene gain (default %g)\n"
      "-closs cost : cost of gene loss (default %g)\n"
      "-closs1 cost: cost of questionable gene loss (default %g)\n"
      "-ctrwi cost : cost of gene transfer with retaining (default %g)\n"
      "-ctrwo cost : cost of gene transfer without retaining (default %g)\n"
      "-cinit cost : initial shift of zero cost (default %g)\n"
      "-cexpo real : exponent to raise the cost ratio (default %g)\n"
      "-corrk real : log2(k) factor to correct costs of transfer (default %g)\n"
      "-g pathname : file of gene tree(s) in Newick form, --g : override [also -t]\n"
      "-h          : show help\n"
      "-i pathname : configuration file (default %s in working dir) [-c -q]\n"
      "-k number   : number of best events to hold (default %d)\n"
      "-l pathname : output log file (overwrite mode),    --l : append mode\n"
      , c_gain_big/SCALE, c_dupl/SCALE, c_gain/SCALE, c_loss/SCALE, 
      c_loss1/SCALE, c_tr_with/SCALE, c_tr_without/SCALE, c_init/SCALE, 
      c_exponent, k_correction, ConfigFilename, MaxEvents); )
   #ifdef   EMBED3MPI
   CON( printf(
      "-nompi      : do not use MPI (--mpi does the same), otherwise use if present\n"); )
   #endif
   CON( printf(
      "-o outmode  : 1=con[0] 2=con2log 4=con[*] (default %d)\n"
      "-r number   : reliability shift (default %g)\n"
      "-s pathname : file of species tree in Newick form (overrides config data)\n"
      "-w real     : min weight to multiply (default %g),  --w : disable weights\n\n"
      , outmode, r_shift, MinWeight); )
}
