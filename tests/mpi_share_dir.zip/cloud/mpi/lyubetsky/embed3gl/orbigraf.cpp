// embed3GL: A program for phylogenetic study of joint gene & species evolution.
//
// The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/embed3gl]
//
// (C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
// E-mail: rubanov{at}iitp.ru
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// Functions: CreateOgraph, DestructOgraph, BuildOgNode, RunForward3,
//            Itype2Name, Itype2Index, ProcessOgNode, RunBackward3,
//            LoggingOgraph, LoggingTmarkStats, LoggingTubeStats

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <math.h>
#include "embed3gl.h"

// Allocate & clear orbigraph matrix w/o edges
bool     CreateOgraph(void) {
   Ograph = (OGNODE**)malloc((Gtree->nedges + 1) * sizeof(OGNODE*));
   if(!Ograph) {
      CON( printf("STA: Not enough memory for orbigraph.\n"); )
      LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
      return false;
   }
   if(MemoryCount) {
      MemUsed[ognodes] += M16((Gtree->nedges + 1) * sizeof(OGNODE*));
   }
   Ograph[0] = NULL;    // to enumerate edges from 1
   for(int e = 1; e <= Gtree->nedges; e++) {
      Ograph[e] = (OGNODE*)malloc((Stree->ntubes + 1) * sizeof(OGNODE));
      if(!Ograph[e]) {
         CON( printf("STA: Not enough memory for orbigraph.\n"); )
         LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
         return false;
      }
      if(MemoryCount) {
         MemUsed[ognodes] += M16((Stree->ntubes + 1) * sizeof(OGNODE));
      }
      EDGE* edge        = Gtree->edges[e];
      OGNODE*  ognode   = Ograph[e];
      for(int t = 0; t <= Stree->ntubes; t++,ognode++) {
         ognode->edge      = t ? edge : NULL;
         ognode->tube      = t ? Stree->tubes[t] : NULL;
         ognode->firstin   = NULL;
         ognode->firstout  = NULL;
         ognode->lastin    = NULL;
         ognode->lastout   = NULL;
         ognode->ped       = 0.0;
      }
   }
   return true;
}

// Destruct orbigraph (both matrix and edges)
void     DestructOgraph(void) {
   if(!Ograph) return;
   for(int e = 1; e <= Gtree->nedges; e++) {
      OGNODE*  ognode   = Ograph[e];
      if(!ognode) continue;
      for(int t = 0; t <= Stree->ntubes; t++,ognode++) {
         OGEDGE* ogedge = ognode->firstout;
         while(ogedge) {
            if(ogedge->triples) {
               free(ogedge->triples);
               if(MemoryCount)
                  MemUsed[freedmem] += M16(ogedge->ntriples * sizeof(TRIPLE));
            }
            OGEDGE* next = ogedge->nextout;
            free(ogedge);
            if(MemoryCount) {
               MemUsed[freedmem] += M16(sizeof(OGEDGE));
            }
            ogedge = next;
         }
      }
      free(Ograph[e]);
      if(MemoryCount) {
         MemUsed[freedmem] += M16((Stree->ntubes + 1) * sizeof(OGNODE));
      }
   }
   free(Ograph);
   if(MemoryCount) {
      MemUsed[freedmem] += M16((Gtree->nedges + 1) * sizeof(OGNODE*));
   }
   Ograph = NULL;
}

// Build orbigraph node (true=ok, false=error)
#ifdef __GNUC__
#pragma warning(disable: 589)
#endif
bool     BuildOgNode(OGNODE* ognode) {
   EDGE* edge  = ognode->edge;
   TUBE* tube  = ognode->tube;
   int e       = edge->edgeno;
   int d       = tube->tubeno;
   EVENT* evt  = edge->events[d];
   TRIPLE* t   = NULL;
   int shift = 0x7FFFFFFF; // first use to find min cost
   double norm = 0.0;      // factor for pi calculation
   // Confirm that at least one event exist for this pair
   if(evt->id == id_none) {
      CON( printf("STA: No event found for <%s=%d,%s=%d>.\n",
         edge->name, e, tube->name, d); )
      LOG( fprintf(Log, "STA: No event found for <%s=%d,%s=%d>.\n",
         edge->name, e, tube->name, d); )
      goto Error;
   }
   // Handle leaf pairs and zero cost cases
   if(evt->id == id_fin) {                            // fin
      // No outbound edges
      return true;
   }
   if(evt->id == id_tr_fin) {                         // tr_fin 
      OGEDGE* ogedge = (OGEDGE*)malloc(sizeof(OGEDGE));
      if( !ogedge ) {
         CON( printf("STA: Not enough memory for orbigraph.\n"); )
         LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
         goto Error;
      }
      if(MemoryCount) {
         MemUsed[ogedges] += M16(sizeof(OGEDGE));
      }
      ogedge->from      = ognode;
      ogedge->to        = &Ograph[e][evt->d1];
      ogedge->nextin    = NULL;
      ogedge->nextout   = NULL;
      ogedge->twin      = NULL;
      ogedge->pi        = 1.0;
      ogedge->to        = &Ograph[e][evt->d1];
      ogedge->ntriples  = 3; 
      ogedge->triples   = (TRIPLE*)malloc(ogedge->ntriples * sizeof(TRIPLE));
      if(!ogedge->triples) {
         CON( printf("STA: Not enough memory for orbigraph.\n"); )
         LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
         goto Error;
      }
      if(MemoryCount) {
         MemUsed[ogtriples] += M16(ogedge->ntriples * sizeof(TRIPLE));
      }
      t                 = ogedge->triples;
      t[0].Itype        = I_tr_o;
      t[0].edge         = edge;
      t[0].edge2        = NULL;
      t[0].tube         = tube;
      t[0].tube2        = NULL;
      t[1].Itype        = I_tr_i;
      t[1].edge         = edge;
      t[1].edge2        = NULL;
      t[1].tube         = Stree->tubes[evt->d1];
      t[1].tube2        = NULL;
      t[2].Itype        = I_loss;
      t[2].edge         = edge;
      t[2].edge2        = NULL;
      t[2].tube         = tube;
      t[2].tube2        = NULL;
      // Insert this edge into from-node outbound list
      if(ogedge->from->lastout)
         ogedge->from->lastout->nextout   = ogedge;
      else
         ogedge->from->firstout           = ogedge;
      ogedge->from->lastout               = ogedge;
      // Insert this edge into to-node inbound list
      if(ogedge->to->lastin)
         ogedge->to->lastin->nextin       = ogedge;
      else
         ogedge->to->firstin              = ogedge;
      ogedge->to->lastin                  = ogedge;
      OgUnary++;
      OgTriples += ogedge->ntriples;
      return true;
   }
   if(evt->id == id_ga_fin) {                         // ga_fin
      OGEDGE* ogedge = (OGEDGE*)malloc(sizeof(OGEDGE));
      if( !ogedge ) {
         CON( printf("STA: Not enough memory for orbigraph.\n"); )
         LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
         goto Error;
      }
      if(MemoryCount) {
         MemUsed[ogedges] += M16(sizeof(OGEDGE));
      }
      ogedge->from      = ognode;
      ogedge->to        = &Ograph[e][evt->d1];
      ogedge->nextin    = NULL;
      ogedge->nextout   = NULL;
      ogedge->twin      = NULL;
      ogedge->pi        = 1.0;
      ogedge->to        = &Ograph[e][evt->d1];
      ogedge->ntriples  = 1; 
      ogedge->triples   = (TRIPLE*)malloc(sizeof(TRIPLE));
      if(!ogedge->triples) {
         CON( printf("STA: Not enough memory for orbigraph.\n"); )
         LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
         goto Error;
      }
      if(MemoryCount) {
         MemUsed[ogtriples] += M16(ogedge->ntriples * sizeof(TRIPLE));
      }
      t                 = ogedge->triples;
      t[0].Itype        = I_gain;
      t[0].edge         = edge;
      t[0].edge2        = NULL;
      t[0].tube         = Stree->tubes[evt->d1];
      t[0].tube2        = NULL;
      // Insert this edge into from-node outbound list
      if(ogedge->from->lastout)
         ogedge->from->lastout->nextout   = ogedge;
      else
         ogedge->from->firstout           = ogedge;
      ogedge->from->lastout               = ogedge;
      // Insert this edge into to-node inbound list
      if(ogedge->to->lastin)
         ogedge->to->lastin->nextin       = ogedge;
      else
         ogedge->to->firstin              = ogedge;
      ogedge->to->lastin                  = ogedge;
      OgUnary++;
      OgTriples += ogedge->ntriples;
      return true;
   }
   if(evt->cost == 0) {    // Draw single outbound (bi)edge
      OGEDGE* ogedge = (OGEDGE*)malloc(sizeof(OGEDGE));
      if( !ogedge ) {
         CON( printf("STA: Not enough memory for orbigraph.\n"); )
         LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
         goto Error;
      }
      if(MemoryCount) {
         MemUsed[ogedges] += M16(sizeof(OGEDGE));
      }
      OGEDGE* ogedge2 = NULL;
      int id = evt->id;
      if(id == id_fork_lr || id == id_fork_rl ||
         id == id_dup0_l  || id == id_dup0_r  || id == id_outd) {
            ogedge2 = (OGEDGE*)malloc(sizeof(OGEDGE));
            if( !ogedge2 ) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogedges] += M16(sizeof(OGEDGE));
            }
      }
      switch(evt->id) {
         case id_pass: {                              // pass
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[e][evt->d1];
            ogedge->nextin    = NULL;
            ogedge->nextout   = NULL;
            ogedge->twin      = NULL;
            ogedge->ntriples  = 0;
            ogedge->triples   = NULL;
            ogedge->pi        = 1.0;
            OgUnary++;
            break;     }
         case id_fork_lr:                             // fork_lr
         case id_fork_rl: {                           // fork_rl
            EDGE *le, *re;
            if(evt->id == id_fork_lr) {
               le = edge->child;
               re = edge->child->sibling;
            }
            else {
               le = edge->child->sibling;
               re = edge->child;
            }
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[le->edgeno][tube->left->tubeno];
            ogedge->nextin    = NULL;
            ogedge->nextout   = ogedge2;
            ogedge->twin      = ogedge2;
            ogedge->ntriples  = 0;
            ogedge->triples   = NULL;
            ogedge->pi        = 1.0;
            ogedge2->from     = ognode;
            ogedge2->to       = &Ograph[re->edgeno][tube->right->tubeno];
            ogedge2->nextin   = NULL;
            ogedge2->nextout  = NULL;
            ogedge2->twin     = ogedge;
            ogedge2->ntriples = 0;
            ogedge2->triples  = NULL;
            ogedge2->pi       = 1.0;
            OgBinary++;
            break;        }
         case id_nout_l:                              // nout_l
         case id_out_l: {                             // out_l
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[e][tube->left->tubeno];
            ogedge->nextin    = NULL;
            ogedge->nextout   = NULL;
            ogedge->twin      = NULL;
            ogedge->ntriples  = 0;
            ogedge->triples   = NULL;
            ogedge->pi        = 1.0;
            OgUnary++;
            break;      }
         case id_nout_r:                              // nout_r
         case id_out_r: {                             // out_r
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[e][tube->right->tubeno];
            ogedge->nextin    = NULL;
            ogedge->nextout   = NULL;
            ogedge->twin      = NULL;
            ogedge->ntriples  = 0;
            ogedge->triples   = NULL;
            ogedge->pi        = 1.0;
            OgUnary++;
            break;      }
         case id_dup0_l:                              // dup0_l
         case id_dup0_r: {                            // dup0_l
            EDGE *le, *re;
            if(evt->id == id_dup0_l) {
               le = edge->child;
               re = edge->child->sibling;
            }
            else {
               le = edge->child->sibling;
               re = edge->child;
            }
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[le->edgeno][d];
            ogedge->nextin    = NULL;
            ogedge->nextout   = ogedge2;
            ogedge->twin      = ogedge2;
            ogedge->ntriples  = 0;
            ogedge->triples   = NULL;
            ogedge->pi        = 1.0;
            int dz            = Stree->slices[Stree->height-1].tubes[0]->tubeno;
            ogedge2->from     = ognode;
            ogedge2->to       = &Ograph[re->edgeno][dz];
            ogedge2->nextin   = NULL;
            ogedge2->nextout  = NULL;
            ogedge2->twin     = ogedge;
            ogedge2->ntriples = 0;
            ogedge2->triples  = NULL;
            ogedge2->pi       = 1.0;
            OgBinary++;
            break;       }
         case id_outd: {                              // outd
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[edge->child->edgeno][d];
            ogedge->nextin    = NULL;
            ogedge->nextout   = ogedge2;
            ogedge->twin      = ogedge2;
            ogedge->ntriples  = 0;
            ogedge->triples   = NULL;
            ogedge->pi        = 1.0;
            ogedge2->from     = ognode;
            ogedge2->to       = &Ograph[edge->child->sibling->edgeno][d];
            ogedge2->nextin   = NULL;
            ogedge2->nextout  = NULL;
            ogedge2->twin     = ogedge;
            ogedge2->ntriples = 0;
            ogedge2->triples  = NULL;
            ogedge2->pi       = 1.0;
            OgBinary++;
            break;     }
         default:       {
            CON( printf("STA: Zero cost event %s found for <%s=%d,%s=%d>.\n",
               EventNames[evt->id], edge->name, e, tube->name, d); )
            LOG( fprintf(Log, "STA: Zero cost event %s found for <%s=%d,%s=%d>.\n",
               EventNames[evt->id], edge->name, e, tube->name, d); )
            goto Error; }
      }
      // Insert this (bi)edge into from-node outbound list
      if(ogedge->from->lastout)
         ogedge->from->lastout->nextout   = ogedge;
      else
         ogedge->from->firstout           = ogedge;
      ogedge->from->lastout               = ogedge2 ? ogedge2 : ogedge;
      // Insert this (bi)edge into to-node inbound list
      if(ogedge->to->lastin)
         ogedge->to->lastin->nextin       = ogedge;
      else
         ogedge->to->firstin              = ogedge;
      ogedge->to->lastin                  = ogedge;
      if(ogedge2) {
         if(ogedge2->to->lastin)
            ogedge2->to->lastin->nextin   = ogedge2;
         else
            ogedge2->to->firstin          = ogedge2;
         ogedge2->to->lastin              = ogedge2;
      }
      OgTriples += ogedge->ntriples;
      return true;
   }
   // Handle pairs in general case
   for(int k = 0; k < MaxEvents; k++) {
      if(evt[k].id == id_none) break;
      else if(evt[k].cost < shift)
         shift = evt[k].cost;
   }
   shift      -= c_init;   // since now, cost offset
   for(int k = 0; k < MaxEvents; k++) {
      if(evt[k].id == id_none) break;
      else {
         double d = SCALE / (evt[k].cost - shift);
         norm    += pow(d, c_exponent);
      }
   }
   norm = pow(SCALE, c_exponent) / norm;
   // Draw outbound (bi)edges
   for(int k = 0; k < MaxEvents; k++) {
      if(evt[k].id == id_none) break;
      OGEDGE* ogedge = (OGEDGE*)malloc(sizeof(OGEDGE));
      if( !ogedge ) {
         CON( printf("STA: Not enough memory for orbigraph.\n"); )
         LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
         goto Error;
      }
      if(MemoryCount) {
         MemUsed[ogedges] += M16(sizeof(OGEDGE));
      }
      OGEDGE* ogedge2 = NULL;
      int id = evt[k].id;
      if(id == id_fork_lr || id == id_fork_rl || id == id_dupl    ||
         id == id_dup0_l  || id == id_dup0_r  || id == id_outd    || 
         id == id_tr1     || id == id_tr2     || id == id_ga1     || 
         id == id_ga2     || id == id_tr_lr   || id == id_tr_rl   || 
         id == id_ga_lr   || id == id_ga_rl   || id == id_tr_dupl || 
         id == id_ga_dupl || id == id_tr      || id == id_ga) {
            ogedge2 = (OGEDGE*)malloc(sizeof(OGEDGE));
            if( !ogedge2 ) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogedges] += M16(sizeof(OGEDGE));
            }
      }
      switch(evt[k].id) {
         case id_pass: {                              // pass
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[e][evt[k].d1];
            ogedge->nextin    = NULL;
            ogedge->nextout   = NULL;
            ogedge->twin      = NULL;
            ogedge->ntriples  = 0;
            ogedge->triples   = NULL;
            ogedge->pi        = norm / pow((double)(evt[k].cost - shift), c_exponent);
            OgUnary++;
            break;     }
         case id_fork_lr:                             // fork_lr
         case id_fork_rl: {                           // fork_rl
            EDGE *le, *re;
            if(evt[k].id == id_fork_lr) {
               le = edge->child;
               re = edge->child->sibling;
            }
            else {
               le = edge->child->sibling;
               re = edge->child;
            }
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[le->edgeno][tube->left->tubeno];
            ogedge->nextin    = NULL;
            ogedge->nextout   = ogedge2;
            ogedge->twin      = ogedge2;
            ogedge->ntriples  = 0;
            ogedge->triples   = NULL;
            ogedge->pi        = norm / pow((double)(evt[k].cost - shift), c_exponent);
            ogedge2->from     = ognode;
            ogedge2->to       = &Ograph[re->edgeno][tube->right->tubeno];
            ogedge2->nextin   = NULL;
            ogedge2->nextout  = NULL;
            ogedge2->twin     = ogedge;
            ogedge2->ntriples = 0;
            ogedge2->triples  = NULL;
            ogedge2->pi       = norm / pow((double)(evt[k].cost - shift), c_exponent);
            OgBinary++;
            break;        }
         case id_pass_l:                              // pass_l
         case id_pass_r: {                            // pass_r
            TUBE *ld, *rd;
            if(evt[k].id == id_pass_l) {
               ld = tube->left;
               rd = tube->right;
            }
            else {
               ld = tube->right;
               rd = tube->left;
            }
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[e][ld->tubeno];
            ogedge->nextin    = NULL;
            ogedge->nextout   = NULL;
            ogedge->twin      = NULL;
            ogedge->ntriples  = 1;
            ogedge->triples   = (TRIPLE*)malloc(sizeof(TRIPLE));
            if(!ogedge->triples) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogtriples] += M16(ogedge->ntriples * sizeof(TRIPLE));
            }
            ogedge->pi        = norm / pow((double)(evt[k].cost - shift), c_exponent);
            t                 = ogedge->triples;
            t[0].Itype        = (evt[k].d2 == -c_loss1) ? I_loss1 : I_loss;
            t[0].edge         = edge;
            t[0].edge2        = NULL;
            t[0].tube         = rd;
            t[0].tube2        = NULL;
            OgUnary++;
            break;       }
         case id_nout_l:                              // nout_l
         case id_out_l: {                             // out_l
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[e][tube->left->tubeno];
            ogedge->nextin    = NULL;
            ogedge->nextout   = NULL;
            ogedge->twin      = NULL;
            ogedge->ntriples  = 0;
            ogedge->triples   = NULL;
            ogedge->pi        = norm / pow((double)(evt[k].cost - shift), c_exponent);
            OgUnary++;
            break;      }
         case id_nout_r:                              // nout_r
         case id_out_r: {                             // out_r
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[e][tube->right->tubeno];
            ogedge->nextin    = NULL;
            ogedge->nextout   = NULL;
            ogedge->twin      = NULL;
            ogedge->ntriples  = 0;
            ogedge->triples   = NULL;
            ogedge->pi        = norm / pow((double)(evt[k].cost - shift), c_exponent);
            OgUnary++;
            break;      }
         case id_dupl: {                              // dupl
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[edge->child->edgeno][d];
            ogedge->nextin    = NULL;
            ogedge->nextout   = ogedge2;
            ogedge->twin      = ogedge2;
            ogedge->ntriples  = 1;
            ogedge->triples   = (TRIPLE*)malloc(sizeof(TRIPLE));
            if(!ogedge->triples) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogtriples] += M16(ogedge->ntriples * sizeof(TRIPLE));
            }
            ogedge->pi        = norm / pow((double)(evt[k].cost - shift), c_exponent);
            t                 = ogedge->triples;
            t[0].Itype        = I_dupl;
            t[0].edge         = edge;
            t[0].edge2        = NULL;
            t[0].tube         = tube;
            t[0].tube2        = NULL;
            ogedge2->from     = ognode;
            ogedge2->to       = &Ograph[edge->child->sibling->edgeno][d];
            ogedge2->nextin   = NULL;
            ogedge2->nextout  = NULL;
            ogedge2->twin     = ogedge;
            ogedge2->ntriples = 1;
            ogedge2->triples  = (TRIPLE*)malloc(sizeof(TRIPLE));
            if(!ogedge2->triples) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogtriples] += M16(ogedge2->ntriples * sizeof(TRIPLE));
            }
            ogedge2->pi       = norm / pow((double)(evt[k].cost - shift), c_exponent);
            t                 = ogedge2->triples;
            t[0].Itype        = I_dupl;
            t[0].edge         = edge;
            t[0].edge2        = NULL;
            t[0].tube         = tube;
            t[0].tube2        = NULL;
            OgBinary++;
            break;     }
         case id_dup0_l:                              // dup0_l
         case id_dup0_r: {                            // dup0_r
            EDGE *le, *re;
            if(evt->id == id_dup0_l) {
               le = edge->child;
               re = edge->child->sibling;
            }
            else {
               le = edge->child->sibling;
               re = edge->child;
            }
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[le->edgeno][d];
            ogedge->nextin    = NULL;
            ogedge->nextout   = ogedge2;
            ogedge->twin      = ogedge2;
            ogedge->ntriples  = 0;
            ogedge->triples   = NULL;
            ogedge->pi        = norm / pow((double)(evt[k].cost - shift), c_exponent);
            int dz            = Stree->slices[Stree->height-1].tubes[0]->tubeno;
            ogedge2->from     = ognode;
            ogedge2->to       = &Ograph[re->edgeno][dz];
            ogedge2->nextin   = NULL;
            ogedge2->nextout  = NULL;
            ogedge2->twin     = ogedge;
            ogedge2->ntriples = 0;
            ogedge2->triples  = NULL;
            ogedge2->pi       = norm / pow((double)(evt[k].cost - shift), c_exponent);
            OgBinary++;
            break;     }
         case id_outd: {                              // outd
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[edge->child->edgeno][d];
            ogedge->nextin    = NULL;
            ogedge->nextout   = ogedge2;
            ogedge->twin      = ogedge2;
            ogedge->ntriples  = 0;
            ogedge->triples   = NULL;
            ogedge->pi        = norm / pow((double)(evt[k].cost - shift), c_exponent);
            ogedge2->from     = ognode;
            ogedge2->to       = &Ograph[edge->child->sibling->edgeno][d];
            ogedge2->nextin   = NULL;
            ogedge2->nextout  = NULL;
            ogedge2->twin     = ogedge;
            ogedge2->ntriples = 0;
            ogedge2->triples  = NULL;
            ogedge2->pi       = norm / pow((double)(evt[k].cost - shift), c_exponent);
            OgBinary++;
            break;     }
         case id_tr1:                                 // tr1
         case id_tr2: {                               // tr2
            EDGE *le, *re;
            if(evt[k].id == id_tr1) {
               le = edge->child;
               re = edge->child->sibling;
            }
            else {
               le = edge->child->sibling;
               re = edge->child;
            }
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[le->edgeno][evt[k].d1];
            ogedge->nextin    = NULL;
            ogedge->nextout   = ogedge2;
            ogedge->twin      = ogedge2;
            ogedge->ntriples  = 2;
            ogedge->triples   = (TRIPLE*)malloc(ogedge->ntriples * sizeof(TRIPLE));
            if(!ogedge->triples) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogtriples] += M16(ogedge->ntriples * sizeof(TRIPLE));
            }
            ogedge->pi        = norm / pow((double)(evt[k].cost - shift), c_exponent);
            t                 = ogedge->triples;
            t[0].Itype        = I_tr_o;
            t[0].edge         = le;
            t[0].edge2        = NULL;
            t[0].tube         = tube;
            t[0].tube2        = NULL;
            t[1].Itype        = I_tr_i;
            t[1].edge         = le;
            t[1].edge2        = NULL;
            t[1].tube         = Stree->tubes[evt[k].d1];
            t[1].tube2        = NULL;
            ogedge2->from     = ognode;
            ogedge2->to       = &Ograph[re->edgeno][d];
            ogedge2->nextin   = NULL;
            ogedge2->nextout  = NULL;
            ogedge2->twin     = ogedge;
            ogedge2->ntriples = 2;
            ogedge2->triples  = (TRIPLE*)malloc(ogedge2->ntriples * sizeof(TRIPLE));
            if(!ogedge2->triples) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogtriples] += M16(ogedge2->ntriples * sizeof(TRIPLE));
            }
            ogedge2->pi       = norm / pow((double)(evt[k].cost - shift), c_exponent);
            t                 = ogedge2->triples;
            t[0].Itype        = I_tr_o;
            t[0].edge         = le;
            t[0].edge2        = NULL;
            t[0].tube         = tube;
            t[0].tube2        = NULL;
            t[1].Itype        = I_tr_i;
            t[1].edge         = le;
            t[1].edge2        = NULL;
            t[1].tube         = Stree->tubes[evt[k].d1];
            t[1].tube2        = NULL;
            OgBinary++;
            break;    }
         case id_ga1:                                 // ga1
         case id_ga2: {                               // ga2
            EDGE *le, *re;
            if(evt[k].id == id_ga1) {
               le = edge->child;
               re = edge->child->sibling;
            }
            else {
               le = edge->child->sibling;
               re = edge->child;
            }
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[le->edgeno][evt[k].d1];
            ogedge->nextin    = NULL;
            ogedge->nextout   = ogedge2;
            ogedge->twin      = ogedge2;
            ogedge->ntriples  = 1;
            ogedge->triples   = (TRIPLE*)malloc(sizeof(TRIPLE));
            if(!ogedge->triples) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogtriples] += M16(ogedge->ntriples * sizeof(TRIPLE));
            }
            ogedge->pi        = norm / pow((double)(evt[k].cost - shift), c_exponent);
            t                 = ogedge->triples;
            t[0].Itype        = I_gain;
            t[0].edge         = le;
            t[0].edge2        = NULL;
            t[0].tube         = Stree->tubes[evt[k].d1];
            t[0].tube2        = NULL;
            ogedge2->from     = ognode;
            ogedge2->to       = &Ograph[re->edgeno][d];
            ogedge2->nextin   = NULL;
            ogedge2->nextout  = NULL;
            ogedge2->twin     = ogedge;
            ogedge2->ntriples = 1;
            ogedge2->triples  = (TRIPLE*)malloc(sizeof(TRIPLE));
            if(!ogedge2->triples) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogtriples] += M16(ogedge2->ntriples * sizeof(TRIPLE));
            }
            ogedge2->pi       = norm / pow((double)(evt[k].cost - shift), c_exponent);
            t                 = ogedge2->triples;
            t[0].Itype        = I_gain;
            t[0].edge         = le;
            t[0].edge2        = NULL;
            t[0].tube         = Stree->tubes[evt[k].d1];
            t[0].tube2        = NULL;
            OgBinary++;
            break;    }
         case id_ga_big: {                            // ga_big
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[e][evt[k].d1];
            ogedge->nextin    = NULL;
            ogedge->nextout   = NULL;
            ogedge->twin      = NULL;
            ogedge->ntriples  = 1;
            ogedge->triples   = (TRIPLE*)malloc(sizeof(TRIPLE));
            if(!ogedge->triples) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogtriples] += M16(ogedge->ntriples * sizeof(TRIPLE));
            }
            ogedge->pi        = norm / pow((double)(evt[k].cost - shift), c_exponent);
            t                 = ogedge->triples;
            t[0].Itype        = I_gain_big;
            t[0].edge         = edge;
            t[0].edge2        = NULL;
            t[0].tube         = Stree->tubes[evt[k].d1];
            t[0].tube2        = NULL;
            OgUnary++;
            break;   }
         case id_tr_pass: {                           // tr_pass
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[e][evt[k].d2];
            ogedge->nextin    = NULL;
            ogedge->nextout   = NULL;
            ogedge->twin      = NULL;
            ogedge->ntriples  = 3;
            ogedge->triples   = (TRIPLE*)malloc(ogedge->ntriples * sizeof(TRIPLE));
            if(!ogedge->triples) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogtriples] += M16(ogedge->ntriples * sizeof(TRIPLE));
            }
            ogedge->pi        = norm / pow((double)(evt[k].cost - shift), c_exponent);
            t                 = ogedge->triples;
            t[0].Itype        = I_tr_o;
            t[0].edge         = edge;
            t[0].edge2        = NULL;
            t[0].tube         = tube;
            t[0].tube2        = NULL;
            t[1].Itype        = I_tr_i;
            t[1].edge         = edge;
            t[1].edge2        = NULL;
            t[1].tube         = Stree->tubes[evt[k].d1];
            t[1].tube2        = NULL;
            t[2].Itype        = I_loss;
            t[2].edge         = edge;
            t[2].edge2        = NULL;
            t[2].tube         = tube;
            t[2].tube2        = NULL;
            OgUnary++;
            break;        }
         case id_ga_pass: {                           // ga_pass
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[e][evt[k].d2];
            ogedge->nextin    = NULL;
            ogedge->nextout   = NULL;
            ogedge->twin      = NULL;
            ogedge->ntriples  = 1;
            ogedge->triples   = (TRIPLE*)malloc(sizeof(TRIPLE));
            if(!ogedge->triples) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogtriples] += M16(ogedge->ntriples * sizeof(TRIPLE));
            }
            ogedge->pi        = norm / pow((double)(evt[k].cost - shift), c_exponent);
            t                 = ogedge->triples;
            t[0].Itype        = I_gain;
            t[0].edge         = edge;
            t[0].edge2        = NULL;
            t[0].tube         = Stree->tubes[evt[k].d1];
            t[0].tube2        = NULL;
            OgUnary++;
            break;        }
         case id_tr_lr:                               // tr_lr
         case id_tr_rl: {                             // tr_rl
            EDGE *le, *re;
            if(evt[k].id == id_tr_lr) {
               le = edge->child;
               re = edge->child->sibling;
            }
            else {
               le = edge->child->sibling;
               re = edge->child;
            }
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[le->edgeno][Stree->tubes[evt[k].d1]->left->tubeno];
            ogedge->nextin    = NULL;
            ogedge->nextout   = ogedge2;
            ogedge->twin      = ogedge2;
            ogedge->ntriples  = 3;
            ogedge->triples   = (TRIPLE*)malloc(ogedge->ntriples * sizeof(TRIPLE));
            if(!ogedge->triples) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogtriples] += M16(ogedge->ntriples * sizeof(TRIPLE));
            }
            ogedge->pi        = norm / pow((double)(evt[k].cost - shift), c_exponent);
            t                 = ogedge->triples;
            t[0].Itype        = I_tr_o;
            t[0].edge         = edge;
            t[0].edge2        = NULL;
            t[0].tube         = tube;
            t[0].tube2        = NULL;
            t[1].Itype        = I_tr_i;
            t[1].edge         = edge;
            t[1].edge2        = NULL;
            t[1].tube         = Stree->tubes[evt[k].d1];
            t[1].tube2        = NULL;
            t[2].Itype        = I_loss;
            t[2].edge         = edge;
            t[2].edge2        = NULL;
            t[2].tube         = tube;
            t[2].tube2        = NULL;
            ogedge2->from     = ognode;
            ogedge2->to       = &Ograph[re->edgeno][Stree->tubes[evt[k].d1]->right->tubeno];
            ogedge2->nextin   = NULL;
            ogedge2->nextout  = NULL;
            ogedge2->twin     = ogedge;
            ogedge2->ntriples = 3;
            ogedge2->triples  = (TRIPLE*)malloc(ogedge2->ntriples * sizeof(TRIPLE));
            if(!ogedge2->triples) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogtriples] += M16(ogedge2->ntriples * sizeof(TRIPLE));
            }
            ogedge2->pi       = norm / pow((double)(evt[k].cost - shift), c_exponent);
            t                 = ogedge2->triples;
            t[0].Itype        = I_tr_o;
            t[0].edge         = edge;
            t[0].edge2        = NULL;
            t[0].tube         = tube;
            t[0].tube2        = NULL;
            t[1].Itype        = I_tr_i;
            t[1].edge         = edge;
            t[1].edge2        = NULL;
            t[1].tube         = Stree->tubes[evt[k].d1];
            t[1].tube2        = NULL;
            t[2].Itype        = I_loss;
            t[2].edge         = edge;
            t[2].edge2        = NULL;
            t[2].tube         = tube;
            t[2].tube2        = NULL;
            OgBinary++;
            break;    }
         case id_ga_lr:                               // ga_lr
         case id_ga_rl: {                             // ga_rl
            EDGE *le, *re;
            if(evt[k].id == id_ga_lr) {
               le = edge->child;
               re = edge->child->sibling;
            }
            else {
               le = edge->child->sibling;
               re = edge->child;
            }
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[le->edgeno][Stree->tubes[evt[k].d1]->left->tubeno];
            ogedge->nextin    = NULL;
            ogedge->nextout   = ogedge2;
            ogedge->twin      = ogedge2;
            ogedge->ntriples  = 1;
            ogedge->triples   = (TRIPLE*)malloc(sizeof(TRIPLE));
            if(!ogedge->triples) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogtriples] += M16(ogedge->ntriples * sizeof(TRIPLE));
            }
            ogedge->pi        = norm / pow((double)(evt[k].cost - shift), c_exponent);
            t                 = ogedge->triples;
            t[0].Itype        = I_gain;
            t[0].edge         = edge;
            t[0].edge2        = NULL;
            t[0].tube         = Stree->tubes[evt[k].d1];
            t[0].tube2        = NULL;
            ogedge2->from     = ognode;
            ogedge2->to       = &Ograph[re->edgeno][Stree->tubes[evt[k].d1]->right->tubeno];
            ogedge2->nextin   = NULL;
            ogedge2->nextout  = NULL;
            ogedge2->twin     = ogedge;
            ogedge2->ntriples = 1;
            ogedge2->triples  = (TRIPLE*)malloc(sizeof(TRIPLE));
            if(!ogedge2->triples) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogtriples] += M16(ogedge2->ntriples * sizeof(TRIPLE));
            }
            ogedge2->pi       = norm / pow((double)(evt[k].cost - shift), c_exponent);
            t                 = ogedge2->triples;
            t[0].Itype        = I_gain;
            t[0].edge         = edge;
            t[0].edge2        = NULL;
            t[0].tube         = Stree->tubes[evt[k].d1];
            t[0].tube2        = NULL;
            OgBinary++;
            break;    }
         case id_tr_l:                                // tr_l
         case id_tr_r: {                              // tr_r
            TUBE *ld, *rd;
            if(evt[k].id == id_tr_l) {
               ld = Stree->tubes[evt[k].d1]->left;
               rd = Stree->tubes[evt[k].d1]->right;
            }
            else {
               ld = Stree->tubes[evt[k].d1]->right;
               rd = Stree->tubes[evt[k].d1]->left;
            }
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[e][ld->tubeno];
            ogedge->nextin    = NULL;
            ogedge->nextout   = NULL;
            ogedge->twin      = NULL;
            ogedge->ntriples  = 4;
            ogedge->triples   = (TRIPLE*)malloc(ogedge->ntriples * sizeof(TRIPLE));
            if(!ogedge->triples) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogtriples] += M16(ogedge->ntriples * sizeof(TRIPLE));
            }
            ogedge->pi        = norm / pow((double)(evt[k].cost - shift), c_exponent);
            t                 = ogedge->triples;
            t[0].Itype        = I_tr_o;
            t[0].edge         = edge;
            t[0].edge2        = NULL;
            t[0].tube         = tube;
            t[0].tube2        = NULL;
            t[1].Itype        = I_tr_i;
            t[1].edge         = edge;
            t[1].edge2        = NULL;
            t[1].tube         = Stree->tubes[evt[k].d1];
            t[1].tube2        = NULL;
            t[2].Itype        = I_loss;
            t[2].edge         = edge;
            t[2].edge2        = NULL;
            t[2].tube         = tube;
            t[2].tube2        = NULL;
            t[3].Itype        = (evt[k].d2 == -c_loss1) ? I_loss1 : I_loss;
            t[3].edge         = edge;
            t[3].edge2        = NULL;
            t[3].tube         = rd;
            t[3].tube2        = NULL;
            OgUnary++;
            break;    }
         case id_ga_l:                                // ga_l
         case id_ga_r: {                              // ga_r
            TUBE *ld, *rd;
            if(evt[k].id == id_ga_l) {
               ld = Stree->tubes[evt[k].d1]->left;
               rd = Stree->tubes[evt[k].d1]->right;
            }
            else {
               ld = Stree->tubes[evt[k].d1]->right;
               rd = Stree->tubes[evt[k].d1]->left;
            }
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[e][ld->tubeno];
            ogedge->nextin    = NULL;
            ogedge->nextout   = NULL;
            ogedge->twin      = NULL;
            ogedge->ntriples  = 2;
            ogedge->triples   = (TRIPLE*)malloc(ogedge->ntriples * sizeof(TRIPLE));
            if(!ogedge->triples) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogtriples] += M16(ogedge->ntriples * sizeof(TRIPLE));
            }
            ogedge->pi        = norm / pow((double)(evt[k].cost - shift), c_exponent);
            t                 = ogedge->triples;
            t[0].Itype        = I_gain;
            t[0].edge         = edge;
            t[0].edge2        = NULL;
            t[0].tube         = Stree->tubes[evt[k].d1];
            t[0].tube2        = NULL;
            t[1].Itype        = I_loss;
            t[1].edge         = edge;
            t[1].edge2        = NULL;
            t[1].tube         = rd;
            t[1].tube2        = NULL;
            OgUnary++;
            break;    }
         case id_tr_dupl: {                           // tr_dupl
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[edge->child->edgeno][evt[k].d1];
            ogedge->nextin    = NULL;
            ogedge->nextout   = ogedge2;
            ogedge->twin      = ogedge2;
            ogedge->ntriples  = 4;
            ogedge->triples   = (TRIPLE*)malloc(ogedge->ntriples * sizeof(TRIPLE));
            if(!ogedge->triples) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogtriples] += M16(ogedge->ntriples * sizeof(TRIPLE));
            }
            ogedge->pi        = norm / pow((double)(evt[k].cost - shift), c_exponent);
            t                 = ogedge->triples;
            t[0].Itype        = I_tr_o;
            t[0].edge         = edge;
            t[0].edge2        = NULL;
            t[0].tube         = tube;
            t[0].tube2        = NULL;
            t[1].Itype        = I_tr_i;
            t[1].edge         = edge;
            t[1].edge2        = NULL;
            t[1].tube         = Stree->tubes[evt[k].d1];
            t[1].tube2        = NULL;
            t[2].Itype        = I_loss;
            t[2].edge         = edge;
            t[2].edge2        = NULL;
            t[2].tube         = tube;
            t[2].tube2        = NULL;
            t[3].Itype        = I_dupl;
            t[3].edge         = edge;
            t[3].edge2        = NULL;
            t[3].tube         = Stree->tubes[evt[k].d1];
            t[3].tube2        = NULL;
            ogedge2->from     = ognode;
            ogedge2->to       = &Ograph[edge->child->sibling->edgeno][evt[k].d1];
            ogedge2->nextin   = NULL;
            ogedge2->nextout  = NULL;
            ogedge2->twin     = ogedge;
            ogedge2->ntriples = 4;
            ogedge2->triples  = (TRIPLE*)malloc(ogedge2->ntriples * sizeof(TRIPLE));
            if(!ogedge2->triples) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogtriples] += M16(ogedge2->ntriples * sizeof(TRIPLE));
            }
            ogedge2->pi       = norm / pow((double)(evt[k].cost - shift), c_exponent);
            t                 = ogedge2->triples;
            t[0].Itype        = I_tr_o;
            t[0].edge         = edge;
            t[0].edge2        = NULL;
            t[0].tube         = tube;
            t[0].tube2        = NULL;
            t[1].Itype        = I_tr_i;
            t[1].edge         = edge;
            t[1].edge2        = NULL;
            t[1].tube         = Stree->tubes[evt[k].d1];
            t[1].tube2        = NULL;
            t[2].Itype        = I_loss;
            t[2].edge         = edge;
            t[2].edge2        = NULL;
            t[2].tube         = tube;
            t[2].tube2        = NULL;
            t[3].Itype        = I_dupl;
            t[3].edge         = edge;
            t[3].edge2        = NULL;
            t[3].tube         = Stree->tubes[evt[k].d1];
            t[3].tube2        = NULL;
            OgBinary++;
            break;    }
         case id_ga_dupl: {                           // ga_dupl
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[edge->child->edgeno][evt[k].d1];
            ogedge->nextin    = NULL;
            ogedge->nextout   = ogedge2;
            ogedge->twin      = ogedge2;
            ogedge->ntriples  = 2;
            ogedge->triples   = (TRIPLE*)malloc(ogedge->ntriples * sizeof(TRIPLE));
            if(!ogedge->triples) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogtriples] += M16(ogedge->ntriples * sizeof(TRIPLE));
            }
            ogedge->pi        = norm / pow((double)(evt[k].cost - shift), c_exponent);
            t                 = ogedge->triples;
            t[0].Itype        = I_gain;
            t[0].edge         = edge;
            t[0].edge2        = NULL;
            t[0].tube         = Stree->tubes[evt[k].d1];
            t[0].tube2        = NULL;
            t[1].Itype        = I_dupl;
            t[1].edge         = edge;
            t[1].edge2        = NULL;
            t[1].tube         = Stree->tubes[evt[k].d1];
            t[1].tube2        = NULL;
            ogedge2->from     = ognode;
            ogedge2->to       = &Ograph[edge->child->sibling->edgeno][evt[k].d1];
            ogedge2->nextin   = NULL;
            ogedge2->nextout  = NULL;
            ogedge2->twin     = ogedge;
            ogedge2->ntriples = 2;
            ogedge2->triples  = (TRIPLE*)malloc(ogedge2->ntriples * sizeof(TRIPLE));
            if(!ogedge2->triples) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogtriples] += M16(ogedge2->ntriples * sizeof(TRIPLE));
            }
            ogedge2->pi       = norm / pow((double)(evt[k].cost - shift), c_exponent);
            t                 = ogedge2->triples;
            t[0].Itype        = I_gain;
            t[0].edge         = edge;
            t[0].edge2        = NULL;
            t[0].tube         = Stree->tubes[evt[k].d1];
            t[0].tube2        = NULL;
            t[1].Itype        = I_dupl;
            t[1].edge         = edge;
            t[1].edge2        = NULL;
            t[1].tube         = Stree->tubes[evt[k].d1];
            t[1].tube2        = NULL;
            OgBinary++;
            break;    }
         case id_tr: {                                // tr
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[edge->child->edgeno][evt[k].d1];
            ogedge->nextin    = NULL;
            ogedge->nextout   = ogedge2;
            ogedge->twin      = ogedge2;
            ogedge->ntriples  = 5;
            ogedge->triples   = (TRIPLE*)malloc(ogedge->ntriples * sizeof(TRIPLE));
            if(!ogedge->triples) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogtriples] += M16(ogedge->ntriples * sizeof(TRIPLE));
            }
            ogedge->pi        = norm / pow((double)(evt[k].cost - shift), c_exponent);
            t                 = ogedge->triples;
            t[0].Itype        = I_tr_o;
            t[0].edge         = edge;
            t[0].edge2        = NULL;
            t[0].tube         = tube;
            t[0].tube2        = NULL;
            t[1].Itype        = I_tr_i;
            t[1].edge         = edge;
            t[1].edge2        = NULL;
            t[1].tube         = Stree->tubes[evt[k].d1];
            t[1].tube2        = Stree->tubes[evt[k].d2];
            t[2].Itype        = I_tr_o;
            t[2].edge         = edge->child;
            t[2].edge2        = edge->child->sibling;
            t[2].tube         = Stree->tubes[evt[k].d1];
            t[2].tube2        = Stree->tubes[evt[k].d2];
            t[3].Itype        = I_tr_i;
            t[3].edge         = edge->child;
            t[3].edge2        = edge->child->sibling;
            t[3].tube         = Stree->tubes[evt[k].d1];
            t[3].tube2        = Stree->tubes[evt[k].d2];
            t[4].Itype        = I_loss;
            t[4].edge         = edge;
            t[4].edge2        = NULL;
            t[4].tube         = tube;
            t[4].tube2        = NULL;
            ogedge2->from     = ognode;
            ogedge2->to       = &Ograph[edge->child->sibling->edgeno][evt[k].d2];
            ogedge2->nextin   = NULL;
            ogedge2->nextout  = NULL;
            ogedge2->twin     = ogedge;
            ogedge2->ntriples = 5;
            ogedge2->triples  = (TRIPLE*)malloc(ogedge2->ntriples * sizeof(TRIPLE));
            if(!ogedge2->triples) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogtriples] += M16(ogedge2->ntriples * sizeof(TRIPLE));
            }
            ogedge2->pi       = norm / pow((double)(evt[k].cost - shift), c_exponent);
            t                 = ogedge2->triples;
            t[0].Itype        = I_tr_o;
            t[0].edge         = edge;
            t[0].edge2        = NULL;
            t[0].tube         = tube;
            t[0].tube2        = NULL;
            t[1].Itype        = I_tr_i;
            t[1].edge         = edge;
            t[1].edge2        = NULL;
            t[1].tube         = Stree->tubes[evt[k].d1];
            t[1].tube2        = Stree->tubes[evt[k].d2];
            t[2].Itype        = I_tr_o;
            t[2].edge         = edge->child;
            t[2].edge2        = edge->child->sibling;
            t[2].tube         = Stree->tubes[evt[k].d1];
            t[2].tube2        = Stree->tubes[evt[k].d2];
            t[3].Itype        = I_tr_i;
            t[3].edge         = edge->child;
            t[3].edge2        = edge->child->sibling;
            t[3].tube         = Stree->tubes[evt[k].d1];
            t[3].tube2        = Stree->tubes[evt[k].d2];
            t[4].Itype        = I_loss;
            t[4].edge         = edge;
            t[4].edge2        = NULL;
            t[4].tube         = tube;
            t[4].tube2        = NULL;
            OgBinary++;
            break;   }
         case id_ga: {                                // ga
            ogedge->from      = ognode;
            ogedge->to        = &Ograph[edge->child->edgeno][evt[k].d1];
            ogedge->nextin    = NULL;
            ogedge->nextout   = ogedge2;
            ogedge->twin      = ogedge2;
            ogedge->ntriples  = 3;
            ogedge->triples   = (TRIPLE*)malloc(ogedge->ntriples * sizeof(TRIPLE));
            if(!ogedge->triples) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogtriples] += M16(ogedge->ntriples * sizeof(TRIPLE));
            }
            ogedge->pi        = norm / pow((double)(evt[k].cost - shift), c_exponent);
            t                 = ogedge->triples;
            t[0].Itype        = I_gain;
            t[0].edge         = edge;
            t[0].edge2        = NULL;
            t[0].tube         = Stree->tubes[evt[k].d1];
            t[0].tube2        = Stree->tubes[evt[k].d2];
            t[1].Itype        = I_tr_o;
            t[1].edge         = edge->child;
            t[1].edge2        = edge->child->sibling;
            t[1].tube         = Stree->tubes[evt[k].d1];
            t[1].tube2        = Stree->tubes[evt[k].d2];
            t[2].Itype        = I_tr_i;
            t[2].edge         = edge->child;
            t[2].edge2        = edge->child->sibling;
            t[2].tube         = Stree->tubes[evt[k].d1];
            t[2].tube2        = Stree->tubes[evt[k].d2];
            ogedge2->from     = ognode;
            ogedge2->to       = &Ograph[edge->child->sibling->edgeno][evt[k].d2];
            ogedge2->nextin   = NULL;
            ogedge2->nextout  = NULL;
            ogedge2->twin     = ogedge;
            ogedge2->ntriples = 3;
            ogedge2->triples  = (TRIPLE*)malloc(ogedge2->ntriples * sizeof(TRIPLE));
            if(!ogedge2->triples) {
               CON( printf("STA: Not enough memory for orbigraph.\n"); )
               LOG( fprintf(Log, "STA: Not enough memory for orbigraph.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[ogtriples] += M16(ogedge2->ntriples * sizeof(TRIPLE));
            }
            ogedge2->pi       = norm / pow((double)(evt[k].cost - shift), c_exponent);
            t                 = ogedge2->triples;
            t[0].Itype        = I_gain;
            t[0].edge         = edge;
            t[0].edge2        = NULL;
            t[0].tube         = Stree->tubes[evt[k].d1];
            t[0].tube2        = Stree->tubes[evt[k].d2];
            t[1].Itype        = I_tr_o;
            t[1].edge         = edge->child;
            t[1].edge2        = edge->child->sibling;
            t[1].tube         = Stree->tubes[evt[k].d1];
            t[1].tube2        = Stree->tubes[evt[k].d2];
            t[2].Itype        = I_tr_i;
            t[2].edge         = edge->child;
            t[2].edge2        = edge->child->sibling;
            t[2].tube         = Stree->tubes[evt[k].d1];
            t[2].tube2        = Stree->tubes[evt[k].d2];
            OgBinary++;
            break;   }
         default:          {
            CON( printf("STA: Invalid event %s found for <%s=%d,%s=%d>.\n",
               EventNames[evt->id], edge->name, e, tube->name, d); )
            LOG( fprintf(Log, "STA: Invalid event %s found for <%s=%d,%s=%d>.\n",
               EventNames[evt->id], edge->name, e, tube->name, d); )
            goto Error;    }
      }

      // Insert this (bi)edge into from-node outbound list
      if(ogedge->from->lastout)
         ogedge->from->lastout->nextout   = ogedge;
      else
         ogedge->from->firstout           = ogedge;
      ogedge->from->lastout               = ogedge2 ? ogedge2 : ogedge;
      // Insert this (bi)edge into to-node inbound list
      if(ogedge->to->lastin)
         ogedge->to->lastin->nextin       = ogedge;
      else
         ogedge->to->firstin              = ogedge;
      ogedge->to->lastin                  = ogedge;
      if(ogedge2) {
         if(ogedge2->to->lastin)
            ogedge2->to->lastin->nextin   = ogedge2;
         else
            ogedge2->to->firstin          = ogedge2;
         ogedge2->to->lastin              = ogedge2;
      }
      OgTriples += ogedge->ntriples;
      continue;
   }
   return true;
Error:
   return false;
}

// Forward run in Task 3 (building orbigraph)
bool     RunForward3(void) {
   int e, d;
   for(e = 1; e < Gtree->nedges; e++) {
      for(d = 1; d <= Stree->ntubes; d++) {
         if( !BuildOgNode(&Ograph[e][d]) )
            return false;
      }
   }
   e = Gtree->nedges;   // Special tube order for e0
   for(int i = 0; i <= Stree->height; i++) {     // by slices
      for(int j = 1; j < Stree->slices[i].ntubes; j++) {
         d = Stree->slices[i].tubes[j]->tubeno;
         if( !BuildOgNode(&Ograph[e][d]) )
            return false;
      }
      d = Stree->slices[i].tubes[0]->tubeno;
      if( !BuildOgNode(&Ograph[e][d]) )
         return false;
   }
   return true;
}

// Convert Itype value to its name
const char*    Itype2Name(unsigned Itype) {
   int k;
   for(k = 0; k < nItypes; k++) {
      if(Itype & 1) break;
      Itype >>= 1;
   }
   if(k < nItypes) return ItypeNames[k];
   else return NULL;
}

// Convert Itype value to its serial number
int      Itype2Index(unsigned Itype) {
   int k;
   for(k = 0; k < nItypes; k++) {
      if(Itype & 1) break;
      Itype >>= 1;
   }
   if(k < nItypes) return k;
   else {
      CON( printf("STA: Itype %X not found.\n", Itype); )
      LOG( fprintf(Log, "STA: Itype %X not  found.\n", Itype); )
      return -1;
   }
}

// Process orbigraph node in backward run
void     ProcessOgNode(OGNODE* ognode) {
   EDGE* edge  = ognode->edge;
   TUBE* tube  = ognode->tube;
   int e       = edge->edgeno;
   int d       = tube->tubeno;
   // Process inbound edges to compute p(e,d)
   OGEDGE* ogedge = ognode->firstin;
   while(ogedge) {
      ognode->ped += ogedge->pi;
      ogedge      = ogedge->nextin;
   }
   // Process outbound edges to compute p(e,d,i,j) for f(I,x) & g(I,T)
   ogedge = ognode->firstout;
   while(ogedge) {
      ogedge->pi  *= ognode->ped;
      // select all triples in turn
      TRIPLE* t = ogedge->triples;
      for(int n = 0; n < ogedge->ntriples; n++) {
         if((t[n].Itype & Itype) == 0)
            continue;      // Itype is out of interest
         int I = Itype2Index(t[n].Itype);
         // accumulate f(I)
         if(t[n].tube2) {
            t[n].tube->mean[I]   += ogedge->pi * 0.5;
            t[n].tube2->mean[I]  += ogedge->pi * 0.5;
         }
         else {
            t[n].tube->mean[I]   += ogedge->pi;
         }
         // accumulate g(I,T)
         if(t[n].edge2) {
            if(t[n].edge->Tmark == TmarkChar)
               gjIT[I]  += ogedge->pi * 0.5;
            if(t[n].edge2->Tmark == TmarkChar)
               gjIT[I]  += ogedge->pi * 0.5;
         }
         else {
            if(t[n].edge->Tmark == TmarkChar)
               gjIT[I]  += ogedge->pi;
         }
      }
      if(ogedge->twin) {
         ogedge      = ogedge->nextout;
         ogedge->pi *= ognode->ped;
      }
      ogedge = ogedge->nextout;
   }
}

// Backward run in Task 3
bool     RunBackward3(void) {
   int e          = Gtree->nedges;
   int d          = Stree->ntubes;
   OGNODE* ognode = &Ograph[e][d];
   ognode->ped    = 1.0;         // initial <e0,d0> node
   // Special tube selection order for e0 case
   for(int i = Stree->height; i >= 0; i--) {
      d = Stree->slices[i].tubes[0]->tubeno;
      ProcessOgNode( &Ograph[e][d] );
      for(int j = Stree->slices[i].ntubes - 1; j > 0; j--) {
         d = Stree->slices[i].tubes[j]->tubeno;
         ProcessOgNode( &Ograph[e][d] );
      }
   }
   // General case
   for(--e; e > 0; e--) {
      if(Gtree->edges[e]->nchildren != 0) {     // non-leaf edge
         for(d = Stree->ntubes; d > 0; d--) {
            ProcessOgNode( &Ograph[e][d] );
         }
      }
      else {      // leaf edge
         int dd = Gtree->edges[e]->specno + 1;
         for(d = Stree->ntubes; d > 0; d--) {
            if(d == dd) continue;
            ProcessOgNode( &Ograph[e][d] );
         }
         ProcessOgNode( &Ograph[e][dd] );
      }
   }
   // Count total means
   for(d = 1; d <= Stree->ntubes; d++) {
      TUBE* tube = Stree->tubes[d];
      for(int j = 0; j < nItypes; j++) 
         tube->totmean[j] += tube->mean[j];
   }
   return true;
};

// Orbigraph output to Log file
void     LoggingOgraph(void) {
   const char* esep = "=";
   const char* tsep = "=";
   if(Log) fprintf(Log, "\n");
   for(int e = Gtree->nedges; e > 0; e--) {
      EDGE* edge = Ograph[e][1].edge;
      if(e != Gtree->nedges)
         if(Log) fprintf(Log, "----------------\n");
      for(int d = Stree->ntubes; d > 0; d--) {
         OGNODE* ognode = &Ograph[e][d];
         TUBE*   tube   = ognode->tube;
         OGEDGE* ogedge = ognode->firstout;
         OGEDGE* last   = NULL;
         do {
            if(ogedge == ognode->firstout) {
               if(Log) fprintf(Log, "%*s%s%*d ", OgEdgeLabel, edge->name,
                  esep, OgEdgeNumber, edge->edgeno);
            }
            else {
               if(Log) fprintf(Log, "%*s", OgEdgeLabel + (int)strlen(esep) + 
                  OgEdgeNumber + 1, "");
            }
            if(ogedge == ognode->firstout) {
               if(Log) fprintf(Log, "%*s%s%*d ", OgTubeLabel, tube->name,
                  tsep, OgTubeNumber, tube->tubeno); 
            }
            else {
               if(Log) fprintf(Log, "%*s", OgTubeLabel + (int)strlen(tsep) + 
                  OgTubeNumber + 1, "");
            }
            if(ogedge == ognode->firstout) {
               if(Log) fprintf(Log, " p=%.*f ", OgPrecision, ognode->ped);
            }
            else {
               if(Log) fprintf(Log, "%*s", OgPrecision + 6, "");
            }
            if(ogedge) {
               OGNODE* to  = ogedge->to;
               if(Log) fprintf(Log, " ==> <%*s%s%*d, %*s%s%*d>  ",
                  OgEdgeLabel, to->edge->name, esep, OgEdgeNumber, to->edge->edgeno,
                  OgTubeLabel, to->tube->name, tsep, OgTubeNumber, to->tube->tubeno);
               if(!ogedge->twin || ogedge->twin != last) {
                  if(Log) fprintf(Log, "pi=%.*f  ", OgPrecision, ogedge->pi);
                  for(int n = 0; n < ogedge->ntriples; n++) {
                     TRIPLE* t = &(ogedge->triples[n]);
                     if(Log) fprintf(Log, "<%s, ", Itype2Name(t->Itype));
                     if(t->edge2) {
                        if(Log) fprintf(Log, "%s=%d & %s=%d, ", t->edge->name, 
                           t->edge->edgeno, t->edge2->name, t->edge2->edgeno);
                     }
                     else {
                        if(Log) fprintf(Log, "%s=%d, ", t->edge->name, t->edge->edgeno);
                     }
                     if(t->tube2) {
                        if(Log) fprintf(Log, "%s=%d & %s=%d>  ", t->tube->name, 
                           t->tube->tubeno, t->tube2->name, t->tube2->tubeno);
                     }
                     else {
                        if(Log) fprintf(Log, "%s=%d>  ", t->tube->name, t->tube->tubeno);
                     }
                  }
               }
               last     = ogedge;
               ogedge   = ogedge->nextout;
            }
            if(Log) fprintf(Log, "\n");
         } while(ogedge);
      }
   }
   if(Log) fprintf(Log, "\n");
}

// gjIT/gIT output to Log file
void     LoggingTmarkStats(double *g) {
   // Headings
   if(g == gjIT) {
      if(Log) fprintf(Log, "\n%-*s %*d  ", OgTubeLabel, "Tree", OgTubeNumber, Treeno);
   }
   else {
      if(Log) fprintf(Log, "\n%-*s  ", OgTubeLabel + OgTubeNumber + 1, "All trees");
   }
   unsigned I = 1;
   for(int i = 0; i < nItypes - 1; i++,I<<=1) {    // -1 due to hidden I_loss1
      if((I & Itype) == 0)
         continue;
      if(Log) fprintf(Log, "%*s  ", MeanWidth, ItypeNames[i]);
   }
   if(Log) fprintf(Log, "\n%c%*s  ", TmarkChar, OgTubeLabel + OgTubeNumber, "");
   I = 1;
   for(int i = 0; i < nItypes - 1; i++,I<<=1) {    // -1 due to hidden I_loss1
      if((I & Itype) == 0)
         continue;
      double f =  g[i];
      if(I == I_loss)
         f += g[nItypes-1];   // to account for I_loss1 mean
      if(Log) fprintf(Log, "%*.*f  ", MeanWidth, MeanPrecision, f);
   }
   if(Log) fprintf(Log, "\n\n");
}

// tube->mean output to Log file
// old==true: over OLD tubes, otherwise NEW tubes
// summary==true: over all gene trees, otherwise current gene tree
// NB: After logging old tubes, the data are damaged!
void     LoggingTubeStats(bool old, bool summary) {
   double* total = (double*)malloc(nItypes * sizeof(double));
   if(!total) {
      CON( printf("STA: Not enough memory.\n"); )
      LOG( fprintf(Log, "STA: Not enough memory.\n"); )
      return;
   }
   if(MemoryCount) {
      MemUsed[housekeeping] += M16(nItypes * sizeof(double));
   }
   for(int i = 0; i < nItypes; i++) total[i] = 0.0;
   // Headings
   int wc1 = OgTubeLabel + OgTubeNumber + 1;
   if(Log) fprintf(Log, "\n%-*s  ", wc1, "All trees");
   unsigned I = 1;
   for(int i = 0; i < nItypes - 1; i++,I<<=1) {    // -1 due to hidden I_loss1
      if((I & Itype) == 0)
         continue;
      if(Log) fprintf(Log, "%*s  ", MeanWidth, ItypeNames[i]);
   }
   if(Log) fprintf(Log, "\n");
   for(int d = Stree->ntubes; d > 0; d--) {
      TUBE* tube = Stree->tubes[d];
      if(old && (d == Stree->ntubes || tube->oldtube != tube)) {
         TUBE* oldtube = (d == Stree->ntubes ? tube->right : tube->oldtube);
         for(int i = 0; i < nItypes; i++)
            if(summary)
               oldtube->totmean[i] += tube->totmean[i];
            else
               oldtube->mean[i] += tube->mean[i];
         continue;
      }
      if(_strnicmp(tube->name, OutgroupName, strlen(OutgroupName)) == 0)
         continue;    // eliminate outgroup output in statistics
      if(Log) fprintf(Log, "%*s=%*d  ", OgTubeLabel, tube->name, 
         OgTubeNumber, tube->tubeno);
      I = 1;
      for(int i = 0; i < nItypes - 1; i++,I<<=1) {    // -1 due to hidden I_loss1
         if((I & Itype) == 0)
            continue;
         double f = summary ? tube->totmean[i] : tube->mean[i];
         total[i] += f;
         if(I == I_loss)   // to account for hidden I_loss1 at output
            f += summary ? tube->totmean[nItypes-1] : tube->mean[nItypes-1];
         if(Log) fprintf(Log, "%*.*f  ", MeanWidth, MeanPrecision, f);
      }
      total[nItypes-1] += summary ? tube->totmean[nItypes-1] : tube->mean[nItypes-1];
      if(Log) fprintf(Log, "\n");
   }
   //if(Log) fprintf(Log, "%.*s  ", wc1, "----------------");
   for(int i = 0; i < wc1; i++)
      if(Log) fprintf(Log, "%c", '-');
   if(Log) fprintf(Log, "  ");
   I = 1;
   for(int i = 0; i < nItypes - 1; i++,I<<=1) {    // -1 due to hidden I_loss1
      if((I & Itype) == 0)
         continue;
      double f = total[i];
      if(I == I_loss)   // to account for hidden I_loss1 at output
         f += total[nItypes-1];
      if(Log) fprintf(Log, "%*.*f  ", MeanWidth, MeanPrecision, f);
   }
   if(Log) fprintf(Log, "\n");
   if(!summary && LogMeanJ && (old || !old && !LogOTubeJ) ||
      summary && LogTotalMean && (old || !old && !LogOTubeStats)) {
      double mean = 0.0;
      I = 1;
      for(int i = 0; i < nItypes; i++,I<<=1) {
         switch( I ) {
            case I_gain:   
               mean += total[i] * c_gain / SCALE; 
               break;
            case I_loss:
               mean += total[i] * c_loss / SCALE; 
               break;
            case I_dupl:
               mean += total[i] * c_dupl / SCALE; 
               break;
            case I_tr_o:
               mean += total[i] * c_tr_with / (2 * SCALE); 
               break;
            case I_tr_i:
               mean += total[i] * c_tr_with / (2 * SCALE); 
               break;
            case I_gain_big:   
               mean += total[i] * c_gain_big / SCALE; 
               break;
            case I_loss1:
               mean += total[i] * c_loss1 / SCALE; 
               break;
            default:
               mean = -1.0e-10;  // indicates error
               break;
         }
      }
      if(Log) fprintf(Log, "Mean cost of scenarios: %.*f\n", 
         MeanPrecision, mean);
   }
   free(total);
   if(MemoryCount) {
      MemUsed[housekeeping] -= M16(nItypes * sizeof(double));
   }
}
