// embed3GL: A program for phylogenetic study of joint gene & species evolution.
//
// The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/embed3gl]
//
// (C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
// E-mail: rubanov{at}iitp.ru
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// Functions: OpenSpeciesTree, RemoveTreeComments, ReadStreeString,
//            PrintStree, FillStreeHeights, FillSlices, AllocateFI, 
//            ReadSpeciesTree, WriteSpeciesTree, MarkOldNewTubes

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "embed3gl.h"

FILE*    stf = NULL;

// Return true if species tree can be opened
bool     OpenSpeciesTree(void) {
   char*    streefilename = (char*)malloc(BUFLEN);
   if( !streefilename ) {
      CON( printf("STR: Not enough memory.\n"); )
      LOG( fprintf(Log, "STR: Not enough memory.\n"); )
      return false;
   }
   if(MemoryCount) {
      MemUsed[speciestree] += M16(BUFLEN);
   }
   streefilename[0] = 0;

   strcpy(streefilename, DataDirectory);
   strcat(streefilename, SpeciesTreeName);
   stf = fopen(streefilename, "rb");
   if( !stf && !ModeSuper3Build ) {
      CON( printf("STR: Cannot open species tree '%s'.\n", streefilename); )
      LOG( fprintf(Log, "STR: Cannot open species tree '%s'.\n", streefilename); )
   }

   free(streefilename);
   if(MemoryCount) {
      MemUsed[speciestree] -= M16(BUFLEN);
   }
   return (stf != NULL);
}

// Remove blanks and [...] comments in Newick line
void     RemoveTreeComments(char *str) {
   char *p = str, *q;
   char blanks[] = " \t\n\r";
   // substitute blanks for comments
   while( p = strchr(p, '[') ) {
      q = strchr(p+1, ']');
      if( !q ) {
         *p = 0;
         break;
      }
      memset(p, ' ', ++q - p);
      p = q;
   }
   // remove blanks
   p = str;
   while(1) {
      int pos = (int)strcspn(p, blanks);
      if(p[pos] == 0)
         break;
      p += pos;

      for(q = p + 1; *q; ++q) {
         if( !strchr(blanks, *q) )
            break;
      }

      if(*q == 0) {
         *p = 0;
         break;
      }
      memmove(p, q, strlen(q) + 1);
   }
}

// Return ptr to a new string containing a whole species tree
char*    ReadStreeString(void) {
   char* buf   = (char*)malloc(BUFLEN + 1);
   char* tree  = (char*)malloc(MAXTREELEN + 1);
   if(!buf || !tree) {
      CON( printf("STR: Not enough memory.\n"); )
      LOG( fprintf(Log, "STR: Not enough memory.\n"); )
      return false;
   }
   if(MemoryCount) {
      MemUsed[speciestree] += M16(BUFLEN + 1);
      MemUsed[speciestree] += M16(MAXTREELEN + 1);
   }
   tree[0] = 0;
   int length = 0;
   int line = 0;

   while(fgets(buf, BUFLEN, stf)) {
      ++line;
      RemoveTreeComments(buf);
      if(length + strlen(buf) >= MAXTREELEN) {
         CON( printf("STR: Species tree storage exceeded in line %d.\n", 
            line); )
         LOG( fprintf(Log, "STR: Species tree storage exceeded in line %d.\n", 
            line); )
         return false;
      }
      strcpy(tree + length, buf);
      length += (int)strlen(buf);
   }

   if(ferror(stf)) {
      CON( printf("STR: Species tree file I/O error.\n"); )
      LOG( fprintf(Log, "STR: Species tree file I/O error.\n"); )
      return false;
   }

   free(buf);
   if(MemoryCount) {
      MemUsed[speciestree] -= M16(BUFLEN + 1);
   }
   return tree;
}

// Print species tree in parenthesis format
void     PrintStree(TUBE* node, FILE* file, TREEMODE* mode) {
   if( !mode->enable ) return;
   if( !node->parent && mode->heading )
      fprintf(file, "[Species Tree]\n");
   if( !node->left && !node->right ) {       // leaf case
      if(mode->label_leaf)
         fprintf(file, "%s", mode->full_labels ? node->name :
            node->specno ? FindKey(node->specno) : node->name);
      else if(mode->number_leaf)
         fprintf(file, "%d", node->tubeno);
      if(mode->length_leaf)
         fprintf(file, ":%g", node->length);
   }
   else {                                    // interior node
      fprintf(file, "(");
      if(node->left) {
         PrintStree(node->left, file, mode);
         if(node->right) {
            fprintf(file, ",");
            PrintStree(node->right, file, mode);
         }
      }
      else if(node->right) 
         PrintStree(node->right, file, mode);

      fprintf(file, ")");
      if( !node->parent ) {                     // root case
         if(mode->label_root)
            fprintf(file, "%s", node->name);
         else if(mode->number_root)
            fprintf(file, "%d", node->tubeno);
         if(mode->length_root)
            fprintf(file, ":%g", node->length);
      }
      else {                                    // general case
         if(mode->label_inner)
            fprintf(file, "%s", node->name);
         else if(mode->number_inner)
            fprintf(file, "%d", node->tubeno);
         if(mode->length_inner)
            fprintf(file, ":%g", node->length);
      }
   }
}

// Fill height values across species tree
// Return false if found a leaf at nonzero level
static   TUBE* badleaf = NULL;
static   int leaflevel = -1;
void     fillStreeLevels(TUBE* node);
bool     fillStreeHeights(TUBE* node);

bool     FillStreeHeights(void) {
   Stree->root->height  = 0;   // temporary uses height for level
   fillStreeLevels(Stree->root);
   Stree->height        = leaflevel;
   return fillStreeHeights(Stree->root);
}

void     fillStreeLevels(TUBE* node) {
   if( !node->left && !node->right ) {       // leaf case
      if(node->height > leaflevel)
         leaflevel = node->height;
   }
   else {
      if(node->left) {
         node->left->height   = node->height + 1;
         fillStreeLevels(node->left);
      }
      if(node->right) {
         node->right->height  = node->height + 1;
         fillStreeLevels(node->right);
      }
   }
}

bool     fillStreeHeights(TUBE* node) {
   // convert levels to heights
   node->height = Stree->height - node->height;
   if( !node->left && !node->right ) {       // leaf case
      if(node->height) {
         badleaf = node;
         return false;
      }
   }
   else {
      if(node->left  && !fillStreeHeights(node->left))
         return false;
      if(node->right && !fillStreeHeights(node->right))
         return false;
   }
   return true;
}

// Traverse species tree filling slices & counting old tubes
void     FillSlices(TUBE* node) {
   SLICE* slc = Stree->slices + node->height;
   slc->tubes[slc->ntubes++] = node;
   if(node == node->oldtube)
      Stree->noldtubes++;
   if(node->left)
      FillSlices(node->left);
   if(node->right)
      FillSlices(node->right);
}

// Allocate mean array in each tube for f(I) fuction
double*  AllocateFI(void) {
   if( !ModeStatistics ) return NULL;
   double* mean = (double*)malloc(nItypes * sizeof(double));
   if( !mean ) {
      CON( printf("STR: Not enough memory.\n"); )
      LOG( fprintf(Log, "STR: Not enough memory.\n"); )
   }
   else {
      if(MemoryCount) {
         MemUsed[speciestree] += M16(nItypes * sizeof(double));
      }
      for(int k = 0; k < nItypes; k++) 
         mean[k] = 0.0;
   }
   return mean;
}

// Read species tree from given string or file (if str==NULL).
// Return true if species tree has been parsed correctly
#ifdef __GNUC__
#pragma warning(disable: 589)
#endif
bool     ReadSpeciesTree(char* str) {
   int   ntubes   = 0;        // number of old tree tubes
   double length  = 1.0;      // tube length (<=1: R, >1: add.nodes)
   int   specno   = 0;        // species no.
   char  name[MAXNODENAME] = "";
   char* etok     = NULL;     // end of current token
   char* tree     = NULL;
   SLICE* slc     = NULL;
   TUBE* parent   = NULL;     // current parent =pair of () 
   TUBE* tube     = NULL;     // current tube to fill data
   TUBE* outgroup = NULL;     // outgroup tube

   if( !str ) {
      if( !OpenSpeciesTree() ) {
         if(ModeSuper3Build)
            return false;
         goto Error;
      }

      tree = ReadStreeString();
      if( !tree ) goto Error;
      DBG( printf("\n%s\n\n", tree); )
      DBG( LOG( fprintf(Log, "\n%s\n\n", tree); ) )
   }
   else
      tree = str;

   // Establish species tree
   nIncluded = 0;
   if(Stree) 
      DeleteStree(Stree);
   Stree = (STREE*)malloc(sizeof(STREE));
   tube  = (TUBE*) malloc(sizeof(TUBE));
   if( !tube || !Stree ) {
      CON( printf("STR: Not enough memory.\n"); )
      LOG( fprintf(Log, "STR: Not enough memory.\n"); )
      goto Error;
   }
   if(MemoryCount) {
      MemUsed[speciestree] += M16(sizeof(STREE));
      MemUsed[speciestree] += M16(sizeof(TUBE));
   }
   Stree->root    = tube;
   Stree->height  = 0;
   Stree->slices  = NULL;
   Stree->tubes   = NULL;
   Stree->nleaves = Stree->ninteriors = Stree->ntubes = Stree->noldtubes = 0;

   tube->tubeno   = 0;
   tube->parent   = NULL;
   tube->left     = NULL;
   tube->right    = NULL;
   tube->oldtube  = tube;
   tube->height   = -1;
   tube->specno   = 0;
   tube->mean     = AllocateFI();
   tube->totmean  = AllocateFI();
   tube->length   = 1.0;      // to be changed if length<1
   memset(tube->name, 0, sizeof(name));
   
   // Parse tree loop

   for(char* p = tree; *p; p++) {

      if(*p == ';') {         // ';' found - end of tree

         if(!tube || parent) {
            CON( printf("STR: Symbol ';' prematurely encountered.\n"); )
            LOG( fprintf(Log, "STR: Symbol ';' prematurely encountered.\n"); )
            goto Error;
         }

         if(*name != 0) {
            strncpy(tube->name, name, MAXNODENAME-1);
            if(ModeSuper3Build) {
               tube->specno = specno;
               specno = 0;      
            }
         }
         else
            sprintf(tube->name, "R");

         if(length < 1.0)
            tube->length = length;

         break;
      }

      else if(*p == '(') {    // '(' found - push parent

         if(*name != 0) {
            CON( printf("STR: No delimiter after token before '('.\n"); )
            LOG( fprintf(Log, "STR: No delimiter after token before '('.\n"); )
            goto Error;
         }

         parent = tube;             // push

         tube = (TUBE*)malloc(sizeof(TUBE));
         if( !tube ) {
            CON( printf("STR: Not enough memory.\n"); )
            LOG( fprintf(Log, "STR: Not enough memory.\n"); )
            goto Error;
         }
         if(MemoryCount) {
            MemUsed[speciestree] += M16(sizeof(TUBE));
         }
         tube->tubeno   = 0;
         tube->parent   = parent;   // will be broken if length>1
         tube->left     = NULL;
         tube->right    = NULL;
         tube->oldtube  = tube;
         tube->height   = -1;
         tube->specno   = 0;
         tube->mean     = AllocateFI();
         tube->totmean  = AllocateFI();
         tube->length   = 1.0;      // to be changed if length<1
         memset(tube->name, 0, MAXNODENAME);

         parent->left = tube;       // will be broken if length>1
      }

      else if(*p == ')') {    // ')' found - pop parent

         if(*name == 0)
            sprintf(name, "S%d", ++ntubes);
         else if( _stricmp(name, OutgroupName) == 0)
            outgroup = tube;
         else if(ModeSuper3Build) {
            tube->specno = specno;
            specno = 0;      
         }
         strncpy(tube->name, name, MAXNODENAME-1);
         if(length < 1.0)
            tube->length = length;
         TUBE* oldtube = tube;
         
         for(int n = 1; n < (int)length; n++) {    // insert new (length-1) nodes

            TUBE* node = (TUBE*)malloc(sizeof(TUBE));
            if( !node ) {
               CON( printf("STR: Not enough memory.\n"); )
               LOG( fprintf(Log, "STR: Not enough memory.\n"); )
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[speciestree] += M16(sizeof(TUBE));
            }
            node->tubeno   = 0;
            node->parent   = parent;
            node->left     = tube;
            node->right    = NULL;
            node->oldtube  = oldtube;
            node->height   = -1;
            node->specno   = 0;
            node->mean     = AllocateFI();
            node->totmean  = AllocateFI();
            node->length   = 1.0;
            sprintf(node->name, "%s_%d", name, n);

            tube->parent   = node;
            if (parent->right == tube)
               parent->right = node;
            else if (parent->left == tube)
               parent->left = node;
            else {
               printf("STR: Internal tree inconsistence.\n");
               goto Error;
            }

            tube = node;
         }
         *name = 0;
         length = 1.0;
         tube = parent;             // pop
         parent = tube->parent;
      }

      else if(*p == ',') {    // ',' found - add sibling

         if(*name == 0)
            sprintf(name, "S%d", ++ntubes);
         else if( _stricmp(name, OutgroupName) == 0)
            outgroup = tube;
         else if(ModeSuper3Build) {
            tube->specno = specno;
            specno = 0;      
         }
         strncpy(tube->name, name, MAXNODENAME-1);
         if(length < 1.0)
            tube->length = length;
         TUBE* oldtube = tube;
         
         for(int n = 1; n < (int)length; n++) {    // insert new (length-1) nodes

            TUBE* node = (TUBE*)malloc(sizeof(TUBE));
            if( !node ) {
               printf("STR: Not enough memory.\n");
               goto Error;
            }
            if(MemoryCount) {
               MemUsed[speciestree] += M16(sizeof(TUBE));
            }
            node->tubeno   = 0;
            node->parent   = parent;
            node->left     = tube;
            node->right    = NULL;
            node->oldtube  = oldtube;
            node->height   = -1;
            node->specno   = 0;
            node->mean     = AllocateFI();
            node->totmean  = AllocateFI();
            sprintf(node->name, "%s_%d", name, n);

            tube->parent   = node;
            if (parent->right == tube)
               parent->right = node;
            else if (parent->left == tube)
               parent->left = node;
            else {
               CON( printf("STR: Internal tree inconsistence.\n"); )
               LOG( fprintf(Log, "STR: Internal tree inconsistence.\n"); )
               goto Error;
            }

            tube = node;
         }
         *name = 0;
         length = 1.0;

         if(parent->right) {
            CON( printf("STR: A node with more than two children found.\n"); )
            LOG( fprintf(Log, "STR: A node with more than two children found.\n"); )
            goto Error;
         }
                                    // add sibling
         tube = (TUBE*)malloc(sizeof(TUBE));
         if( !tube ) {
            CON( printf("STR: Not enough memory.\n"); )
            LOG( fprintf(Log, "STR: Not enough memory.\n"); )
            goto Error;
         }
         if(MemoryCount) {
            MemUsed[speciestree] += M16(sizeof(TUBE));
         }
         tube->tubeno   = 0;
         tube->parent   = parent;   // will be broken if length>1
         tube->left     = NULL;
         tube->right    = NULL;
         tube->oldtube  = tube;
         tube->height   = -1;
         tube->specno   = 0;
         tube->mean     = AllocateFI();
         tube->totmean  = AllocateFI();
         tube->length   = 1.0;      // to be changed if length<1
         memset(tube->name, 0, MAXNODENAME);

         parent->right  = tube;
      }
      else {                  // token found - process

         // Find end of token
         etok = strpbrk(p, ";(),:");
         if( !etok ) {
            CON( printf("STR: End of tree not found.\n"); )
            LOG( fprintf(Log, "STR: End of tree not found.\n"); )
            goto Error;
         }

         // Count necessary words
         int nwords = 0;
         char* q;
         for(q = p; q != etok; ++q) {
            if(*q == '_')
               ++nwords;
         }
         if(q == etok)
            nwords++;
         if(nwords < LeafMinWords) {
            CON( printf("STR: Too few words in a name.\n"); )
            LOG( fprintf(Log, "STR: Too few words in a name.\n"); )
            goto Error;
         }

         // Store edge length if any
         length = (*etok == ':') ? atof(etok + 1) : 1.0;
         if(length <= 0) {
            CON( printf("STR: Invalid edge length %g specified.\n", length); )
            LOG( fprintf(Log, "STR: Invalid edge length %g specified.\n", length); )
            goto Error;
         }

         if(q == p)
            name[0] = 0;
         else if(q - p >= MAXNODENAME) {
            CON( printf("STR: Max length of node name exceeded.\n"); )
            LOG( fprintf(Log, "STR: Max length of node name exceeded.\n"); )
            goto Error;
         }
         else {
            memcpy(name, p, q - p);
            name[q - p] = 0;
            if(ModeSuper3Build && !tube->left && !tube->right) {
               specno = FindSpecies(name);
               if(specno == 0 && _stricmp(name, OutgroupName) != 0) {
                  CON( printf("STR: Can't find species name %s.\n", name); )
                  LOG( fprintf(Log, "STR: Can't find species name %s.\n", name); )
                  goto Error;
               }
               else if(specno) {
                  Species[specno].enable = true;
                  nIncluded++;
               }
            }
         }
         
         if(*etok == ':') {
            etok = strpbrk(etok, ";(),");
            if( !etok ) {
               CON( printf("STR: End of tree not found.\n"); )
               LOG( fprintf(Log, "STR: End of tree not found.\n"); )
               goto Error;
            }
         }
         p = etok - 1;     // position to continue
      }
   }


   // Fill levels and check alignment of species tree
   if( !FillStreeHeights() ) {
      CON( printf("STR: Found leaf %s at nonzero height %d.\n", 
         badleaf->name, badleaf->height); )
      LOG( fprintf(Log, "STR: Found leaf %s at nonzero height %d.\n", 
         badleaf->name, badleaf->height); )
      goto Error;
   }

   // Make outgroup the first tube of each slice
   if( !outgroup ) {
      CON( printf("STR: Outgroup not found in species tree.\n"); )
      LOG( fprintf(Log, "STR: Outgroup not found in species tree.\n"); )
      goto Error;
   }
   tube = outgroup;
   while(tube->parent) {
      if(tube->parent->left != tube) {    // swap children
         if(tube->parent->right != tube) {
            CON( printf("STR: Outgroup path is broken.\n"); )
            LOG( fprintf(Log, "STR: Outgroup path is broken.\n"); )
            goto Error;
         }
         TUBE* tmp = tube->parent->left;
         tube->parent->left = tube;
         tube->parent->right = tmp;
      }
      tube = tube->parent;                // step upwards
   }

   // Form table of slices
   Stree->slices = (SLICE*)malloc( (Stree->height + 1) * sizeof(SLICE) );
   if( !Stree->slices ) {
      CON( printf("STR: Not enough memory.\n"); )
      LOG( fprintf(Log, "STR: Not enough memory.\n"); )
      goto Error;
   }
   if(MemoryCount) {
      MemUsed[speciestree] += M16((Stree->height + 1) * sizeof(SLICE));
   }
   // Clear ntubes & initially allocate slices
   slc = Stree->slices;
   for(int n = 0; n <= Stree->height; n++,slc++) {
      slc->ntubes = 0;
      slc->tubes = (TUBE**)malloc(MAXSPECIES * sizeof(TUBE*));
      if( !slc->tubes ) {
         CON( printf("STR: Not enough memory.\n"); )
         LOG( fprintf(Log, "STR: Not enough memory.\n"); )
         goto Error;
      }
      if(MemoryCount) {
         MemUsed[speciestree] += M16(MAXSPECIES * sizeof(TUBE*));
      }
      for(int j = 0; j < MAXSPECIES; ++j) slc->tubes[j] = NULL;
   }

   FillSlices(Stree->root);      // Fill slices

   // Finalize slices
   slc = Stree->slices;
   for(int n = 0; n <= Stree->height; n++,slc++) {
      slc->tubes = (TUBE**)realloc(slc->tubes, slc->ntubes * sizeof(TUBE*));
      if( !slc->tubes ) {
         CON( printf("STR: Not enough memory.\n"); )
         LOG( fprintf(Log, "STR: Not enough memory.\n"); )
         goto Error;
      }
      if(MemoryCount) {
         MemUsed[speciestree] -= M16((MAXSPECIES - slc->ntubes) * sizeof(TUBE*));
      }
      Stree->ntubes += slc->ntubes;
      if(n == 0)
         Stree->nleaves    += slc->ntubes;
      else
         Stree->ninteriors += slc->ntubes;
   }
   
   // Fill species table
   if( !ModeSuper3Build ) {
      slc = Stree->slices;
      for(int i = 0; i < slc->ntubes; i++) {
         TUBE* leaf = slc->tubes[i];
         leaf->specno = i;
         strcpy(name, leaf->name);
         // Take no more than LeafMaxWords
         char* p = name;
         int   nwords = 0;
         while(p = strchr(p, '_')) {
            if(++nwords >= LeafMaxWords)
               break;
            p++;
         }
         if(p)    *p = 0;
         else     ++nwords;
         if(nwords > LeafMaxWords) {
            CON( printf("STR: Too many words in name %s.\n", leaf->name); )
            LOG( fprintf(Log, "STR: Too many words in name %s.\n", leaf->name); )
         }

         if( !InsertSpecies(name, i) ) {
            CON( printf("STR: Cannot insert or duplicated species %s.\n", 
               leaf->name); )
            LOG( fprintf(Log, "STR: Cannot insert or duplicated species %s.\n", 
               leaf->name); )
            goto Error;
         }
      }
   }

   // Fill common sequence of all tubes
   Stree->tubes = (TUBE**)malloc((Stree->ntubes + 1) * sizeof(TUBE*));
   if( !Stree->tubes ) {
      CON( printf("STR: Not enough memory.\n"); )
      LOG( fprintf(Log, "STR: Not enough memory.\n"); )
      goto Error;
   }
   if(MemoryCount) {
      MemUsed[speciestree] += M16((Stree->ntubes + 1) * sizeof(TUBE*));
   }
   Stree->tubes[0] = NULL;    // Reserve first entry to number tubes from 1
   for(int n = 1, k = 0; k <= Stree->height; k++) {    // loop over slices
      for(int i = 0; i < Stree->slices[k].ntubes; i++) {  // across slice
         TUBE* tmp = Stree->slices[k].tubes[i];
         tmp->tubeno = n;
         Stree->tubes[n++] = tmp;
      }
   }
 
   DBG( PrintStree(Stree->root, stdout, &StreeMode); )
   DBG( if(StreeMode.enable) printf(";\n\n"); )

   if(StreeMode.enable && Log && !ModeSuper3Build) {
      fprintf(Log, "\n");
      PrintStree(Stree->root, Log, &StreeMode);
      fprintf(Log, ";\n\n");
   }

   if(!str) {
      fclose(stf);
      free(tree);
      if(MemoryCount) {
         MemUsed[speciestree] -= M16(MAXTREELEN + 1);
      }
   }
   return true;

Error:
   if(!str && ModeSuper3Build) {
      CON( printf("STR: Existing supertree ignored.\n"); )
      LOG( fprintf(Log, "STR: Existing supertree ignored.\n"); )
   }
   return false;
}

// Return true if current species tree has been written correctly
bool     WriteSpeciesTree(void) {
   char*    streefilename = (char*)malloc(BUFLEN);
   if( !streefilename ) {
      CON( printf("STW: Not enough memory.\n"); )
      LOG( fprintf(Log, "STW: Not enough memory.\n"); )
      return false;
   }
   if(MemoryCount) {
      MemUsed[speciestree] += M16(BUFLEN);
   }
   streefilename[0] = 0;

   strcpy(streefilename, DataDirectory);
   strcat(streefilename, SpeciesTreeName);
   stf = fopen(streefilename, "wt");
   if( !stf ) {
      CON( printf("STW: Cannot write species tree '%s'.\n", streefilename); )
      LOG( fprintf(Log, "STR: Cannot write species tree '%s'.\n", streefilename); )
      return false;
   }
   free(streefilename);
   if(MemoryCount) {
      MemUsed[speciestree] -= M16(BUFLEN);
   }

   PrintStree(Stree->root, stf, &StreeMode);
   fprintf(stf, ";\n");
   fclose(stf);
   return true;
}

// Set tube.oldtube=tube for old tubes, =old_tube for its new tubes
void     MarkOldNewTubes(void) {
   Stree->noldtubes = 0;
   for(int h = 0; h < Stree->height; h++) {
      SLICE* slc = Stree->slices + h;
      for(int n = 0; n < slc->ntubes; n++) {
         TUBE* tube     = slc->tubes[n];
         TUBE* parent   = tube->parent;
         if(h == 0) {
            tube->oldtube = tube;
            Stree->noldtubes++;
         }
         else if(parent->left && parent->right) {
            if(tube->left && tube->right) {
               tube->oldtube = tube;
               Stree->noldtubes++;
            }
            else {
               tube->oldtube = tube->left ? 
                  tube->left->oldtube : tube->right->oldtube;
            }
         }
         else if(tube->left && tube->right) {
            tube->oldtube = tube;
            Stree->noldtubes++;
         }
         else {
            tube->oldtube = tube->left ? 
               tube->left->oldtube : tube->right->oldtube;
         }
      }
   }
   Stree->root->oldtube = Stree->root;
   Stree->noldtubes++;
}
