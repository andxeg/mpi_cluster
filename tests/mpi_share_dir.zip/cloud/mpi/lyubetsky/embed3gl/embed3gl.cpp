// embed3GL: A program for phylogenetic study of joint gene & species evolution.
//
// The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/embed3gl]
//
// (C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
// E-mail: rubanov{at}iitp.ru
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// Functions: main, ElapsedMin, SetDefaultMode, EarlyCheckMpi, 
//            InitializeExports, InitializeLog 

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#ifndef  EMBED3MPI
#include <time.h>
#endif
#include <math.h>
#define  EMBED3GL_ALLOCATE
#include "embed3gl.h"

// Exit codes: 0=ok, 1=no memory, 2=data error, 3=i/o error, 4=internal error
int main(int argc, char **argv) {
   InitializeExports(argc, argv);
#ifdef   EMBED3MPI
   if(rank_mpi)   Console = false;    // Output only to root console for now
#endif
   CON( printf("\n"
      "embed3GL: Phylogenetic study of joint gene & species evolution. V.%s\n"
      "The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/embed3gl]\n"
      "(C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS\n\n"
   	"This program is distributed in the hope that it will be useful,\n"
   	"but WITHOUT ANY WARRANTY; without even the implied warranty of\n"
   	"MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n"
   	"GNU General Public License for more details.\n\n", Version); )

   if( !ParseArguments(argc, argv) ) {
      #ifdef   EMBED3MPI
      if(embed3_mpi)
         MPI::COMM_WORLD.Abort(2);
      else
      #endif
      exit(2);    // argument error or help requested
   }

   if( !ReadConfigFile() ) {
      #ifdef   EMBED3MPI
      if(embed3_mpi)
         MPI::COMM_WORLD.Abort(2);
      else
      #endif
      exit(2);    // config error
   }

   if(Milestones > 0)
      Milestones = 1 << Milestones;

#ifdef   EMBED3MPI
   if(rank_mpi)   Console = SecondaryCon;
#endif

   InitializeLog();
   LOG( fprintf(Log, "\n"
      "embed3GL: Phylogenetic study of joint gene & species evolution. V.%s\n"
      "The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/embed3gl]\n"
      "(C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS\n\n"
   	"This program is distributed in the hope that it will be useful,\n"
   	"but WITHOUT ANY WARRANTY; without even the implied warranty of\n"
   	"MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n"
   	"GNU General Public License for more details.\n\n", Version); )
   if(argc > 1) {
	   LOG( fprintf(Log, "Command line:"); )
	   LOG( for(int i = 1; i < argc; ++i) 
              fprintf(Log, " %s", argv[i]); )
	   LOG( fprintf(Log, "\n"); )
   }

   LOG( fprintf(Log, "Tasks:"); )
   if(ModeOptimumCost)
      LOG( fprintf(Log, " 1=OptimumCost"); )
   if(ModeEmbedding) 
      LOG( fprintf(Log, " 2=Embedding(scenario)"); )
   if(ModeStatistics)
      LOG( fprintf(Log, " 3=Evolution_statistics"); )
   if(ModeSuper3Build)
      LOG( fprintf(Log, " 4=Supertree"); )
#ifdef   EMBED3MPI
   if(embed3_mpi && size_mpi > 1) {
      CON( printf("MPI %d.%d: size=%d rank=%d", 
         ver_mpi, sub_mpi, size_mpi, rank_mpi); )
      LOG( fprintf(Log, "  MPI(%d.%d)=%d", 
         ver_mpi, sub_mpi, size_mpi); )
   }
#endif
   CON( printf("\n"); )
   LOG( fprintf(Log, "\n"); )

   if(!ModeSuper3Build && k_correction > 0) {        // Apply K_correction
      double corr    = k_correction * log((double)MaxEvents) / log(2.0);
      int icorr      = (int)(corr * SCALE);
      c_tr_with     += icorr;
      c_tr_without  += icorr;
   }
   CON( printf("Costs: loss=%g loss1=%g dupl=%g gain=%g gain_big=%g "
      "tr_with=%g tr_without=%g (init=%g power=%g K=%d) weight=%s.\n",
      c_loss/SCALE, c_loss1/SCALE, c_dupl/SCALE, c_gain/SCALE, c_gain_big/SCALE, 
      c_tr_with/SCALE, c_tr_without/SCALE, c_init/SCALE, c_exponent, 
      MaxEvents, TreeWeight ? "yes" : "no"); )
   LOG( fprintf(Log, "Costs: loss=%g loss1=%g dupl=%g gain=%g gain_big=%g "
      "tr_with=%g tr_without=%g (init=%g power=%g K=%d) weight=%s.\n",
      c_loss/SCALE, c_loss1/SCALE, c_dupl/SCALE, c_gain/SCALE, c_gain_big/SCALE, 
      c_tr_with/SCALE, c_tr_without/SCALE, c_init/SCALE, c_exponent, 
      MaxEvents, TreeWeight ? "yes" : "no"); )

   if(ModeSuper3Build) { 
      if(ModeOptimumCost || ModeEmbedding || ModeStatistics) {
         CON( printf("%4dm: Supertree building is incompatible with other modes!\n", ElapsedMin(true)); )
         LOG( fprintf(Log, "%4dm: Supertree building is incompatible with other modes!\n", ElapsedMin(true)); )
         ModeOptimumCost = ModeEmbedding = ModeStatistics = false;
      }
      MaxEvents = 1;       // Enough to compute costs
      DBG( printf("\n"); )
      DBG( fprintf(Log, "\n"); )

      // Read basis trees, fill Species table - All branches
      if( !ProcessBasisTrees() ) {
         #ifdef   EMBED3MPI
         if(embed3_mpi)
            MPI::COMM_WORLD.Abort(5);
         else
         #endif
         exit(5);
      }
      
      // Attempt to read existing partial supertree - All branches
      if( !ReadSpeciesTree(NULL) ) {
         // Make dummy initial tree and fill it
         if( !MakeDummyStree() || !FillTubeDistances() ) {
            #ifdef   EMBED3MPI
            if(embed3_mpi)
               MPI::COMM_WORLD.Abort(5);
            else
            #endif
            exit(5);
         }
         SelectInitialStree();   // Optional parallelization inside
      }
      else if( !FillTubeDistances() ) {
         #ifdef   EMBED3MPI
         if(embed3_mpi)
            MPI::COMM_WORLD.Abort(5);
         else
         #endif
         exit(5);
      }
      // Calculate cost and print tree - Root branch only
      #ifdef   EMBED3MPI
      else if(!embed3_mpi || rank_mpi == 0) {
      #else
      else {
      #endif
         int tc = 0;
         for (int n = 1; n <= nBtrees; n++) {
            PruneBasisTree( Btree[n-1] );      // result in Gtree
            if( !Gtree )
               continue;
            int cost = ComputeCost();
            if(GtreeMode.enable && Log) {
               fprintf(Log, "%7.1f <= ", cost/SCALE); 
               PrintGtree(Gtree->root, Log, &GtreeMode);
               fprintf(Log, ";\n");
            }
            tc += cost;
            DestructGtree();
         }
         CON( printf("%4dm:   N=%d  TotalC=%g\n", ElapsedMin(true), nIncluded, tc/SCALE); )
         LOG( fprintf(Log, "%4dm:   N=%d  TotalC=%g\n", ElapsedMin(true), nIncluded, tc/SCALE); )
         LOG( PrintStree(Stree->root, Log, &StreeMode); )
         LOG( fprintf(Log, ";\n"); )
         if( !WriteSpeciesTree() ) {
            #ifdef   EMBED3MPI
            if(embed3_mpi)
               MPI::COMM_WORLD.Abort(3);
            else
            #endif
            exit(3);
         }
      }
      // Induction step - All branches
      while(nIncluded < nSpecies) {
         MarkOldNewTubes();
         if( !MakeInductionStep() )   // Optional parallelization inside
            break;
         // Write last supertree in output file - Root branch only
         #ifdef   EMBED3MPI
         if(!embed3_mpi || rank_mpi == 0)
         #endif
         if( !WriteSpeciesTree() ) {
            #ifdef   EMBED3MPI
            if(embed3_mpi)
               MPI::COMM_WORLD.Abort(3);
            else
            #endif
            exit(3);
         }
      }

   #ifdef   EMBED3MPI
      if((!embed3_mpi || rank_mpi == 0) && nIncluded < nSpecies) {
   #else
      if(nIncluded < nSpecies) {
   #endif
         // List remaining species
         int rsp = nSpecies - nIncluded;
         CON( printf("\nCannot include %d species.\n", rsp); )
         LOG( fprintf(Log, "\nCannot include %d species.\n", rsp); )
         rsp = 1;
         for(int n = 1; n <= nSpecies; n++)
            if(!Species[n].enable)
               LOG( fprintf(Log, "%d) #%d = %s\n", rsp++, n, Species[n].name); )
      }
      #ifdef EMBED3MPI
      else if(!embed3_mpi || rank_mpi == 0){
         CON( printf("%4dm: Supertree built successfully.\n\n", ElapsedMin(true)); )
         LOG( fprintf(Log, "%4dm: Supertree built successfully.\n", ElapsedMin(true)); )
      }
      #endif
   }

   else {
      if(ModeStatistics && Itype != I_none) {
         unsigned m = 1;
         CON( printf("Itype:"); )
         CON( for(int i = 0; i < nItypes - 1; i++, m <<= 1) )     // -1 as I_loss1 is hidden
            CON( if(Itype & m) printf(" %s", ItypeNames[i]); )
         CON( printf("  (MaxEvents=%d K_correction=%g).\n", 
            MaxEvents, k_correction); )
         LOG( fprintf(Log, "Itype:"); )
         m = 1;
         LOG( for(int i = 0; i < nItypes - 1; i++, m <<= 1) )     // -1 as I_loss1 is hidden
            LOG( if(Itype & m) fprintf(Log, " %s", ItypeNames[i]); )
         LOG( fprintf(Log, "  (MaxEvents=%d K_correction=%g).\n", 
            MaxEvents, k_correction); )
      }

      if( !ReadSpeciesTree(NULL) || !FillTubeDistances() ) {
         #ifdef   EMBED3MPI
         if(embed3_mpi)
            MPI::COMM_WORLD.Abort(5);
         else
         #endif
         exit(5);    // species tree error
      }
      MarkOldNewTubes();
      nSpecies = Stree->nleaves-1;
      CON( printf("%4dm: Species tree read OK: tubes=%d(%d) leaves=%d+1 slices=%d.\n",
         ElapsedMin(true), Stree->ntubes, Stree->noldtubes, 
         nSpecies, Stree->height + 1); )
      LOG( fprintf(Log, "%4dm: Species tree read OK: tubes=%d(%d) leaves=%d+1 slices=%d.\n",
         ElapsedMin(true), Stree->ntubes, Stree->noldtubes, 
         nSpecies, Stree->height + 1); )

      if(ModeStatistics) {    // Allocate g(I,T) and g[j](I,T)
         gIT   = (double*)malloc(nItypes * sizeof(double));
         gjIT  = (double*)malloc(nItypes * sizeof(double));
         if( !gIT || !gjIT) {
            CON( printf("STA: Not enough memory.\n"); )
            LOG( fprintf(Log, "STA: Not enough memory.\n"); )
            #ifdef   EMBED3MPI
            if(embed3_mpi)
               MPI::COMM_WORLD.Abort(1);
            else
            #endif
            exit(1);
         }
         if(MemoryCount) {
            MemUsed[housekeeping] += M16(nItypes * sizeof(double));
            MemUsed[housekeeping] += M16(nItypes * sizeof(double));
         }
         for(int k = 0; k < nItypes; k++) gIT[k] = 0.0;
      }

      if( !ProcessGeneTrees() ) {    // NB: Parallel processing inside!
         #ifdef   EMBED3MPI
         if(embed3_mpi)
            MPI::COMM_WORLD.Abort(5);
         else
         #endif
         exit(5);    // gene tree error
      }

      CON( printf("%4dm: %d gene tree(s) read, %d processed successfully.\n", 
         ElapsedMin(true), Treeno, ProcessedTrees); )
      LOG( fprintf(Log, "%4dm: %d gene tree(s) read, %d processed successfully.\n", 
         ElapsedMin(true), Treeno, ProcessedTrees); )
      if(ModeOptimumCost) {
         CON( printf("Task1: Total cost of optimum scenarios = %.*f.\n", 
            T1Precision, TotalCost/SCALE); )
         LOG( fprintf(Log, "Task1: Total cost of optimum scenarios = %.*f.\n", 
            T1Precision, TotalCost/SCALE); )
      }
   }

   if(MemoryCount) {
      __int64 MemTotal = MemPeak[genetree] + MemPeak[scenario] +
            MemPeak[ognodes] + MemPeak[ogedges] + MemPeak[ogtriples];
      if(Log) fprintf(Log, "Mem_K: hk=%d st=%d gt=%d sc=%d on=%d oe=%d ot=%d total=%d\n",
         (int)(MemPeak[housekeeping] >> 10), 
         (int)(MemPeak[speciestree] >> 10), 
         (int)(MemPeak[genetree] >> 10), 
         (int)(MemPeak[scenario] >> 10), 
         (int)(MemPeak[ognodes] >> 10), 
         (int)(MemPeak[ogedges] >> 10), 
         (int)(MemPeak[ogtriples] >> 10), 
         (int)((MemTotal + MemPeak[housekeeping] + MemPeak[speciestree]) >> 10));
   }
   #ifdef   EMBED3MPI
   if(embed3_mpi)
      MPI::Finalize();
   #endif
   return 0;
}

int      ElapsedMin(bool now) {
   int      elapsed = 0;
#ifdef   EMBED3MPI
   if(embed3_mpi) {
      static double StartTime;
      if(now)
         elapsed = (int)((MPI::Wtime() - StartTime) / 60.0);
      else 
         StartTime = MPI::Wtime();
   }
   else
#endif
   {
      static time_t StartTime;        // Starting time
      time_t   t;
      if(now)
         elapsed = (int)(difftime(time(&t), StartTime) / 60.0);
      else
         time(&StartTime);
   }
   return elapsed;
}
void     SetDefaultMode(TREEMODE* mode) {
   memset(mode, 0, sizeof(TREEMODE));
   //mode->enable         = 1;
   //mode->length_root    = 1;
   //mode->length_inner   = 1;
   //mode->length_leaf    = 1;
   //mode->label_root     = 1;
   //mode->label_inner    = 1;
   //mode->label_leaf     = 1;
   //mode->number_root    = 1;
   //mode->number_inner   = 1;
   //mode->number_leaf    = 1;
   //mode->full_labels    = 1;
}

bool     EarlyCheckMpi(int argc, char **argv) {
   for(int i = 1; i < argc; i++) {
      if((argv[i][0] == '-' || argv[i][0] == '/') &&
         (_stricmp(argv[i] + 1, "nompi") == 0 || 
          _stricmp(argv[i] + 1, "-mpi")  == 0 ||
          _stricmp(argv[i] + 1, "h")     == 0) )
            return false;
   }
   return true;
}

void     InitializeExports(int argc, char **argv) {
#ifdef   EMBED3MPI
   embed3_mpi  = EarlyCheckMpi(argc, argv);
   if(embed3_mpi) {
		ver_mpi = 0;
      sub_mpi = 0;
		MPI::Get_version(ver_mpi, sub_mpi);
      if(!(ver_mpi == 2 && sub_mpi >= 0 && sub_mpi <= 2 || 
         ver_mpi == 1 && sub_mpi == 2)) {
			printf("Improper MPI version %d.%d -- use nompi mode.\n", ver_mpi, sub_mpi);
         embed3_mpi  = false;
		   size_mpi    = 1;
		   rank_mpi    = 0;
      }
      else {
		   MPI::Init(argc, argv);
		   size_mpi = MPI::COMM_WORLD.Get_size();
		   rank_mpi = MPI::COMM_WORLD.Get_rank();
      }
   }
   else {
		size_mpi = 1;
		rank_mpi = 0;
   }
#endif
   ElapsedMin(false);
   Stree = NULL;
   sprintf(ConfigFilename, "embed3GL.ini");
   sprintf(LogFilename,    "embed3GL.log");
   memset(DataDirectory, 0, MAXPATH);
   memset(SpeciesTreeName, 0, MAXPATH);
   Console        = true;
   Console2Log    = true;
   SecondaryCon   = false;
   SecondaryLog   = false;
   Log            = NULL;
   LogAppend      = false;
   SetDefaultMode(&StreeMode);
   SetDefaultMode(&GtreeMode);
   LogTable1      = false;
   T1TextID       = true;
   T1EdgeLabel    = 5;
   T1EdgeNumber   = 3;
   T1TubeLabel    = 5;
   T1TubeNumber   = 3;
   T1Precision    = 0;
   LeafMinWords   = 1;
   LeafMaxWords   = 1;
   TmarkChar      = '*';
   TmarkAnywhere  = true;
   TmarkShow      = true;
   TreeWeight     = false;
   MinWeightGiven = false;
   MinWeight      = 0.25;
   StopLabel      = '\0';
   LogScenario    = true;
   LogS2Message   = true;
   ConS2Message   = true;
   S2Condense     = true;
   S2Indent       = 4;
   S2EdgeLabel    = 5;
   S2EdgeNumber   = 3;
   S2TubeLabel    = 5;
   S2TubeNumber   = 3;
   S2EventID      = 0;
   S2EventLabel   = 8;
   S2EventCost    = 6;
   S2Precision    = 0;
   LogOrbigraph0  = false;
   LogOrbigraph   = true;
   LogOgMessage   = true;
   ConOgMessage   = true;
   OgEdgeLabel    = 5;
   OgEdgeNumber   = 3;
   OgTubeLabel    = 5;
   OgTubeNumber   = 3;
   OgPrecision    = 6;
   OptimumCostJ  = false;
   LogTmarkJ      = true;
   LogTubeJ       = true;
   LogOTubeJ      = true;
   LogMeanJ       = true;
   LogMemoryJ     = true;
   LogTmarkStats  = true;
   LogTubeStats   = true;
   LogOTubeStats  = true;
   LogTotalMean   = true;
   MeanWidth      = 10;
   MeanPrecision  = 6;
   strncpy(OutgroupName, "Out", sizeof(OutgroupName) - 1);
   MaxEvents      = 1;
   Milestones     = 6;
   QueueLog       = 0;
   Gtree          = NULL;
   Treeno         = 0;
   ProcessedTrees = 0;
   TotalCost      = 0;
   Scenario       = NULL;
   GeneTreeNameFirst = NULL;
   GeneTreeNameLast  = NULL;
   static const char*   event_names[] = {
      "fin",         //  0 
      "tr_fin",      //  1 
      "ga_fin",      //  2    
      "pass",        //  3 
      "fork_lr",     //  4
      "fork_rl",     //  5
      "pass_l",      //  6
      "pass_r",      //  7
      "nout_l",      //  8
      "nout_r",      //  9
      "out_l",       // 10
      "out_r",       // 11
      "dupl",        // 12
      "dup0_l",      // 13
      "dup0_r",      // 14
      "outd",        // 15
      "tr1",         // 16
      "tr2",         // 17
      "ga1",         // 18
      "ga2",         // 19
      "ga_big",      // 20
      "tr_pass",     // 21
      "ga_pass",     // 22
      "tr_lr",       // 23
      "tr_rl",       // 24
      "ga_lr",       // 25
      "ga_rl",       // 26
      "tr_l",        // 27
      "tr_r",        // 28
      "ga_l",        // 29
      "ga_r",        // 30
      "tr_dupl",     // 31
      "ga_dupl",     // 32
      "tr",          // 33
      "ga"           // 34
   };
   nEvents        = 35;       // Must be consistent with event_names array!
   EventNames     = event_names;
   c_loss         = (int)( 2 * SCALE);
   c_loss1        = (int)( 1 * SCALE);
   c_dupl         = (int)( 3 * SCALE);
   c_tr_with      = (int)(11 * SCALE);
   c_tr_without   = (int)(13 * SCALE);
   c_gain         = (int)(12 * SCALE);
   c_gain_big     = (int)(10 * SCALE);
   c_init         = (int)( 3 * SCALE);
   c_exponent     = 3.0;
   k_correction   = 2.0;
   r_shift        = 0.0;
   static const char*   I_names[] = {
      "gain",        // 1
      "loss",        // 2
      "dupl",        // 4
      "tr_o",        // 8
      "tr_i",        // 16
      "gain_big",    // 32
      "loss1"        // 64    hidden, linked with "loss"
   };
   nItypes        = 7;       // Must be consistent with I_names array!
   ItypeNames     = I_names;
   Itype          = I_none;
   gIT            = NULL;
   gjIT           = NULL;
   Ograph         = NULL;
   OgUnary        = 0;
   OgBinary       = 0;
   OgTriples      = 0;
   Cmd_gain       = false;
   Cmd_loss       = false;
   Cmd_loss1      = false;
   Cmd_dupl       = false;
   Cmd_tr_with    = false;
   Cmd_tr_without = false;
   Cmd_gain_big   = false;
   Cmd_init_cost  = false;
   Cmd_exponent   = false;
   Cmd_correction = false;
   Cmd_shift      = false;
   ModeOptimumCost = false;
   ModeEmbedding  = false;
   ModeStatistics = false;
   ModeSuper3Build = false;
   CmdSpeciesTree = false;
   CmdNoGeneTrees = false;
   CmdLogfile     = false;
   CmdMaxEvents   = false;
   MemoryCount    = false;
   for(int i = 0; i < nMemTypes; i++) {
      MemUsed[i] = 0;
      MemPeak[i] = 0;
   }
   nSpecies = 0;
   nBtrees  = BTREEPART;
   Btree    = (GTREE**) malloc(nBtrees * sizeof(GTREE*));
   MemUsed[genetree] += M16( (sizeof(GTREE*)+sizeof(double)) * BTREEPART);
}
void     InitializeLog(void) {
#ifdef   EMBED3MPI
   if(embed3_mpi && rank_mpi && !SecondaryLog) {
      Console2Log = false;
      Log = NULL;
      return;
   }
#endif
   if(*LogFilename) {
      char filename[MAXPATH*2+1];
      strcpy(filename, DataDirectory);
      strcat(filename, LogFilename);
   #ifdef EMBED3MPI
      if(rank_mpi) {
         char bb[8];
         sprintf(bb, "_%d", rank_mpi);
         strcat(filename, bb);
      }
   #endif
      Log = fopen(filename, LogAppend ? "at" : "wt");
      if( !Log )
         CON( printf("Cannot open log file '%s'.\n", filename); )
   }
   else Log = NULL;
}
