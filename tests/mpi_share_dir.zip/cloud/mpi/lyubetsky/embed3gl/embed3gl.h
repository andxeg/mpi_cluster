// embed3GL: A program for phylogenetic study of joint gene & species evolution.
//
// The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/embed3gl]
//
// (C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
// E-mail: rubanov{at}iitp.ru
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// Common header file (global declarations and type definitions)

#ifndef  EMBED3GL_H
#define  EMBED3GL_H

#ifdef   EMBED3GL_ALLOCATE
#  define   EXPORT
#else
#  define   EXPORT      extern
#endif

//#define NOMPI
#ifndef  NOMPI          // To be defined in IDE configuration or makefile [-DNOMPI]
#define  EMBED3MPI      // Include code for MPI parallelization
#endif

#ifdef   EMBED3MPI
#undef SEEK_SET
#undef SEEK_CUR
#undef SEEK_END
#include "mpi.h"
#endif

#define  CON(x)   if(Console) x
#define  LOG(x)   if(Log && Console2Log) x
#define  M16(x)   ((x) & 15) == 0 ? (x) : (((x) + 16) >> 4) << 4;

#ifdef __GNUC__
#define _stricmp(str1, str2)           strcasecmp((str1), (str2))
#define _strnicmp(str1, str2, count)   strncasecmp((str1), (str2), (count))
#define __max(a,b)  (((a) > (b)) ? (a) : (b))
#define __min(a,b)  (((a) < (b)) ? (a) : (b))
#define __int64   long long
#endif

const char  Version[]   = "1.1.7";

// Global limits 
const int   MAXSPECIES  = 1024;
const int   MAXLEVELS   = 128;
const int   MAXGENES    = 1024;     // Per gene tree
const int   MAXPOLYTOMY = 32;
const int   MAXPATH     = 256;
const int   BUFLEN      = 65535;
const int   MAXTREELEN  = 1024*1024;
const int   MAXNODENAME = 64;
const int   BTREEPART   = 64;       // BTree array increment
const double   SCALE    = 100.0;    // For all cost values

// Tree output options
struct   TREEMODE {
   unsigned short enable         : 1;     // enable print
   unsigned short length_root    : 1;     // print edge lengths
   unsigned short length_inner   : 1;
   unsigned short length_leaf    : 1;
   unsigned short label_root     : 1;     // print node labels
   unsigned short label_inner    : 1;
   unsigned short label_leaf     : 1;
   unsigned short number_root    : 1;     // print node numbers
   unsigned short number_inner   : 1;
   unsigned short number_leaf    : 1;
   unsigned short full_labels    : 1;     // full labels or species
   unsigned short heading        : 1;     // print tree heading as comment
};

// Forward declarations
struct   TUBE;
struct   GTNAME;
struct   SLICE;
struct   EDGE;
struct   LEVEL;
struct   EVENT;
struct   SCENARIO;
struct   OGNODE;
struct   OGEDGE;
struct   TRIPLE;

// Expanded species tree 
struct   STREE {
   TUBE*    root;                   // Root tube (d0) ptr
   int      height;                 // Root height (=number of tree levels - 1)
   int      nleaves;                // Number of leaf tubes
   int      ninteriors;             // Number of interior tubes
   int      ntubes;                 // Total number of tubes
   int      noldtubes;              // Total number of old tubes
   SLICE*   slices;                 // Slices for each height (0 - leaves)
   TUBE**   tubes;                  // NULL[0] + Common sequence of all tubes
};

struct   SLICE {
   int		ntubes;						// Number of tubes in this slice
   TUBE**   tubes;						// Array of tube pointers, [0]=outgroup
};

struct   TUBE {
   int      tubeno;                 // Sequential tube number (1-based)
   TUBE*    parent;                 // Parent tube ptr
   TUBE*    left;                   // Left/single child tube ptr
   TUBE*    right;                  // Right child ptr
   TUBE*    oldtube;                // Pointer to old tube (or itself for old ones)
   int      height;                 // This tube height (0=leaf)
   int      specno;                 // Species number (0=outgroup/interior)
   double*  mean;                   // [nItypes] f(I,x) values (current tree)
   double*  totmean;                // [nItypes] f(I,x) values (all trees)
   double   length;                 // To present reliability (leaves only)
   char     name[MAXNODENAME];
};

EXPORT   STREE*   Stree;            // Species tree (S0) ptr

// Gene tree
struct   GTREE {
   EDGE*    root;                   // Root edge (r0) ptr
   int      nlevels;                // Number of tree levels
   int      nleaves;                // Number of leaf edges
   int      nTmarks;                // Number of marked leaves
   int      ninteriors;             // Number of interior edges
   int      nedges;                 // Total number of edges
   int      npolytom;               // Number of polytomous nodes
   int      polytomy;               // Maximal polytomy over nodes
   LEVEL*   levels;                 // Array[nlevels] of tree levels
   EDGE**   edges;                  // NULL[0] + Common sequence of all edges
};

struct   LEVEL {
   int      nedges;                 // Number of edges at this level
   EDGE**   edges;                  // Array of edge pointers
};

struct   EDGE {
   int      edgeno;                 // Sequential edge number (1-based)
   EDGE*    parent;                 // Parent edge ptr
   EDGE*    child;                  // First child ptr
   EDGE*    sibling;                // Next sibling ptr
   int      nchildren;              // Number of children
   int      level;                  // This edge level (0=root)
   int      specno;                 // Species number (leaves only)
   double   weight;                 // For basis trees only
   char     Tmark;                  // T-type node mark (0=none)
   char     name[MAXNODENAME];
   EVENT**  events;                 // NULL[0] + K-arrays of events for all tubes
};

struct   EVENT {
   int      cost;                   // Cost of this event (*SCALE)
   int      id;                     // Event ID as per table
   int      d1, d2;                 // d',d" tube numbers (0=none)
               // NB: For id_pass_l/r & id_tr_l/r events, d2 = -c_loss|-c_loss1
};

enum EVENT_ID {
   id_none = -1,
   id_fin = 0, 
   id_tr_fin, 
   id_ga_fin, 
   id_pass, 
   id_fork_lr, 
   id_fork_rl, 
   id_pass_l, 
   id_pass_r, 
   id_nout_l, 
   id_nout_r,
   id_out_l, 
   id_out_r,
   id_dupl,
   id_dup0_l,
   id_dup0_r,
   id_outd,
   id_tr1,
   id_tr2,
   id_ga1,
   id_ga2,
   id_ga_big,
   id_tr_pass,
   id_ga_pass,
   id_tr_lr,
   id_tr_rl,
   id_ga_lr,
   id_ga_rl,
   id_tr_l,
   id_tr_r,
   id_ga_l,
   id_ga_r,
   id_tr_dupl,
   id_ga_dupl,
   id_tr,
   id_ga
};

enum I_TYPE {     // linked with nItypes,ItypeNames
   I_none      = 0,
   I_gain      = 1,
   I_loss      = 2,
   I_dupl      = 4,
   I_tr_o      = 8,
   I_tr_i      = 16,
   I_gain_big  = 32,
   I_loss1     = 64     // hidden, linked with I_loss
};

struct   OGNODE {          // Orbigraph node
   EDGE*       edge;                // Gtree edge of this pair
   TUBE*       tube;                // Stree tube of this pair
   OGEDGE*     firstin;             // First inbound edge 
   OGEDGE*     lastin;              // Last  inbound edge
   OGEDGE*     firstout;            // First outbound edge
   OGEDGE*     lastout;             // Last  outbound edge
   double      ped;                 // Probability p(<e,d>)
};

struct   OGEDGE {          // Orbigraph edge
   OGNODE*     from;                // Source node
   OGNODE*     to;                  // Destination node
   OGEDGE*     nextin;              // Next source with same destination
   OGEDGE*     nextout;             // Next destination with same source
   OGEDGE*     twin;                // Another edge of a bi-edge
   int         ntriples;            // Number of triples on this edge
   double      pi;                  // Probability p[i]
   TRIPLE*     triples;             // [ntriples] array of TRIPLEs
};

struct   TRIPLE {          // Triple to label orbigraph edge
   unsigned    Itype;               // I_TYPE
   EDGE*       edge;                // edge
   EDGE*       edge2;               // edge2 or NULL
   TUBE*       tube;                // tube
   TUBE*       tube2;               // tube2 or NULL
};

struct   SCENARIO {
   SCENARIO*   parent;
   SCENARIO*   left;
   SCENARIO*   right;
   EDGE*       edge;
   TUBE*       tube;
   EVENT*      evt;
};

EXPORT   SCENARIO*   Scenario;      // Task 2 result (root of event tree)
EXPORT   OGNODE**    Ograph;        // Task 3 orbigraph matrix
EXPORT   int      OgUnary;          // Number of unagy orbigraph edges
EXPORT   int      OgBinary;         // Number of binagy orbigraph edges
EXPORT   int      OgTriples;        // Number of triples w/o duplication

EXPORT   int      MaxEvents;        // Number of best events to hold
EXPORT   int      Milestones;       // Print live data every 2^milestones steps
EXPORT   GTREE*   Gtree;            // Current gene tree pointer
EXPORT   int      Treeno;           // Current gene tree number (1-based)
EXPORT   int      ProcessedTrees;   // Successfully processed gene trees
EXPORT   int      TotalCost;        // Over all processed trees
EXPORT   GTREE**  Btree;            // Array of basis tree pointers
EXPORT   int      nBtrees;          // Size of these array
EXPORT   int      nSpecies;         // Number of species (excl. outgroup)
EXPORT   int      nIncluded;        // Number of species in current supertree 
struct   SPTABLE {
   bool     enable;
   char     name[MAXNODENAME];
};
EXPORT   SPTABLE* Species;          // Table of species along with data
EXPORT   int      QueueLog;   // Best super3 variants to log (<0: two queues)

EXPORT   char     ConfigFilename[MAXPATH];   // Config filename including path
EXPORT   char     DataDirectory[MAXPATH];    // Path prefix for data filenames
EXPORT   char     SpeciesTreeName[MAXPATH];  // Species tree filename
EXPORT   char     LogFilename[MAXPATH];      // Logfilename

EXPORT   int      LeafMinWords;     // Essential words in species name (min)
EXPORT   int      LeafMaxWords;     // Essential words in species name (max)
EXPORT   char     OutgroupName[16];
EXPORT   char     TmarkChar;        // Character to mark genes of T-type
EXPORT   bool     TmarkAnywhere;    // true=any place, false=only ending
EXPORT   bool     TmarkShow;        // true=retain mark, false=clear mark
EXPORT   bool     TreeWeight;       // true=consider weighted basis trees
EXPORT   double   MinWeight;        // Minimum weight to multiply cost by
EXPORT   bool     MinWeightGiven;   // True if -w/--w is provided in cmd line
EXPORT   char     StopLabel;        // Character to terminate species name
EXPORT   int      nEvents;          // Number of different events to discern
EXPORT   const char**   EventNames;       // Event names according to ID
EXPORT   int      c_gain;
EXPORT   int      c_loss;
EXPORT   int      c_loss1;
EXPORT   int      c_dupl;
EXPORT   int      c_tr_with;
EXPORT   int      c_tr_without;
EXPORT   int      c_gain_big;
EXPORT   int      c_init;           // Value to which shift min cost in Task 3.
EXPORT   double   c_exponent;       // Power to raise the cost ratio
EXPORT   double   k_correction;     // Adds k_correction*log2(MaxEvents) to c_tr_*
EXPORT   double   r_shift;          // Reliability shift parameter
EXPORT   int      nItypes;          // Number of valid I_TYPEs (excl. I_none)
EXPORT   const char**   ItypeNames;       // I_TYPE names according to enumeration
EXPORT   unsigned Itype;            // Desired combination of I_TYPEs
EXPORT   double*  gIT;              // [nItypes] overall g(I,T) values (Task 3)
EXPORT   double*  gjIT;             // [nItypes] gj(I,T) for current Gtree

// Gene tree name structure
struct   GTNAME {
   GTNAME*  next;
   char*    filename;
};

EXPORT   GTNAME*  GeneTreeNameFirst;         // Ptr to first GTNAME struct
EXPORT   GTNAME*  GeneTreeNameLast;          // Ptr to last GTNAME struct

EXPORT   bool     Console;          // Console output (common & live)
EXPORT   bool     Console2Log;      // Common console output to log
EXPORT   bool     SecondaryCon;     // Output to MPI secondary console
EXPORT   bool     SecondaryLog;     // Write MPI secondary logs
EXPORT   FILE*    Log;              // Log file
EXPORT   bool     LogAppend;        // true: append, false: overwrite
EXPORT   TREEMODE StreeMode;        // Species tree logging mode
EXPORT   TREEMODE GtreeMode;        // Gene tree(s) logging mode

EXPORT   bool     LogTable1;        // Table <e,d> logging mode:
EXPORT   bool     T1TextID;         //  Print ID as text or number
EXPORT   int      T1EdgeLabel;      //  Max chars of edge label (0=none)
EXPORT   int      T1EdgeNumber;     //  Max places of edge number (0=none)
EXPORT   int      T1TubeLabel;      //  Max chars of tube label (0=none)
EXPORT   int      T1TubeNumber;     //  Max places of tube number (0=none)
EXPORT   int      T1Precision;      //  Cost precision (0=integer)

EXPORT   bool     LogScenario;      // Log event tree after Task 2
EXPORT   bool     LogS2Message;     // Scenario info message to log 
EXPORT   bool     ConS2Message;     // Scenario info message to console 
EXPORT   bool     S2Condense;       // Use condensed format
EXPORT   int      S2Indent;         // Tree level indent
EXPORT   int      S2EdgeLabel;      // Edge label characters (0=none)
EXPORT   int      S2EdgeNumber;     // Edge number places (0=none)
EXPORT   int      S2TubeLabel;      // Tube label characters (0=none)
EXPORT   int      S2TubeNumber;     // Tube number places (0=none)
EXPORT   int      S2EventID;        // Decimal places for event ID (0=none)
EXPORT   int      S2EventLabel;     // Event label characters (0=none)
EXPORT   int      S2EventCost;      // Decimal places for cost value (0=none)
EXPORT   int      S2Precision;      // Cost precision (0=integer)

EXPORT   bool     LogOrbigraph0;    // Log orbigraph after forward run in Task 3
EXPORT   bool     LogOrbigraph;     // Log orbigraph after backward run in Task 3
EXPORT   bool     LogOgMessage;     // Orbigraph info message to log
EXPORT   bool     ConOgMessage;     // Orbigraph info message to console
EXPORT   int      OgEdgeLabel;      // Edge label characters (0=none)
EXPORT   int      OgEdgeNumber;     // Edge number places (0=none)
EXPORT   int      OgTubeLabel;      // Tube label characters (0=none)
EXPORT   int      OgTubeNumber;     // Tube number places (0=none)
EXPORT   int      OgPrecision;      // Probability precision

EXPORT   bool     OptimumCostJ;     // Log optimum scenario cost for each gene tree 
EXPORT   bool     LogTmarkJ;        // Log g(I,T) values for each gene tree
EXPORT   bool     LogTubeJ;         // Log f(I) values for all tubes (each gene tree)
EXPORT   bool     LogOTubeJ;        // Log f(I) values for all old tubes (each gene tree)
EXPORT   bool     LogMeanJ;         // Log mean total cost of embedding for each gene tree
EXPORT   bool     LogMemoryJ;       // Log memory usage for each gene tree
EXPORT   bool     LogTmarkStats;    // Log g(I,T) values for whole set of gene trees
EXPORT   bool     LogTubeStats;     // Log f(I) values for all tubes (over all gene trees)
EXPORT   bool     LogOTubeStats;    // Log f(I) values for all old tubes (over all gene trees)
EXPORT   bool     LogTotalMean;     // Log mean total cost of embedding over all gene trees
EXPORT   int      MeanWidth;        // Mean field width including precision
EXPORT   int      MeanPrecision;    // Mean precision

EXPORT   bool     ModeOptimumCost;  // Compute optimum cost of embedding (Task 1)
EXPORT   bool     ModeEmbedding;    // Compute embedding scenarios (Task 2)
EXPORT   bool     ModeStatistics;   // Compute statistics (Task 3)
EXPORT   bool     ModeSuper3Build;  // Assembly super3 for basis trees (Task 4)
EXPORT   bool     CmdSpeciesTree;   // Species tree given in cmd line
EXPORT   bool     CmdNoGeneTrees;   // Gene trees rejected via cmd line
EXPORT   bool     CmdLogfile;       // Logfile specified in cmd line
EXPORT   bool     CmdMaxEvents;     // MaxEvents specified in cmd line
EXPORT   bool     Cmd_gain;
EXPORT   bool     Cmd_loss;
EXPORT   bool     Cmd_loss1;
EXPORT   bool     Cmd_dupl;
EXPORT   bool     Cmd_tr_with;
EXPORT   bool     Cmd_tr_without;
EXPORT   bool     Cmd_gain_big;
EXPORT   bool     Cmd_init_cost;
EXPORT   bool     Cmd_exponent;
EXPORT   bool     Cmd_correction;
EXPORT   bool     Cmd_shift;
enum     MEM_TYPE {
   housekeeping,
   speciestree,
   genetree,
   scenario,
   ognodes,
   ogedges,
   ogtriples,
   freedmem
};
const    int      nMemTypes = 8;
EXPORT   bool     MemoryCount;      // Calculate used/peak memory
EXPORT   __int64  MemUsed[nMemTypes];
EXPORT   __int64  MemPeak[nMemTypes];

int      ElapsedMin(bool now);
void     InitializeExports(int argc, char **argv);
void     InitializeLog(void);
bool     ParseArguments(int argc, char **argv);
void     PrintHelpInfo(void);
bool     ReadConfigFile(void);
bool     ReadSpeciesTree(char *str);
bool     WriteSpeciesTree(void);
void     DeleteStree(STREE* tree);
bool     MakeDummyStree(void);
void     SelectInitialStree(void);
void     PrintStree(TUBE* node, FILE* file, TREEMODE* mode);
void     RemoveTreeComments(char *str);
bool     InsertSpecies(char* name, int index);
int      FindSpecies(char* name);
const char* FindKey(int index);
int      GetSpeciesCount(void);
void     FillSpecies(SPTABLE *species);
void     DeleteSpecies(char* name);
bool     FillTubeDistances(void);
int      TubeDistance(int d1, int d2);
bool     ProcessGeneTrees(void);
bool     ReadGeneTree(char* filename);
bool     ProcessBasisTrees(void);
bool     ReadBasisTree(char* filename);
void     PrintGtree(EDGE* node, FILE* file, TREEMODE* mode);
void     FillLevels(GTREE *gtree, EDGE* node);
void     FillGtreeLevels(GTREE* gtree, EDGE* node);
void     GtreeCortege(GTREE* gtree);
void     DestructGtree(void);
bool     RunForward(void);
bool     RunBackward(void);
void     DestructScenario(void);
void     LoggingScenario(void);
bool     CreateOgraph(void);
void     DestructOgraph(void);
bool     RunForward3(void);
bool     RunBackward3(void);
void     LoggingOgraph(void);
void     LoggingTmarkStats(double *g);
void     LoggingTubeStats(bool old, bool summary);
void     PruneBasisTree(GTREE* btree);
int      ComputeCost(void);
void     MarkOldNewTubes(void);
bool     MakeInductionStep(void);

#ifdef   _DEBUG
#  define   DBG(x) x
#  define   NDBG(x)
#else
#  define   DBG(x)
#  define   NDBG(x) x
#endif

#ifdef   EMBED3MPI
EXPORT   bool     embed3_mpi;       // true = MPI mode enabled
EXPORT   int      ver_mpi;
EXPORT   int      sub_mpi;
EXPORT   int      size_mpi;
EXPORT   int      rank_mpi;
enum TAG_MPI {
   tag_var = 1,
   tag_eoq
};
#endif

#endif
