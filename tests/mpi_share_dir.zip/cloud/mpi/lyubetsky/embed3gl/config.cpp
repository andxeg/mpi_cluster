// embed3GL: A program for phylogenetic study of joint gene & species evolution.
//
// The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/embed3gl]
//
// (C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
// E-mail: rubanov{at}iitp.ru
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// Functions: IsComment, CheckKey, IsBool, Are3Bools, ReadConfigFile

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include "embed3gl.h"

char  blanks[] = " \t\n\r";
char  seps[]   = "=; \t\n\r";

// Return true if str contains a comment line
bool     IsComment(char* str) {
   assert(str);
   int pos = (int)strspn(str, blanks);
   char c = str[pos];
   return c==0 || strchr(";/#", c);
}

// Return true if str fits to key
bool     CheckKey(char* key, const char* str) {
   assert(key);
   assert(str);
   return _stricmp(key, str) == 0;
}

// Set given flag from value 
// Return false on error
bool     IsBool(char* value, bool* flag) {
   const char* yes[] = {"1", "true", "y", "yes", "on", "enable"};
   const char* no[] = {"0", "false", "n", "no", "not", "off", "disable"};
   int n;
   n = sizeof(yes) / sizeof(char*);
   for(int i = 0; i < n; i++) {
      if(_stricmp(value, yes[i]))
         continue;
      *flag = true;
      return true;
   }
   n = sizeof(no)  / sizeof(char*);
   for(int i = 0; i < n; i++) {
      if(_stricmp(value, no[i]))
         continue;
      *flag = false;
      return true;
   }
   return false;
}
// Set given flag[3] from value 
// Return false on error
bool     Are3Bools(char *value, bool* flags) {
   char  valseps[] = ",:_/|-\\";
   char* v  = strtok(value, valseps);
   if( !v || !IsBool(v, flags) )
      return false;
   v = strtok(NULL, valseps);
   if( !v || !IsBool(v, flags + 1) )
      return false;
   v = strtok(NULL, valseps);
   if( !IsBool(v, flags + 2) )
      return false;
   return true;
}

// Parse configuration file
// Return: true=OK, false=Error
bool     ReadConfigFile(void) {
   FILE*    config;
   char* buf   = (char*)malloc(BUFLEN+1);
   char* key   = NULL;
   char* value = NULL;
   bool  bit   = 0;
   int   len   = 0;        // length of value string
   int   line  = 0;        // current line number

   if(!buf) return false;
   if(MemoryCount) {
      MemUsed[housekeeping] += M16(BUFLEN+1);
   }
   config = fopen(ConfigFilename, "rb");
   if( !config ) {
      CON( printf("CFG: Configuration file '%s' does not exist.\n", 
         ConfigFilename); )
      return false;
   }

   while( fgets(buf, BUFLEN, config) ) {

      line++;
      if( IsComment(buf) )
         continue;
      char* soc = strstr(buf, "//");     // Delete inline comments if exist
      if(soc)  *soc = 0;
      
      key = strtok(buf, seps);
      value = strtok(NULL, seps);

      // Special case of a spaced value enclosed in double quotes
      if( *value == '\"' ) {
         value++;
         value[strlen(value)] = ' ';
         char *p = strchr(value, '\"');
         if( !p ) {
            CON( printf("CFG: Closing quote missed in line %d.\n", line); )
            return false;
         }
         else *p = 0;
      }
      len = (int)strlen(value);

      // Checking keys and store values
      bool badvalue = false;
      if      (CheckKey(key, "OptimumCost")) {
         if( !IsBool(value, &ModeOptimumCost) )
            badvalue = true;
      }
      else if (CheckKey(key, "Embedding")) {
         if( !IsBool(value, &ModeEmbedding) )
            badvalue = true;
      }
      else if (CheckKey(key, "Statistics")) {
         if( !IsBool(value, &ModeStatistics) )
            badvalue = true;
      }
      else if (CheckKey(key, "Super3Build")) {
         if( !IsBool(value, &ModeSuper3Build) )
            badvalue = true;
      }
      else if (CheckKey(key, "MaxEvents")) {
         if(!CmdMaxEvents) {
            if(MaxEvents <= 1)
               MaxEvents = atoi(value);
            if(MaxEvents < 1)
               badvalue = true;
         }
      }
      else if (CheckKey(key, "Milestones")) {
         Milestones = atoi(value);
         if(Milestones < 0 || Milestones > 31)
            Milestones = 0;
      }
      else if (CheckKey(key, "QueueLog")) {
         QueueLog = atoi(value);
      }
      else if (CheckKey(key, "MemoryCount")) {
         if( !IsBool(value, &MemoryCount) )
            badvalue = true;
      }
      else if (CheckKey(key, "C_gain")) {
         if( !Cmd_gain )
            c_gain = (int)(atof(value) * SCALE);
      }
      else if (CheckKey(key, "C_loss")) {
         if( !Cmd_loss )
            c_loss = (int)(atof(value) * SCALE);
      }
      else if (CheckKey(key, "C_loss1")) {
         if( !Cmd_loss1 )
            c_loss1 = (int)(atof(value) * SCALE);
      }
      else if (CheckKey(key, "C_dupl")) {
         if( !Cmd_dupl )
            c_dupl = (int)(atof(value) * SCALE);
      }
      else if (CheckKey(key, "C_tr_with")) {
         if( !Cmd_tr_with )
            c_tr_with = (int)(atof(value) * SCALE);
      }
      else if (CheckKey(key, "C_tr_without")) {
         if( !Cmd_tr_without )
            c_tr_without = (int)(atof(value) * SCALE);
      }
      else if (CheckKey(key, "C_gain_big")) {
         if( !Cmd_gain_big )
            c_gain_big = (int)(atof(value) * SCALE);
      }
      else if (CheckKey(key, "InitialCost")) {
         if( !Cmd_init_cost )
            c_init = (int)(atof(value) * SCALE);
      }
      else if (CheckKey(key, "C_exponent")) {
         if( !Cmd_exponent )
            c_exponent = atof(value);
      }
      else if (CheckKey(key, "K_correction")) {
         if( !Cmd_correction )
            k_correction = atof(value);
      }
      else if (CheckKey(key, "R_shift")) {
         if( !Cmd_shift )
            r_shift = atof(value);
      }
      else if (CheckKey(key, "I_loss")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else if(bit)
            Itype |= I_loss | I_loss1;    // compute together with hidden I_loss1
      }
      else if (CheckKey(key, "I_dupl")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else if(bit)
            Itype |= I_dupl;
      }
      else if (CheckKey(key, "I_gain")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else if(bit)
            Itype |= I_gain;
      }
      else if (CheckKey(key, "I_gain_big")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else if(bit)
            Itype |= I_gain_big;
      }
      else if (CheckKey(key, "I_tr_o")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else if(bit)
            Itype |= I_tr_o;
      }
      else if (CheckKey(key, "I_tr_i")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else if(bit)
            Itype |= I_tr_i;
      }
      else if (CheckKey(key, "DataDirectory")) {
         #ifdef __GNUC__
         if(value[len-1] != '/')
            value[len++] = '/';
         #else
         if(value[len-1] != '\\' && value[len-1] != '/')
            value[len++] = '\\';
         #endif
         if(len >= MAXPATH) {
            CON( printf("CFG: Too long DataDirectory name in line %d.\n", line); )
            return false;
         }
         else
            value[len] = 0;
         strcpy(DataDirectory, value);
      }
      else if (CheckKey(key, "SpeciesTree")) {
         if( !CmdSpeciesTree ) {
            if(len >= MAXPATH) {
               CON( printf("CFG: Too long SpeciesTree name in line %d.\n", line); )
               return false;
            }
            strcpy(SpeciesTreeName, value);
         }
      }
      else if (CheckKey(key, "LeafMinWords")) {
         LeafMinWords = atoi(value);
      }
      else if (CheckKey(key, "LeafMaxWords")) {
         LeafMaxWords = atoi(value);
      }
      else if (CheckKey(key, "OutgroupName")) {
         strncpy(OutgroupName, value, sizeof(OutgroupName) - 1);
      }
      else if (CheckKey(key, "TmarkChar")) {
         TmarkChar = value[0];
      }
      else if (CheckKey(key, "TmarkAnywhere")) {
         if( !IsBool(value, &TmarkAnywhere) )
            badvalue = true;
      }
      else if (CheckKey(key, "TmarkShow")) {
         if( !IsBool(value, &TmarkShow) )
            badvalue = true;
      }
      else if (CheckKey(key, "TreeWeight")) {
         if( !MinWeightGiven ) {
            if( !IsBool(value, &TreeWeight) )
               badvalue = true;
         }
      }
      else if (CheckKey(key, "MinWeight")) {
         if( !MinWeightGiven )
            MinWeight = atof(value);
      }
      else if (CheckKey(key, "StopLabel")) {
         StopLabel = value[0];
      }
      else if (CheckKey(key, "GeneTree")) {
         if( !CmdNoGeneTrees ) {
            GTNAME* gtname = (GTNAME*)malloc(sizeof(GTNAME));
            char* filename = (char*)malloc(len+1);
            if(!gtname || !filename) {
               CON( printf("CFG: Not enough memory.\n"); )
               return false;
            }
            if(MemoryCount) {
               MemUsed[housekeeping] += M16(sizeof(GTNAME));
               MemUsed[housekeeping] += M16(len + 1);
            }
            strcpy(filename, value);
            gtname->filename = filename;
            gtname->next = NULL;

            // Insert in GTNAME list
            if(GeneTreeNameLast)
               GeneTreeNameLast->next = gtname;
            else 
               GeneTreeNameFirst = gtname;
            GeneTreeNameLast = gtname;
         }
      }
      else if (CheckKey(key, "LogFilename")) {
         if( !CmdLogfile )
            strncpy(LogFilename, value, MAXPATH - 1);
      }
      else if (CheckKey(key, "LogAppend")) {
         if( !CmdLogfile ) {
            if( !IsBool(value, &LogAppend) )
               badvalue = true;
         }
      }
      else if (CheckKey(key, "Console")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else Console = bit;
      }
      else if (CheckKey(key, "Console2Log")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else Console2Log = bit;
      }
      else if (CheckKey(key, "SecondaryCon")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else SecondaryCon = bit;
      }
      else if (CheckKey(key, "SecondaryLog")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else SecondaryLog = bit;
      }
      else if (CheckKey(key, "LogSpeciesTree")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else StreeMode.enable = bit;
      }
      else if (CheckKey(key, "StreeHeading")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else StreeMode.heading = bit;
      }

      else if (CheckKey(key, "StreeLengths")) {
         bool bits[3];
         if( !Are3Bools(value, bits) )
            badvalue = true;
         else {
            StreeMode.length_root   = bits[0];
            StreeMode.length_inner  = bits[1];
            StreeMode.length_leaf   = bits[2];
         }
      }
      else if (CheckKey(key, "StreeLabels")) {
         bool bits[3];
         if( !Are3Bools(value, bits) )
            badvalue = true;
         else {
            StreeMode.label_root    = bits[0];
            StreeMode.label_inner   = bits[1];
            StreeMode.label_leaf    = bits[2];
         }
      }
      else if (CheckKey(key, "StreeNumbers")) {
         bool bits[3];
         if( !Are3Bools(value, bits) )
            badvalue = true;
         else {
            StreeMode.number_root   = bits[0];
            StreeMode.number_inner  = bits[1];
            StreeMode.number_leaf   = bits[2];
         }
      }
      else if (CheckKey(key, "StreeFullLabel")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else StreeMode.full_labels = bit;
      }
      else if (CheckKey(key, "LogGeneTree")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else GtreeMode.enable = bit;
      }
      else if (CheckKey(key, "GtreeHeading")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else GtreeMode.heading = bit;
      }

      else if (CheckKey(key, "GtreeLengths")) {
         bool bits[3];
         if( !Are3Bools(value, bits) )
            badvalue = true;
         else {
            GtreeMode.length_root   = bits[0];
            GtreeMode.length_inner  = bits[1];
            GtreeMode.length_leaf   = bits[2];
         }
      }
      else if (CheckKey(key, "GtreeLabels")) {
         bool bits[3];
         if( !Are3Bools(value, bits) )
            badvalue = true;
         else {
            GtreeMode.label_root    = bits[0];
            GtreeMode.label_inner   = bits[1];
            GtreeMode.label_leaf    = bits[2];
         }
      }
      else if (CheckKey(key, "GtreeNumbers")) {
         bool bits[3];
         if( !Are3Bools(value, bits) )
            badvalue = true;
         else {
            GtreeMode.number_root   = bits[0];
            GtreeMode.number_inner  = bits[1];
            GtreeMode.number_leaf   = bits[2];
         }
      }
      else if (CheckKey(key, "GtreeFullLabel")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else GtreeMode.full_labels = bit;
      }
      else if (CheckKey(key, "LogTable1")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else LogTable1 = bit;
      }
      else if (CheckKey(key, "T1TextID")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else T1TextID = bit;
      }
      else if (CheckKey(key, "T1EdgeLabel")) {
         T1EdgeLabel = atoi(value);
      }
      else if (CheckKey(key, "T1EdgeNumber")) {
         T1EdgeNumber = atoi(value);
      }
      else if (CheckKey(key, "T1TubeLabel")) {
         T1TubeLabel = atoi(value);
      }
      else if (CheckKey(key, "T1TubeNumber")) {
         T1TubeNumber = atoi(value);
      }
      else if (CheckKey(key, "T1Precision")) {
         T1Precision = atoi(value);
      }
      else if (CheckKey(key, "LogScenario")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else LogScenario = bit;
      }
      else if (CheckKey(key, "LogS2Message")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else LogS2Message = bit;
      }
      else if (CheckKey(key, "ConS2Message")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else ConS2Message = bit;
      }
      else if (CheckKey(key, "S2Condense")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else S2Condense = bit;
      }
      else if (CheckKey(key, "S2Indent")) {
         S2Indent = atoi(value);
      }
      else if (CheckKey(key, "S2EdgeLabel")) {
         S2EdgeLabel = atoi(value);
      }
      else if (CheckKey(key, "S2EdgeNumber")) {
         S2EdgeNumber = atoi(value);
      }
      else if (CheckKey(key, "S2TubeLabel")) {
         S2TubeLabel = atoi(value);
      }
      else if (CheckKey(key, "S2TubeNumber")) {
         S2TubeNumber = atoi(value);
      }
      else if (CheckKey(key, "S2EventID")) {
         S2EventID = atoi(value);
      }
      else if (CheckKey(key, "S2EventLabel")) {
         S2EventLabel = atoi(value);
      }
      else if (CheckKey(key, "S2EventCost")) {
         S2EventCost = atoi(value);
      }
      else if (CheckKey(key, "S2Precision")) {
         S2Precision = atoi(value);
      }
      else if (CheckKey(key, "LogOrbigraph0")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else LogOrbigraph0 = bit;
      }
      else if (CheckKey(key, "LogOrbigraph")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else LogOrbigraph = bit;
      }
      else if (CheckKey(key, "LogOgMessage")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else LogOgMessage = bit;
      }
      else if (CheckKey(key, "ConOgMessage")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else ConOgMessage = bit;
      }
      else if (CheckKey(key, "OgEdgeLabel")) {
         OgEdgeLabel = atoi(value);
      }
      else if (CheckKey(key, "OgEdgeNumber")) {
         OgEdgeNumber = atoi(value);
      }
      else if (CheckKey(key, "OgTubeLabel")) {
         OgTubeLabel = atoi(value);
      }
      else if (CheckKey(key, "OgTubeNumber")) {
         OgTubeNumber = atoi(value);
      }
      else if (CheckKey(key, "OgPrecision")) {
         OgPrecision = atoi(value);
      }
      else if (CheckKey(key, "OptimumCostJ")) {
         if( !IsBool(value, &OptimumCostJ) )
            badvalue = true;
      }
      else if (CheckKey(key, "LogTmarkJ")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else LogTmarkJ = bit;
      }
      else if (CheckKey(key, "LogTubeJ")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else LogTubeJ = bit;
      }
      else if (CheckKey(key, "LogOTubeJ")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else LogOTubeJ = bit;
      }
      else if (CheckKey(key, "LogMeanJ")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else LogMeanJ = bit;
      }
      else if (CheckKey(key, "LogMemoryJ")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else LogMemoryJ = bit;
      }
      else if (CheckKey(key, "LogTmarkStats")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else LogTmarkStats = bit;
      }
      else if (CheckKey(key, "LogTubeStats")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else LogTubeStats = bit;
      }
      else if (CheckKey(key, "LogOTubeStats")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else LogOTubeStats = bit;
      }
      else if (CheckKey(key, "LogTotalMean")) {
         if( !IsBool(value, &bit) )
            badvalue = true;
         else LogTotalMean = bit;
      }
      else if (CheckKey(key, "MeanWidth")) {
         MeanWidth = atoi(value);
      }
      else if (CheckKey(key, "MeanPrecision")) {
         MeanPrecision = atoi(value);
      }
      else {
         CON( printf("CFG: Unknown key '%s' in line %d.\n", key, line); )
         return false;
      }

      if(badvalue) {
         CON( printf("CFG: Invalid %s value in line %d.\n", key, line); )
         return false;
      }
   }

   if( ferror(config) ) {
      CON( printf("CFG: Configuration file I/O error.\n"); )
      return false;
   }
   free(buf);
   if(MemoryCount) {
      MemUsed[housekeeping] -= M16(BUFLEN+1);
   }
   return true;
}
