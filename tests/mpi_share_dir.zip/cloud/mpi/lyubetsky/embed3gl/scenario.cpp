// embed3GL: A program for phylogenetic study of joint gene & species evolution.
//
// The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/embed3gl]
//
// (C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
// E-mail: rubanov{at}iitp.ru
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// Functions: runBackward, RunBackward, destructScenario, DestructScenario,
//            loggingScenario, LoggingScenario

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "embed3gl.h"

// Recursive scenario node construction
// Return pointer to the node or NULL (errors)
static SCENARIO*  runBackward(EDGE* edge, TUBE* tube, SCENARIO* parent) {
   assert(edge && tube);
   SCENARIO*   node = (SCENARIO*)malloc(sizeof(SCENARIO));
   if( !node ) {
      CON( printf("SCN: Not enough memory.\n"); )
      LOG( fprintf(Log, "SCN: Not enough memory.\n"); )
      return NULL;
   }
   if(MemoryCount) {
      MemUsed[scenario] += M16(sizeof(SCENARIO));
   }
   node->parent   = parent;
   node->left     = NULL;
   node->right    = NULL;
   node->edge     = edge;
   node->tube     = tube;
   TUBE* dprime = NULL;
   EVENT* evt = edge->events[tube->tubeno];
   node->evt      = evt;

   switch( evt->id ) {
      case id_fin:         // 0
         if(edge->nchildren || tube->left || tube->right) {
            // incorrect leaf pair reached
            CON( printf("SCN: Incorrect leaf pair <%d,%d>.\n",
                  edge->edgeno, tube->tubeno); )
            LOG( fprintf(Log, "SCN: Incorrect leaf pair <%d,%d>.\n",
                  edge->edgeno, tube->tubeno); )
         }
         break;
      case id_tr_fin:      // 1
      case id_ga_fin:      // 2
      case id_pass:        // 3
      case id_ga_big:      // 20
         dprime      = Stree->tubes[evt->d1];
         node->left = runBackward(edge, dprime, node);
         if( !node->left ) return NULL;
         break;
      case id_fork_lr:     // 4
         node->left  = runBackward(edge->child, tube->left, node);
         node->right = runBackward(edge->child->sibling, tube->right, node);
         if( !node->left || !node->right ) return NULL;
         break;
      case id_fork_rl:     // 5
         node->left  = runBackward(edge->child->sibling, tube->left, node);
         node->right = runBackward(edge->child, tube->right, node);
         if( !node->left || !node->right ) return NULL;
         break;
      case id_pass_l:      // 6
      case id_nout_l:      // 8
      case id_out_l:       // 10
         node->left  = runBackward(edge, tube->left, node);
         if( !node->left ) return NULL;
         break;
      case id_pass_r:      // 7
      case id_nout_r:      // 9
      case id_out_r:       // 11
         node->left  = runBackward(edge, tube->right, node);
         if( !node->left ) return NULL;
         break;
      case id_dupl:        // 12
         node->left  = runBackward(edge->child, tube, node);
         node->right = runBackward(edge->child->sibling, tube, node);
         if( !node->left || !node->right ) return NULL;
         break;
      case id_dup0_l: {    // 13
         TUBE* dz = Stree->slices[Stree->height-1].tubes[0];
         node->left  = runBackward(edge->child, tube, node);
         node->right = runBackward(edge->child->sibling, dz, node);
         if( !node->left || !node->right ) return NULL;
         break;       }
      case id_dup0_r: {    // 14
         TUBE* dz = Stree->slices[Stree->height-1].tubes[0];
         node->left  = runBackward(edge->child->sibling, tube, node);
         node->right = runBackward(edge->child, dz, node);
         if( !node->left || !node->right ) return NULL;
         break;       }
      case id_outd:        // 15
         node->left  = runBackward(edge->child, tube, node);
         node->right = runBackward(edge->child->sibling, tube, node);
         if( !node->left || !node->right ) return NULL;
         break;
      case id_tr1:         // 16
         dprime      = Stree->tubes[evt->d1];
         node->left  = runBackward(edge->child, dprime, node);
         node->right = runBackward(edge->child->sibling, tube, node);
         if( !node->left || !node->right ) return NULL;
         break;
      case id_ga1:         // 18
         dprime      = Stree->tubes[evt->d1];
         node->left  = runBackward(edge->child, dprime, node);
         node->right = runBackward(edge->child->sibling, tube, node);
         if( !node->left || !node->right ) return NULL;
         break;
      case id_tr2:         // 17
         dprime      = Stree->tubes[evt->d1];
         node->left  = runBackward(edge->child->sibling, dprime, node);
         node->right = runBackward(edge->child, tube, node);
         if( !node->left || !node->right ) return NULL;
         break;
      case id_ga2:         // 19
         dprime      = Stree->tubes[evt->d1];
         node->left  = runBackward(edge->child->sibling, dprime, node);
         node->right = runBackward(edge->child, tube, node);
         if( !node->left || !node->right ) return NULL;
         break;
      case id_tr_pass:     // 21
         dprime      = Stree->tubes[evt->d2];
         node->left  = runBackward(edge, dprime, node);
         if( !node->left ) return NULL;
         break;
      case id_ga_pass:     // 22
         dprime      = Stree->tubes[evt->d2];
         node->left  = runBackward(edge, dprime, node);
         if( !node->left ) return NULL;
         break;
      case id_tr_lr:       // 23
      case id_ga_lr:       // 25
         dprime      = Stree->tubes[evt->d1];
         node->left  = runBackward(edge->child, dprime->left, node);
         node->right = runBackward(edge->child->sibling, dprime->right, node);
         if( !node->left || !node->right ) return NULL;
         break;
      case id_tr_rl:       // 24
      case id_ga_rl:       // 26
         dprime      = Stree->tubes[evt->d1];
         node->left  = runBackward(edge->child->sibling, dprime->left, node);
         node->right = runBackward(edge->child, dprime->right, node);
         if( !node->left || !node->right ) return NULL;
         break;
      case id_tr_l:        // 27
         dprime      = Stree->tubes[evt->d1];
         node->left  = runBackward(edge, dprime->left, node);
         if( !node->left ) return NULL;
         break;
      case id_ga_l:        // 29
         dprime      = Stree->tubes[evt->d1];
         node->left  = runBackward(edge, dprime->left, node);
         if( !node->left ) return NULL;
         break;
      case id_tr_r:        // 28
         dprime      = Stree->tubes[evt->d1];
         node->left  = runBackward(edge, dprime->right, node);
         if( !node->left ) return NULL;
         break;
      case id_ga_r:        // 30
         dprime      = Stree->tubes[evt->d1];
         node->left  = runBackward(edge, dprime->right, node);
         if( !node->left ) return NULL;
         break;
      case id_tr_dupl:     // 31
      case id_ga_dupl:     // 32
         dprime      = Stree->tubes[evt->d1];
         node->left  = runBackward(edge->child, dprime, node);
         node->right = runBackward(edge->child->sibling, dprime, node);
         if( !node->left || !node->right ) return NULL;
         break;
      case id_tr:          // 33
      case id_ga:          // 34
         dprime      = Stree->tubes[evt->d1];
         node->left  = runBackward(edge->child, dprime, node);
         dprime      = Stree->tubes[evt->d2];
         node->right = runBackward(edge->child->sibling, dprime, node);
         if( !node->left || !node->right ) return NULL;
         break;
      default:
         CON( printf("SCN: Invalid event ID=%d in the table.\n", evt->id); )
         LOG( fprintf(Log, "SCN: Invalid event ID=%d in the table.\n", evt->id); )
         if(node) {
            free(node);
            if(MemoryCount) 
               MemUsed[freedmem] += M16(sizeof(SCENARIO));
         }
         node = NULL;
         break;
   }
   return node;
}

// Backward run in Task 2
bool     RunBackward(void) {
   Scenario = runBackward(Gtree->root, Stree->root, NULL);
   return (Scenario != NULL);
}

// Traverse scenario tree deleting nodes
static void    destructScenario(SCENARIO* node) {
   if(!node) return;
   if(node->left)
      destructScenario(node->left);
   if(node->right)
      destructScenario(node->right);
   free(node);
   if(MemoryCount) {
      MemUsed[freedmem] += M16(sizeof(SCENARIO));
   }
}

// Completely destruct current scenario
void     DestructScenario(void) {
   if(!Scenario) return;
   destructScenario(Scenario);
   Scenario = NULL;
}

// Traverse scenario tree logging events
static void    loggingScenario(SCENARIO* node) {
   static int depth  = -1;
   char esep[] = "=";
   char tsep[] = "=";
   if(!S2EdgeLabel || !S2EdgeNumber) esep[0] = 0;
   if(!S2TubeLabel || !S2TubeNumber) tsep[0] = 0;
   depth ++;
   if(S2Condense) {
      if(Log) 
         fprintf(Log, "%*s<%.*s%s%.*d, %.*s%s%.*d, %.*s%s%.*d>  ",
            depth * S2Indent, "", 
            S2EdgeLabel, node->edge->name, esep, 
            S2EdgeNumber ? 1 : 0, node->edge->edgeno,
            S2TubeLabel, node->tube->name, tsep,
            S2TubeNumber ? 1 : 0, node->tube->tubeno,
            S2TubeLabel, node->tube->oldtube->name, tsep,
            S2TubeNumber ? 1 : 0, node->tube->oldtube->tubeno);
      if(S2EventID && Log) 
         fprintf(Log, "#%.*d ", S2EventID, node->evt->id);
      if(S2EventLabel && Log) {
         fprintf(Log, "%.*s", S2EventLabel, 
            node->evt->id >= 0 ? EventNames[node->evt->id] : "none");
      }
      if(node->evt->d1 > 0 || node->evt->d2 > 0) {
         if(Log) fprintf(Log, "(");
         if(node->evt->d1 > 0) {
            if(Log) fprintf(Log, "%.*s%s%.*d", S2TubeLabel, 
               Stree->tubes[node->evt->d1]->name, tsep,
               S2TubeNumber ? 1 : 0, node->evt->d1);
         }
         if(node->evt->d2 > 0) {
            if(Log) fprintf(Log, ",%.*s%s%.*d", S2TubeLabel, 
               Stree->tubes[node->evt->d2]->name, tsep,
               S2TubeNumber ? 1 : 0, node->evt->d2);
         }
         if(Log) fprintf(Log, ")");
      }
      if(S2EventCost) {
         if(Log) fprintf(Log, "  c=%.*f", S2Precision, 
            node->evt->cost / SCALE);
      }
      if(Log) fprintf(Log, "\n");
   }
   else {
      if(Log) 
         fprintf(Log, "%*s<%*.*s%*d, %*.*s%*d, %*.*s%*d> ", 
            depth * S2Indent, "",
            S2EdgeLabel, S2EdgeLabel, node->edge->name,
            S2EdgeNumber, node->edge->edgeno,
            S2TubeLabel, S2TubeLabel, node->tube->name,
            S2TubeNumber, node->tube->tubeno,
            S2TubeLabel, S2TubeLabel, node->tube->oldtube->name,
            S2TubeNumber, node->tube->oldtube->tubeno); 
      if(S2EventID && Log)
         fprintf(Log, "#%0*d", S2EventID, node->evt->id);
      if(S2EventLabel && Log)
         fprintf(Log, "%*.*s", S2EventLabel, S2EventLabel, 
            node->evt->id >= 0 ? EventNames[node->evt->id] : "none");
      if(node->evt->d1 > 0 || node->evt->d2 > 0) {
         if(Log) fprintf(Log, "(");
         if(node->evt->d1 > 0) {
            //if(Log) fprintf(Log, "%d", node->evt->d1);
            if(Log) fprintf(Log, "%.*s%s%.*d", S2TubeLabel, 
               Stree->tubes[node->evt->d1]->name, tsep,
               S2TubeNumber ? 1 : 0, node->evt->d1);
         }
         if(node->evt->d2 > 0) {
            //if(Log) fprintf(Log, ",%d", node->evt->d2);
            if(Log) fprintf(Log, "%.*s%s%.*d", S2TubeLabel, 
               Stree->tubes[node->evt->d2]->name, tsep,
               S2TubeNumber ? 1 : 0, node->evt->d2);
         }
         if(Log) fprintf(Log, ") ");
      }
      if(S2EventCost && Log)
         fprintf( Log, "%*.*f", S2EventCost, S2Precision, 
            node->evt->cost / SCALE);
      if(Log) fprintf(Log, "\n");
   }

   if(node->left) {
      loggingScenario(node->left);
   }

   if(node->right) {
      loggingScenario(node->right);
   }

   depth --;
}

// Print event tree after Task 2 to logfile
void     LoggingScenario(void) {
   if(!Scenario) return;
   if(Log) fprintf(Log, "\n");
   loggingScenario(Scenario);
   if(Log) fprintf(Log, "\n");
}
