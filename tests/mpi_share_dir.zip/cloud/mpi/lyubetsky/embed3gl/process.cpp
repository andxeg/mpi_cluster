// embed3GL: A program for phylogenetic study of joint gene & species evolution.
//
// The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/embed3gl]
//
// (C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
// E-mail: rubanov{at}iitp.ru
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// Functions: DestructGtree, LoggingTable1, ProcessGeneTrees, ProcessBasisTrees,
//            PushEvent, MergeEvents, ClearTempEventQueue, ClearTempEvent,
//            HasSpecies, IsActualLoss, FindCost, RunForward 

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "embed3gl.h"

// Completely destruct current gene tree
void     DestructGtree(void) {
   if( !Gtree ) return;
   // Free corteges and edges
   for(int i = 1; i <= Gtree->nedges; i++) {    // i=edge
      EDGE* edge = Gtree->edges[i];
      if(!edge) 
         continue;
      for(int j = 1; j <=Stree->ntubes; j++) {     // j=tube
         EVENT* evt = edge->events[j];
         if(evt) {
            free(evt);
            if(MemoryCount)
               MemUsed[freedmem] += M16(MaxEvents * sizeof(EVENT));
         }
      }
      if(edge->events) {
         free(edge->events);
         if(MemoryCount) 
            MemUsed[freedmem] += M16((Stree->ntubes + 1) * sizeof(EVENT*));
      }
      free(edge);
      if(MemoryCount) {
         MemUsed[freedmem] += M16(sizeof(EDGE));
      }
   }
   // Free levels
   for(int n = 0; n < Gtree->nlevels; n++) {    // n=level
      LEVEL* lvl = Gtree->levels + n;
      if(lvl->edges) {
         free(lvl->edges);
         if(MemoryCount) 
            MemUsed[freedmem] += M16(lvl->nedges * sizeof(EDGE*));
      }
   }
   if(Gtree->levels) {
      free(Gtree->levels);
      if(MemoryCount) 
         MemUsed[freedmem] += M16(Gtree->nlevels * sizeof(LEVEL*));
   }
   // Free edge sequence
   if(Gtree->edges) {
      free(Gtree->edges);
      if(MemoryCount) {
         MemUsed[freedmem] += M16((Gtree->nedges + 1) * sizeof(EDGE*));
         MemUsed[freedmem] += M16(sizeof(Gtree));
      }
   }
   free(Gtree);
   Gtree = NULL;
}

// Print <e,d> table after Task 1 to logfile
void     LoggingTable1(void) {
   int ewidth = __max(T1EdgeLabel, T1EdgeNumber);
   int twidth = __max(T1TubeLabel, T1TubeNumber);
   // Loop over levels from the root's downward
   for(int k = 0; k < Gtree->nlevels; k++) {    // k is levelNo
      LEVEL* level = Gtree->levels + k;
      // Loop over edges at the curent level
      for(int e = 0; e < level->nedges; e++) {     // e is edgeNo
         EDGE* edge = level->edges[e];

         // Print edge's & tubes' labels and/or numbers
         if(T1EdgeLabel || T1TubeLabel) {
            if(Log) fprintf(Log, "\n%*.*s ", ewidth, ewidth, edge->name);
            for(int d = 1; d <= Stree->ntubes; d++) {    // d is tubeNo
               TUBE* tube  = Stree->tubes[d];
               if(Log) fprintf(Log, "%*.*s ", twidth, twidth, tube->name);
            }
            if(Log) fprintf(Log, "\n");
         }
         else if(Log) fprintf(Log, "\n");

         if(T1EdgeNumber || T1TubeNumber) {
            if(Log) fprintf(Log, "%*d ", ewidth, edge->edgeno);
            for(int d = 1; d <= Stree->ntubes; d++) {    // d is tubeNo
               TUBE* tube  = Stree->tubes[d];
               if(Log) fprintf(Log, "%*d ", twidth, tube->tubeno);
            }
            if(Log) fprintf(Log, "\n");
         }
         // Loop over MaxEvents events
         for(int evi = 0; evi < MaxEvents; evi++) {      // evi=#event
            // cost
            if(Log) fprintf(Log, "%*s ", ewidth, " ");
            for(int d = 1; d <= Stree->ntubes; d++)   // d is tubeNo
               if(Log) fprintf(Log, "%*.*f ", twidth, T1Precision,
                           edge->events[d][evi].cost / SCALE);
            if(Log) fprintf(Log, "\n");
            // id
            if(Log) fprintf(Log, "%*s ", ewidth, " ");
            for(int d = 1; d <= Stree->ntubes; d++) { // d is tubeNo
               int id = edge->events[d][evi].id;
               if(T1TextID)
                  if(Log) fprintf(Log, "%*s ", twidth, 
                     (id < 0 ? "---" : EventNames[id]));
               else
                  if(Log) fprintf(Log, "%*d ", twidth, id);
            }
            if(Log) fprintf(Log, "\n");
            // d1
            if(Log) fprintf(Log, "%*s ", ewidth, " ");
            for(int d = 1; d <= Stree->ntubes; d++)   // d is tubeNo
               if(Log) fprintf(Log, "%*d ", twidth, edge->events[d][evi].d1);
            if(Log) fprintf(Log, "\n");
            // d2
            if(Log) fprintf(Log, "%*s ", ewidth, " ");
            for(int d = 1; d <= Stree->ntubes; d++)   // d is tubeNo
               if(Log) fprintf(Log, "%*d ", twidth, edge->events[d][evi].d2);
            if(Log) fprintf(Log, "\n");
         }
      }
   }
   if(Log) fprintf(Log, "\n");
}

// Process gene trees in turn
bool     ProcessGeneTrees(void) {
   GTNAME*  gtn   = GeneTreeNameFirst;
   while(gtn) {
      if( !ReadGeneTree(gtn->filename) )
         goto Error;

      if(Gtree) {
         PruneBasisTree(Gtree);
         if( !Gtree ) {
            continue;
         }

         bool bhd = GtreeMode.heading;
         GtreeMode.heading = false;

         DBG( bool ben = GtreeMode.enable; GtreeMode.enable = true; )
         DBG( printf("\n"); )
         DBG( PrintGtree(Gtree->root, stdout, &GtreeMode); )
         DBG( printf(";\n"); fflush(stdout); )
         DBG( GtreeMode.enable = ben; )

         if(GtreeMode.enable && Log) {
            fprintf(Log, "\n");
            PrintGtree(Gtree->root, Log, &GtreeMode);
            fprintf(Log, ";\n");
         }

         GtreeMode.heading = bhd;

         if( !RunForward() ) {     // Forward processing in Task 1
            CON( printf("%4dm: Gene tree %d cost processing error: edges=%d "
               "leaves=%d(%d*) levels=%d.\n", ElapsedMin(true), Treeno, 
               Gtree->nedges, Gtree->nleaves, Gtree->nTmarks, Gtree->nlevels); )
            LOG( fprintf(Log, "%4dm: Gene tree %d cost processing error: edges=%d "
               "leaves=%d(%d*) levels=%d.\n", ElapsedMin(true), Treeno, 
               Gtree->nedges, Gtree->nleaves, Gtree->nTmarks, Gtree->nlevels); )
            goto Error;
         }

         int cost = Gtree->root->events[Stree->root->tubeno][0].cost;
         TotalCost += cost;
         if(OptimumCostJ) {
            CON( printf("%4dm: Gene tree %d cost processed: edges=%d leaves=%d(%d*) "
               "levels=%d cost=%.*f.\n", ElapsedMin(true), 
               Treeno, Gtree->nedges, Gtree->nleaves, Gtree->nTmarks,
               Gtree->nlevels, T1Precision, cost/SCALE); )
            LOG( fprintf(Log, "%4dm: Gene tree %d cost processed: edges=%d leaves=%d(%d*) "
               "levels=%d cost=%.*f.\n", ElapsedMin(true), 
               Treeno, Gtree->nedges, Gtree->nleaves, Gtree->nTmarks, 
               Gtree->nlevels, T1Precision, cost/SCALE); )
         }
         if(LogTable1)        // Print <e,d> table to logfile
            LoggingTable1();
         
         if(ModeEmbedding) {
            if( !RunBackward() ) {     // Backward processing in Task 2
               CON( printf("%4dm: Gene tree %d scenario error: edges=%d "
                  "leaves=%d(%d*) levels=%d.\n", ElapsedMin(true), Treeno, 
                  Gtree->nedges, Gtree->nleaves, Gtree->nTmarks, Gtree->nlevels); )
               LOG( fprintf(Log, "%4dm: Gene tree %d scenario error: edges=%d "
                  "leaves=%d(%d*) levels=%d.\n", ElapsedMin(true), Treeno, 
                  Gtree->nedges, Gtree->nleaves, Gtree->nTmarks, Gtree->nlevels); )
               goto Error;
            }
            if(ConS2Message) {
               CON( printf("%4dm: Gene tree %d scenario built, optimum cost=%.*f.\n", 
                  ElapsedMin(true), Treeno, T1Precision, cost/SCALE); )
            }
            if(LogS2Message) {
               LOG( fprintf(Log, "%4dm: Gene tree %d scenario built, optimum cost=%.*f.\n", 
                  ElapsedMin(true), Treeno, T1Precision, cost/SCALE); )
            }
            if(LogScenario)   // Print events scenario to logfile
               LoggingScenario();
            DestructScenario();
         }

         if(ModeStatistics) {       // Compute statistics in Task 3
            // Clear f(I,x) of current gene tree
            for(int d = 1; d <= Stree->ntubes; d++)
               for(int k = 0; k < nItypes; k++)
                  Stree->tubes[d]->mean[k] = 0.0;
            // Clear gjIT of current gene tree
            for(int k = 0; k < nItypes; k++) gjIT[k] = 0.0;
            // Construct orbigraph matrix
            if( !CreateOgraph() ) goto Error;
            // Run Task 3 forward
            OgUnary = OgBinary = OgTriples = 0;
            if( !RunForward3() ) {
               CON( printf("%4dm: Gene tree %d orbigraph building error.\n", 
                  ElapsedMin(true), Treeno); )
               LOG( fprintf(Log, "%4dm: Gene tree %d orbigraph building error.\n", 
                  ElapsedMin(true), Treeno); )
               goto Error;
            }
            if(ConOgMessage) {
               CON( printf("%4dm: Gene tree %d orbigraph built: nodes=%d un=%d "
                  "bi=%d tri=%d.\n", ElapsedMin(true), Treeno, 
                  Gtree->nedges * Stree->ntubes, OgUnary, OgBinary, OgTriples); )
            }
            if(LogOgMessage) {
               LOG( fprintf(Log, "%4dm: Gene tree %d orbigraph built: nodes=%d un=%d "
                  "bi=%d tri=%d.\n", ElapsedMin(true), Treeno, 
                  Gtree->nedges * Stree->ntubes, OgUnary, OgBinary, OgTriples); )
            }

            // Optional orbigraph output to log
            if(LogOrbigraph0 && Log) {
               fprintf(Log, "\nOrbigraph after forward run in Task 3:\n");
               LoggingOgraph();
            }

            // Run Task 3 backward
            if( !RunBackward3() ) {
               CON( printf("%4dm: Gene tree %d orbigraph backward run error.\n", 
                  ElapsedMin(true), Treeno); )
               LOG( fprintf(Log, "%4dm: Gene tree %d orbigraph backward run error.\n", 
                  ElapsedMin(true), Treeno); )
               goto Error;
            }

            // Optional orbigraph output to log
            if(LogOrbigraph && Log) {
               fprintf(Log, "\nOrbigraph after backward run in Task 3:\n");
               LoggingOgraph();
            }

            // Destruct entire orbigraph
            DestructOgraph();

            // Log per tree statistics
            if(LogTubeJ)
               LoggingTubeStats(false, false);   // new tubes
            if(LogOTubeJ)
               LoggingTubeStats(true, false);    // old tubes (must be after new!)
            if(LogTmarkJ)
               LoggingTmarkStats(gjIT);

            // Add current gjIT to total gIT
            for(int k = 0; k < nItypes; k++) gIT[k] += gjIT[k];
         }

         ++ProcessedTrees;
         DestructGtree();
         if(MemoryCount) {
            for(int i = 0; i < nMemTypes; i++)
               if(MemPeak[i] < MemUsed[i])
                  MemPeak[i] = MemUsed[i];
            if(LogMemoryJ) {
               __int64 MemTotal = MemUsed[genetree] + MemUsed[scenario] +
                     MemUsed[ognodes] + MemUsed[ogedges] + MemUsed[ogtriples];
               if(Log) fprintf(Log, "Mem_K: hk=%d st=%d gt=%d sc=%d on=%d oe=%d ot=%d lk=%d total=%d\n",
                  (int)(MemUsed[housekeeping] >> 10), 
                  (int)(MemUsed[speciestree] >> 10), 
                  (int)(MemUsed[genetree] >> 10), 
                  (int)(MemUsed[scenario] >> 10), 
                  (int)(MemUsed[ognodes] >> 10), 
                  (int)(MemUsed[ogedges] >> 10), 
                  (int)(MemUsed[ogtriples] >> 10), 
                  (int)((MemTotal - MemUsed[freedmem]) >> 10),
                  (int)((MemTotal + MemUsed[housekeeping] + MemUsed[speciestree]) >> 10));
            }
            for(int i = 2; i < nMemTypes; i++)
               MemUsed[i] = 0;
         }
         continue;
      }
      gtn = gtn->next;
   }
#ifdef   EMBED3MPI
   if(embed3_mpi) {
      // Collect from all branches: ProcessedTrees, TotalCost, MemPeak[]
      // NB: Assume nMemTypes > nItypes
      __int64  sendbuf[nMemTypes];
      __int64  recvbuf[nMemTypes];
      double*  send_double = (double*)sendbuf;
      double*  recv_double = (double*)recvbuf;
      int*     send_int    = (int*)sendbuf;
      int*     recv_int    = (int*)recvbuf;

      MPI::COMM_WORLD.Barrier();

      send_int[0] = ProcessedTrees;
      send_int[1] = TotalCost;
      MPI::COMM_WORLD.Reduce(sendbuf, recvbuf, 2, MPI::INT, MPI::SUM, 0);
      if(rank_mpi == 0) {
         ProcessedTrees = recv_int[0];
         TotalCost      = recv_int[1];
      }
      if(MemoryCount) {
         for(int i = 0; i < nMemTypes; i++)
            sendbuf[i] = MemPeak[i];
         MPI::COMM_WORLD.Reduce(sendbuf, recvbuf, nMemTypes, MPI::LONG_LONG, MPI::MAX, 0);
         if(rank_mpi == 0) {
            for(int i = 0; i < nMemTypes; i++)
               MemPeak[i] = recvbuf[i];
         }
      }
      if(ModeStatistics) {
         // Collect from all branches: gIT[nItypes]
         for(int i = 0; i < nItypes; i++)
            send_double[i] = gIT[i];
         MPI::COMM_WORLD.Reduce(sendbuf, recvbuf, nItypes, MPI::DOUBLE, MPI::SUM, 0);
         if(rank_mpi == 0)
            for(int i = 0; i < nItypes; i++)
               gIT[i] = recv_double[i];

         // Collect from all branches: tube->totmean[nItypes]
         for(int d = 1; d <= Stree->ntubes; d++) {
            TUBE* tube = Stree->tubes[d];
            for(int i = 0; i < nItypes; i++)
               send_double[i] = tube->totmean[i];
            MPI::COMM_WORLD.Reduce(sendbuf, recvbuf, nItypes, MPI::DOUBLE, MPI::SUM, 0);
            if(rank_mpi == 0)
               for(int i = 0; i < nItypes; i++)
                  tube->totmean[i] = recv_double[i];
         }
      }
   }
#endif
   if( !ProcessedTrees ) {
      CON( printf("PRO: No valid gene trees to process.\n"); )
      LOG( fprintf(Log, "PRO: No valid gene trees to process.\n"); )
      goto Error;
   }
   if(ModeStatistics) {       // Log Task 3 results summary
      if(LogTubeStats)
         LoggingTubeStats(false, true);   // new tubes
      if(LogOTubeStats)
         LoggingTubeStats(true, true);    // old tubes (must be after new!)
      if(LogTmarkStats)
         LoggingTmarkStats(gIT);
   }
   return true;
Error:
   fflush(stdout);
   return false;
}

// Process basis trees in turn
bool     ProcessBasisTrees(void) {
   GTNAME*  gtn   = GeneTreeNameFirst;

   while(gtn) {
      if( !ReadBasisTree(gtn->filename) )
         goto Error;
      if( !Gtree )
         gtn = gtn->next;
   }

   nSpecies = GetSpeciesCount();
   Species  = (SPTABLE*)calloc(nSpecies+1, sizeof(SPTABLE));
   if( !Species ) {
      CON( printf("PRB: Not enough memory.\n"); )
      LOG( fprintf(Log, "PRB: Not enough memory.\n"); )
      #ifdef   EMBED3MPI
      if(embed3_mpi)
         MPI::COMM_WORLD.Abort(1);
      else
      #endif
      exit(1);
   }
   if(MemoryCount)
      MemUsed[speciestree] += M16(nSpecies+1 * sizeof(SPTABLE));

   FillSpecies(Species);
   CON( printf("%4dm: Basis trees read: %d, Species present: %d.\n", \
      ElapsedMin(true), Treeno, nSpecies); )
   LOG( fprintf(Log, "%4dm: Basis trees read: %d, Species present: %d.\n", \
      ElapsedMin(true), Treeno, nSpecies); )
   nBtrees = Treeno;
   return true;
Error:
   fflush(stdout);
   return false;
}

// Try to insert event in given array of best MaxEvents
// nd means tube number, 0=don't care
void     PushEvent(EVENT* evtvect, EVENT* evt, int nd) {
   //DBG( fprintf(Log, "( %4.1f %7s %2d %2d )  =>  (",
   //   evt->cost/SCALE, evt->id < 0 ? "---" : EventNames[evt->id], evt->d1, evt->d2);
   //   for(int k = 0; k < MaxEvents; k++)
   //      fprintf(Log, " %4.1f %7s %2d %2d ",
   //         evtvect[k].cost/SCALE, evtvect[k].id < 0 ? "---" : EventNames[evtvect[k].id], evtvect[k].d1, evtvect[k].d2); 
   //   fprintf(Log, ")  =>  ("); 
   //)
   for(int i = 0; i < MaxEvents; i++) {
      if(evtvect[i].id == id_none) {      // store at i-th place
         memcpy(evtvect + i, evt, sizeof(EVENT));
         break;
      }
      if(evtvect[i].cost < evt->cost)     // try next
         continue;
      if(evtvect[i].cost > evt->cost) {   // insert at i-th place
         if(i < MaxEvents - 1) {   // is there anything to shift?
            memmove(evtvect + i + 1, evtvect + i,
               sizeof(EVENT) * (MaxEvents - i - 1));
         }
         memcpy(evtvect + i, evt, sizeof(EVENT));
         break;
      }
      // case of equal costs
      if(nd == 0 || evt->d1 == 0) continue;
      // compare dist(d,d1) with rival's
      int rold = TubeDistance(nd, evtvect[i].d1);
      int rnew = TubeDistance(nd, evt->d1);
      if(evt->d2 > 0) {   // also add dist(d,d2)
         rold += TubeDistance(nd, evtvect[i].d2);
         rnew += TubeDistance(nd, evt->d2);
      }
      if(rnew >= rold) continue;
      // insert here with rnew < rold
      if(i < MaxEvents - 1) {   // is there anything to shift?
         memmove(evtvect + i + 1, evtvect + i,
            sizeof(EVENT) * (MaxEvents - i - 1));
      }
      memcpy(evtvect + i, evt, sizeof(EVENT));
      break;
   }
   //DBG( 
   //   for(int k = 0; k < MaxEvents; k++) 
   //      fprintf(Log, " %4.1f %7s %2d %2d ",
   //         evtvect[k].cost/SCALE, evtvect[k].id < 0 ? "---" : EventNames[evtvect[k].id], evtvect[k].d1, evtvect[k].d2); 
   //   fprintf(Log, ")\n");
   //)
}

// Merge second array of events to first one (both of MaxEvents)
void     MergeEvents(EVENT* to, EVENT* from) {
   NDBG( if(from[0].id == id_none) return; )
   //DBG( fprintf(Log, "(");
   //   for(int k = 0; k < MaxEvents; k++)
   //      fprintf(Log, " %4.1f %7s %2d %2d ",
   //         from[k].cost/SCALE, from[k].id < 0 ? "---" : EventNames[from[k].id], from[k].d1, from[k].d2); 
   //   fprintf(Log, ")  =>  ");
   //   )
   //DBG( fprintf(Log, "(");
   //   for(int k = 0; k < MaxEvents; k++)
   //      fprintf(Log, " %4.1f %7s %2d %2d ",
   //         to[k].cost/SCALE, to[k].id < 0 ? "---" : EventNames[to[k].id], to[k].d1, to[k].d2);
   //   fprintf(Log, ")  =>  ");
   //   )
   int k = 0;        // current position in FROM array
   for(int i = 0; i < MaxEvents; i++) {   // loop over TO positions
      if(from[k].id == id_none) break;
      if(to[i].id == id_none) {     // copy tail of FROM
         memcpy(to + i, from + k, sizeof(EVENT) * (MaxEvents - i));
         break;
      }
      if(from[k].cost >= to[i].cost)   // next position of TO
         continue;
      // FROM < TO - insert here
      int len = 1;     // copy count
      for(int j = k + 1; j < MaxEvents; j++) {
         if(from[j].id == id_none) break;
         if(from[j].cost >= to[i].cost) break;
         len++;
      }
      if(i + len <= MaxEvents) {
         if(i + len < MaxEvents)
            memmove(to + i + len, to + i, sizeof(EVENT) * (MaxEvents - i - len));
         memcpy(to + i, from + k, sizeof(EVENT) * len);
         k += len;
         i += len;
      }
      else {
         memcpy(to + i, from + k, sizeof(EVENT) * (MaxEvents - i));
         break;
      }
   }
   //DBG( fprintf(Log, "(");
   //   for(int k = 0; k < MaxEvents; k++)
   //      fprintf(Log, " %4.1f %7s %2d %2d ",
   //         to[k].cost/SCALE, to[k].id < 0 ? "---" : EventNames[to[k].id], to[k].d1, to[k].d2); 
   //   fprintf(Log, ")\n");
   //   )
}

static EVENT* evtqueue = NULL;       // temporary event queue to merge

// Clear temporary event queue
void     ClearTempEventQueue(void) {
   EVENT* evt = evtqueue;
   for(int i = 0; i < MaxEvents; i++, evt++) {    // clear queue
      evt->cost   = -1;    //(int)SCALE;
      evt->id     = id_none;
      evt->d1     = 0;
      evt->d2     = 0;
   }
}

// Clear temporary event
void     ClearTempEvent(EVENT* evt) {
   evt->cost   = -1;    //(int)SCALE;
   evt->id     = id_none;
   evt->d1     = 0;
   evt->d2     = 0;
}

// Return true if the gene tree contains given species
bool     HasSpecies(int sp) {
   for(int i = 1; i <= Gtree->nedges; i++) {
      EDGE *edge = Gtree->edges[i];
      if(edge->nchildren > 0)
         continue;
      if(sp == edge->specno)
         return true;
   }
   return false;
}

// Implement p(e,d): return true if whole gene tree containing edge e
//  also contains at least one species that is a descendant of tube d
bool     IsActualLoss(TUBE* d) {
   if(!d->left && !d->right)
      return HasSpecies(d->specno);
   if(d->left && IsActualLoss(d->left))
      return true;
   if(d->right && IsActualLoss(d->right))
      return true;
   return false;
}

// Find cost & event details (best MaxEvents)
// Return cost of the very best (zeroth) event
int     FindCost(EDGE* e, TUBE* d) {
   assert(e!=NULL); assert(d!=NULL);
   TUBE* outtube;
   EVENT evt;                    // new-built event
   EVENT* pevt = & evt;
   EVENT* evt_ed = e->events[d->tubeno];
   if(!evtqueue) {
      evtqueue = (EVENT*)malloc(MaxEvents * sizeof(EVENT));
      if(!evtqueue) {
         CON( printf("CST: Not enough memory.\n"); )
         LOG( fprintf(Log, "CST: Not enough memory.\n"); )
      }
      if(MemoryCount) {
         MemUsed[genetree] += M16(MaxEvents * sizeof(EVENT));
      }
   }
   
   // Using weights of the basis tree nodes
   double Ftop = 1.0;
   double Fbot = 1.0;
   double qG   = 1.0;
   if(TreeWeight) {
      Ftop = e->parent ? e->parent->weight : 1.0;
      Fbot = e->weight;
      qG   = (double)Gtree->nleaves / nSpecies;
      Ftop = MinWeight + Ftop * (1 - MinWeight);
      Fbot = MinWeight + Fbot * (1 - MinWeight);
      qG   = MinWeight + qG * (1 - MinWeight);
   }

   // -1: Clear new evt
   ClearTempEvent(pevt);

   // 0,1,2: Both edge e and tube d are leaves
   if(e->nchildren == 0 && !d->left && !d->right) {
      if(e->specno == d->specno) {                    // 0: fin
         evt.id   = id_fin;
         evt.cost = 0;
         evt.d1   = 0;
         evt.d2   = 0;
      }
      else {
         //assert(Stree->tubes[e->specno + 1]->specno == e->specno);
         //evt.d1 = e->specno + 1;
         evt.d1 = 0;
         for(int d1 = 1; d1 <= Stree->ntubes; d1++) {
            if(Stree->tubes[d1]->specno == e->specno) {
               evt.d1 = d1;
               break;
            }
         }
         if(evt.d1 == 0) {
            CON( printf("FIC: Can't find corresponding tube.\n"); )
            LOG( fprintf(Log, "FIC: Can't find corresponding tube.\n"); )
            #ifdef   EMBED3MPI
            if(embed3_mpi)
               MPI::COMM_WORLD.Abort(4);
            else
            #endif
            exit(4);
         }
         evt.d2 = 0;
         if(d->specno != 0) {                         // 1: tr_fin
            evt.id   = id_tr_fin;
            evt.cost = (int)(c_tr_without * Ftop);
         }
         else {                                       // 2: ga_fin
            evt.id   = id_ga_fin;
            evt.cost = (int)(c_gain * Ftop);
         }
      }
      //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
      PushEvent(evt_ed, pevt, 0);
   }

   // 3: Tube d has one child
   if(d->left && !d->right) {                         // 3: pass (left child only)
      evt.id   = id_pass;
      evt.cost = e->events[d->left->tubeno][0].cost;
      evt.d1   = d->left->tubeno;   // for later use instead of 0;
      evt.d2   = 0;
      //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
      PushEvent(evt_ed, pevt, 0);
   }
   else if(!d->left && d->right) {                    // 3: pass (right child only)
      evt.id   = id_pass;
      evt.cost = e->events[d->right->tubeno][0].cost;
      evt.d1   = d->right->tubeno;  // for later use instead of 0;
      evt.d2   = 0;
      //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
      PushEvent(evt_ed, pevt, 0);
   }

   // 4,5: Both edge e and tube d have two children
   if(e->nchildren == 2 && d->left && d->right) {
      evt.d1   = 0;
      evt.d2   = 0;
      EDGE* e1 = e->child;
      EDGE* e2 = e->child->sibling;
      assert(e1 && e2);
      evt.id   = id_fork_lr;                          // 4: fork_lr
      evt.cost = e1->events[d->left->tubeno][0].cost +
                 e2->events[d->right->tubeno][0].cost;
      //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
      PushEvent(evt_ed, pevt, 0);
      evt.id   = id_fork_rl;                          // 5: fork_rl
      evt.cost = e2->events[d->left->tubeno][0].cost +
                 e1->events[d->right->tubeno][0].cost;
      //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
      PushEvent(evt_ed, pevt, 0);
   }

   // 6,7: Tube d has two children and isn't root
   if(d->parent && d->left && d->right) {
      evt.d1   = 0;
      evt.id   = id_pass_l;                           // 6: pass_l
      int cl   = (int)(IsActualLoss(d->right) ? c_loss * Ftop : c_loss1 * qG);
      evt.d2   = -cl;
      evt.cost = e->events[d->left->tubeno][0].cost + cl;
      //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
      PushEvent(evt_ed, pevt, 0);
      evt.id   = id_pass_r;                           // 7: pass_r
      cl       = (int)(IsActualLoss(d->left) ? c_loss * Ftop : c_loss1 * qG);
      evt.d2   = -cl;
      evt.cost = e->events[d->right->tubeno][0].cost + cl;
      //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
      PushEvent(evt_ed, pevt, 0);
   }

   // 8,9,10,11: Tube d is root, has two children (outgroup and not)
   if(!d->parent && d->left && d->right) {
      outtube = Stree->slices[Stree->height-1].tubes[0];
      evt.d1   = 0;
      evt.d2   = 0;
      if(d->right == outtube) {
         evt.id   = id_nout_l;                        // 8: nout_l
         evt.cost = e->events[d->left->tubeno][0].cost;
         //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
         PushEvent(evt_ed, pevt, 0);
      }
      else if(d->left == outtube) {
         evt.id   = id_nout_r;                        // 9: nout_r
         evt.cost = e->events[d->right->tubeno][0].cost;
         //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
         PushEvent(evt_ed, pevt, 0);
      }
      if(d->left == outtube) {
         evt.id   = id_out_l;                         // 10: nout_l
         evt.cost = e->events[d->left->tubeno][0].cost;
         //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
         PushEvent(evt_ed, pevt, 0);
      }
      else if(d->right == outtube) {
         evt.id   = id_out_r;                         // 11: nout_r
         evt.cost = e->events[d->right->tubeno][0].cost;
         //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
         PushEvent(evt_ed, pevt, 0);
      }
   }

   outtube = (d->parent) ?
      Stree->slices[d->height].tubes[0]  // invalid if d is the root!
      : NULL;

   // 12: Edge e has two children, tube d isn't outgroup.
   if(e->nchildren == 2 && d != outtube) {
      evt.id   = id_dupl;                             // 12: dupl
      evt.cost = e->child->events[d->tubeno][0].cost +
         e->child->sibling->events[d->tubeno][0].cost + 
         (int)(c_dupl * Fbot);
      evt.d1   = 0;
      evt.d2   = 0;
      //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
      PushEvent(evt_ed, pevt, 0);
   }

   // 13,14: Edge e has two children, tube d is root
   if(e->nchildren == 2 && !d->parent) {
      TUBE* dz = Stree->slices[Stree->height-1].tubes[0];
      int cl   = e->child->events[d->tubeno][0].cost +
         e->child->sibling->events[dz->tubeno][0].cost;
      int cr   = e->child->events[dz->tubeno][0].cost +
         e->child->sibling->events[d->tubeno][0].cost;
      if(cl <= cr) {
         evt.id   = id_dup0_l;                        // 13: dup0_l
         evt.cost = cl;
      }
      else {
         evt.id   = id_dup0_r;                        // 14: dup0_r
         evt.cost = cr;
      }
      evt.d1   = 0;
      evt.d2   = 0;
      //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
      PushEvent(evt_ed, pevt, 0);
   }

   // 15: Edge e has two children, tube d is outgroup and not root
   if(e->nchildren == 2 && d->parent && d == outtube) {
      evt.id   = id_outd;                             // 15: outd
      evt.cost = e->child->events[d->tubeno][0].cost +
         e->child->sibling->events[d->tubeno][0].cost;
      evt.d1   = 0;
      evt.d2   = 0;
      //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
      PushEvent(evt_ed, pevt, 0);
   }

   // 16,17: Edge e has two children, tube d isn't outgroup or root
   if(e->nchildren == 2 && d->parent && d != outtube) {
      ClearTempEventQueue();
      evt.d2 = 0;
      SLICE* slice = Stree->slices + d->height;
      for(int i = 1; i < slice->ntubes; i++) {
         TUBE* d1 = slice->tubes[i];
         if(d1 == d) continue;
         evt.d1   = d1->tubeno;
         evt.id   = id_tr1;                           // 16: tr1
         evt.cost = e->child->events[d1->tubeno][0].cost +
            e->child->sibling->events[d->tubeno][0].cost;
         //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
         PushEvent(evtqueue, pevt, d->tubeno);
         evt.id   = id_tr2;                           // 17: tr2
         evt.cost = e->child->events[d->tubeno][0].cost +
            e->child->sibling->events[d1->tubeno][0].cost;
         //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
         PushEvent(evtqueue, pevt, d->tubeno);
      }
      for(int i = 0; i < MaxEvents; i++) {   // add c_tr_with
         if(evtqueue[i].id != id_none)
            evtqueue[i].cost += (int)(c_tr_with * Fbot);
         else break;
      }
      //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
      MergeEvents(evt_ed, evtqueue);
   }

   // 18,19: Edge e has two children, tube d is outgroup and not root
   if(e->nchildren == 2 && d->parent && d == outtube) {
      ClearTempEventQueue();
      evt.d2 = 0;
      SLICE* slice = Stree->slices + d->height;
      for(int i = 1; i < slice->ntubes; i++) {
         TUBE* d1 = slice->tubes[i];
         if(d1 == d) continue;
         evt.d1   = d1->tubeno;
         evt.id   = id_ga1;                           // 18: ga1
         evt.cost = e->child->events[d1->tubeno][0].cost +
            e->child->sibling->events[d->tubeno][0].cost;
         //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
         PushEvent(evtqueue, pevt, d->tubeno);
         evt.id   = id_ga2;                           // 19: ga2
         evt.cost = e->child->events[d->tubeno][0].cost +
            e->child->sibling->events[d1->tubeno][0].cost;
         //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
         PushEvent(evtqueue, pevt, d->tubeno);
      }
      for(int i = 0; i < MaxEvents; i++) {   // add c_gain
         if(evtqueue[i].id != id_none)
            evtqueue[i].cost += (int)(c_gain * Fbot);
         else break;
      }
      //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
      MergeEvents(evt_ed, evtqueue);
   }

   // 20: Edge e is root, tube d is outgroup and not root
   if(!e->parent && d->parent && d == outtube) {
      ClearTempEventQueue();
      evt.id   = id_ga_big;                           // 20: ga_big
      evt.d2 = 0;
      SLICE* slice = Stree->slices + d->height;
      for(int i = 1; i < slice->ntubes; i++) {
         TUBE* d1 = slice->tubes[i];
         //if(d1 == d) continue;    // not needed
         evt.cost = e->events[d1->tubeno][0].cost + 
                    (int)(c_gain_big * Ftop);
         evt.d1   = d1->tubeno;
         //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
         PushEvent(evtqueue, pevt, 0);
      }
      //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
      MergeEvents(evt_ed, evtqueue);
   }

   // 21: Tube d isn't outgroup or root, over one-child d', except outgroup
   if(d->parent && d != outtube) {
      ClearTempEventQueue();
      evt.id   = id_tr_pass;                          // 21: tr_pass
      SLICE* slice = Stree->slices + d->height;
      for(int i = 1; i < slice->ntubes; i++) {
         TUBE* d1 = slice->tubes[i];
         if(d1 == d) continue;
         if(d1->left && !d1->right) {
            evt.cost = e->events[d1->left->tubeno][0].cost + 
                       (int)(c_tr_without * Ftop);
            evt.d2   = d1->left->tubeno;  // for later use instead of 0;
         }
         else if(!d1->left && d1->right) {
            evt.cost = e->events[d1->right->tubeno][0].cost + 
                       (int)(c_tr_without * Ftop);
            evt.d2   = d1->right->tubeno; // for later use instead of 0;
         }
         else continue;
         evt.d1   = d1->tubeno;
         //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
         PushEvent(evtqueue, pevt, d->tubeno);
      }
      //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
      MergeEvents(evt_ed, evtqueue);
   }

   // 22: Edge e isn't root, tube d is outgroup and not root, over one-child d'
   if(e->parent && d->parent && d == outtube) {
      ClearTempEventQueue();
      evt.id   = id_ga_pass;                          // 22: ga_pass
      SLICE* slice = Stree->slices + d->height;
      for(int i = 1; i < slice->ntubes; i++) {
         TUBE* d1 = slice->tubes[i];
         //if(d1 == d) continue;       // not needed
         if(d1->left && !d1->right) {
            evt.cost = e->events[d1->left->tubeno][0].cost + 
                       (int)(c_gain * Ftop);
            evt.d2   = d1->left->tubeno;  // for later use instead of 0;
         }
         else if(!d1->left && d1->right) {
            evt.cost = e->events[d1->right->tubeno][0].cost +
                       (int)(c_gain * Ftop);
            evt.d2   = d1->right->tubeno; // for later use instead of 0;
         }
         else continue;
         evt.d1   = d1->tubeno;
         //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
         PushEvent(evtqueue, pevt, 0);
      }
      //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
      MergeEvents(evt_ed, evtqueue);
   }

   // 23,24: Edge e has two children, tube d isn't outgroup or root
   if(e->nchildren == 2 && d->parent && d != outtube) {
      ClearTempEventQueue();
      evt.d2 = 0;
      SLICE* slice = Stree->slices + d->height;
      for(int i = 1; i < slice->ntubes; i++) {
         TUBE* d1 = slice->tubes[i];
         if(d1 == d) continue;
         if(!d1->left || !d1->right) continue;
         evt.d1   = d1->tubeno;
         evt.id   = id_tr_lr;                         // 23: tr_lr
         evt.cost = e->child->events[d1->left->tubeno][0].cost +
            e->child->sibling->events[d1->right->tubeno][0].cost;
         //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
         PushEvent(evtqueue, pevt, d->tubeno);
         evt.id   = id_tr_rl;                         // 24: tr_rl
         evt.cost = e->child->events[d1->right->tubeno][0].cost +
            e->child->sibling->events[d1->left->tubeno][0].cost;
         //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
         PushEvent(evtqueue, pevt, d->tubeno);
      }
      for(int i = 0; i < MaxEvents; i++) {   // add c_tr_without
         if(evtqueue[i].id != id_none)
            evtqueue[i].cost += (int)(c_tr_without * Ftop);
         else break;
      }
      //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
      MergeEvents(evt_ed, evtqueue);
   }

   // 25,26: Edge e isn't root & 2-chi, d is outgroup & not root, over 2-chi d'
   if(e->parent && e->nchildren == 2 && d->parent && d == outtube) {
      ClearTempEventQueue();
      evt.d2 = 0;
      SLICE* slice = Stree->slices + d->height;
      for(int i = 1; i < slice->ntubes; i++) {
         TUBE* d1 = slice->tubes[i];
         //if(d1 == d) continue;       // not needed
         if(!d1->left || !d1->right) continue;
         evt.d1   = d1->tubeno;
         evt.id   = id_ga_lr;                         // 25: ga_lr
         evt.cost = e->child->events[d1->left->tubeno][0].cost +
            e->child->sibling->events[d1->right->tubeno][0].cost;
         //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
         PushEvent(evtqueue, pevt, 0);
         evt.id   = id_ga_rl;                         // 26: ga_rl
         evt.cost = e->child->events[d1->right->tubeno][0].cost +
            e->child->sibling->events[d1->left->tubeno][0].cost;
         //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
         PushEvent(evtqueue, pevt, 0);
      }
      for(int i = 0; i < MaxEvents; i++) {   // add c_gain
         if(evtqueue[i].id != id_none)
            evtqueue[i].cost += (int)(c_gain * Ftop);
         else break;
      }
      //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
      MergeEvents(evt_ed, evtqueue);
   }

   // 27,28: Tube d isn't outgroup or root, over two-children d'
   if(d->parent && d != outtube) {
      ClearTempEventQueue();
      SLICE* slice = Stree->slices + d->height;
      for(int i = 1; i < slice->ntubes; i++) {
         TUBE* d1 = slice->tubes[i];
         if(d1 == d) continue;
         if(!d1->left || !d1->right) continue;
         evt.d1   = d1->tubeno;
         evt.id   = id_tr_l;                          // 27: tr_l
         evt.cost = e->events[d1->left->tubeno][0].cost;
         int cl   = (int)(IsActualLoss(d1->right) ? c_loss * Ftop : c_loss1 * qG);
         evt.d2   = -cl;
         evt.cost += cl;
         //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
         PushEvent(evtqueue, pevt, d->tubeno);
         evt.id   = id_tr_r;                          // 28: tr_r
         evt.cost = e->events[d1->right->tubeno][0].cost;
         cl       = (int)(IsActualLoss(d1->left) ? c_loss * Ftop : c_loss1 * qG);
         evt.d2   = -cl;
         evt.cost += cl;
         //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
         PushEvent(evtqueue, pevt, d->tubeno);
      }
      int toadd = (int)(c_tr_without * Ftop);      // add c_tr_without
      for(int i = 0; i < MaxEvents; i++) {
         if(evtqueue[i].id != id_none)
            evtqueue[i].cost += toadd;
         else break;
      }
      //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
      MergeEvents(evt_ed, evtqueue);
   }

   // 29,30: Edge e isn't root, d is outgroup & not root, over 2-chi d'
   if(e->parent && d->parent && d == outtube) {
      ClearTempEventQueue();
      evt.d2 = 0;
      SLICE* slice = Stree->slices + d->height;
      for(int i = 1; i < slice->ntubes; i++) {
         TUBE* d1 = slice->tubes[i];
         //if(d1 == d) continue;       // not needed
         if(!d1->left || !d1->right) continue;
         evt.d1   = d1->tubeno;
         evt.id   = id_ga_l;                          // 29: ga_l
         evt.cost = e->events[d1->left->tubeno][0].cost;
         int cl   = (int)(IsActualLoss(d1->right) ? c_loss * Ftop : c_loss1 * qG);
         evt.d2   = -cl;
         evt.cost += cl;
         //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
         PushEvent(evtqueue, pevt, 0);
         evt.id   = id_ga_r;                          // 30: ga_r
         evt.cost = e->events[d1->right->tubeno][0].cost;
         cl       = (int)(IsActualLoss(d1->left) ? c_loss * Ftop : c_loss1 * qG);
         evt.d2   = -cl;
         evt.cost += cl;
         //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
         PushEvent(evtqueue, pevt, 0);
      }
      int toadd = (int)(c_gain * Ftop);            // add c_gain
      for(int i = 0; i < MaxEvents; i++) {
         if(evtqueue[i].id != id_none)
            evtqueue[i].cost += toadd;
         else break;
      }
      //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
      MergeEvents(evt_ed, evtqueue);
   }

   // 31: Edge e has two children, tube d isn't outgroup or root
   if(e->nchildren == 2 && d->parent && d != outtube) {
      ClearTempEventQueue();
      evt.id   = id_tr_dupl;                          // 31: tr_dupl
      evt.d2 = 0;
      SLICE* slice = Stree->slices + d->height;
      for(int i = 1; i < slice->ntubes; i++) {
         TUBE* d1 = slice->tubes[i];
         if(d1 == d) continue;
         evt.cost = e->child->events[d1->tubeno][0].cost +
            e->child->sibling->events[d1->tubeno][0].cost;
         evt.d1   = d1->tubeno;
         //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
         PushEvent(evtqueue, pevt, d->tubeno);
      }
      int toadd = (int)(c_tr_without * Ftop + c_dupl * Fbot);   // add c_tr_w/o + c_dupl
      for(int i = 0; i < MaxEvents; i++) {
         if(evtqueue[i].id != id_none)
            evtqueue[i].cost += toadd;
         else break;
      }
      //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
      MergeEvents(evt_ed, evtqueue);
   }

   // 32: Edge e isn't root & 2-chi, d is outgroup & not root
   if(e->parent && e->nchildren == 2 && d->parent && d == outtube) {
      ClearTempEventQueue();
      evt.id   = id_ga_dupl;                          // 32: ga_dupl
      evt.d2 = 0;
      SLICE* slice = Stree->slices + d->height;
      for(int i = 1; i < slice->ntubes; i++) {
         TUBE* d1 = slice->tubes[i];
         //if(d1 == d) continue;    // not needed
         evt.cost = e->child->events[d1->tubeno][0].cost +
            e->child->sibling->events[d1->tubeno][0].cost;
         evt.d1   = d1->tubeno;
         //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
         PushEvent(evtqueue, pevt, 0);
      }
      int toadd = (int)(c_gain * Ftop + c_dupl * Fbot);   // add c_gain + c_dupl
      for(int i = 0; i < MaxEvents; i++) {
         if(evtqueue[i].id != id_none)
            evtqueue[i].cost += toadd;
         else break;
      }
      //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
      MergeEvents(evt_ed, evtqueue);
   }

   // 33: Edge e has two children, tube d isn't outgroup or root
   if(e->nchildren == 2 && d->parent && d != outtube) {
      ClearTempEventQueue();
      SLICE* slice = Stree->slices + d->height;
      evt.id   = id_tr;                               // 33: tr
      for(int i = 1; i < slice->ntubes; i++) {
         TUBE* d1 = slice->tubes[i];
         if(d1 == d) continue;
         evt.d1   = d1->tubeno;
         for(int j = 1; j < slice->ntubes; j++) {
            TUBE* d2 = slice->tubes[j];
            if(d2 == d || d2 == d1) continue;
            evt.cost = e->child->events[d1->tubeno][0].cost +
               e->child->sibling->events[d2->tubeno][0].cost;
            evt.d2   = d2->tubeno;
            //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
            PushEvent(evtqueue, pevt, d->tubeno);
         }
      }
      int toadd = (int)(c_tr_without * Ftop + c_tr_with * Fbot);   // add c_tr_w/o + c_tr_with
      for(int i = 0; i < MaxEvents; i++) {
         if(evtqueue[i].id != id_none)
            evtqueue[i].cost += toadd;
         else break;
      }
      //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
      MergeEvents(evt_ed, evtqueue);
   }

   // 34: Edge e isn't root & 2-chi, d is outgroup & not root
   if(e->parent && e->nchildren == 2 && d->parent && d == outtube) {
      ClearTempEventQueue();
      SLICE* slice = Stree->slices + d->height;
      evt.id   = id_ga;                               // 34: ga
      for(int i = 1; i < slice->ntubes; i++) {
         TUBE* d1 = slice->tubes[i];
         //if(d1 == d) continue;    // not needed
         evt.d1   = d1->tubeno;
         for(int j = 1; j < slice->ntubes; j++) {
            TUBE* d2 = slice->tubes[j];
            if(/*d2 == d ||*/ d2 == d1) continue;
            evt.cost = e->child->events[d1->tubeno][0].cost +
               e->child->sibling->events[d2->tubeno][0].cost;
            evt.d2   = d2->tubeno;
            //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
            PushEvent(evtqueue, pevt, 0);
         }
      }
      int toadd = (int)(c_gain * Ftop + c_tr_with * Fbot);   // add c_gain + c_tr_with
      for(int i = 0; i < MaxEvents; i++) {
         if(evtqueue[i].id != id_none)
            evtqueue[i].cost += toadd;
         else break;
      }
      //DBG( fprintf(Log, "%3s %5s: ", e->name, d->name); )
      MergeEvents(evt_ed, evtqueue);
   }
   return evt_ed[0].cost;
}

// Forward run in Task 1
bool     RunForward(void) {
   assert(Gtree!=NULL);
   EDGE* edge = NULL;
   TUBE* tube = NULL;
   for(int e = 1; e < Gtree->nedges; e++) {     // Main loop for non-root edges
      edge = Gtree->edges[e];
      if(edge->nchildren > 2) {        // Polytomy case
         //TODO polytomy
         CON( printf("TS1: Polytomy case is not implemented yet.\n"); )
         LOG( fprintf(Log, "TS1: Polytomy case is not implemented yet.\n"); )
         return false;
      }
      else {
         for(int d = 1; d <= Stree->ntubes; d++) {
            tube = Stree->tubes[d];
            if(FindCost(edge, tube) < 0) {
               CON( printf("TS1: No event found for <%s=%d,%s=%d> pair.\n",
                  edge->name, edge->edgeno, tube->name, tube->tubeno); )
               LOG( fprintf(Log, "TS1: No event found for <%s=%d,%s=%d> pair.\n",
                  edge->name, edge->edgeno, tube->name, tube->tubeno); )
               return false;
            }
         }
      }
   }
   edge = Gtree->edges[Gtree->nedges];          // Main loop for root edge
   assert(edge==Gtree->root);
   if(edge->nchildren > 2) {           // Root polytomy case
      //TODO polytomy
      CON( printf("TS1: Polytomy case is not implemented yet.\n"); )
      LOG( fprintf(Log, "TS1: Polytomy case is not implemented yet.\n"); )
      return false;
   }
   else {
      for(int i = 0; i <= Stree->height; i++) {   // by slices
         for(int j = 1; j < Stree->slices[i].ntubes; ++j) {
            tube = Stree->slices[i].tubes[j];
            if(FindCost(edge, tube) < 0) {
               CON( printf("TS1: No event found for <%s=%d,%s=%d> pair.\n",
                  edge->name, edge->edgeno, tube->name, tube->tubeno); )
               LOG( fprintf(Log, "TS1: No event found for <%s=%d,%s=%d> pair.\n",
                  edge->name, edge->edgeno, tube->name, tube->tubeno); )
               return false;
            }
         }
         tube = Stree->slices[i].tubes[0];
         if(FindCost(edge, tube) < 0) {
            CON( printf("TS1: No event found for <%s=%d,%s=%d> pair.\n",
               edge->name, edge->edgeno, tube->name, tube->tubeno); )
            LOG( fprintf(Log, "TS1: No event found for <%s=%d,%s=%d> pair.\n",
               edge->name, edge->edgeno, tube->name, tube->tubeno); )
            return false;
         }
      }
   }
   return true;
}
