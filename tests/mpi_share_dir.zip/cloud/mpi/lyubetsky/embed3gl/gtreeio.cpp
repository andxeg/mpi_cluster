// embed3GL: A program for phylogenetic study of joint gene & species evolution.
//
// The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/embed3gl]
//
// (C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
// E-mail: rubanov{at}iitp.ru
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// Functions: OpenGeneTree, ReadGtreeString, PrintGtree,
//            FillGtreeLevels, FillLevels, ReadGeneTree, 
//            ReadBasisTree

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "embed3gl.h"

FILE*    gtf   = NULL;
int      line  = 0;

// Return true if gene tree file can be opened
bool     OpenGeneTree(char* filename) {

   char*    gtreefilename = (char*)malloc(BUFLEN);

   if( !gtreefilename ) {
      CON( printf("GTR: Not enough memory.\n"); )
      LOG( fprintf(Log, "GTR: Not enough memory.\n"); )
      return false;
   }
   if(MemoryCount) {
      MemUsed[housekeeping] += M16(BUFLEN);
   }
   gtreefilename[0] = 0;

   strcpy(gtreefilename, DataDirectory);
   strcat(gtreefilename, filename);
   gtf = fopen(gtreefilename, "rb");
   if( !gtf ) {
      const char gttype[2][6] = {"gene", "basis"};
      const char *p = ModeSuper3Build ? gttype[1] : gttype[0];
      CON( printf("GTR: Cannot open %s tree file '%s'.\n", p, gtreefilename); )
      LOG( fprintf(Log, "GTR: Cannot open %s tree file '%s'.\n", p, gtreefilename); )
      return false;
   }
   line = 0;
   free(gtreefilename);
   if(MemoryCount) {
      MemUsed[housekeeping] -= M16(BUFLEN);
   }
   return true;
}

// Return ptr to a new string containing a gene tree.
// The string can be empty(=EOF)! Return NULL on errors.
char*    ReadGtreeString(char *filename) {
   char* buf   = (char*)malloc(BUFLEN + 1);
   char* tree  = (char*)malloc(MAXTREELEN + 1);
   if(!buf || !tree) {
      CON( printf("GTR: Not enough memory.\n"); )
      LOG( fprintf(Log, "GTR: Not enough memory.\n"); )
      return NULL;
   }
   if(MemoryCount) {
      MemUsed[housekeeping] += M16(BUFLEN + 1);
      MemUsed[genetree] += M16(MAXTREELEN + 1);
   }
   tree[0] = 0;
   int length = 0;

   while(fgets(buf, BUFLEN, gtf)) {
      ++line;
      RemoveTreeComments(buf);
      if(length + strlen(buf) >= MAXTREELEN) {
         CON( printf("GTR: Gene tree '%s' storage exceeded in line %d.\n",
            filename, line); )
         LOG( fprintf(Log, "GTR: Gene tree '%s' storage exceeded in line %d.\n",
            filename, line); )
         return false;
      }
      strcpy(tree + length, buf);
      length += (int)strlen(buf);
      if(tree[length - 1] == ';')
         break;                     // Completely read tree
   }

   if(ferror(gtf)) {
      CON( printf("GTR: Genes tree file '%s' I/O error.\n", filename); )
      LOG( fprintf(Log, "GTR: Genes tree file '%s' I/O error.\n", filename); )
      return NULL;
   }

   free(buf);
   if(MemoryCount) {
      MemUsed[housekeeping] -= M16(BUFLEN + 1);
   }
   return tree;
}

// Print gene tree in parenthesis format
void     PrintGtree(EDGE* node, FILE* file, TREEMODE *mode) {
   if( !mode->enable ) return;
   if( !node->parent && mode->heading )
      fprintf(file, "[%d]  ", Treeno);
   if( !node->nchildren ) {                  // leaf case
      if(mode->label_leaf)
         fprintf(file, "%s", mode->full_labels ? node->name :
            FindKey(node->specno));
      else if(mode->number_leaf)
         fprintf(file, "%d", node->edgeno);
      if(mode->length_leaf)
         fprintf(file, ":%g", node->weight);
   }
   else {                                    // interior node
      fprintf(file, "(");
      EDGE* daughter = node->child;
      while(daughter) {
         PrintGtree(daughter, file, mode);
         if(daughter->sibling)
            fprintf(file, ",");
         daughter = daughter->sibling;
      }

      fprintf(file, ")");
      if( !node->parent ) {                     // root case
         if(mode->label_root)
            fprintf(file, "%s", node->name);
         else if(mode->number_root)
            fprintf(file, "%d", node->edgeno);
         if(mode->length_root)
            fprintf(file, ":%g", node->weight);
      }
      else {                                    // general case
         if(mode->label_inner)
            fprintf(file, "%s", node->name);
         else if(mode->number_inner)
            fprintf(file, "%d", node->edgeno);
         if(mode->length_inner)
            fprintf(file, ":%g", node->weight);
      }
   }
}

// Fill level values across gene tree
void     FillGtreeLevels(GTREE* gtree, EDGE* node) {
   if(node->child) {
      node->child->level = node->level + 1;
      FillGtreeLevels(gtree, node->child);
   }
   else {      // remember max level
      if(node->level > Gtree->nlevels)
         Gtree->nlevels = node->level;
   }
   if(node->sibling) {
      node->sibling->level   = node->level;
      FillGtreeLevels(gtree, node->sibling);
   }
}

// Traverse gene tree filling levels
void     FillLevels(GTREE *gtree, EDGE* node) {
   LEVEL* lvl = gtree->levels + node->level;
   lvl->edges[lvl->nedges++] = node;
   if(node->child)
      FillLevels(gtree, node->child);
   if(node->sibling)
      FillLevels(gtree, node->sibling);
}

// Fill common sequence of all edges & allocate their corteges
void     GtreeCortege(GTREE* gtree) {
   gtree->edges = (EDGE**)malloc((gtree->nedges + 1) * sizeof(EDGE*));
   if( !gtree->edges )
      goto Error;
   if(MemoryCount)
      MemUsed[genetree] += M16((gtree->nedges + 1)*sizeof(EDGE*));

   gtree->edges[0] = NULL;    // Reserve first entry to number edges from 1
   for(int n = 1, k = gtree->nlevels - 1; k >= 0 ; --k) {    // loop over levels
      for(int i = 0; i < gtree->levels[k].nedges; i++) {  // across level
         EDGE* tmp = gtree->levels[k].edges[i];
         tmp->edgeno = n;
         gtree->edges[n++] = tmp;
         // Allocate ntubes*MaxEvents cortege of this edge
         tmp->events = (EVENT**)malloc((Stree->ntubes + 1) * sizeof(EVENT*));
         if( !tmp->events )
            goto Error;
         if(MemoryCount)
            MemUsed[genetree] += M16((Stree->ntubes + 1) * sizeof(EVENT*));

         tmp->events[0] = NULL;     // since tube numbers start from 1
         for(int j = 1; j <= Stree->ntubes; j++) {
            tmp->events[j] = (EVENT*)malloc(MaxEvents * sizeof(EVENT));
            if( !tmp->events[j] )
               goto Error;
            if(MemoryCount)
               MemUsed[genetree] += M16(MaxEvents * sizeof(EVENT));

            EVENT* evt = tmp->events[j];     // initialize event
            for(int k = 0; k < MaxEvents; k++,evt++) {
               evt->id     = id_none;
               evt->cost   = -1;    //(int)SCALE;
               evt->d1 = evt->d2 = 0;
            }
         }
      }
   }
   return;
Error:
   CON( printf("GTC%d: Not enough memory.\n", Treeno); )
   LOG( fprintf(Log, "GTC%d: Not enough memory.\n", Treeno); )
   #ifdef   EMBED3MPI
   if(embed3_mpi)
      MPI::COMM_WORLD.Abort(1);
   else
   #endif
   exit(1);
}
   
// Return true if gene tree has been read correctly
#ifdef __GNUC__
#pragma warning(disable: 589)
#endif
bool     ReadGeneTree(char* filename) {
   double weight = 1.0;
   char* tree = NULL;
   int   specno   = 0;        // species number
   char* etok     = NULL;     // end of current token
   char  name[MAXNODENAME] = { "" };

   EDGE* parent   = NULL;     // current parent =pair of () 
   EDGE* edge     = NULL;     // current edge to fill data
   LEVEL* lvl     = NULL;

#ifdef   EMBED3MPI
   while(1) {
#endif
      if( !gtf ) {
         if( !OpenGeneTree(filename) )
            goto Error;
      }
      else if(feof(gtf)) {
         fclose(gtf);
         gtf   = NULL;
         line  = 0;
         Gtree = NULL;     // report EOF to caller
         return true;
      }

      tree = ReadGtreeString(filename);
      if( !tree )    goto Error;
      if(*tree == 0) { 
         fclose(gtf);
         gtf   = NULL;
         line  = 0;
         Gtree = NULL; 
         goto OK; 
      }
#ifdef   EMBED3MPI
      if(Treeno++ % size_mpi == rank_mpi)
         break;
   }
#else
   Treeno++;
#endif
   //DBG( printf("\n[%d] %s\n\n", Treeno, tree); )
   //DBG( LOG( fprintf(Log, "\n[%d] %s\n\n", Treeno, tree); ) )

   // Establish gene tree
   Gtree = (GTREE*)malloc(sizeof(GTREE));
   edge  = (EDGE*) malloc(sizeof(EDGE));
   if( !edge || !Gtree ) {
      CON( printf("GTR%d: Not enough memory.\n", Treeno); )
      LOG( fprintf(Log, "GTR%d: Not enough memory.\n", Treeno); )
      goto Error;
   }
   if(MemoryCount) {
      MemUsed[genetree] += M16(sizeof(GTREE));
      MemUsed[genetree] += M16(sizeof(EDGE));
   }

   Gtree->root    = edge;
   Gtree->nlevels = 0;
   Gtree->nleaves = Gtree->ninteriors = Gtree->nedges = 0;
   Gtree->nTmarks = 0;
   Gtree->npolytom = Gtree->polytomy = 0;
   Gtree->levels  = NULL;
   Gtree->edges   = NULL;

   edge->edgeno   = 0;
   edge->parent   = NULL;
   edge->child    = NULL;
   edge->sibling  = NULL;
   edge->nchildren = 0;
   edge->level    = 0;
   edge->specno   = 0;
   edge->Tmark    = 0;
   edge->weight   = 1.0;
   memset(edge->name, 0, MAXNODENAME);
   edge->events   = NULL;

   // Parse tree loop
   for(char* p = tree; *p; p++) {   

      if(*p == ';') {         // ';' found - end of tree

         if(!edge || parent) {
            CON( printf("GTR%d: Symbol ';' prematurely encountered.\n", Treeno); )
            LOG( fprintf(Log, "GTR%d: Symbol ';' prematurely encountered.\n", Treeno); )
            goto Error;
         }
         if(*name != 0)
            strncpy(edge->name, name, MAXNODENAME-1);
         else
            sprintf(edge->name, "r");
         edge->specno = 0;
         edge->weight = weight > 0 ? weight : 1.0;
         break;
      }

      else if(*p == '(') {    // '(' found - push parent

         if(*name != 0) {
            CON( printf("GTR%d: No delimiter after token before '('.\n", Treeno); )
            LOG( fprintf(Log, "GTR%d: No delimiter after token before '('.\n", Treeno); )
            goto Error;
         }

         parent = edge;             // push

         edge = (EDGE*)malloc(sizeof(EDGE));
         if( !edge ) {
            CON( printf("GTR%d: Not enough memory.\n", Treeno); )
            LOG( fprintf(Log, "GTR%d: Not enough memory.\n", Treeno); )
            goto Error;
         }
         if(MemoryCount) {
            MemUsed[genetree] += M16(sizeof(EDGE));
         }
         edge->edgeno   = 0;
         edge->parent   = parent;
         edge->child    = NULL;
         edge->sibling  = NULL;
         edge->nchildren = 0;
         edge->level    = -1;
         edge->specno   = 0;
         edge->Tmark    = 0;
         edge->weight   = 1.0;
         memset(edge->name, 0, MAXNODENAME);
         edge->events   = NULL;

         parent->child     = edge;
         parent->nchildren = 1;
      }

      else if(*p == ')') {    // ')' found - pop parent

         if(*name) {
            strncpy(edge->name, name, MAXNODENAME-1);
            edge->specno = specno;
            *name = 0;
         }
         edge->weight = weight > 0 ? weight : 1.0;
         weight = 1.0;
         
         edge = parent;             // pop
         parent = edge->parent;
      }

      else if(*p == ',') {    // ',' found - add sibling

         if(*name) {
            strncpy(edge->name, name, MAXNODENAME-1);
            edge->specno = specno;
            *name = 0;
         }
         edge->weight = weight > 0 ? weight : 1.0;
         weight = 1.0;
         
         EDGE* left = edge;           // add sibling
         edge = (EDGE*)malloc(sizeof(EDGE));
         if( !edge ) {
            CON( printf("GTR%d: Not enough memory.\n", Treeno); )
            LOG( fprintf(Log, "GTR%d: Not enough memory.\n", Treeno); )
            goto Error;
         }
         if(MemoryCount) {
            MemUsed[genetree] += M16(sizeof(EDGE));
         }
         edge->edgeno   = 0;
         edge->parent   = parent;
         edge->child    = NULL;
         edge->sibling  = NULL;
         edge->nchildren = 0;
         edge->level    = -1;
         edge->specno   = 0;
         edge->Tmark    = 0;
         edge->weight   = 1.0;
         memset(edge->name, 0, MAXNODENAME);
         edge->events   = NULL;

         left->sibling  = edge;
         if(++parent->nchildren == 3) {   // only first time when > 2
            ++Gtree->npolytom;
         }
         if(parent->nchildren > Gtree->polytomy)
            Gtree->polytomy = parent->nchildren;
      }
      else {                  // token found - process

         // Find end of token
         etok = strpbrk(p, ";(),:");
         if( !etok ) {
            CON( printf("GTR%d: End of tree not found.\n", Treeno); )
            LOG( fprintf(Log, "GTR%d: End of tree not found.\n", Treeno); )
            goto Error;
         }

         // Count necessary words
         int nwords = 0;
         char* q;
         for(q = p; q != etok; ++q) {
            if((*q == '_' || *q == TmarkChar || *q == StopLabel) && ++nwords >= LeafMaxWords)
               break;
         }
         if(q == etok)
            nwords++;
         if(nwords < LeafMinWords) {
            CON( printf("GTR%d: Too few words in a name.\n", Treeno); )
            LOG( fprintf(Log, "GTR%d: Too few words in a name.\n", Treeno); )
            goto Error;
         }

         // Check species name versus the table
         if(q == p)
            name[0] = 0;
         else if(q - p >= MAXNODENAME) {
            CON( printf("GTR%d: Max length of species name exceeded.\n", Treeno); )
            LOG( fprintf(Log, "GTR%d: Max length of species name exceeded.\n", Treeno); )
            goto Error;
         }
         else {
            memcpy(name, p, q - p);
            name[q - p] = 0;
         }
         specno = FindSpecies(name);

         // Store full name in gene tree leaves
         if(q != etok) {
            if(etok == p)
               name[0] = 0;
            else if(etok - p >= MAXNODENAME) {
               CON( printf("GTR%d: Max length of species name exceeded.\n", Treeno); )
               LOG( fprintf(Log, "GTR%d: Max length of species name exceeded.\n", Treeno); )
               goto Error;
            }
            else {
               if(TmarkChar) {               // Check Tmark:
                  if(TmarkAnywhere) {        //  at any position
                     char* mp = strchr(p, TmarkChar);
                     if(mp && mp < etok) {
                        edge->Tmark = TmarkChar;
                        if( !TmarkShow ) {
                           memcpy(name, p, mp - p);
                           memcpy(name + (mp - p), mp + 1, etok - mp + 1);
                           name[etok - p - 1] = 0;
                        }
                        else {
                           memcpy(name, p, etok - p);
                           name[etok - p] = 0;
                        }
                     }
                     else {
                        memcpy(name, p, etok - p);
                        name[etok - p] = 0;
                     }
                  }
                  else {                     //  only in the end
                     if(*(etok - 1) == TmarkChar) {
                        edge->Tmark = TmarkChar;
                        if( !TmarkShow ) {
                           memcpy(name, p, etok - p - 1);
                           name[etok - p - 1] = 0;
                        }
                        else {
                           memcpy(name, p, etok - p);
                           name[etok - p] = 0;
                        }
                     }
                  }
               }
               else {
                  memcpy(name, p, etok - p);
                  name[etok - p] = 0;
               }
            }
         }
         
         if(*etok == ':') {
            weight = atof(etok+1);     // use the length value as a weight
            etok = strpbrk(etok, ";(),");
            if( !etok ) {
               CON( printf("GTR%d: End of tree not found.\n", Treeno); )
               LOG( fprintf(Log, "GTR%d: End of tree not found.\n", Treeno); )
               goto Error;
            }
         }
         p = etok - 1;     // position to continue
      }
   }

   // Fill levels of gene tree
   FillGtreeLevels(Gtree, Gtree->root);
   ++Gtree->nlevels;       // because levels are 0-based
   // Form table of levels
   Gtree->levels = (LEVEL*)malloc( Gtree->nlevels * sizeof(LEVEL) );
   if( !Gtree->levels ) {
      CON( printf("GTR%d: Not enough memory.\n", Treeno); )
      LOG( fprintf(Log, "GTR%d: Not enough memory.\n", Treeno); )
      goto Error;
   }
   if(MemoryCount) {
      MemUsed[genetree] += M16(Gtree->nlevels * sizeof(LEVEL));
   }
   // Clear nedges & initially allocate levels
   lvl = Gtree->levels;
   for(int n = 0; n < Gtree->nlevels; n++,lvl++) {
      lvl->nedges = 0;
      lvl->edges = (EDGE**)malloc(MAXGENES * sizeof(EDGE*));
      if( !lvl->edges ) {
         CON( printf("GTR%d: Not enough memory.\n", Treeno); )
         LOG( fprintf(Log, "GTR%d: Not enough memory.\n", Treeno); )
         goto Error;
      }
      if(MemoryCount) {
         MemUsed[genetree] += M16(MAXGENES * sizeof(EDGE*));
      }
      for(int j = 0; j < MAXGENES; j++) lvl->edges[j] = NULL;
   }

   FillLevels(Gtree, Gtree->root);      // Fill levels

   // Finalize levels and counters of gene tree
   lvl = Gtree->levels;
   for(int n = 0; n < Gtree->nlevels; n++,lvl++) {
      lvl->edges = (EDGE**)realloc(lvl->edges, lvl->nedges * sizeof(EDGE*));
      if( !lvl->edges ) {
         CON( printf("GTR%d: Not enough memory.\n", Treeno); )
         LOG( fprintf(Log, "GTR%d: Not enough memory.\n", Treeno); )
         goto Error;
      }
      if(MemoryCount) {
         MemUsed[genetree] -= M16((MAXGENES - lvl->nedges) * sizeof(EDGE*));
      }
      Gtree->nedges += lvl->nedges;
      for(int i = 0; i < lvl->nedges; i++) {
         if(lvl->edges[i]->nchildren)
            ++Gtree->ninteriors;
         else {
            ++Gtree->nleaves;
            if(lvl->edges[i]->Tmark) 
               ++Gtree->nTmarks;
         }
      }
   }

   // Expand Tmarking upward
   char TmarkStr[2];
   TmarkStr[0] = TmarkChar;
   TmarkStr[1] = 0;
   if(TmarkChar) {
      lvl = Gtree->levels + Gtree->nlevels - 1;
      for(int n = Gtree->nlevels - 1; n >= 0; n--,lvl--) {
         for(int j = 0; j < lvl->nedges; j++) {
            EDGE* current  = lvl->edges[j];
            EDGE* child    = current->child;
            if(!child) continue;
            while(child) {
               if(child->Tmark != TmarkChar)
                  break;
               child = child->sibling;
            }
            if(!child) {
               current->Tmark = TmarkChar;
               strcat(current->name, TmarkStr);
            }
         }
      }
   }

   GtreeCortege(Gtree);

   DBG( bool ben = GtreeMode.enable; GtreeMode.enable = true; )
   DBG( printf("\n"); )
   DBG( PrintGtree(Gtree->root, stdout, &GtreeMode); )
   DBG( printf(";\n"); )
   DBG( GtreeMode.enable = ben; )

   if(GtreeMode.enable && Log) {
      fprintf(Log, "\n");
      PrintGtree(Gtree->root, Log, &GtreeMode);
      fprintf(Log, ";\n");
   }

OK:
   if(tree) {
      free(tree);
      if(MemoryCount)
         MemUsed[freedmem] += M16(MAXTREELEN + 1);
   }
   return true;
Error:
   return false;
}

// Read basis tree, fill species table and return true if OK
bool     ReadBasisTree(char* filename) {
   double weight = 1.0;
   char* tree = NULL;
   int   specno   = 0;        // species number
   char* etok     = NULL;     // end of current token
   char  name[MAXNODENAME] = { "" };

   EDGE* parent   = NULL;     // current parent =pair of () 
   EDGE* edge     = NULL;     // current edge to fill data
   LEVEL* lvl     = NULL;

   if( !gtf ) {
      if( !OpenGeneTree(filename) )
         goto Error;
   }
   else if(feof(gtf)) {
      fclose(gtf);
      gtf   = NULL;
      line  = 0;
      Gtree = NULL;     // report EOF to caller
      return true;
   }

   tree = ReadGtreeString(filename);
   if( !tree )    goto Error;
   if(*tree == 0) { 
      fclose(gtf);
      gtf   = NULL;
      line  = 0;
      Gtree = NULL; 
      goto OK; 
   }

   if(Treeno >= nBtrees) {     // Expand Btree
      nBtrees += BTREEPART;
      Btree    = (GTREE**) realloc(Btree,   nBtrees * sizeof(GTREE*));
      if( !Btree ) {
         CON( printf("BTR%d: Not enough memory.\n", Treeno); )
         LOG( fprintf(Log, "BTR%d: Not enough memory.\n", Treeno); )
         goto Error;
      }
      if(MemoryCount)
         MemUsed[genetree] += M16( (sizeof(GTREE*)+sizeof(double)) * BTREEPART);
   }

   Treeno++;
   if(Milestones && Treeno % Milestones == 0)
      CON( printf("BT%6d\r", Treeno); )
   DBG( printf("[%d] %s\n", Treeno, tree); )
   DBG( LOG( fprintf(Log, "[%d] %s\n", Treeno, tree); ) )

   // Establish Gtree and store into Btree[Treeno-1]
   Gtree = (GTREE*)malloc(sizeof(GTREE));
   edge  = (EDGE*) malloc(sizeof(EDGE));
   if( !edge || !Gtree ) {
      CON( printf("GTR%d: Not enough memory.\n", Treeno); )
      LOG( fprintf(Log, "GTR%d: Not enough memory.\n", Treeno); )
      goto Error;
   }
   if(MemoryCount) {
      MemUsed[genetree] += M16(sizeof(GTREE));
      MemUsed[genetree] += M16(sizeof(EDGE));
   }

   Gtree->root    = edge;
   Gtree->nlevels = 0;
   Gtree->nleaves = Gtree->ninteriors = Gtree->nedges = 0;
   Gtree->nTmarks = 0;
   Gtree->npolytom = Gtree->polytomy = 0;
   Gtree->levels  = NULL;
   Gtree->edges   = NULL;

   edge->edgeno   = 0;
   edge->parent   = NULL;
   edge->child    = NULL;
   edge->sibling  = NULL;
   edge->nchildren = 0;
   edge->level    = 0;
   edge->specno   = 0;
   edge->Tmark    = 0;
   edge->weight   = 1.0;
   memset(edge->name, 0, MAXNODENAME);
   edge->events   = NULL;

   // Parse tree loop
   for(char* p = tree; *p; p++) {   

      if(*p == ';') {         // ';' found - end of tree

         if(!edge || parent) {
            CON( printf("BTR%d: Symbol ';' prematurely encountered.\n", Treeno); )
            LOG( fprintf(Log, "BTR%d: Symbol ';' prematurely encountered.\n", Treeno); )
            goto Error;
         }
         if(*name != 0) {
            strncpy(edge->name, name, MAXNODENAME-1);
            DeleteSpecies(name);
         }
         else
            sprintf(edge->name, "r");
         edge->specno = 0;
         edge->weight = weight > 0 ? weight : 1.0;
         break;
      }

      else if(*p == '(') {    // '(' found - push parent

         if(*name != 0) {
            CON( printf("BTR%d: No delimiter after token before '('.\n", Treeno); )
            LOG( fprintf(Log, "BTR%d: No delimiter after token before '('.\n", Treeno); )
            goto Error;
         }

         parent = edge;             // push

         edge = (EDGE*)malloc(sizeof(EDGE));
         if( !edge ) {
            CON( printf("BTR%d: Not enough memory.\n", Treeno); )
            LOG( fprintf(Log, "BTR%d: Not enough memory.\n", Treeno); )
            goto Error;
         }
         if(MemoryCount) {
            MemUsed[genetree] += M16(sizeof(EDGE));
         }
         edge->edgeno   = 0;
         edge->parent   = parent;
         edge->child    = NULL;
         edge->sibling  = NULL;
         edge->nchildren = 0;
         edge->level    = -1;
         edge->specno   = 0;
         edge->Tmark    = 0;
         edge->weight   = 1.0;
         memset(edge->name, 0, MAXNODENAME);
         edge->events   = NULL;

         parent->child     = edge;
         parent->nchildren = 1;
      }

      else if(*p == ')') {    // ')' found - pop parent

         if(*name) {
            strncpy(edge->name, name, MAXNODENAME-1);
            edge->specno = specno;
            *name = 0;
         }
         edge->weight = weight > 0 ? weight : 1.0;
         weight = 1.0;
         
         edge = parent;             // pop
         parent = edge->parent;
      }

      else if(*p == ',') {    // ',' found - add sibling

         if(*name) {
            strncpy(edge->name, name, MAXNODENAME-1);
            edge->specno = specno;
            *name = 0;
         }
         edge->weight = weight > 0 ? weight : 1.0;
         weight = 1.0;
         
         EDGE* left = edge;           // add sibling
         edge = (EDGE*)malloc(sizeof(EDGE));
         if( !edge ) {
            CON( printf("BTR%d: Not enough memory.\n", Treeno); )
            LOG( fprintf(Log, "BTR%d: Not enough memory.\n", Treeno); )
            goto Error;
         }
         if(MemoryCount) {
            MemUsed[genetree] += M16(sizeof(EDGE));
         }
         edge->edgeno   = 0;
         edge->parent   = parent;
         edge->child    = NULL;
         edge->sibling  = NULL;
         edge->nchildren = 0;
         edge->level    = -1;
         edge->specno   = 0;
         edge->Tmark    = 0;
         edge->weight   = 1.0;
         memset(edge->name, 0, MAXNODENAME);
         edge->events   = NULL;

         left->sibling  = edge;
         if(++parent->nchildren == 3) {   // only first time when > 2
            ++Gtree->npolytom;
         }
         if(parent->nchildren > Gtree->polytomy)
            Gtree->polytomy = parent->nchildren;
      }
      else {                  // token found - process

         // Find end of token
         etok = strpbrk(p, ";(),:");
         if( !etok ) {
            CON( printf("BTR%d: End of tree not found.\n", Treeno); )
            LOG( fprintf(Log, "BTR%d: End of tree not found.\n", Treeno); )
            goto Error;
         }

         // Count necessary words
         int nwords = 0;
         char* q;
         for(q = p; q != etok; ++q) {
            if((*q == '_' || *q == TmarkChar) && ++nwords >= LeafMaxWords)
               break;
         }
         if(q == etok)
            nwords++;
         if(nwords < LeafMinWords) {
            CON( printf("BTR%d: Too few words in a name.\n", Treeno); )
            LOG( fprintf(Log, "BTR%d: Too few words in a name.\n", Treeno); )
            goto Error;
         }

         // Check species name versus the table
         if(q == p)
            name[0] = 0;
         else if(q - p >= MAXNODENAME) {
            CON( printf("BTR%d: Max length of species name exceeded.\n", Treeno); )
            LOG( fprintf(Log, "BTR%d: Max length of species name exceeded.\n", Treeno); )
            goto Error;
         }
         else {
            memcpy(name, p, q - p);
            name[q - p] = 0;
         }
         if(name[0]) {
            specno = FindSpecies(name);
            if(specno == 0) {
               specno = GetSpeciesCount() + 1;
               InsertSpecies(name, specno);
            }
         }

         // Store full name in gene tree leaves
         if(q != etok) {
            if(etok == p)
               name[0] = 0;
            else if(etok - p >= MAXNODENAME) {
               CON( printf("BTR%d: Max length of species name exceeded.\n", Treeno); )
               LOG( fprintf(Log, "BTR%d: Max length of species name exceeded.\n", Treeno); )
               goto Error;
            }
            else {
               if(TmarkChar) {               // Check Tmark:
                  if(TmarkAnywhere) {        //  at any position
                     char* mp = strchr(p, TmarkChar);
                     if(mp && mp < etok) {
                        edge->Tmark = TmarkChar;
                        if( !TmarkShow ) {
                           memcpy(name, p, mp - p);
                           memcpy(name + (mp - p), mp + 1, etok - mp + 1);
                           name[etok - p - 1] = 0;
                        }
                        else {
                           memcpy(name, p, etok - p);
                           name[etok - p] = 0;
                        }
                     }
                     else {
                        memcpy(name, p, etok - p);
                        name[etok - p] = 0;
                     }
                  }
                  else {                     //  only in the end
                     if(*(etok - 1) == TmarkChar) {
                        edge->Tmark = TmarkChar;
                        if( !TmarkShow ) {
                           memcpy(name, p, etok - p - 1);
                           name[etok - p - 1] = 0;
                        }
                        else {
                           memcpy(name, p, etok - p);
                           name[etok - p] = 0;
                        }
                     }
                  }
               }
               else {
                  memcpy(name, p, etok - p);
                  name[etok - p] = 0;
               }
            }
         }
         
         if(*etok == ':') {
            weight = atof(etok+1);     // use the length value as a weight
            etok = strpbrk(etok, ";(),");
            if( !etok ) {
               CON( printf("BTR%d: End of tree not found.\n", Treeno); )
               LOG( fprintf(Log, "BTR%d: End of tree not found.\n", Treeno); )
               goto Error;
            }
         }
         p = etok - 1;     // position to continue
      }
   }

   // Fill levels of gene tree
   FillGtreeLevels(Gtree, Gtree->root);
   ++Gtree->nlevels;       // because levels are 0-based
   // Form table of levels
   Gtree->levels = (LEVEL*)malloc( Gtree->nlevels * sizeof(LEVEL) );
   if( !Gtree->levels ) {
      CON( printf("BTR%d: Not enough memory.\n", Treeno); )
      LOG( fprintf(Log, "BTR%d: Not enough memory.\n", Treeno); )
      goto Error;
   }
   if(MemoryCount) {
      MemUsed[genetree] += M16(Gtree->nlevels * sizeof(LEVEL));
   }
   // Clear nedges & initially allocate levels
   lvl = Gtree->levels;
   for(int n = 0; n < Gtree->nlevels; n++,lvl++) {
      lvl->nedges = 0;
      lvl->edges = (EDGE**)malloc(MAXGENES * sizeof(EDGE*));
      if( !lvl->edges ) {
         CON( printf("BTR%d: Not enough memory.\n", Treeno); )
         LOG( fprintf(Log, "BTR%d: Not enough memory.\n", Treeno); )
         goto Error;
      }
      if(MemoryCount) {
         MemUsed[genetree] += M16(MAXGENES * sizeof(EDGE*));
      }
      for(int j = 0; j < MAXGENES; j++) lvl->edges[j] = NULL;
   }

   FillLevels(Gtree, Gtree->root);      // Fill levels

   // Finalize levels and counters of gene tree
   lvl = Gtree->levels;
   for(int n = 0; n < Gtree->nlevels; n++,lvl++) {
      lvl->edges = (EDGE**)realloc(lvl->edges, lvl->nedges * sizeof(EDGE*));
      if( !lvl->edges ) {
         CON( printf("BTR%d: Not enough memory.\n", Treeno); )
         LOG( fprintf(Log, "BTR%d: Not enough memory.\n", Treeno); )
         goto Error;
      }
      if(MemoryCount) {
         MemUsed[genetree] -= M16((MAXGENES - lvl->nedges) * sizeof(EDGE*));
      }
      Gtree->nedges += lvl->nedges;
      for(int i = 0; i < lvl->nedges; i++) {
         if(lvl->edges[i]->nchildren)
            ++Gtree->ninteriors;
         else 
            ++Gtree->nleaves;
      }
   }

   // Fill common sequence of all edges & allocate their corteges
   Gtree->edges = (EDGE**)malloc((Gtree->nedges + 1) * sizeof(EDGE*));
   if( !Gtree->edges ) {
      CON( printf("BTR%d: Not enough memory.\n", Treeno); )
      LOG( fprintf(Log, "BTR%d: Not enough memory.\n", Treeno); )
      goto Error;
   }
   if(MemoryCount) {
      MemUsed[genetree] += M16((Gtree->nedges + 1)*sizeof(EDGE*));
   }
   Gtree->edges[0] = NULL;    // Reserve first entry to number edges from 1
   for(int n = 1, k = Gtree->nlevels - 1; k >= 0 ; --k) {    // loop over levels
      for(int i = 0; i < Gtree->levels[k].nedges; i++) {       // across level
         EDGE* tmp = Gtree->levels[k].edges[i];
         tmp->edgeno = n;
         Gtree->edges[n++] = tmp;
      }
   }

   Btree[Treeno-1]   = Gtree;

   DBG( PrintGtree(Gtree->root, stdout, &GtreeMode); )
   DBG( if(GtreeMode.enable) printf(";\n\n"); )

   if(GtreeMode.enable && Log) {
      PrintGtree(Gtree->root, Log, &GtreeMode);
      fprintf(Log, ";\n\n");
   }

OK:
   if(tree) {
      free(tree);
      if(MemoryCount) 
         MemUsed[freedmem] += M16(MAXTREELEN + 1);
   }
   return true;
Error:
   return false;
}
