// embed3GL: A program for phylogenetic study of joint gene & species evolution.
//
// The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/embed3gl]
//
// (C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
// E-mail: rubanov{at}iitp.ru
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// Functions: CalcDistance, FillTubeDistances, TubeDistance

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "embed3gl.h"

static int  **distance = NULL;
static int  dim        = 0;

// Calculate tree distance between given tubes
// Return -1 at errors
int      CalcDistance(int d1, int d2) {
   if(d1 == d2)   return 0;
   TUBE* t1 = Stree->tubes[d1];
   TUBE* t2 = Stree->tubes[d2];
   int   d  = 0;
   int   h1 = t1->height;
   int   h2 = t2->height;
   while(h1 < h2) {       // lift d1 to d2's level
      if( !t1 )   return -1;
      t1 = t1->parent;
      ++h1;
      ++d;
   }
   while(h1 > h2) {       // lift d2 to d1's level
      if( !t2 )   return -1;
      t2 = t2->parent;
      ++h2;
      ++d;
   }
   while(t1 != t2) {
      if( !t1 || !t2 )   return -1;
      t1 = t1->parent;
      t2 = t2->parent;
      d += 2;
   }
   return d;
}

// Fill table of pairwise distances between tubes in species tree.
// Return false at errors.
bool     FillTubeDistances(void) {
   assert(Stree);
   // Free old distance table if exists
   if(distance) {
      for(int i = 0; i < dim; ++i) {
         if(distance[i]) {
            free(distance[i]);
            if(MemoryCount)
               MemUsed[freedmem] += M16(dim * sizeof(int));
         }
      }
      free(distance);
      if(MemoryCount)
         MemUsed[freedmem] += M16(dim * sizeof(int*));
   }

   dim = Stree->ntubes;

   // Allocate and initialize 2D table
   distance = (int**)malloc(dim * sizeof(int*));
   if( !distance ) {
      CON( printf("DST: Not enough memory for table of distances.\n"); )
      LOG( fprintf(Log, "DST: Not enough memory for table of distances.\n"); )
      return false;
   }
   if(MemoryCount) {
      MemUsed[housekeeping] += M16(dim * sizeof(int*));
   }
   for(int i = 0; i < dim; ++i) {
      distance[i] = (int*)malloc(dim * sizeof(int));
      if( !distance[i] ) {
         CON( printf("DST: Not enough memory for table of distances.\n"); )
         LOG( fprintf(Log, "DST: Not enough memory for table of distances.\n"); )
         return false;
      }
      if(MemoryCount) {
         MemUsed[housekeeping] += M16(dim * sizeof(int));
      }
      memset(distance[i], 0, dim * sizeof(int));
   }

   // Fill distances
   for(int i = 0; i < dim; ++i) {
      for(int j = i + 1; j < dim; ++j) {
         int d = CalcDistance(i+1, j+1);
         if(d < 0) {
            CON( printf("DST: Inconsistent species tree [%d, %d].\n", 
               i+1, j+1); )
            LOG( fprintf(Log, "DST: Inconsistent species tree [%d, %d].\n", 
               i+1, j+1); )
            return false;
         }
         distance[i][j] = distance[j][i] = d;
      }
   }
   return true;
}

int      TubeDistance(int d1, int d2) {
   assert(distance);
   return   distance[d1-1][d2-1];
}
