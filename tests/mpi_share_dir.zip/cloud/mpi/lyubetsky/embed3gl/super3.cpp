// embed3GL: A program for phylogenetic study of joint gene & species evolution.
//
// The algorithm by K.Gorbunov and V.Lyubetsky [http://lab6.iitp.ru/en/embed3gl]
//
// (C)2013, Lev Rubanov, Institute for Information Transmission Problems RAS
// E-mail: rubanov{at}iitp.ru
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// Functions: LessCost, ClearQueue, Stree2String, MakeDummyStree, CopyGtree, 
//            RemoveEdge, PruneBasisTree, ComputeCost, SelectInitialStree,
//            DeleteStree, CopyStree, HangNewLeaf, AddNewAbove, 
//            MakeInductionStep

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <assert.h>
#include <string>
#include <vector>
#include <queue>
#include <sstream>
#include "embed3gl.h"

using namespace std;

// An entry of the queue of variants
struct VARINS {
   double   C;
   double   R;
   int      cost;
   int      cost2;
   int      specno;     //                    || (init) besta
   int      oldtubeno;  //                    || (init) bestb
   int      ontubeno;   // >0: edge, <0: node || (init) bestc
   string   betree;
};

// This class defines a comparison function for Vqueue
class LessCost {
public:
   bool operator() (VARINS v1, VARINS v2) const {
      if(v1.C == v2.C) {    // collision resolving
         if(v1.cost == v2.cost) {
            if(v1.cost == 0) {
               if(v1.cost2 < v2.cost2)
                  return true;
               if(v1.cost2 > v2.cost2)
                  return false;
            }
            if(v1.specno == v2.specno) {
               if(v1.oldtubeno == v2.oldtubeno) {
                  if(v1.ontubeno < 0 && v2.ontubeno < 0 ||
                     v1.ontubeno > 0 && v2.ontubeno > 0)
                     return (abs(v1.ontubeno) > abs(v2.ontubeno));
                  else
                     return (v1.ontubeno > v2.ontubeno);
               }
               else
                  return (v1.oldtubeno > v2.oldtubeno);
            }
            else
               return (v1.specno > v2.specno);
         }
         else 
            return (v1.cost > v2.cost);
      }
      else 
         return (v1.C > v2.C);
   }
};

priority_queue <VARINS, vector<VARINS>, LessCost> Vqueue;

// Clear queue
void ClearQueue(void) {
   while( !Vqueue.empty() )
      Vqueue.pop();
}

// Recursively convert a node subtree into parenthesis format
string   stree2String(TUBE* node, TREEMODE* mode) {
   ostringstream t;
   string s;
   if( !mode->enable ) 
      return t.str();
   if( !node->left && !node->right ) {       // leaf case
      if(mode->label_leaf) {
         if(mode->full_labels)
            s.assign(node->name);
         else if(node->specno)
            s.assign(FindKey(node->specno));
         else
            s.assign(node->name);
         t << s;
      }
      else if(mode->number_leaf)
         t << node->tubeno;
      if(mode->length_leaf)
         t << ":" << node->length;
   }
   else {                                    // interior node
      t << "(";
      if(node->left) {
         t << stree2String(node->left, mode);
         if(node->right) {
            t << ",";
            t << stree2String(node->right, mode);
         }
      }
      else if(node->right) 
         t << stree2String(node->right, mode);

      t << ")";
      if( !node->parent ) {                     // root case
         if(mode->label_root) {
            s.assign(node->name);
            t << s;
         }
         else if(mode->number_root)
            t << node->tubeno;
         if(mode->length_root)
            t << ":" << node->length;
      }
      else {                                    // general case
         if(mode->label_inner) {
            s.assign(node->name);
            t << s;
         }
         else if(mode->number_inner)
            t << node->tubeno;
         if(mode->length_inner)
            t << ":" << node->length;
      }
   }
   return t.str();
}

// Convert a tree into parenthesis format string
string   Stree2String(STREE* tree, TREEMODE* mode) {
   string s;
   s += stree2String(tree->root, mode) + ";";
   return s;
}

// Make dummy Stree with 3 species, outgroup & slices
// (0:3,(1:2,(2,3)6)8)9; = (((0,-)4,-)7,((1,-)5,(2,3)6)8)9;
bool     MakeDummyStree(void) {
   TUBE* tube     = NULL;
   Stree          = (STREE*)malloc(sizeof(STREE));
   TUBE **tubes   = (TUBE**)malloc(11*sizeof(TUBE*));
   SLICE *slices  = (SLICE*)malloc(4*sizeof(SLICE));
   if( !Stree || !tubes || !slices )
      goto Error;
   if(MemoryCount) {
      MemUsed[speciestree] += M16(sizeof(STREE));
      MemUsed[speciestree] += M16(11*sizeof(TUBE*));
      MemUsed[speciestree] += M16(4*sizeof(SLICE));
   }

   // Stree tubes, tube numbers & names
   tubes[0] = NULL;
   for(int n = 1; n <= 10; n++) {
      tubes[n] = (TUBE*)malloc(sizeof(TUBE));
      if(!tubes[n])
         goto Error;
      if(MemoryCount)
         MemUsed[speciestree] += M16(sizeof(TUBE));
      tubes[n]->tubeno = n;
      tubes[n]->length = 1.0;
      memset(tubes[n]->name, 0, MAXNODENAME);
   }

   // Stree
   Stree->root       = tubes[10];
   Stree->height     = 3;
   Stree->nleaves    = 4;
   Stree->ninteriors = 6;
   Stree->ntubes     = 10;
   Stree->noldtubes  = 7;
   Stree->slices     = slices;
   Stree->tubes      = tubes;

   // Stree slices
   for(int i = 0; i <= 3; i++) {
      slices[i].ntubes  = 4 - i;
      slices[i].tubes   = (TUBE**)malloc((4 - i)*sizeof(TUBE*));
      if(!slices[i].tubes)
         goto Error;
      if(MemoryCount)
         MemUsed[speciestree] += M16((i+1)*sizeof(TUBE*));
   }
   slices[0].tubes[0] = tubes[1];
   slices[0].tubes[1] = tubes[2];
   slices[0].tubes[2] = tubes[3];
   slices[0].tubes[3] = tubes[4];
   slices[1].tubes[0] = tubes[5];
   slices[1].tubes[1] = tubes[6];
   slices[1].tubes[2] = tubes[7];
   slices[2].tubes[0] = tubes[8];
   slices[2].tubes[1] = tubes[9];
   slices[3].tubes[0] = tubes[10];

   // Tubes
   tube           = tubes[1];
   tube->parent   = tubes[5];
   tube->left     = NULL;
   tube->right    = NULL;
   tube->oldtube  = tube;
   tube->height   = 0;
   tube->specno   = 0;
   tube->mean     = NULL;
   tube->totmean  = NULL;

   tube           = tubes[2];
   tube->parent   = tubes[6];
   tube->left     = NULL;
   tube->right    = NULL;
   tube->oldtube  = tube;
   tube->height   = 0;
   tube->specno   = 0;
   tube->mean     = NULL;
   tube->totmean  = NULL;

   tube           = tubes[3];
   tube->parent   = tubes[7];
   tube->left     = NULL;
   tube->right    = NULL;
   tube->oldtube  = tube;
   tube->height   = 0;
   tube->specno   = 0;
   tube->mean     = NULL;
   tube->totmean  = NULL;

   tube           = tubes[4];
   tube->parent   = tubes[7];
   tube->left     = NULL;
   tube->right    = NULL;
   tube->oldtube  = tube;
   tube->height   = 0;
   tube->specno   = 0;
   tube->mean     = NULL;
   tube->totmean  = NULL;

   tube           = tubes[5];
   tube->parent   = tubes[8];
   tube->left     = tubes[1];
   tube->right    = NULL;
   tube->oldtube  = tubes[1];
   tube->height   = 1;
   tube->specno   = 0;
   tube->mean     = NULL;
   tube->totmean  = NULL;

   tube           = tubes[6];
   tube->parent   = tubes[9];
   tube->left     = tubes[2];
   tube->right    = NULL;
   tube->oldtube  = tubes[2];
   tube->height   = 1;
   tube->specno   = 0;
   tube->mean     = NULL;
   tube->totmean  = NULL;

   tube           = tubes[7];
   tube->parent   = tubes[9];
   tube->left     = tubes[3];
   tube->right    = tubes[4];
   tube->oldtube  = tube;
   tube->height   = 1;
   tube->specno   = 0;
   tube->mean     = NULL;
   tube->totmean  = NULL;

   tube           = tubes[8];
   tube->parent   = tubes[10];
   tube->left     = tubes[5];
   tube->right    = NULL;
   tube->oldtube  = tubes[1];
   tube->height   = 2;
   tube->specno   = 0;
   tube->mean     = NULL;
   tube->totmean  = NULL;

   tube           = tubes[9];
   tube->parent   = tubes[10];
   tube->left     = tubes[6];
   tube->right    = tubes[7];
   tube->oldtube  = tube;
   tube->height   = 2;
   tube->specno   = 0;
   tube->mean     = NULL;
   tube->totmean  = NULL;

   tube           = tubes[10];
   tube->parent   = NULL;
   tube->left     = tubes[8];
   tube->right    = tubes[9];
   tube->oldtube  = tube;
   tube->height   = 3;
   tube->specno   = 0;
   tube->mean     = NULL;
   tube->totmean  = NULL;

   strncpy(tubes[1]->name, OutgroupName, MAXNODENAME);

   return true;
Error:
   CON( printf("CGT: Not enough memory.\n"); )
   LOG( fprintf(Log, "CGT: Not enough memory.\n"); )
   return false;
}

// Recursive traversal copy of corresponding edges
void     copyGtree(EDGE* my, EDGE* bt) {
   if(bt->child) {
      EDGE* child = (EDGE*)malloc(sizeof(EDGE));
      if( !child )
         goto Error;
      if(MemoryCount) 
         MemUsed[genetree] += M16(sizeof(EDGE));
      memcpy(child, bt->child, sizeof(EDGE));
      child->parent  = my;
      my->child      = child;
      copyGtree(child, bt->child);
   }
   if(bt->sibling) {
      EDGE* sibling = (EDGE*)malloc(sizeof(EDGE));
      if( !sibling )
         goto Error;
      if(MemoryCount) 
         MemUsed[genetree] += M16(sizeof(EDGE));
      memcpy(sibling, bt->sibling, sizeof(EDGE));
      sibling->parent   = my->parent;
      my->sibling       = sibling;
      copyGtree(sibling, bt->sibling);
   }
   return;

Error:
   CON( printf("CGT: Not enough memory.\n"); )
   LOG( fprintf(Log, "CGT: Not enough memory.\n"); )
   #ifdef   EMBED3MPI
   if(embed3_mpi)
      MPI::COMM_WORLD.Abort(1);
   else
   #endif
   exit(1);
}

// Create and return a copy of given gene tree (excl. *edges array)
GTREE*   CopyGtree(GTREE* gtree) {
   LEVEL* lvl = NULL;
   LEVEL* gtl = NULL;
   GTREE* mytree = (GTREE*)malloc(sizeof(GTREE));
   EDGE*  edge   = (EDGE*)malloc(sizeof(EDGE));
   if( !mytree || !edge )
      goto Error;
   if(MemoryCount) {
      MemUsed[genetree] += M16(sizeof(GTREE));
      MemUsed[genetree] += M16(sizeof(EDGE));
   }
   memcpy(mytree, gtree, sizeof(GTREE));
   memcpy(edge, gtree->root, sizeof(EDGE));

   mytree->root   = edge;
   copyGtree(edge, gtree->root);

   // Form table of levels
   mytree->levels = (LEVEL*)malloc( gtree->nlevels * sizeof(LEVEL) );
   if( !mytree->levels )
      goto Error;
   if(MemoryCount)
      MemUsed[genetree] += M16(Gtree->nlevels * sizeof(LEVEL));

   // Allocate levels and clear counters
   lvl = mytree->levels;
   gtl = gtree->levels;
   for(int n = 0; n < mytree->nlevels; n++,lvl++,gtl++) {
      lvl->edges = (EDGE**)malloc(gtl->nedges * sizeof(EDGE*));
      if( !lvl->edges )
         goto Error;
      if(MemoryCount)
         MemUsed[genetree] += M16(gtl->nedges * sizeof(EDGE*));
      lvl->nedges = 0;
   }

   FillLevels(mytree, mytree->root);      // Fill levels
   mytree->edges = NULL;
   return mytree;

Error:
   CON( printf("CGT%d: Not enough memory.\n", Treeno); )
   LOG( fprintf(Log, "CGT%d: Not enough memory.\n", Treeno); )
   #ifdef   EMBED3MPI
   if(embed3_mpi) {
      MPI::COMM_WORLD.Abort(1);
      return NULL;
   }
   else
   #endif
   exit(1);
}

// Remove edge lifting up its subtree
void     RemoveEdge(GTREE* gtree, EDGE* edge) {
   EDGE* parent   = edge->parent;
   EDGE* child    = edge->child;
   EDGE* sibling  = edge->sibling;
   if(!gtree || !edge)
      return;
   // Find last sibling if any
   EDGE* lastsib  = NULL;     
   if(parent) {
      EDGE* ch = parent->child;
      while(ch) {
         if(ch == edge)
            break;
         if(ch->sibling == edge) {
            lastsib = ch;
            break;
         }
         ch = ch->sibling;
      }
      parent->nchildren += edge->nchildren - 1; 
   }
   else {
      if(sibling || child && child->sibling) {
         CON( printf("RED: Tree splitting in the root - internal error.\n"); )
         LOG( fprintf(Log, "RED: Tree splitting in the root - internal error.\n"); )
         #ifdef   EMBED3MPI
         if(embed3_mpi)
            MPI::COMM_WORLD.Abort(4);
         else
         #endif
         exit(4);
      }
      gtree->root = child;
   }
   if(child) {
      child->parent  = parent;
      if(lastsib)
         lastsib->sibling  = child;
      else if(parent)
         parent->child     = child;
      EDGE* si = child->sibling;
      if( !si )
         child->sibling    = sibling;
      while(si) {
         si->parent  = parent;
         if( !si->sibling ) {
            si->sibling    = sibling;
            break;
         }
         si = si->sibling;
      }
   }
   else {
      if(lastsib)
         lastsib->sibling  = sibling;
      else if(parent)
         parent->child     = sibling;
   }
   // Delete edge
   gtree->nedges --;
   if(edge->specno)
      gtree->nleaves --;
   else
      gtree->ninteriors --;
   if(edge->events) {
      for(int i = 1; i <= Stree->ntubes; i++) {
         if(edge->events[i]) {
            free(edge->events[i]);
            if(MemoryCount)
               MemUsed[freedmem] += M16(MaxEvents * sizeof(EVENT));
         }
      }
      free(edge->events);
      if(MemoryCount)
         MemUsed[freedmem] += M16((Stree->ntubes + 1) * sizeof(EVENT*));
   }
   free(edge);
   if(MemoryCount)
      MemUsed[freedmem] += M16(sizeof(EDGE));
}

// Prune Btree as per enabled Species. Result in Gtree
void     PruneBasisTree(GTREE* btree) {
   if(btree != Gtree)
      Gtree  = CopyGtree(btree);
   int ne = Gtree->nedges;

   for(int k = Gtree->nlevels - 1; k >= 0; k--) {
      for(int i = 0; i < Gtree->levels[k].nedges; i++) {
         EDGE* edge = Gtree->levels[k].edges[i];
         int sp;
         switch(edge->nchildren) {
            case 0:
               sp = edge->specno;
               if(sp == 0 || (ModeSuper3Build && !Species[sp].enable))
                  RemoveEdge(Gtree, edge);
               break;
            case 1:
               RemoveEdge(Gtree, edge);
               break;
            case 2:
               break;
            default:
               CON( printf("PBT: Polytomous node found in the basis tree %d.\n", Treeno); )
               LOG( fprintf(Log, "PBT: Polytomous node found in the basis tree %d.\n", Treeno); )
               #ifdef   EMBED3MPI
               if(embed3_mpi)
                  MPI::COMM_WORLD.Abort(4);
               else
               #endif
               exit(4);
         }
      }
      if(Gtree->levels[k].edges) {
         free(Gtree->levels[k].edges);
         if(MemoryCount)
            MemUsed[freedmem] += M16(Gtree->levels[k].nedges * sizeof(EDGE*));
      }
      Gtree->levels[k].nedges = 0;
   }
   if(Gtree->levels) {
      free(Gtree->levels);
      if(MemoryCount)
         MemUsed[freedmem] += M16(Gtree->nlevels * sizeof(LEVEL));
   }
   if(Gtree->edges) {
      free(Gtree->edges);
      if(MemoryCount) 
         MemUsed[freedmem] += M16(ne * sizeof(EDGE*));
   }
   if(Gtree->nedges == 1)     // Only one root-leaf (enabled species)
      RemoveEdge(Gtree, Gtree->root);
   if(Gtree->nedges == 0) {   // Whole Gtree pruned
      free(Gtree);
      if(MemoryCount)
         MemUsed[freedmem] += M16(sizeof(GTREE));
      Gtree = NULL;
   }
   else {
      Gtree->root->level = 0;
      Gtree->nlevels     = 0;
      FillGtreeLevels(Gtree, Gtree->root);
      ++Gtree->nlevels;       // because levels are 0-based

      // Form table of levels
      Gtree->levels = (LEVEL*)malloc( Gtree->nlevels * sizeof(LEVEL) );
      if( !Gtree->levels )
         goto Error;
      if(MemoryCount)
         MemUsed[genetree] += M16(Gtree->nlevels * sizeof(LEVEL));

      // Clear nedges & initially allocate levels
      LEVEL* lvl = Gtree->levels;
      for(int n = 0; n < Gtree->nlevels; n++,lvl++) {
         lvl->nedges = 0;
         lvl->edges = (EDGE**)malloc(MAXGENES * sizeof(EDGE*));
         if( !lvl->edges )
            goto Error;
         if(MemoryCount)
            MemUsed[genetree] += M16(MAXGENES * sizeof(EDGE*));
         for(int j = 0; j < MAXGENES; j++) lvl->edges[j] = NULL;
      }

      FillLevels(Gtree, Gtree->root);

      // Finalize levels and counters of gene tree
      Gtree->nedges     = 0;
      Gtree->nleaves    = 0;
      Gtree->ninteriors = 0;
      lvl = Gtree->levels;
      for(int n = 0; n < Gtree->nlevels; n++,lvl++) {
         lvl->edges = (EDGE**)realloc(lvl->edges, lvl->nedges * sizeof(EDGE*));
         if( !lvl->edges )
            goto Error;
         if(MemoryCount) 
            MemUsed[genetree] -= M16((MAXGENES - lvl->nedges) * sizeof(EDGE*));

         Gtree->nedges += lvl->nedges;
         for(int i = 0; i < lvl->nedges; i++) {
            if(lvl->edges[i]->nchildren)
               ++Gtree->ninteriors;
            else {
               ++Gtree->nleaves;
               if(lvl->edges[i]->Tmark) 
                  ++Gtree->nTmarks;
            }
         }
      }

      GtreeCortege(Gtree);
   }
   return;
Error:
   CON( printf("PBT%d: Not enough memory.\n", Treeno); )
   LOG( fprintf(Log, "PBT%d: Not enough memory.\n", Treeno); )
   #ifdef   EMBED3MPI
   if(embed3_mpi)
      MPI::COMM_WORLD.Abort(1);
   else
   #endif
   exit(1);
}

// Prepare Gtree and compute the cost of embedding in Stree
int      ComputeCost(void) {
   // Clear old edge->events across Gtree
   for(int n = 1; n <= Gtree->nedges; n++) {
      EDGE* edge = Gtree->edges[n];
      for(int j = 1; j <= Stree->ntubes; j++) {
         EVENT* evt = edge->events[j];     // initialize event
         for(int k = 0; k < MaxEvents; k++,evt++) {
            evt->id     = id_none;
            evt->cost   = -1;    //(int)SCALE;
            evt->d1 = evt->d2 = 0;
         }
      }
   }

   if( !RunForward() ) {
      CON( printf("%4dm: Basis tree %d cost processing error: edges=%d "
         "leaves=%d(%d*) levels=%d.\n", ElapsedMin(true), Treeno, 
         Gtree->nedges, Gtree->nleaves, Gtree->nTmarks, Gtree->nlevels); )
      LOG( fprintf(Log, "%4dm: Basis tree %d cost processing error: edges=%d "
         "leaves=%d(%d*) levels=%d.\n", ElapsedMin(true), Treeno, 
         Gtree->nedges, Gtree->nleaves, Gtree->nTmarks, Gtree->nlevels); )
      return -1;
   }
   return Gtree->root->events[Stree->root->tubeno][0].cost;
}

// Select over all (pair + one) species for best initial Stree.
void     SelectInitialStree(void) {
   int      spa, spb, spc;             // triple species
   int      tc1, tc2, tc3;             // total cost for 3 topologies
   double   bestR = 0;                 // best triple reliability
   int      bestcost;                  // best total cost
   int      cost2;                     // 2nd cost
   int      besta, bestb, bestc;       // best triple & topology
   int      tripleno = 0;
   int      alltriples = nSpecies * (nSpecies-1) * (nSpecies-2) / 6;
   int      nzero = 0;
   VARINS   var;

   CON( printf("%4dm: Start building of the supertree.\n", ElapsedMin(true)); )
   CON( fflush(stdout); )
   LOG( fprintf(Log, "%4dm: Start building of the supertree.\n", ElapsedMin(true)); )
   CON( fflush(Log); )
   ClearQueue();

   for (spa = 1; spa <= nSpecies; spa++) {
      Species[spa].enable = true;

      for (spb = spa+1; spb <= nSpecies; spb++) {
         Species[spb].enable = true;

         for (spc = spb+1; spc <= nSpecies; spc++) {

            #ifdef   EMBED3MPI
            if(embed3_mpi && tripleno % size_mpi != rank_mpi) {
               ++tripleno;
               continue;
            }
            else
               ++tripleno;
            #else
            ++tripleno;
            #endif

            Species[spc].enable = true;

            if(Milestones && tripleno % Milestones == 0)
               CON( printf("S3 %d of %d\r", tripleno, alltriples); )
            tc1 = tc2 = tc3 = 0;
            // Loop over basis trees
            for (Treeno = 1; Treeno <= nBtrees; Treeno++) {
               int cost;

               PruneBasisTree( Btree[Treeno-1] );      // result in Gtree
               if( !Gtree )
                  continue;

               DBG( PrintGtree(Gtree->root, stdout, &GtreeMode); )
               DBG( if(GtreeMode.enable) printf(";\n\n"); )

               //weight -= TreeWeight ? Gtree->weight : 1.0;

               Stree->tubes[2]->specno = spa;   // 1st topology
               strncpy(Stree->tubes[2]->name, Species[spa].name, MAXNODENAME);
               Stree->tubes[3]->specno = spb;
               strncpy(Stree->tubes[3]->name, Species[spb].name, MAXNODENAME);
               Stree->tubes[4]->specno = spc;
               strncpy(Stree->tubes[4]->name, Species[spc].name, MAXNODENAME);
               cost = ComputeCost();
               tc1 += cost;

               Stree->tubes[2]->specno = spb;   // 2nd topology
               strncpy(Stree->tubes[2]->name, Species[spb].name, MAXNODENAME);
               Stree->tubes[3]->specno = spa;
               strncpy(Stree->tubes[3]->name, Species[spa].name, MAXNODENAME);
               Stree->tubes[4]->specno = spc;
               strncpy(Stree->tubes[4]->name, Species[spc].name, MAXNODENAME);
               cost = ComputeCost();
               tc2 += cost;

               Stree->tubes[2]->specno = spc;   // 3rd topology
               strncpy(Stree->tubes[2]->name, Species[spc].name, MAXNODENAME);
               Stree->tubes[3]->specno = spa;
               strncpy(Stree->tubes[3]->name, Species[spa].name, MAXNODENAME);
               Stree->tubes[4]->specno = spb;
               strncpy(Stree->tubes[4]->name, Species[spb].name, MAXNODENAME);
               cost = ComputeCost();
               tc3 += cost;

               DestructGtree();
            }

            // Analyse the triple reliability and store best data if reached 
            double R = 0.0;
            if      (tc1 < tc2 && tc1 < tc3) {
               cost2 = tc2 <= tc3 ? tc2 : tc3;
               R = (double)(cost2 - tc1) / cost2;
            }
            else if (tc2 < tc1 && tc2 < tc3) {
               cost2 = tc1 <= tc3 ? tc1 : tc3;
               R = (double)(cost2 - tc2) / cost2;
            }
            else if (tc3 < tc1 && tc3 < tc2) {
               cost2 = tc1 <= tc2 ? tc1 : tc2;
               R = (double)(cost2 - tc3) / cost2;
            }

            // Queueing
            if(R == 0.0) {
               if (!tc1 || !tc2 || !tc3) nzero++;
            }
            else {
               Stree->tubes[2]->specno = spa;   // 1st topology
               strncpy(Stree->tubes[2]->name, Species[spa].name, MAXNODENAME);
               Stree->tubes[3]->specno = spb;
               strncpy(Stree->tubes[3]->name, Species[spb].name, MAXNODENAME);
               Stree->tubes[4]->specno = spc;
               strncpy(Stree->tubes[4]->name, Species[spc].name, MAXNODENAME);
               var.cost       = tc1;
               var.cost2      = cost2;
               var.specno     = spa;
               var.oldtubeno  = spb;   // 2ndary use
               var.ontubeno   = spc;   // 2ndary use
               var.R          = R;
               var.C          = tc1 * (2 - R + r_shift);
               var.betree     = Stree2String(Stree, &StreeMode);
               Vqueue.push(var);

               Stree->tubes[2]->specno = spb;   // 2nd topology
               strncpy(Stree->tubes[2]->name, Species[spb].name, MAXNODENAME);
               Stree->tubes[3]->specno = spa;
               strncpy(Stree->tubes[3]->name, Species[spa].name, MAXNODENAME);
               Stree->tubes[4]->specno = spc;
               strncpy(Stree->tubes[4]->name, Species[spc].name, MAXNODENAME);
               var.cost       = tc2;
               var.cost2      = cost2;
               var.specno     = spb;
               var.oldtubeno  = spa;   // 2ndary use
               var.ontubeno   = spc;   // 2ndary use
               var.R          = R;
               var.C          = tc2 * (2 - R + r_shift);
               var.betree     = Stree2String(Stree, &StreeMode);
               Vqueue.push(var);

               Stree->tubes[2]->specno = spc;   // 3rd topology
               strncpy(Stree->tubes[2]->name, Species[spc].name, MAXNODENAME);
               Stree->tubes[3]->specno = spa;
               strncpy(Stree->tubes[3]->name, Species[spa].name, MAXNODENAME);
               Stree->tubes[4]->specno = spb;
               strncpy(Stree->tubes[4]->name, Species[spb].name, MAXNODENAME);
               var.cost       = tc3;
               var.cost2      = cost2;
               var.specno     = spc;
               var.oldtubeno  = spa;   // 2ndary use
               var.ontubeno   = spb;   // 2ndary use
               var.R          = R;
               var.C          = tc3 * (2 - R + r_shift);
               var.betree     = Stree2String(Stree, &StreeMode);
               Vqueue.push(var);
            }

            Species[spc].enable = false;
         }
         Species[spb].enable = false;
      }
      Species[spa].enable = false;
   }
   #ifdef   EMBED3MPI
   // Send secondary queues to root branch
   if(embed3_mpi && rank_mpi != 0) {
      int buflen = 0;
      buflen += MPI::DOUBLE.Pack_size  (2, MPI::COMM_WORLD);
      buflen += MPI::INT.Pack_size     (6, MPI::COMM_WORLD);

      while(!Vqueue.empty()) {
         var         = Vqueue.top();
         int count   = (int)var.betree.length()+1;
         int L       = MPI::CHAR.Pack_size(count, MPI::COMM_WORLD);
         L          += buflen;
         char* buf   = (char*)malloc(L);
         if(!buf) {
            CON( printf("IST: Not enough memory.\n"); )
            LOG( fprintf(Log, "IST: Not enough memory.\n"); )
            MPI::COMM_WORLD.Abort(1);
         }
         // Pack var into buf and send
         int position = 0;
         MPI::DOUBLE.Pack(&var.C,      1, buf, L, position, MPI::COMM_WORLD);
         MPI::DOUBLE.Pack(&var.R,      1, buf, L, position, MPI::COMM_WORLD);
         MPI::INT.Pack(&var.cost,      1, buf, L, position, MPI::COMM_WORLD);
         MPI::INT.Pack(&var.cost2,     1, buf, L, position, MPI::COMM_WORLD);
         MPI::INT.Pack(&var.specno,    1, buf, L, position, MPI::COMM_WORLD);
         MPI::INT.Pack(&var.oldtubeno, 1, buf, L, position, MPI::COMM_WORLD);
         MPI::INT.Pack(&var.ontubeno,  1, buf, L, position, MPI::COMM_WORLD);
         MPI::INT.Pack(&count,         1, buf, L, position, MPI::COMM_WORLD);
         MPI::CHAR.Pack(var.betree.c_str(), count, buf, L, position, MPI::COMM_WORLD);

         MPI::COMM_WORLD.Send(buf, position, MPI::PACKED, 0, tag_var);
         free(buf);
         Vqueue.pop();
      }
      // Send end-of-queue signal
      MPI::COMM_WORLD.Send(&nzero, 1, MPI::INT, 0, tag_eoq);
   }
   // Collect & process secondary queues in root branch
   else if(embed3_mpi) {
      int k = size_mpi - 1;
      while(k > 0) {
         MPI::Status status;
         MPI::COMM_WORLD.Probe(MPI::ANY_SOURCE, MPI::ANY_TAG, status);
         int from = status.Get_source();
         int nz = 0;
         if(status.Get_tag() == tag_eoq) {
            MPI::COMM_WORLD.Recv(&nz, 1, MPI::INT, from, tag_eoq);
            nzero += nz;
            k--;
            continue;
         }
         else if(status.Get_tag() == tag_var) {
            int L = status.Get_count(MPI::PACKED);
            int count;
            char* buf = (char*)malloc(L);
            if(!buf) {
               CON( printf("IST: Not enough memory.\n"); )
               LOG( fprintf(Log, "IST: Not enough memory.\n"); )
               MPI::COMM_WORLD.Abort(1);
            }
            // Recv buf and unpack to var
            MPI::COMM_WORLD.Recv(buf, L, MPI::PACKED, from, tag_var); 
            int position = 0;
            MPI::DOUBLE.Unpack(buf, L, &var.C,     1, position, MPI::COMM_WORLD); 
            MPI::DOUBLE.Unpack(buf, L, &var.R,     1, position, MPI::COMM_WORLD); 
            MPI::INT.Unpack(buf, L, &var.cost,     1, position, MPI::COMM_WORLD); 
            MPI::INT.Unpack(buf, L, &var.cost2,    1, position, MPI::COMM_WORLD); 
            MPI::INT.Unpack(buf, L, &var.specno,   1, position, MPI::COMM_WORLD); 
            MPI::INT.Unpack(buf, L, &var.oldtubeno,1, position, MPI::COMM_WORLD); 
            MPI::INT.Unpack(buf, L, &var.ontubeno, 1, position, MPI::COMM_WORLD); 
            MPI::INT.Unpack(buf, L, &count,        1, position, MPI::COMM_WORLD);
            char* str = (char*)malloc(count);
            if(!str) {
               CON( printf("IST: Not enough memory.\n"); )
               LOG( fprintf(Log, "IST: Not enough memory.\n"); )
               MPI::COMM_WORLD.Abort(1);
            }
            MPI::CHAR.Unpack(buf, L, str, count, position, MPI::COMM_WORLD);
            str[count-1] = '\0';
            var.betree.assign(str);
            Vqueue.push(var);
            free(str);
            free(buf);
         }
      }
   }
   if(embed3_mpi)
      MPI::COMM_WORLD.Barrier();

   if(!embed3_mpi || rank_mpi == 0) {
   #endif

   // Get best variant
   bestR = 0;
   if(!Vqueue.empty()) {
      var      = Vqueue.top();
      bestR    = var.R;
      bestcost = var.cost;
      cost2    = var.cost2;
      besta    = var.specno;
      bestb    = var.oldtubeno;
      bestc    = var.ontubeno;
   }

   // Optional queue logging
   if(QueueLog) {
      LOG( fprintf(Log, "\n"); )
      int n = abs(QueueLog);
      while(!Vqueue.empty() && n-- > 0) {
         var = Vqueue.top();
         if(nzero > 0) {
            LOG( fprintf(Log, "%d ambigous triples with zero cost skipped.\n", nzero); )
            nzero = 0;
         }
         LOG( fprintf(Log, "%7.2f  c2=%7.2f  R=%7.6f  Crit=%7.2f  <= %s\n", 
            var.cost/SCALE, var.cost2/SCALE, var.R, var.C/SCALE, var.betree.c_str()); )
         Vqueue.pop();
      }
      if(!Vqueue.empty()) {
         LOG( fprintf(Log, "...\n"); )
         ClearQueue();
      }
      LOG( fprintf(Log, "\n"); )
   }

   // Check if any unambiguous triple exists 
   if(bestR == 0) {
      CON( printf("IST: No unambiguous triple exists - can't build supertree.\n"); )
      LOG( fprintf(Log, "IST: No unambiguous triple exists - can't build supertree.\n"); )
      #ifdef   EMBED3MPI
      if(embed3_mpi)
         MPI::COMM_WORLD.Abort(2);
      else
      #endif
      exit(2);
   }
   #ifdef   EMBED3MPI
   }
   // Broadcast root's bestX to secondary branches
   if(embed3_mpi) {
      const int sz = 4;
      double best[sz] = { (double)besta, (double)bestb, (double)bestc, bestR };
      MPI::COMM_WORLD.Bcast(best, sz, MPI::DOUBLE, 0);
      if(rank_mpi) {
         besta = (int)best[0];
         bestb = (int)best[1];
         bestc = (int)best[2];
         bestR = best[3];
      }
   }
   #endif

   // Store resulting best Stree - All branches
   Stree->tubes[2]->specno = besta;
   Stree->tubes[2]->length = bestR;
   strncpy(Stree->tubes[2]->name, Species[besta].name, MAXNODENAME);
   Stree->tubes[3]->specno = bestb;
   Stree->tubes[3]->length = bestR;
   strncpy(Stree->tubes[3]->name, Species[bestb].name, MAXNODENAME);
   Stree->tubes[4]->specno = bestc;
   Stree->tubes[4]->length = bestR;
   strncpy(Stree->tubes[4]->name, Species[bestc].name, MAXNODENAME);

   Species[besta].enable = true;
   Species[bestb].enable = true;
   Species[bestc].enable = true;
   nIncluded = 3;

   #ifdef   EMBED3MPI
   if(!embed3_mpi || rank_mpi == 0)
   #endif
   {
      // Log resulting best Stree - Root branch only
      CON( printf("%4dm:   N=%d  TotalC=%g  R=%.6f\n", \
         ElapsedMin(true), nIncluded, bestcost/SCALE, bestR); )
      LOG( fprintf(Log, "%4dm:   N=%d  TotalC=%g  R=%.6f\n", \
         ElapsedMin(true), nIncluded, bestcost/SCALE, bestR); )
      LOG( PrintStree(Stree->root, Log, &StreeMode); )
      LOG( fprintf(Log, ";\n"); )
   }
}

// Delete given Stree
void     DeleteStree(STREE* tree) {
   if( !tree )
      return;
   // insert here
   if(tree->slices) {
      for(int h = 0; h <= tree->height; h++) {
         if(tree->slices[h].tubes) {
            free(tree->slices[h].tubes);
            if(MemoryCount)
               MemUsed[freedmem] += M16( tree->slices[h].ntubes * sizeof(TUBE*) );
         }
      }
      free(tree->slices);
      if(MemoryCount)
         MemUsed[freedmem] += M16( (tree->height+1) * sizeof(SLICE) );
   }
   if(tree->tubes) {
      for(int n = 1; n <= tree->ntubes; n++) {
         TUBE* tube = tree->tubes[n];
         if(!tube) 
            continue;
         free(tube);
         if(MemoryCount)
            MemUsed[freedmem] += M16(sizeof(TUBE));
      }
      free(tree->tubes);
      if(MemoryCount)
         MemUsed[freedmem] += M16((tree->ntubes+1)*sizeof(TUBE*));
   }
   free(tree);
   if(MemoryCount)
      MemUsed[freedmem] += M16(sizeof(STREE));
}

// Clone current Stree (excl. means) and return its pointer (NULL on errors).
STREE*   CopyStree(void) {
   STREE* tree = (STREE*)malloc(sizeof(STREE));
   if(!tree)
      goto Error;
   if(MemoryCount)
      MemUsed[speciestree] += M16(sizeof(STREE));
   memcpy(tree, Stree, sizeof(STREE));
   tree->tubes    = NULL;
   tree->root     = NULL;
   tree->slices   = NULL;

   tree->tubes    = (TUBE**)malloc((tree->ntubes+1)*sizeof(TUBE*));
   if(!tree->tubes)
      goto Error;
   if(MemoryCount)
      MemUsed[speciestree] += M16((tree->ntubes+1)*sizeof(TUBE*));
   for(int n = 0; n <= tree->ntubes; n++)
      tree->tubes[n] = NULL;

   // Allocate tubes and copy their data
   for(int n = 1; n <= tree->ntubes; n++) {
      TUBE* tube  = (TUBE*)malloc(sizeof(TUBE));
      if(!tube)
         goto Error;
      if(MemoryCount)
         MemUsed[speciestree] += M16(sizeof(TUBE));
      memcpy(tube, Stree->tubes[n], sizeof(TUBE));
      tube->parent   = NULL;
      tube->left     = NULL;
      tube->right    = NULL;
      tube->oldtube  = NULL;
      tube->mean     = NULL;
      tube->totmean  = NULL;
      tree->tubes[n] = tube;
   }
   // Interconnect tubes
   tree->root = tree->tubes[Stree->root->tubeno];
   for(int n = 1; n <= tree->ntubes; n++) {
      TUBE* tube     = tree->tubes[n];
      TUBE* tube0    = Stree->tubes[n];
      tube->parent   = tube0->parent   ? tree->tubes[tube0->parent->tubeno] : NULL;
      tube->left     = tube0->left     ? tree->tubes[tube0->left->tubeno] : NULL;
      tube->right    = tube0->right    ? tree->tubes[tube0->right->tubeno] : NULL;
      tube->oldtube  = tube0->oldtube  ? tree->tubes[tube0->oldtube->tubeno] : NULL;
   }

   // Allocate slices
   tree->slices      = (SLICE*)malloc((tree->height+1)*sizeof(SLICE));
   if(!tree->slices)
      goto Error;
   if(MemoryCount)
      MemUsed[speciestree] += M16((tree->height+1)*sizeof(SLICE));
   for(int h = 0; h <= tree->height; h++) {
      tree->slices[h].ntubes  = Stree->slices[h].ntubes;
      tree->slices[h].tubes   = NULL;
   }
   for(int h = 0; h <= tree->height; h++) {
      SLICE* slc     = tree->slices + h;
      SLICE* slc0    = Stree->slices + h;
      int ntubes     = slc->ntubes;
      slc->tubes     = (TUBE**)malloc(ntubes * sizeof(TUBE*));
      if(!slc->tubes)
         goto Error;
      if(MemoryCount)
         MemUsed[speciestree] += M16(ntubes * sizeof(TUBE*));
      for(int j = 0; j < ntubes; j++) {
         if(slc0->tubes[j]) {
            int j0 = slc0->tubes[j]->tubeno;
            slc->tubes[j] = tree->tubes[j0];
         }
         else
            slc->tubes[j] = NULL;
      }
   }
   return tree;
Error:
   if(tree)
      DeleteStree(tree);
   return NULL;
}

// Append new leaf (along with additional nodes) to the given node.
// Return the leaf pointer or NULL on errors.
TUBE*    HangNewLeaf(TUBE* tube) {
   int ntubes;
   TUBE* leaf  = NULL;
   TUBE* node  = NULL;
   if(!tube || (tube->left && tube->right) || (!tube->left && !tube->right))
      goto Error;
   leaf  = (TUBE*)malloc(sizeof(TUBE));
   if(!leaf)
      goto Error;
   if(MemoryCount)
      MemUsed[speciestree] += M16(sizeof(TUBE));

   leaf->tubeno   = Stree->ntubes + 1;
   Stree->nleaves++;
   leaf->left     = NULL;
   leaf->right    = NULL;
   leaf->oldtube  = leaf;
   Stree->noldtubes++;
   leaf->height   = 0;
   leaf->mean     = NULL;
   leaf->totmean  = NULL;
   leaf->length   = 1.0;
   leaf->specno   = 0;
   leaf->name[0]  = 0;

   ntubes         = ++Stree->slices[0].ntubes;
   Stree->slices[0].tubes = (TUBE**)realloc(Stree->slices[0].tubes, 
                                             ntubes * sizeof(TUBE*));
   if(!Stree->slices[0].tubes)
      goto Error;
   if(MemoryCount)
      MemUsed[speciestree] += M16(sizeof(TUBE*));
   Stree->slices[0].tubes[ntubes-1] = leaf;

   Stree->ntubes += tube->height;
   Stree->tubes   = (TUBE**)realloc(Stree->tubes, 
                                    (Stree->ntubes+1) * sizeof(TUBE*));
   if(!Stree->tubes)
      goto Error;
   if(MemoryCount)
      MemUsed[speciestree] += M16(tube->height * sizeof(TUBE*));
   Stree->tubes[leaf->tubeno] = leaf;
   
   node = leaf;
   while(tube->height > node->height + 1) {
      TUBE* newnode = (TUBE*)malloc(sizeof(TUBE));
      if(!newnode)
         goto Error;
      if(MemoryCount)
         MemUsed[speciestree] += M16(sizeof(TUBE));

      node->parent      = newnode;
      newnode->height   = node->height + 1;
      newnode->tubeno   = leaf->tubeno + newnode->height;
      Stree->tubes[newnode->tubeno] = newnode;
      Stree->ninteriors++;
      newnode->left     = node;
      newnode->right    = NULL;
      newnode->oldtube  = leaf;
      newnode->mean     = NULL;
      newnode->totmean  = NULL;
      newnode->length   = 1.0;
      newnode->specno   = 0;
      newnode->name[0]  = 0;

      int h             = newnode->height;
      int ntubes        = ++Stree->slices[h].ntubes;
      Stree->slices[h].tubes = (TUBE**)realloc(Stree->slices[h].tubes, 
                                                ntubes * sizeof(TUBE*));
      if(!Stree->slices[h].tubes)
         goto Error;
      if(MemoryCount)
         MemUsed[speciestree] += M16(sizeof(TUBE*));
      Stree->slices[h].tubes[ntubes-1] = newnode;

      node              = newnode;
   }

   node->parent   = tube;
   if(tube->right) {
      tube->left  = tube->right;
      tube->right = NULL;
   }
   tube->right    = node;
   // This node becomes old
   tube->oldtube  = tube;
   Stree->noldtubes++;
   return leaf;

Error:
   TUBE* parent;
   while(leaf) {
      int n  = leaf->specno;
      if(Stree->ntubes >= n)
         Stree->tubes[n] = NULL;
      if(leaf->oldtube == leaf) {
         Stree->nleaves--;
         Stree->noldtubes--;
      }
      else
         Stree->ninteriors--;
      int h  = leaf->height;
      int ntubes = Stree->slices[h].ntubes;
      if(Stree->slices[h].tubes[ntubes-1] == leaf) {
         Stree->slices[h].tubes[ntubes-1] = NULL;
         Stree->slices[h].ntubes--;
      }
      parent = leaf->parent; 
      free(leaf);
      if(MemoryCount)
         MemUsed[freedmem] += M16(sizeof(TUBE));
      leaf = parent;
   }
   return NULL;
}

// Add new node on the given tube and return its pointer.
// Do not modify slices & heights above the new node.
TUBE*    AddNewAbove(TUBE* tube) {
   int h, ntubes;
   TUBE* node = (TUBE*)malloc(sizeof(TUBE));
   if(!node)
      goto Error;
   if(MemoryCount)
      MemUsed[speciestree] += M16(sizeof(TUBE));

   Stree->ninteriors++;
   node->parent   = tube->parent;
   if(node->parent->left == tube)
      node->parent->left = node;
   else if(node->parent->right == tube)
      node->parent->right = node;
   else {
      CON( printf("ANA: Internal error in Stree.\n"); )
      LOG( fprintf(Log, "ANA: Internal error in Stree.\n"); )
      goto Error;
   }
   tube->parent   = node;
   node->left     = tube;
   node->right    = NULL;
   node->oldtube  = tube->oldtube;
   node->mean     = NULL;
   node->totmean  = NULL;
   node->length   = 1.0;
   node->specno   = 0;
   node->name[0]  = 0;

   h              = tube->height + 1;
   ntubes         = ++Stree->slices[h].ntubes;
   node->height   = h;
   Stree->slices[h].tubes = (TUBE**)realloc(Stree->slices[h].tubes, 
                                             ntubes * sizeof(TUBE*));
   if(!Stree->slices[h].tubes)
      goto Error;
   if(MemoryCount)
      MemUsed[speciestree] += M16(sizeof(TUBE*));
   Stree->slices[h].tubes[ntubes-1] = node;


   node->tubeno   = ++Stree->ntubes;
   Stree->tubes   = (TUBE**)realloc(Stree->tubes, 
                                    (Stree->ntubes+1) * sizeof(TUBE*));
   if(!Stree->tubes)
      goto Error;
   if(MemoryCount)
      MemUsed[speciestree] += M16(sizeof(TUBE*));
   Stree->tubes[Stree->ntubes] = node;

   return node;

Error:
   return NULL;
}

// Renumber tubes according to slices
void     RearrangeTubes(void) {
   int n = 0;
   for(int h = 0; h <= Stree->height; h++) {
      int ntubes = Stree->slices[h].ntubes;
      for(int j = 0; j < ntubes; j++) {
         TUBE* tube = Stree->slices[h].tubes[j];
         ++n;
         if(tube->name[0] && atoi(tube->name) == tube->tubeno)
            sprintf(tube->name, "%d", n);
         tube->tubeno = n;
         Stree->tubes[n] = tube;
      }
   }
}

// Make an induction step. Return false if can't continue.
bool     MakeInductionStep(void) {
   int errortype = 0;
   VARINS   var;
   var.cost = -1;
   vector<VARINS> Vspecies(nSpecies+1, var);
   STREE* StreeOld   = Stree;
   TUBE*  tube       = NULL; 
   ClearQueue();

//#define SPTRACE 31

   // Loop over tubes excl. outgroup & root
   for(int n = 2; n <= Stree->ntubes; n++) {

      #ifdef   EMBED3MPI
      if(embed3_mpi && (n-2) % size_mpi != rank_mpi)
         continue;
      #endif

      tube = Stree->tubes[n];
      if(!tube->parent || tube->oldtube->tubeno == 1)
         continue;               // skip root and outgroup tubes
      int oldno = tube->oldtube->tubeno;

      if(Milestones) {
         CON( printf("TUBE %d of %d\r", n, Stree->ntubes); )
      }

      Stree = CopyStree();
      if(!Stree) {
         CON( printf("MIS: Cannot clone current Stree.\n"); )
         LOG( fprintf(Log, "MIS: Cannot clone current Stree.\n"); )
         errortype = 4;
         goto Error;
      }
      tube = Stree->tubes[n];    // now points to new copy

      // node-related variant of addition
      if(tube->oldtube != tube) {
         assert((tube->left && !tube->right) || (!tube->left && tube->right));
         TUBE* leaf = HangNewLeaf(tube);
         if(!leaf) {
            CON( printf("MIS: Cannot hang new leaf to node #%d.\n", tube->tubeno); )
            LOG( fprintf(Log, "MIS: Cannot hang new leaf to node #%d.\n", tube->tubeno); )
            errortype = 4;
            goto Error;
         }
         // Arrange tubes in a proper order
         RearrangeTubes();

         // New table of distances
         if( !FillTubeDistances() ) {
            CON( printf("MIS: Cannot create table of tube distances.\n"); )
            LOG( fprintf(Log, "MIS: Cannot create table of tube distances.\n"); )
            errortype = 4;
            goto Error;
         }

         // Try each remaining species at this leaf
         var.ontubeno   = -n;   // - 'cause node-related addition
         var.oldtubeno  = oldno;
         var.R          = -1.0;
         var.C          = 0.0;
         var.cost2      = 0;
         for(int sp = 1; sp <= nSpecies; sp++) {
            if(Species[sp].enable)
               continue;
            Species[sp].enable   = true;
            leaf->specno         = sp;
            int totalcost        = 0;

#ifdef SPTRACE
            if(sp == SPTRACE) {
               fprintf(Log, "\nAdding %s at node %d:\n", Species[sp].name, n);
            }
#endif
            // Loop over basis trees
            for (Treeno = 1; Treeno <= nBtrees; Treeno++) {
               int cost;

               PruneBasisTree( Btree[Treeno-1] );      // result in Gtree
               if( !Gtree )
                  continue;

               cost = ComputeCost();
               totalcost += cost;
#ifdef SPTRACE
               if(sp == SPTRACE) {
                  fprintf(Log, "%7.1f <= ", cost/SCALE); 
                  PrintGtree(Gtree->root, Log, &GtreeMode);
                  fprintf(Log, ";\n");
               }
#endif
               DestructGtree();
            }

            var.cost             = totalcost;
            var.specno           = sp;
            var.betree           = Stree2String(Stree, &StreeMode);
            Vqueue.push(var);

            Species[sp].enable   = false;
         }
         DeleteStree(Stree);
         Stree = StreeOld;
         Stree = CopyStree();
         if(!Stree) {
            CON( printf("MIS: Cannot clone current Stree.\n"); )
            LOG( fprintf(Log, "MIS: Cannot clone current Stree.\n"); )
            errortype = 4;
            goto Error;
         }
         tube = Stree->tubes[n];    // now points to new copy
      }
      // edge-related variant of addition
      TUBE* newnode = AddNewAbove(tube);
      if(!newnode) {
         CON( printf("MIS: Cannot add new node on tube #%d.\n", tube->tubeno); )
         LOG( fprintf(Log, "MIS: Cannot add new node on tube #%d.\n", tube->tubeno); )
         errortype = 4;
         goto Error;
      }

      TUBE* leaf = HangNewLeaf(newnode);
      if(!leaf) {
         CON( printf("MIS: Cannot hang new leaf to new node above #%d.\n", tube->tubeno); )
         LOG( fprintf(Log, "MIS: Cannot hang new leaf to new node above #%d.\n", tube->tubeno); )
         errortype = 4;
         goto Error;
      }

      // Increase tree height and prepare upper slice
      Stree->height++;
      Stree->slices = (SLICE*)realloc(Stree->slices, (Stree->height+1)*sizeof(SLICE));
      if(!Stree->slices) {
         CON( printf("MIS: No memory - cannot reallocate array of slices.\n"); )
         LOG( fprintf(Log, "MIS: No memory - cannot reallocate array of slices.\n"); )
         errortype = 1;
         goto Error;
      }
      if(MemoryCount)
         MemUsed[speciestree] += M16(sizeof(SLICE));
      Stree->slices[Stree->height].ntubes = 0;
      Stree->slices[Stree->height].tubes  = NULL;

      TUBE* node     = newnode;
      TUBE* parent   = newnode->parent;
      while(parent) {

         // remove parent from slice[node->height]
         int h = node->height;
         SLICE* slc = Stree->slices + h;
         int k;
         for(k = 0; k < slc->ntubes; k++)
            if(slc->tubes[k] == parent)
               break;
         if(k >= slc->ntubes) {
            CON( printf("MIS: Internal error - cannot find a node in its slice.\n"); )
            LOG( fprintf(Log, "MIS: Internal error - cannot find a node in its slice.\n"); )
            errortype = 4;
            goto Error;
         }
         for( ; k < slc->ntubes - 1; k++)
            slc->tubes[k] = slc->tubes[k+1];
         slc->ntubes--;
         slc->tubes[slc->ntubes] = NULL;

         // add parent to slice[node->height+1]
         h++;
         slc++;
         parent->height = h;
         slc->ntubes++;
         slc->tubes = (TUBE**)realloc(slc->tubes, slc->ntubes * sizeof(TUBE*));
         if(!slc->tubes) {
            CON( printf("MIS: No memory - cannot reallocate a slice.\n"); )
            LOG( fprintf(Log, "MIS: No memory - cannot reallocate a slice.\n"); )
            errortype = 1;
            goto Error;
         }
         if(MemoryCount)
            MemUsed[speciestree] += M16(sizeof(TUBE*));
         slc->tubes[slc->ntubes-1] = parent;

         // add a new node on each tube that branches off our path to root
         if(parent->left && parent->left != node)
            AddNewAbove(parent->left);
         else if(parent->right && parent->right != node)
            AddNewAbove(parent->right);

         node     = parent;
         parent   = node->parent;
      }
      // Special case of the before upper slice
      SLICE* slc = Stree->slices + Stree->height - 1;
      if(slc->ntubes != 2) {
         CON( printf("MIS: Internal error - nonbinary root.\n"); )
         LOG( fprintf(Log, "MIS: Internal error - nonbinary root.\n"); )
         errortype = 4;
         goto Error;
      }
      if(slc->tubes[1]->oldtube->tubeno == 1) {
         TUBE* tmp      = slc->tubes[0];
         slc->tubes[0]  = slc->tubes[1];
         slc->tubes[1]  = tmp;
      }
      else if(slc->tubes[0]->oldtube->tubeno != 1) {
         CON( printf("MIS: Internal error - outgroup tube not found form the root.\n"); )
         LOG( fprintf(Log, "MIS: Internal error - outgroup tube not found form the root.\n"); )
         errortype = 4;
         goto Error;
      }

      // Arrange tubes in a proper order
      RearrangeTubes();

      // New table of distances
      if( !FillTubeDistances() ) {
         CON( printf("MIS: Cannot create table of tube distances.\n"); )
         LOG( fprintf(Log, "MIS: Cannot create table of tube distances.\n"); )
         errortype = 4;
         goto Error;
      }

      // Try each remaining species at new leaf
      var.ontubeno   = n;      // + 'cause edge-related addition
      var.oldtubeno  = oldno;
      var.R          = -1.0;
      var.C          = 0.0;
      var.cost2      = 0;
      for(int sp = 1; sp <= nSpecies; sp++) {
         if(Species[sp].enable)
            continue;
         Species[sp].enable   = true;
         leaf->specno         = sp;
         int totalcost        = 0;

#ifdef SPTRACE
         if(sp == SPTRACE) {
            fprintf(Log, "\nAdding %s on tube %d:\n", Species[sp].name, n);
         }
#endif
         // Loop over basis trees
         for (Treeno = 1; Treeno <= nBtrees; Treeno++) {
            int cost;

            PruneBasisTree( Btree[Treeno-1] );      // result in Gtree
            if( !Gtree )
               continue;

            cost = ComputeCost();
            totalcost += cost;
#ifdef SPTRACE
               if(sp == SPTRACE) {
                  fprintf(Log, "%7.1f <= ", cost/SCALE); 
                  PrintGtree(Gtree->root, Log, &GtreeMode);
                  fprintf(Log, ";\n");
               }
#endif
            DestructGtree();
         }

         var.cost             = totalcost;
         var.specno           = sp;
         var.betree           = Stree2String(Stree, &StreeMode);
         Vqueue.push(var);

         Species[sp].enable   = false;
      }

      DeleteStree(Stree);
      Stree = StreeOld;
   }

   #ifdef   EMBED3MPI
   if(embed3_mpi) {
      // Collect 2ndary queues into root's queue
      if(rank_mpi != 0) {
         int buflen = 0;
         buflen += MPI::DOUBLE.Pack_size  (2, MPI::COMM_WORLD);
         buflen += MPI::INT.Pack_size     (6, MPI::COMM_WORLD);

         while(!Vqueue.empty()) {
            var         = Vqueue.top();
            int count   = (int)var.betree.length()+1;
            int L       = MPI::CHAR.Pack_size(count, MPI::COMM_WORLD);
            L          += buflen;
            char* buf   = (char*)malloc(L);
            if(!buf) {
               CON( printf("MIS: Not enough memory.\n"); )
               LOG( fprintf(Log, "MIS: Not enough memory.\n"); )
               errortype = 4;
               goto Error;
               //MPI::COMM_WORLD.Abort(1);
            }
            // Pack var into buf and send
            int position = 0;
            MPI::DOUBLE.Pack(&var.C,      1, buf, L, position, MPI::COMM_WORLD);
            MPI::DOUBLE.Pack(&var.R,      1, buf, L, position, MPI::COMM_WORLD);
            MPI::INT.Pack(&var.cost,      1, buf, L, position, MPI::COMM_WORLD);
            MPI::INT.Pack(&var.cost2,     1, buf, L, position, MPI::COMM_WORLD);
            MPI::INT.Pack(&var.specno,    1, buf, L, position, MPI::COMM_WORLD);
            MPI::INT.Pack(&var.oldtubeno, 1, buf, L, position, MPI::COMM_WORLD);
            MPI::INT.Pack(&var.ontubeno,  1, buf, L, position, MPI::COMM_WORLD);
            MPI::INT.Pack(&count,         1, buf, L, position, MPI::COMM_WORLD);
            MPI::CHAR.Pack(var.betree.c_str(), count, buf, L, position, MPI::COMM_WORLD);

            MPI::COMM_WORLD.Send(buf, position, MPI::PACKED, 0, tag_var);
            free(buf);
            Vqueue.pop();
         }
         // Send end-of-queue signal
         int dummy;
         MPI::COMM_WORLD.Send(&dummy, 1, MPI::INT, 0, tag_eoq);
      }
      else {
         // Collect & process secondary queues in root branch
         int k = size_mpi - 1;
         while(k > 0) {
            MPI::Status status;
            MPI::COMM_WORLD.Probe(MPI::ANY_SOURCE, MPI::ANY_TAG, status);
            int from = status.Get_source();
            if(status.Get_tag() == tag_eoq) {
               MPI::COMM_WORLD.Recv(&from, 1, MPI::INT, from, tag_eoq);
               k--;
               continue;
            }
            else if(status.Get_tag() == tag_var) {
               int L = status.Get_count(MPI::PACKED);
               int count;
               char* buf = (char*)malloc(L);
               if(!buf) {
                  CON( printf("MIS: Not enough memory.\n"); )
                  LOG( fprintf(Log, "MIS: Not enough memory.\n"); )
                  errortype = 4;
                  goto Error;
                  //MPI::COMM_WORLD.Abort(1);
               }
               // Recv buf and unpack to var
               MPI::COMM_WORLD.Recv(buf, L, MPI::PACKED, from, tag_var); 
               int position = 0;
               MPI::DOUBLE.Unpack(buf, L, &var.C,     1, position, MPI::COMM_WORLD); 
               MPI::DOUBLE.Unpack(buf, L, &var.R,     1, position, MPI::COMM_WORLD); 
               MPI::INT.Unpack(buf, L, &var.cost,     1, position, MPI::COMM_WORLD); 
               MPI::INT.Unpack(buf, L, &var.cost2,    1, position, MPI::COMM_WORLD); 
               MPI::INT.Unpack(buf, L, &var.specno,   1, position, MPI::COMM_WORLD); 
               MPI::INT.Unpack(buf, L, &var.oldtubeno,1, position, MPI::COMM_WORLD); 
               MPI::INT.Unpack(buf, L, &var.ontubeno, 1, position, MPI::COMM_WORLD); 
               MPI::INT.Unpack(buf, L, &count,        1, position, MPI::COMM_WORLD);
               char* str = (char*)malloc(count);
               if(!str) {
                  CON( printf("IST: Not enough memory.\n"); )
                  LOG( fprintf(Log, "IST: Not enough memory.\n"); )
                  errortype = 4;
                  goto Error;
                  //MPI::COMM_WORLD.Abort(1);
               }
               MPI::CHAR.Unpack(buf, L, str, count, position, MPI::COMM_WORLD);
               str[count-1] = '\0';
               var.betree.assign(str);
               Vqueue.push(var);
               free(str);
               free(buf);
            }
         }
      }
      MPI::COMM_WORLD.Barrier();
   }
   if(!embed3_mpi || rank_mpi == 0)
   #endif

   {           // Root branch only
      // Make a copy of the queue to use as a last hope
      priority_queue <VARINS, vector<VARINS>, LessCost> Vqtemp(Vqueue);

      // Analyze initial queue
      if(QueueLog < 0) {
         priority_queue <VARINS, vector<VARINS>, LessCost> Vq2(Vqueue);
         LOG( fprintf(Log, "\nInitial queue\n"); )
         int k = abs(QueueLog);
         while(!Vq2.empty() && k-- > 0) {
            var = Vq2.top();
#ifdef SPTRACE
            if(var.specno != SPTRACE) {
               Vq2.pop();
               k++;
               continue;
            }
#endif
            LOG( fprintf(Log, "%7.1f  sp=%3d  old=%3d  on=%4d  <= %s\n", var.cost/SCALE, 
               var.specno, var.oldtubeno, var.ontubeno, var.betree.c_str()); )
            Vq2.pop();
         }
         if(!Vq2.empty()) {
            LOG( fprintf(Log, "...\n"); )
            while(!Vq2.empty()) 
               Vq2.pop();
         }
      }
      // Fill array of variants calculating reliability and criterion.
      while(!Vqueue.empty()) {
         var    = Vqueue.top();
         int sp = var.specno;
         if(Vspecies[sp].cost < 0)
            Vspecies[sp] = var;
         else if(Vspecies[sp].R < 0 && var.oldtubeno != Vspecies[sp].oldtubeno) {
            Vspecies[sp].R = (var.cost == 0) ? 0 :
               (double)(var.cost - Vspecies[sp].cost) / var.cost;
            Vspecies[sp].C = Vspecies[sp].cost * (2 - Vspecies[sp].R + r_shift);
            Vspecies[sp].cost2 = var.cost;
            // Insert actual reliability in the tree record.
            string token = Species[sp].name;
            token.append(":1");
            string::size_type pos = Vspecies[sp].betree.find(token);
            if(pos == string::npos) {
               CON( printf("MIS: Cannot find added species in the tree record.\n"); )
               LOG( fprintf(Log, "MIS: Cannot find added species in the tree record.\n"); )
               errortype = 4;
               goto Error;
            }
            else
               pos += strlen(Species[sp].name) + 1;
            Vspecies[sp].betree.erase(pos, 1);
            char num[16];
            sprintf(num, "%8.6f", Vspecies[sp].R);
            Vspecies[sp].betree.insert(pos, num);
         }
         Vqueue.pop();
      }
      // Fill refined queue
      int nzero = 0;
      for(int sp = 1; sp <= nSpecies; sp++) {
         var = Vspecies[sp];
         if(var.cost < 0)
            continue;
         if(var.R < 0) {
            var.R = 1.0;
            var.C = var.cost * (1 + r_shift);
            var.cost2 = INT_MAX;
         }
         else if(var.R == 0.0) {
            nzero++;
            continue;
         }
         Vqueue.push(var);
      }

      // Make a choice if possible
      if(Vqueue.empty()) {
         // Cannot continue, print variants for each species
         for(int sp = 1; sp <= nSpecies; sp++)
            Vspecies[sp].cost = -1;
         LOG( fprintf(Log, "\nAmbiguous variants:\n"); )
         while(!Vqtemp.empty()) {
            var = Vqtemp.top();
            int sp = var.specno;
            if(Vspecies[sp].cost < 0) {
               Vspecies[sp] = var;
               LOG( fprintf(Log, "%7.1f  sp=%3d  old=%3d  on=%4d  <= %s\n", var.cost/SCALE, 
                  var.specno, var.oldtubeno, var.ontubeno, var.betree.c_str()); )
            }
            else if(var.cost == Vspecies[sp].cost && 
                    var.oldtubeno != Vspecies[sp].oldtubeno) {
               LOG( fprintf(Log, "%7.1f  sp=%3d  old=%3d  on=%4d  <= %s\n", var.cost/SCALE, 
                  var.specno, var.oldtubeno, var.ontubeno, var.betree.c_str()); )
            }
            Vqtemp.pop();
         }
         LOG( fprintf(Log, "\n"); )
         errortype = 0;
         goto Error;
      }
      else {
         while(!Vqtemp.empty()) 
            Vqtemp.pop();
      }
      // Best choice
      var = Vqueue.top();

      // Optional queue logging
      if(QueueLog) {
         LOG( fprintf(Log, "\nFinal queue"); )
         if(nzero) {
            LOG( fprintf(Log, " (%d ambiguous variants skipped)\n", 
               nzero); )
         }
         else {
            LOG( fprintf(Log, "\n"); )
         }
         int n = abs(QueueLog);
         while(!Vqueue.empty() && n-- > 0) {
            VARINS v = Vqueue.top();
            LOG( fprintf(Log, "%7.1f  c2=%7.1f  R=%8.6f  Crit=%7.1f  sp=%3d  "
               "on=%4d  <= %s\n", v.cost/SCALE, v.cost2/SCALE, v.R, v.C/SCALE, 
               v.specno, v.ontubeno, v.betree.c_str()); )
            Vqueue.pop();
         }
         if(!Vqueue.empty()) {
            LOG( fprintf(Log, "...\n"); )
            ClearQueue();
         }
         LOG( fprintf(Log, "\n"); )
      }

      // Modify/write Stree and log the induction process
      int len   = (int)var.betree.length() + 1;
      char *str = (char*)malloc(len);
      if(!str) {
         CON( printf("MIS: No memory for the tree string.\n"); )
         LOG( fprintf(Log, "MIS: No memory for the tree string.\n"); )
         errortype = 1;
         goto Error;
      }
      strcpy(str, var.betree.c_str());
      #ifdef   EMBED3MPI
      if(embed3_mpi) {
         // Bcast var.specno and str to 2ndary branches
         int data[2] = { var.specno, len };
         MPI::COMM_WORLD.Bcast(data, 2, MPI::INT, 0);
         MPI::COMM_WORLD.Bcast(str, len, MPI::CHAR, 0);
      }
      #endif
      if(!ReadSpeciesTree(str)) {
         errortype = 4;
         goto Error;
      }
      free(str);
      CON( printf("%4dm:   N=%d (#%d=%s added %s %d)  TotalC=%g  R=%8.6f\n", 
         ElapsedMin(true), nIncluded, var.specno, Species[var.specno].name, 
         (var.ontubeno > 0 ? "on tube" : "at node"), abs(var.ontubeno), 
         var.cost/SCALE, var.R); )
      CON( fflush(stdout); )
      LOG( fprintf(Log, "%4dm:   N=%d (#%d=%s added %s %d)  TotalC=%g  R=%8.6f\n", 
         ElapsedMin(true), nIncluded, var.specno, Species[var.specno].name, 
         (var.ontubeno > 0 ? "on tube" : "at node"), abs(var.ontubeno), 
         var.cost/SCALE, var.R); )
      LOG( PrintStree(Stree->root, Log, &StreeMode); )
      LOG( fprintf(Log, ";\n"); fflush(Log); )
      Species[var.specno].enable = true;
   }
   #ifdef   EMBED3MPI
   if(embed3_mpi && rank_mpi != 0) {   // Secondary branches only
      int data[2];
      MPI::COMM_WORLD.Bcast(data, 2, MPI::INT, 0);
      Species[data[0]].enable = true;
      int len   = data[1];
      char *str = (char*)malloc(len);
      if(!str) {
         CON( printf("MIS: No memory for the tree string.\n"); )
         LOG( fprintf(Log, "MIS: No memory for the tree string.\n"); )
         errortype = 1;
         goto Error;
      }
      MPI::COMM_WORLD.Bcast(str, len, MPI::CHAR, 0);
      if(!ReadSpeciesTree(str)) {
         errortype = 4;
         goto Error;
      }
      free(str);
   }

   if(embed3_mpi)
      MPI::COMM_WORLD.Barrier();
   #endif

   return true;
Error:
   if(errortype) {
      #ifdef   EMBED3MPI
      printf("MIS: Aborting due to error %d in branch %d.\n", errortype, rank_mpi);
      fflush(stdout);
      if(embed3_mpi)
         MPI::COMM_WORLD.Abort(errortype);
      else
         exit(errortype);
      #else
      CON( printf("MIS: Aborting due to error %d.\n", errortype); )
      CON( fflush(stdout); )
      exit(errortype);
      #endif
   }
   DeleteStree(Stree);
   Stree = StreeOld;
   return false;
}
